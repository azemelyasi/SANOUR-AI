"""Offline tests for the OpenAI provider. No network, no real key, no real SDK required.

The fake client and fake SDK error classes below exist only in this test module.
"""

import importlib.util
import logging
import os
import subprocess
import sys
import time
import unittest
from types import SimpleNamespace
from unittest import mock

from pydantic import SecretStr

from sanour_ai.config.settings import ConfigError
from sanour_ai.errors import ErrorCode, SanourError
from sanour_ai.models.base import ModelCall, ModelProvider, ModelResult, ProviderError
from sanour_ai.models.capabilities import ModelCapabilities, ModelProfile
from sanour_ai.models.gateway import ModelGateway
from sanour_ai.providers import openai_provider as op
from sanour_ai.providers.openai_provider import (
    CONNECT_TIMEOUT_S,
    POOL_TIMEOUT_S,
    READ_TIMEOUT_S,
    WRITE_TIMEOUT_S,
    OpenAIProvider,
    RateLimitedError,
    SdkErrorTypes,
    load_api_key,
)

SECRET = "sk-FAKETESTKEY0123456789ABCDEF"  # fake, test-only


class FakeSdkError(Exception):
    def __init__(self, text="raw server text with " + SECRET, status_code=None):
        super().__init__(text)
        self.status_code = status_code


class FakeOpenAIError(FakeSdkError): ...
class FakeAuth(FakeOpenAIError): ...
class FakePerm(FakeOpenAIError): ...
class FakeNotFound(FakeOpenAIError): ...
class FakeRateLimit(FakeOpenAIError): ...
class FakeInternal(FakeOpenAIError): ...
class FakeStatus(FakeOpenAIError): ...
class FakeConn(FakeOpenAIError): ...
class FakeTimeout(FakeConn): ...  # subclass, as in the real SDK


FAKE_ERRORS = SdkErrorTypes(
    base=FakeOpenAIError,
    authentication=FakeAuth,
    permission_denied=FakePerm,
    not_found=FakeNotFound,
    rate_limit=FakeRateLimit,
    internal_server=FakeInternal,
    api_timeout=FakeTimeout,
    api_connection=FakeConn,
    api_status=FakeStatus,
)


class FakeClient:
    def __init__(self, outcome=None):
        self.calls = []
        self._outcome = outcome
        self.responses = SimpleNamespace(create=self._create)

    def _create(self, **kwargs):
        self.calls.append(kwargs)
        if isinstance(self._outcome, BaseException):
            raise self._outcome
        if callable(self._outcome):
            return self._outcome()
        return self._outcome or SimpleNamespace(output_text="hello", model="gpt-test")


def tuple_timeout(remaining):
    return (
        min(CONNECT_TIMEOUT_S, remaining),
        min(READ_TIMEOUT_S, remaining),
        min(WRITE_TIMEOUT_S, remaining),
        min(POOL_TIMEOUT_S, remaining),
    )


class _TestOnlyUnvalidatedProvider(OpenAIProvider):
    """TEST ONLY. Skips client validation so a fake client can drive the adapter.

    Defined here, never in src/. Production code always runs the real validation.
    """

    def _check_client(self, client, api_key):
        return None


def make_provider(outcome=None):
    client = FakeClient(outcome)
    provider = _TestOnlyUnvalidatedProvider(
        SecretStr(SECRET), client=client, errors=FAKE_ERRORS, timeout_factory=tuple_timeout,
    )
    return provider, client


def call(model="gpt-test", seconds=5.0):
    return ModelCall(
        model_id=model, prompt="hi", max_output_tokens=64, deadline=time.monotonic() + seconds
    )


class ApiKeyTests(unittest.TestCase):
    def test_missing_key_raises_without_echo(self):
        with self.assertRaises(ConfigError) as ctx:
            load_api_key({})
        self.assertIn(op.ENV_OPENAI_API_KEY, str(ctx.exception))

    def test_blank_key_rejected(self):
        with self.assertRaises(ConfigError):
            load_api_key({op.ENV_OPENAI_API_KEY: "   "})

    def test_key_read_from_env_and_not_leaked_in_repr(self):
        key = load_api_key({op.ENV_OPENAI_API_KEY: SECRET})
        self.assertIsInstance(key, SecretStr)
        self.assertNotIn(SECRET, repr(key))
        self.assertNotIn(SECRET, str(key))

    def test_key_not_leaked_through_provider_errors(self):
        provider, _ = make_provider(FakeAuth("bad key " + SECRET, status_code=401))
        with self.assertRaises(ProviderError) as ctx:
            provider.generate(call())
        self.assertNotIn(SECRET, str(ctx.exception))
        self.assertNotIn(SECRET, repr(ctx.exception))

    def test_default_client_built_with_zero_retries(self):
        fake_openai = mock.Mock()
        fake_httpx2 = mock.Mock()
        with mock.patch.dict("sys.modules", {"openai": fake_openai, "httpx2": fake_httpx2}):
            op._build_default_client(SecretStr(SECRET))
        fake_openai.OpenAI.assert_called_once_with(
            api_key=SECRET, base_url=op.PINNED_BASE_URL, max_retries=0,
            http_client=fake_httpx2.Client.return_value,
        )
        fake_httpx2.Client.assert_called_once_with(trust_env=False)


class TimeoutTypeTests(unittest.TestCase):
    def test_default_timeout_uses_httpx2_with_capped_values(self):
        fake_httpx2 = mock.Mock()
        with mock.patch.dict(sys.modules, {"httpx2": fake_httpx2}):
            op._default_timeout(0.5)
        fake_httpx2.Timeout.assert_called_once_with(connect=0.5, read=0.5, write=0.5, pool=0.5)

    def test_default_timeout_uses_configured_values_for_large_budget(self):
        fake_httpx2 = mock.Mock()
        with mock.patch.dict(sys.modules, {"httpx2": fake_httpx2}):
            op._default_timeout(60)
        fake_httpx2.Timeout.assert_called_once_with(
            connect=CONNECT_TIMEOUT_S, read=READ_TIMEOUT_S,
            write=WRITE_TIMEOUT_S, pool=POOL_TIMEOUT_S,
        )

    @unittest.skipUnless(
        importlib.util.find_spec("httpx2") is not None,
        "httpx2 2.13.1 not installed here; real-type check runs only where it is",
    )
    def test_real_httpx2_timeout_type(self):
        import httpx2

        value = op._default_timeout(0.5)
        self.assertIsInstance(value, httpx2.Timeout)
        self.assertLessEqual(value.read, 0.5)


class DeadlineTests(unittest.TestCase):
    def test_expired_deadline_fails_before_any_io(self):
        provider, client = make_provider()
        expired = ModelCall(model_id="gpt-test", prompt="x", max_output_tokens=8,
                            deadline=time.monotonic() - 1)
        with self.assertRaises(ProviderError) as ctx:
            provider.generate(expired)
        self.assertTrue(ctx.exception.retryable)
        self.assertEqual(client.calls, [])

    def test_missing_deadline_fails_before_any_io(self):
        provider, client = make_provider()
        with self.assertRaises(ProviderError) as ctx:
            provider.generate(ModelCall(model_id="gpt-test", prompt="x", max_output_tokens=8))
        self.assertFalse(ctx.exception.retryable)
        self.assertEqual(client.calls, [])

    def test_four_timeouts_capped_by_remaining_budget(self):
        provider, client = make_provider()
        provider.generate(call(seconds=0.5))
        timeout = client.calls[0]["timeout"]
        self.assertEqual(len(timeout), 4)
        for value in timeout:
            self.assertLessEqual(value, 0.5)
            self.assertGreater(value, 0)

    def test_timeouts_use_configured_values_when_budget_is_large(self):
        provider, client = make_provider()
        provider.generate(call(seconds=60))
        self.assertEqual(
            client.calls[0]["timeout"],
            (CONNECT_TIMEOUT_S, READ_TIMEOUT_S, WRITE_TIMEOUT_S, POOL_TIMEOUT_S),
        )

    def test_late_response_is_discarded(self):
        def slow():
            time.sleep(0.05)
            return SimpleNamespace(output_text="late", model="gpt-test")

        provider, _ = make_provider(slow)
        with self.assertRaises(ProviderError) as ctx:
            provider.generate(call(seconds=0.01))
        self.assertTrue(ctx.exception.retryable)


class RequestShapeTests(unittest.TestCase):
    def test_request_arguments(self):
        provider, client = make_provider()
        provider.generate(call())
        self.assertEqual(len(client.calls), 1)
        kwargs = client.calls[0]
        self.assertEqual(kwargs["model"], "gpt-test")
        self.assertEqual(kwargs["input"], "hi")
        self.assertEqual(kwargs["max_output_tokens"], 64)
        self.assertIs(kwargs["store"], False)

    def test_provider_satisfies_contract(self):
        provider, _ = make_provider()
        self.assertIsInstance(provider, ModelProvider)
        self.assertEqual(provider.name, "openai")


class ResponseTests(unittest.TestCase):
    def test_valid_response(self):
        provider, _ = make_provider()
        result = provider.generate(call())
        self.assertEqual(result, ModelResult(text="hello", model_id="gpt-test"))

    def test_mismatched_model_id_is_passed_through_not_rewritten(self):
        other = SimpleNamespace(output_text="hi", model="gpt-other")
        provider, _ = make_provider(other)
        result = provider.generate(call(model="gpt-test"))
        self.assertEqual(result.model_id, "gpt-other")
        self.assertNotEqual(result.model_id, "gpt-test")

    def test_missing_model_id_becomes_empty_and_cannot_match(self):
        provider, _ = make_provider(SimpleNamespace(output_text="hi"))
        result = provider.generate(call(model="gpt-test"))
        self.assertEqual(result.model_id, "")

    def test_non_text_output_becomes_empty(self):
        provider, _ = make_provider(SimpleNamespace(output_text=None, model="gpt-test"))
        self.assertEqual(provider.generate(call()).text, "")


class ErrorMappingTests(unittest.TestCase):
    def assert_mapped(self, exc, retryable, expected_cls=ProviderError):
        provider, client = make_provider(exc)
        with self.assertRaises(ProviderError) as ctx:
            provider.generate(call())
        self.assertIs(type(ctx.exception), expected_cls)
        self.assertEqual(ctx.exception.retryable, retryable)
        self.assertNotIn(SECRET, str(ctx.exception))
        self.assertEqual(len(client.calls), 1)  # zero retries
        return ctx.exception

    def test_401(self):
        self.assert_mapped(FakeAuth(status_code=401), False)

    def test_403(self):
        self.assert_mapped(FakePerm(status_code=403), False)

    def test_404(self):
        self.assert_mapped(FakeNotFound(status_code=404), False)

    def test_429_is_rate_limited(self):
        exc = self.assert_mapped(FakeRateLimit(status_code=429), True, RateLimitedError)
        self.assertEqual(exc.error_code, "provider_rate_limited")

    def test_5xx(self):
        self.assert_mapped(FakeInternal(status_code=503), True)
        self.assert_mapped(FakeStatus(status_code=502), True)

    def test_connection_error(self):
        self.assert_mapped(FakeConn(), True)

    def test_timeout_is_checked_before_connection(self):
        self.assert_mapped(FakeTimeout(), True)

    def test_unknown_exception_is_not_retryable(self):
        self.assert_mapped(RuntimeError("boom " + SECRET), False)


class GatewayCompatibilityTests(unittest.TestCase):
    def setUp(self):
        self.profile = ModelProfile(
            alias="openai_default",
            provider="openai",
            model_id="gpt-test",
            capabilities=ModelCapabilities(
                text_generation=True, max_context_tokens=8192, max_output_tokens=4096
            ),
            runs_locally=False,
        )

    def gateway(self, provider):
        return ModelGateway({"openai": provider}, max_concurrent_calls=2)

    def test_success_through_gateway(self):
        provider, _ = make_provider()
        result = self.gateway(provider).generate(
            self.profile, call(), time.monotonic() + 5
        )
        self.assertEqual(result.text, "hello")

    def test_model_mismatch_rejected_by_gateway(self):
        provider, _ = make_provider(SimpleNamespace(output_text="hi", model="gpt-other"))
        with self.assertRaises(SanourError) as ctx:
            self.gateway(provider).generate(self.profile, call(), time.monotonic() + 5)
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_INVALID_RESPONSE)

    def test_missing_model_rejected_by_gateway(self):
        provider, _ = make_provider(SimpleNamespace(output_text="hi"))
        with self.assertRaises(SanourError) as ctx:
            self.gateway(provider).generate(self.profile, call(), time.monotonic() + 5)
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_INVALID_RESPONSE)


class EnvironmentGuardTests(unittest.TestCase):
    def test_each_blocked_variable_fails_closed_without_echo(self):
        for name in op.BLOCKED_ENV_VARS:
            with self.subTest(name=name):
                with self.assertRaises(ConfigError) as ctx:
                    op.check_environment({name: "https://attacker.example/v1"})
                self.assertIn(name, str(ctx.exception))
                self.assertNotIn("attacker.example", str(ctx.exception))

    def test_empty_blocked_variable_still_blocks(self):
        with self.assertRaises(ConfigError):
            op.check_environment({"OPENAI_BASE_URL": ""})

    def test_clean_environment_passes(self):
        op.check_environment({"OPENAI_API_KEY": SECRET})

    def test_provider_construction_refuses_blocked_environment(self):
        with mock.patch.dict(os.environ, {"OPENAI_BASE_URL": "https://attacker.example/v1"}):
            with self.assertRaises(ConfigError):
                OpenAIProvider(
                    SecretStr(SECRET), client=FakeClient(), errors=FAKE_ERRORS,
                    timeout_factory=tuple_timeout,
                )

    def test_default_builder_checks_before_sdk_is_used(self):
        fake_openai = mock.Mock()
        with mock.patch.dict("sys.modules", {"openai": fake_openai}), mock.patch.dict(
            os.environ, {"OPENAI_CUSTOM_HEADERS": "Authorization: attacker"}
        ):
            with self.assertRaises(ConfigError):
                op._build_default_client(SecretStr(SECRET))
        fake_openai.OpenAI.assert_not_called()


def _real_sdk_available():
    return (
        importlib.util.find_spec("openai") is not None
        and importlib.util.find_spec("httpx2") is not None
    )


@unittest.skipUnless(_real_sdk_available(), "openai and httpx2 not installed; real-SDK tests skipped")
class RealSdkSecurityTests(unittest.TestCase):
    """Real SDK client with a test-only MockTransport. No network, no real key."""

    def setUp(self):
        import httpx2

        self.httpx2 = httpx2
        self.requests = []
        self.responder = lambda req: httpx2.Response(200, json=_ok_body())
        patcher = mock.patch.dict(os.environ, {}, clear=False)
        patcher.start()
        self.addCleanup(patcher.stop)
        for name in op.BLOCKED_ENV_VARS:
            os.environ.pop(name, None)

    def _client(self):
        client = op._build_default_client(SecretStr(SECRET))

        def handler(req):
            self.requests.append(req)
            return self.responder(req)

        # Test-only transport swap. Production code never does this.
        client._client = self.httpx2.Client(
            transport=self.httpx2.MockTransport(handler), trust_env=False
        )
        return client

    def _provider(self):
        from sanour_ai.providers.openai_provider import default_sdk_error_types

        return OpenAIProvider(
            SecretStr(SECRET), client=self._client(), errors=default_sdk_error_types(),
            timeout_factory=tuple_timeout,
        )

    def test_default_client_pins_endpoint_without_org_or_project(self):
        client = op._build_default_client(SecretStr(SECRET))
        self.assertEqual(str(client.base_url).rstrip("/"), op.PINNED_BASE_URL)
        self.assertIsNone(client.organization)
        self.assertIsNone(client.project)
        self.assertEqual(client.max_retries, 0)

    def test_success_request_goes_to_pinned_host_with_adapter_key(self):
        provider = self._provider()
        result = provider.generate(_call())
        self.assertEqual(result.text, "hello")
        self.assertEqual(len(self.requests), 1)
        req = self.requests[0]
        self.assertEqual(req.url.host, "api.openai.com")
        self.assertEqual(req.headers["authorization"], "Bearer " + SECRET)
        self.assertIs(_json_body(req)["store"], False)

    def test_admin_key_env_does_not_replace_authorization(self):
        # Probe: OPENAI_ADMIN_KEY is read by the SDK but not blocked. Result is recorded in the report.
        with mock.patch.dict(os.environ, {"OPENAI_ADMIN_KEY": "sk-ADMIN-SCRATCH-000"}):
            provider = self._provider()
            provider.generate(_call())
        self.assertEqual(self.requests[0].headers["authorization"], "Bearer " + SECRET)

    def test_error_path_logs_contain_no_key_at_debug_level(self):
        self.responder = lambda req: self.httpx2.Response(
            401, json={"error": {"message": "bad key " + SECRET, "type": "x", "code": None}}
        )
        records = _capture_openai_logs(lambda: self._expect_provider_error(self._provider()))
        self.assertGreater(len(records), 0, "debug logging produced no records; test is vacuous")
        self.assertFalse(any(SECRET in r for r in records))

    def test_success_path_logs_contain_no_key_at_debug_level(self):
        records = _capture_openai_logs(lambda: self._provider().generate(_call()))
        self.assertGreater(len(records), 0, "debug logging produced no records; test is vacuous")
        self.assertFalse(any(SECRET in r for r in records))

    def test_subprocess_openai_log_debug_leaks_no_key(self):
        env = {k: v for k, v in os.environ.items() if k not in op.BLOCKED_ENV_VARS}
        env["OPENAI_LOG"] = "debug"
        env["PYTHONPATH"] = os.pathsep.join(p for p in sys.path if p)
        script = (
            "import httpx2, time, sys\n"
            "from pydantic import SecretStr\n"
            "from sanour_ai.providers.openai_provider import _build_default_client, OpenAIProvider\n"
            "from sanour_ai.providers.openai_provider import default_sdk_error_types\n"
            "from sanour_ai.models.base import ModelCall, ProviderError\n"
            f"KEY = {SECRET!r}\n"
            "def h(req):\n"
            "    return httpx2.Response(401, json={'error': {'message': 'bad ' + KEY, 'type': 'x', 'code': None}})\n"
            "c = _build_default_client(SecretStr(KEY))\n"
            "c._client = httpx2.Client(transport=httpx2.MockTransport(h), trust_env=False)\n"
            "p = OpenAIProvider(SecretStr(KEY), client=c, errors=default_sdk_error_types())\n"
            "try:\n"
            "    p.generate(ModelCall(model_id='gpt-test', prompt='x', max_output_tokens=8,\n"
            "                          deadline=time.monotonic() + 10))\n"
            "except ProviderError:\n"
            "    pass\n"
        )
        proc = subprocess.run(
            [sys.executable, "-c", script], env=env, capture_output=True, text=True, timeout=60
        )
        self.assertEqual(proc.returncode, 0, proc.stderr[-500:])
        self.assertNotIn(SECRET, proc.stdout + proc.stderr)
        self.assertIn("DEBUG", proc.stderr, "OPENAI_LOG=debug produced no debug output")

    def _expect_provider_error(self, provider):
        with self.assertRaises(ProviderError):
            provider.generate(_call())

class ClientInjectionTests(unittest.TestCase):
    """The production constructor always validates. Only a test subclass skips validation."""

    def test_production_constructor_has_no_bypass_parameter(self):
        import inspect

        params = inspect.signature(OpenAIProvider.__init__).parameters
        self.assertNotIn("test_only_unvalidated_client", params)
        self.assertEqual(
            set(params), {"self", "api_key", "client", "errors", "timeout_factory"}
        )

    def test_fake_client_rejected_by_production_constructor(self):
        with self.assertRaises(ConfigError) as ctx:
            OpenAIProvider(SecretStr(SECRET), client=FakeClient(), errors=FAKE_ERRORS,
                           timeout_factory=tuple_timeout)
        self.assertIn("client rejected", str(ctx.exception))
        self.assertNotIn(SECRET, str(ctx.exception))

    def test_test_only_subclass_accepts_fake_client(self):
        provider, _ = make_provider()
        self.assertEqual(provider.generate(call()).text, "hello")


def _trusted_sdk_client(**overrides):
    import httpx2
    import openai

    kwargs = dict(api_key=SECRET, base_url=op.PINNED_BASE_URL, max_retries=0,
                  http_client=httpx2.Client(trust_env=False))
    kwargs.update(overrides)
    return openai.OpenAI(**kwargs)


@unittest.skipUnless(_real_sdk_available(), "openai and httpx2 not installed; SDK injection tests skipped")
class SdkClientInjectionTests(unittest.TestCase):
    def setUp(self):
        patcher = mock.patch.dict(os.environ, {}, clear=False)
        patcher.start()
        self.addCleanup(patcher.stop)
        for name in op.BLOCKED_ENV_VARS:
            os.environ.pop(name, None)

    def _assert_rejected(self, client, expected_fragment):
        with self.assertRaises(ConfigError) as ctx:
            OpenAIProvider(SecretStr(SECRET), client=client)
        message = str(ctx.exception)
        self.assertIn(expected_fragment, message)
        self.assertNotIn(SECRET, message)
        self.assertNotIn("attacker.example", message)

    def test_trusted_sdk_client_accepted(self):
        OpenAIProvider(SecretStr(SECRET), client=_trusted_sdk_client())

    def test_foreign_endpoint_rejected(self):
        self._assert_rejected(_trusted_sdk_client(base_url="https://attacker.example/v1"),
                              "endpoint is not the pinned endpoint")

    def test_other_api_key_rejected(self):
        self._assert_rejected(_trusted_sdk_client(api_key="sk-OTHER-SCRATCH-000"),
                              "api key does not match")

    def test_authorization_default_header_rejected(self):
        self._assert_rejected(
            _trusted_sdk_client(default_headers={"Authorization": "Bearer sk-ATTACKER-000"}),
            "authorization header override is set")

    def test_organization_or_project_rejected(self):
        self._assert_rejected(_trusted_sdk_client(organization="org-evil"),
                              "organization or project is set")

    def test_custom_default_header_rejected(self):
        self._assert_rejected(_trusted_sdk_client(default_headers={"X-Probe": "1"}),
                              "custom header is set")

    def test_custom_header_on_client_rejected(self):
        client = _trusted_sdk_client()
        client._custom_headers = {"X-Probe": "1"}
        self._assert_rejected(client, "custom header is set")

    def test_custom_query_rejected(self):
        client = _trusted_sdk_client()
        with mock.patch.object(type(client), "default_query", new_callable=mock.PropertyMock,
                               return_value={"api-version": "2024-01-01"}):
            self._assert_rejected(client, "custom query parameters are set")

    def test_organization_header_override_rejected(self):
        self._assert_rejected(_trusted_sdk_client(default_headers={"OpenAI-Organization": "org-x"}),
                              "organization or project header is set")

    def test_project_header_override_rejected(self):
        self._assert_rejected(_trusted_sdk_client(default_headers={"OpenAI-Project": "proj-x"}),
                              "organization or project header is set")

    def test_host_header_override_rejected(self):
        self._assert_rejected(_trusted_sdk_client(default_headers={"Host": "attacker.example"}),
                              "custom header is set")

    def test_auth_headers_mismatch_rejected(self):
        client = _trusted_sdk_client()
        with mock.patch.object(type(client), "auth_headers", new_callable=mock.PropertyMock,
                               return_value={"Authorization": "Bearer sk-OTHER-SCRATCH-000"}):
            self._assert_rejected(client, "authorization does not come from the adapter key")

    def test_sdk_default_header_names_accepted(self):
        OpenAIProvider(SecretStr(SECRET), client=_trusted_sdk_client(
            default_headers={"User-Agent": "sanour-test", "X-Stainless-Probe": "1"}))

    def test_retries_enabled_rejected(self):
        self._assert_rejected(_trusted_sdk_client(max_retries=2), "retries are not disabled")

    def test_env_transport_client_rejected(self):
        import httpx2
        import openai

        client = openai.OpenAI(api_key=SECRET, base_url=op.PINNED_BASE_URL, max_retries=0,
                               http_client=httpx2.Client(trust_env=True))
        self._assert_rejected(client, "environment proxy or TLS settings are enabled")


@unittest.skipUnless(_real_sdk_available(), "openai and httpx2 not installed; proxy tests skipped")
class ProxyAndTlsEnvironmentTests(unittest.TestCase):
    """Verified against the bundled httpx2 2.13.1 transport internals (pinned version only)."""

    PROXY = "http://proxy.attacker.example:8080"

    def setUp(self):
        patcher = mock.patch.dict(os.environ, {}, clear=False)
        patcher.start()
        self.addCleanup(patcher.stop)
        for name in op.BLOCKED_ENV_VARS + ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "NO_PROXY",
                                            "SSL_CERT_FILE", "SSL_CERT_DIR"):
            os.environ.pop(name, None)

    def _proxy_url_for_openai(self, client):
        from httpx2 import URL

        transport = client._client._transport_for_url(URL("https://api.openai.com/v1/responses"))
        return getattr(getattr(transport, "_pool", None), "_proxy_url", None)

    def test_negative_control_default_client_does_route_via_env_proxy(self):
        import httpx2

        os.environ["HTTPS_PROXY"] = self.PROXY
        plain = httpx2.Client()  # default trust_env=True
        transport = plain._transport_for_url(httpx2.URL("https://api.openai.com/v1/responses"))
        self.assertIsNotNone(getattr(getattr(transport, "_pool", None), "_proxy_url", None),
                             "control failed: the probe cannot see env proxy routing")

    def test_factory_client_ignores_https_and_all_proxy(self):
        os.environ["HTTPS_PROXY"] = self.PROXY
        os.environ["ALL_PROXY"] = self.PROXY
        client = op._build_default_client(SecretStr(SECRET))
        self.assertIsNone(self._proxy_url_for_openai(client))
        self.assertIs(client._client.trust_env, False)

    def test_factory_client_ignores_missing_ssl_cert_file(self):
        os.environ["SSL_CERT_FILE"] = "/nonexistent/attacker-ca.pem"
        os.environ["SSL_CERT_DIR"] = "/nonexistent/attacker-ca-dir"
        client = op._build_default_client(SecretStr(SECRET))  # would raise if trust_env were on
        self.assertEqual(str(client.base_url).rstrip("/"), op.PINNED_BASE_URL)


@unittest.skipUnless(_real_sdk_available(), "openai and httpx2 not installed; SDK env audit skipped")
class SdkEnvironmentAuditTests(unittest.TestCase):
    """Variables not blocked: each is checked for effect on routing, auth, or headers."""

    def setUp(self):
        patcher = mock.patch.dict(os.environ, {}, clear=False)
        patcher.start()
        self.addCleanup(patcher.stop)
        for name in op.BLOCKED_ENV_VARS:
            os.environ.pop(name, None)

    def test_api_type_and_version_do_not_change_client_class_or_endpoint(self):
        import openai

        os.environ["OPENAI_API_TYPE"] = "azure"
        os.environ["OPENAI_API_VERSION"] = "2024-01-01"
        client = op._build_default_client(SecretStr(SECRET))
        self.assertIs(type(client), openai.OpenAI)
        self.assertEqual(str(client.base_url).rstrip("/"), op.PINNED_BASE_URL)

    def test_webhook_secret_does_not_change_authorization(self):
        os.environ["OPENAI_WEBHOOK_SECRET"] = "whsec-SCRATCH-000"
        client = op._build_default_client(SecretStr(SECRET))
        self.assertEqual(client.auth_headers, {"Authorization": "Bearer " + SECRET})

    def test_admin_key_does_not_change_authorization(self):
        os.environ["OPENAI_ADMIN_KEY"] = "sk-ADMIN-SCRATCH-000"
        client = op._build_default_client(SecretStr(SECRET))
        self.assertEqual(client.auth_headers, {"Authorization": "Bearer " + SECRET})



def _ok_body():
    return {
        "id": "resp_1", "object": "response", "created_at": 0, "model": "gpt-test",
        "status": "completed",
        "output": [{"type": "message", "id": "m1", "role": "assistant", "status": "completed",
                    "content": [{"type": "output_text", "text": "hello", "annotations": []}]}],
        "parallel_tool_calls": False, "tool_choice": "auto", "tools": [],
    }


def _json_body(req):
    import json

    return json.loads(req.content)


def _call():
    return ModelCall(model_id="gpt-test", prompt="hi", max_output_tokens=64,
                     deadline=time.monotonic() + 10)


def _capture_openai_logs(action):
    records = []

    class Collect(logging.Handler):
        def emit(self, record):
            records.append(self.format(record))

    handler = Collect(level=logging.DEBUG)
    logger = logging.getLogger("openai")
    old_level = logger.level
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    try:
        action()
    finally:
        logger.removeHandler(handler)
        logger.setLevel(old_level)
    return records


if __name__ == "__main__":
    unittest.main()
