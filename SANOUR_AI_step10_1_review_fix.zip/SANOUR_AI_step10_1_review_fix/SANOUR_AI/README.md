# SANOUR AI (Phase 1, remediated)

Minimal orchestration core. Mock provider only. No network, no API keys, no paid services.

## Windows PowerShell (not yet run on Windows)

    py -3.11 -m venv .venv
    .\.venv\Scripts\Activate.ps1
    python -m pip install -e ".[dev]"
    python -m pytest -q
    python -m ruff check .

Standard library only (no pytest needed):

    $env:PYTHONPATH = "src;."
    python -m unittest discover -s tests -t . -v

## Request policy

- **One attempt per request.** The router selects exactly one model. There is no fallback list,
  and `allow_fallback` is rejected as an invalid field.
- **One total deadline.** `timeout_seconds` (default 10, max 60) starts when `handle()` starts.
  Validation, routing, and the provider call all count against it. An expired deadline fails
  before any provider call.
- **Tolerance.** The caller returns at about the deadline. Tests allow 0.25 s of scheduling
  overhead. Measured only in the sandbox, not on Windows.
- **No retries.** `retryable` in an error tells the client whether a later retry may succeed.
  The core never retries itself.

## Timeout and worker policy

- Provider calls run in daemon threads. Python cannot forcibly stop a thread.
- **A timed-out call is not stopped.** It keeps running until the provider returns, and its
  result is discarded. The code makes no claim that the thread was terminated.
- **Bounded accumulation.** A semaphore caps live worker threads, including abandoned ones, at
  `SANOUR_MAX_CONCURRENT_PROVIDER_CALLS` (default 4, valid range 1 to 16).
- **Overflow fails fast.** When the cap is reached, a new call returns `provider_overloaded`
  (retryable) and starts no thread.
- **Slots return only when workers return.** A provider call that never returns keeps its slot
  for the life of the process. Known limit: recovering it requires a restart.
- **No cancellation** is implemented.

## Configuration

`config/settings.py` holds one operational value: the worker cap. It is read from the environment
variable above. No `.env` file is read, so no secrets can enter through it. Invalid values raise
`ConfigError` at startup, and the message names the setting but never its value.

## Layout

- `core/`: SanourCore entry point and request acceptance.
- `models/`: request/response schemas, capabilities, router, gateway, provider protocol.
- `providers/`: deterministic mock provider.
- `config/`: typed runtime settings.
- `security/`: secret redaction.
- `observability/`: redacted audit events (no prompt text).
- `tests/`: unit tests, integration tests, and shared helpers in `support.py`.

## OpenAI provider (step 09, offline only)

`src/sanour_ai/providers/openai_provider.py` implements the first real adapter. It is **not wired**
into any composition root and has **not been connected to OpenAI**. Nothing in this step sends a
real request.

- Setup (after approval only): `pip install -e ".[openai]"`, which pins `openai==3.45.0` and
  `httpx2==2.13.1`. Set `OPENAI_API_KEY` in the environment. The key is never read from files or
  logged.
- Responses API with `store=False` and `max_output_tokens` from the call. The SDK is created with
  `max_retries=0`. No retry, no fallback, no automatic model substitution.
- Deadline: only `ModelCall.deadline` is used. It is checked before I/O and again after the
  response. The four timeouts (connect, read, write, pool) are capped by the remaining budget.
- Model ID: the provider never rewrites it. A mismatch or a missing id is rejected by the gateway
  as `PROVIDER_INVALID_RESPONSE`.
- Errors: 401, 403, 404, 429, 5xx, connection, and timeout are mapped to fixed messages. Raw SDK
  text never reaches the caller or the log.
- `PROVIDER_RATE_LIMITED` is defined in `ErrorCode`, but the gateway still reports 429 as
  `PROVIDER_FAILED` (retryable). Surfacing the new code needs a gateway change, which is not in
  this step.

**Known limit (Trickle):** the per-phase httpx timeouts do not guarantee an overall deadline when
data arrives slowly. Network work can continue after the deadline. The gateway returns on time and
discards the late result, but the worker thread and its semaphore slot stay occupied until the SDK
call returns. No cancellation is implemented or claimed.

Tests in `tests/unit/test_openai_provider.py` run offline. Without the SDK installed, the
real-SDK tests are skipped and the rest use a fake client and fake SDK error classes that exist
only in the tests. With `openai==3.45.0` and `httpx2==2.13.1` installed, the real-SDK tests also run
against a test-only mock transport. That is not a connection to OpenAI. No test in this repository
has contacted the OpenAI API.

## OpenAI adapter security boundary (step 10.1)

- **Endpoint pinned:** the adapter always uses `https://api.openai.com/v1`. `OPENAI_BASE_URL` is
  not honored.
- **Fail closed:** the adapter refuses to start if any of these variables is set, even empty:
  `OPENAI_BASE_URL`, `OPENAI_CUSTOM_HEADERS`, `OPENAI_ORG_ID`, `OPENAI_PROJECT_ID`. The error names
  the variable and never prints its value.
- **Headers:** the `Authorization` header always carries the adapter's key. `OPENAI_CUSTOM_HEADERS`
  is blocked, so it cannot replace it.
- **Logging:** `OPENAI_LOG` is still read by the SDK, which only changes log verbosity. The SDK
  redacts authorization headers. Tests check debug-level logs on success and error paths for the
  key. Keep `OPENAI_LOG` off in production anyway.
- **Client validation:** every SDK client is validated when the provider is constructed, including
  clients built by the adapter's own factory. There is no flag to skip validation in production.
  The check requires: the adapter's key (`auth_headers` equals `Bearer <key>`), the pinned
  endpoint, no organization or project, retries disabled, no custom query parameters, and an HTTP
  transport built with `trust_env=False`.
- **Header policy:** every header on the client, both the merged `default_headers` and the
  caller-supplied `_custom_headers`, is checked by name. Accepted: SDK-generated headers `Accept`,
  `Content-Type`, `User-Agent`, `X-Stainless-*`, and `OpenAI-Organization`/`OpenAI-Project` while
  they are unset. Rejected: `Authorization` (always the adapter's key), any `OpenAI-Organization` or
  `OpenAI-Project` value that is set, and any other name (such as `Host` or `X-Probe`), which is a
  custom header. Custom query parameters are rejected too. The adapter sends no per-request
  headers, so these checks cover every header the SDK sends.
- **Test-only injection:** the test suite subclasses the provider in the test file to skip
  validation for fake clients. That subclass is not part of `src/`.
- **Proxy and TLS:** `HTTP_PROXY`, `HTTPS_PROXY`, `ALL_PROXY`, `NO_PROXY`, `SSL_CERT_FILE`, and
  `SSL_CERT_DIR` are ignored by the operational transport (`trust_env=False`). Verified: with
  `HTTPS_PROXY` set, a default httpx2 client routes OpenAI traffic through the proxy, and the
  adapter's client does not. Proxy support, if ever needed, must be an explicit, reviewed setting.
- **Environment audit (SDK 3.45.0, verified by code reading and mock-transport tests):**

  | Variable | Effect on this adapter | Action |
  |---|---|---|
  | `OPENAI_BASE_URL` | Redirects requests (key sent to host) | Blocked (fail closed) |
  | `OPENAI_CUSTOM_HEADERS` | Injects or replaces headers | Blocked |
  | `OPENAI_ORG_ID`, `OPENAI_PROJECT_ID` | Adds billing headers | Blocked |
  | `OPENAI_ADMIN_KEY` | Populates `admin_api_key`; Responses auth unchanged (tested) | Not blocked |
  | `OPENAI_WEBHOOK_SECRET` | Used only for webhook verification; auth unchanged (tested) | Not blocked |
  | `OPENAI_API_TYPE`, `OPENAI_API_VERSION` | Module-level/Azure switches; client stays `openai.OpenAI` (tested) | Not blocked |
  | `OPENAI_API_KEY` | Not used; the adapter always passes its own key | Not blocked |
  | `OPENAI_LOG` | Log verbosity; authorization header redacted (tested) | Not blocked |
  | `HTTP(S)_PROXY`, `ALL_PROXY`, `NO_PROXY`, `SSL_CERT_*` | Route traffic / change trust store | Ignored (`trust_env=False`) |

- **Tests against the real SDK** use a test-only mock transport. They do not connect to OpenAI.
  No test here uses a real key or network.
- **Tests:** the test suite assumes the four blocked variables are unset in the environment.
