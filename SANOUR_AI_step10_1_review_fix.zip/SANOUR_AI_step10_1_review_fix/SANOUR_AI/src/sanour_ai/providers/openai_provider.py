"""OpenAI provider adapter (Responses API). Production code: no mocks, no retries, no fallback.

Contract: see models/base.py. The only deadline is ModelCall.deadline. It is never extended,
reset, or recomputed here.

Known limit (Trickle): the four httpx timeouts cap each I/O step, but they do not guarantee an
overall deadline against slow trickled data. Network work can continue after the deadline. The
gateway returns to the caller on time and discards the late result, but the worker thread and its
semaphore slot stay busy until the SDK call returns. No cancellation is claimed.
"""

from __future__ import annotations

import os
import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from typing import Any

from pydantic import SecretStr

from sanour_ai.config.settings import ConfigError
from sanour_ai.models.base import ModelCall, ModelResult, ProviderError

ENV_OPENAI_API_KEY = "OPENAI_API_KEY"
OPENAI_PROVIDER_NAME = "openai"

# Configured ceilings per I/O phase. Each is capped by the remaining deadline budget.
CONNECT_TIMEOUT_S = 5.0
READ_TIMEOUT_S = 30.0
WRITE_TIMEOUT_S = 10.0
POOL_TIMEOUT_S = 5.0


class RateLimitedError(ProviderError):
    """Raised for HTTP 429. The gateway still reports PROVIDER_FAILED until it maps this code."""

    error_code = "provider_rate_limited"


@dataclass(frozen=True)
class SdkErrorTypes:
    """Exception classes from the SDK used for mapping. Injected in tests, real SDK by default."""

    base: type
    authentication: type
    permission_denied: type
    not_found: type
    rate_limit: type
    internal_server: type
    api_timeout: type
    api_connection: type
    api_status: type


def default_sdk_error_types() -> SdkErrorTypes:
    import openai  # imported lazily so the core never needs the SDK

    return SdkErrorTypes(
        base=openai.OpenAIError,
        authentication=openai.AuthenticationError,
        permission_denied=openai.PermissionDeniedError,
        not_found=openai.NotFoundError,
        rate_limit=openai.RateLimitError,
        internal_server=openai.InternalServerError,
        api_timeout=openai.APITimeoutError,
        api_connection=openai.APIConnectionError,
        api_status=openai.APIStatusError,
    )


# Endpoint is pinned in code. The environment cannot redirect requests or replace headers.
PINNED_BASE_URL = "https://api.openai.com/v1"
BLOCKED_ENV_VARS = ("OPENAI_BASE_URL", "OPENAI_CUSTOM_HEADERS", "OPENAI_ORG_ID", "OPENAI_PROJECT_ID")
# Header policy. The adapter accepts only headers the SDK generates itself. Anything else is a
# custom header and is rejected, because a custom header could change routing, auth, or billing.
SDK_DEFAULT_HEADER_NAMES = frozenset({"accept", "content-type", "user-agent"})
SDK_DEFAULT_HEADER_PREFIXES = ("x-stainless-",)
# Organization and project are SDK defaults only while unset (value is the SDK's Omit sentinel).
SDK_OMITTABLE_HEADER_NAMES = frozenset({"openai-organization", "openai-project"})


def check_environment(environ: Mapping[str, str] | None = None) -> None:
    """Fail closed when a blocked variable is present, even if empty. Names only, never values."""
    env = os.environ if environ is None else environ
    present = [name for name in BLOCKED_ENV_VARS if name in env]
    if present:
        raise ConfigError(
            "unsupported environment settings present: "
            + ", ".join(present)
            + " (the adapter pins its endpoint and does not accept these; unset them)"
        )


def load_api_key(environ: Mapping[str, str] | None = None) -> SecretStr:
    """Read the API key from the environment. Errors name the setting, never the value."""
    env = os.environ if environ is None else environ
    raw = env.get(ENV_OPENAI_API_KEY)
    if raw is None or not raw.strip():
        raise ConfigError(f"{ENV_OPENAI_API_KEY} must be set to a non-empty value")
    return SecretStr(raw.strip())


def _default_timeout(remaining: float) -> Any:
    import httpx2  # the SDK's transport package (pinned in pyproject extra 'openai')

    return httpx2.Timeout(
        connect=min(CONNECT_TIMEOUT_S, remaining),
        read=min(READ_TIMEOUT_S, remaining),
        write=min(WRITE_TIMEOUT_S, remaining),
        pool=min(POOL_TIMEOUT_S, remaining),
    )


def _build_http_client() -> Any:
    import httpx2

    # trust_env=False: HTTP(S)_PROXY, ALL_PROXY, NO_PROXY, SSL_CERT_FILE and SSL_CERT_DIR are
    # ignored. Operational transport is explicit and carries no environment-driven routing.
    return httpx2.Client(trust_env=False)


def _build_default_client(api_key: SecretStr) -> Any:
    check_environment()  # before the SDK is imported or any client is built
    import openai

    # Endpoint pinned explicitly. max_retries=0: the SDK must never retry on its own.
    return openai.OpenAI(
        api_key=api_key.get_secret_value(),
        base_url=PINNED_BASE_URL,
        max_retries=0,
        http_client=_build_http_client(),
    )


def _header_problem(name: str, value: Any) -> str | None:
    lname = name.lower()
    if lname == "authorization":
        return "authorization header override is set"
    if lname in SDK_OMITTABLE_HEADER_NAMES:
        return "organization or project header is set" if isinstance(value, str) else None
    if lname in SDK_DEFAULT_HEADER_NAMES or lname.startswith(SDK_DEFAULT_HEADER_PREFIXES):
        return None
    return "custom header is set"


def validate_client(client: Any, api_key: SecretStr) -> None:
    """Accept only a pinned, key-matched, header-clean SDK client with no env transport overrides.

    Fails closed. Error text names the failed checks, never the values involved.
    """
    try:
        import openai
    except ImportError:
        raise ConfigError("client rejected: SDK is not available to verify it") from None

    problems: list[str] = []
    if not isinstance(client, openai.OpenAI):
        problems.append("not an SDK client built by this adapter")
    else:
        if getattr(client, "auth_headers", None) != {"Authorization": "Bearer " + api_key.get_secret_value()}:
            problems.append("authorization does not come from the adapter key")
        if getattr(client, "api_key", None) != api_key.get_secret_value():
            problems.append("api key does not match the adapter key")
        if str(getattr(client, "base_url", "")).rstrip("/") != PINNED_BASE_URL:
            problems.append("endpoint is not the pinned endpoint")
        if getattr(client, "organization", None) is not None or getattr(client, "project", None) is not None:
            problems.append("organization or project is set")
        if getattr(client, "max_retries", None) != 0:
            problems.append("retries are not disabled")
        # admin_api_key is populated from OPENAI_ADMIN_KEY but does not change Responses API auth
        # (tested), so it is not rejected. workload_identity is never set from the environment.
        if getattr(client, "workload_identity", None) is not None:
            problems.append("an alternate credential is set")
        if getattr(client, "default_query", {}):
            problems.append("custom query parameters are set")
        # The SDK stores caller-supplied headers in _custom_headers and the merged set in
        # default_headers. Both are checked name by name against the SDK allowlist.
        header_problems: list[str] = []
        for source in (getattr(client, "default_headers", {}), getattr(client, "_custom_headers", {})):
            for name, value in source.items():
                problem = _header_problem(str(name), value)
                if problem and problem not in header_problems:
                    header_problems.append(problem)
        problems.extend(header_problems)
        http = getattr(client, "_client", None)
        if getattr(http, "trust_env", True) is not False:
            problems.append("environment proxy or TLS settings are enabled")
    if problems:
        raise ConfigError("client rejected: " + "; ".join(problems))


class OpenAIProvider:
    name = OPENAI_PROVIDER_NAME

    def __init__(
        self,
        api_key: SecretStr,
        *,
        client: Any = None,
        errors: SdkErrorTypes | None = None,
        timeout_factory: Callable[[float], Any] | None = None,
    ) -> None:
        check_environment()  # SDK clients read the environment when they are built
        if client is None:
            client = _build_default_client(api_key)
        # Every client is validated here, including factory-built ones. No flag skips it.
        self._check_client(client, api_key)
        self._client = client
        self._errors = errors if errors is not None else default_sdk_error_types()
        self._timeout_factory = timeout_factory or _default_timeout

    def _check_client(self, client: Any, api_key: SecretStr) -> None:
        validate_client(client, api_key)

    def generate(self, call: ModelCall) -> ModelResult:
        if call.deadline is None:
            raise ProviderError("request has no deadline", retryable=False)
        remaining = call.deadline - time.monotonic()
        if remaining <= 0:
            # Fails before any network I/O.
            raise ProviderError("deadline expired before provider call", retryable=True)

        timeout = self._timeout_factory(remaining)
        try:
            response = self._client.responses.create(
                model=call.model_id,
                input=call.prompt,
                max_output_tokens=call.max_output_tokens,
                store=False,
                timeout=timeout,
            )
        except Exception as exc:  # every SDK failure is mapped; raw text never leaves
            raise self._map_error(exc) from None

        # A response that arrives after the deadline is not accepted.
        if time.monotonic() >= call.deadline:
            raise ProviderError("response arrived after deadline", retryable=True)
        return self._to_result(response)

    def _map_error(self, exc: BaseException) -> ProviderError:
        e = self._errors
        # Order matters: APITimeoutError is a subclass of APIConnectionError.
        if isinstance(exc, e.api_timeout):
            return ProviderError("provider call timed out", retryable=True)
        if isinstance(exc, e.api_connection):
            return ProviderError("provider connection failed", retryable=True)
        if isinstance(exc, e.authentication):
            return ProviderError("provider rejected credentials", retryable=False)
        if isinstance(exc, e.permission_denied):
            return ProviderError("provider denied permission", retryable=False)
        if isinstance(exc, e.not_found):
            return ProviderError("provider model or endpoint not found", retryable=False)
        if isinstance(exc, e.rate_limit):
            return RateLimitedError("provider rate limited", retryable=True)
        if isinstance(exc, e.internal_server):
            return ProviderError("provider server error", retryable=True)
        if isinstance(exc, e.api_status) and getattr(exc, "status_code", 0) >= 500:
            return ProviderError("provider server error", retryable=True)
        return ProviderError("provider call failed", retryable=False)

    @staticmethod
    def _to_result(response: Any) -> ModelResult:
        text = getattr(response, "output_text", None)
        model = getattr(response, "model", None)
        # Never rewrite or invent a model id. An empty id can never equal call.model_id, so the
        # gateway rejects it as PROVIDER_INVALID_RESPONSE.
        return ModelResult(
            text=text if isinstance(text, str) else "",
            model_id=model if isinstance(model, str) else "",
        )
