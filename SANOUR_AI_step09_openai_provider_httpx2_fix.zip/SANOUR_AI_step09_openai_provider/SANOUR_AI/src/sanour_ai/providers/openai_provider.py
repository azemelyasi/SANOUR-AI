"""OpenAI provider adapter (Responses API). Production code: no mocks, no retries, no fallback.

Contract: see models/base.py. The only deadline is ModelCall.deadline. It is never extended,
reset, or recomputed here.

Known limit (Trickle): the four httpx timeouts cap each I/O step, but they do not guarantee an
overall deadline against slow trickled data. Network work can continue after the deadline. The
gateway returns to the caller on time and discards the late result, but the worker thread and its
semaphore slot stay busy until the SDK call returns. No cancellation is claimed.
"""

from __future__ import annotations

import os
import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from typing import Any

from pydantic import SecretStr

from sanour_ai.config.settings import ConfigError
from sanour_ai.models.base import ModelCall, ModelResult, ProviderError

ENV_OPENAI_API_KEY = "OPENAI_API_KEY"
OPENAI_PROVIDER_NAME = "openai"

# Configured ceilings per I/O phase. Each is capped by the remaining deadline budget.
CONNECT_TIMEOUT_S = 5.0
READ_TIMEOUT_S = 30.0
WRITE_TIMEOUT_S = 10.0
POOL_TIMEOUT_S = 5.0


class RateLimitedError(ProviderError):
    """Raised for HTTP 429. The gateway still reports PROVIDER_FAILED until it maps this code."""

    error_code = "provider_rate_limited"


@dataclass(frozen=True)
class SdkErrorTypes:
    """Exception classes from the SDK used for mapping. Injected in tests, real SDK by default."""

    base: type
    authentication: type
    permission_denied: type
    not_found: type
    rate_limit: type
    internal_server: type
    api_timeout: type
    api_connection: type
    api_status: type


def default_sdk_error_types() -> SdkErrorTypes:
    import openai  # imported lazily so the core never needs the SDK

    return SdkErrorTypes(
        base=openai.OpenAIError,
        authentication=openai.AuthenticationError,
        permission_denied=openai.PermissionDeniedError,
        not_found=openai.NotFoundError,
        rate_limit=openai.RateLimitError,
        internal_server=openai.InternalServerError,
        api_timeout=openai.APITimeoutError,
        api_connection=openai.APIConnectionError,
        api_status=openai.APIStatusError,
    )


def load_api_key(environ: Mapping[str, str] | None = None) -> SecretStr:
    """Read the API key from the environment. Errors name the setting, never the value."""
    env = os.environ if environ is None else environ
    raw = env.get(ENV_OPENAI_API_KEY)
    if raw is None or not raw.strip():
        raise ConfigError(f"{ENV_OPENAI_API_KEY} must be set to a non-empty value")
    return SecretStr(raw.strip())


def _default_timeout(remaining: float) -> Any:
    import httpx2  # the SDK's transport package (pinned in pyproject extra 'openai')

    return httpx2.Timeout(
        connect=min(CONNECT_TIMEOUT_S, remaining),
        read=min(READ_TIMEOUT_S, remaining),
        write=min(WRITE_TIMEOUT_S, remaining),
        pool=min(POOL_TIMEOUT_S, remaining),
    )


def _build_default_client(api_key: SecretStr) -> Any:
    import openai

    # max_retries=0: the SDK must never retry on its own.
    return openai.OpenAI(api_key=api_key.get_secret_value(), max_retries=0)


class OpenAIProvider:
    name = OPENAI_PROVIDER_NAME

    def __init__(
        self,
        api_key: SecretStr,
        *,
        client: Any = None,
        errors: SdkErrorTypes | None = None,
        timeout_factory: Callable[[float], Any] | None = None,
    ) -> None:
        self._client = client if client is not None else _build_default_client(api_key)
        self._errors = errors if errors is not None else default_sdk_error_types()
        self._timeout_factory = timeout_factory or _default_timeout

    def generate(self, call: ModelCall) -> ModelResult:
        if call.deadline is None:
            raise ProviderError("request has no deadline", retryable=False)
        remaining = call.deadline - time.monotonic()
        if remaining <= 0:
            # Fails before any network I/O.
            raise ProviderError("deadline expired before provider call", retryable=True)

        timeout = self._timeout_factory(remaining)
        try:
            response = self._client.responses.create(
                model=call.model_id,
                input=call.prompt,
                max_output_tokens=call.max_output_tokens,
                store=False,
                timeout=timeout,
            )
        except Exception as exc:  # every SDK failure is mapped; raw text never leaves
            raise self._map_error(exc) from None

        # A response that arrives after the deadline is not accepted.
        if time.monotonic() >= call.deadline:
            raise ProviderError("response arrived after deadline", retryable=True)
        return self._to_result(response)

    def _map_error(self, exc: BaseException) -> ProviderError:
        e = self._errors
        # Order matters: APITimeoutError is a subclass of APIConnectionError.
        if isinstance(exc, e.api_timeout):
            return ProviderError("provider call timed out", retryable=True)
        if isinstance(exc, e.api_connection):
            return ProviderError("provider connection failed", retryable=True)
        if isinstance(exc, e.authentication):
            return ProviderError("provider rejected credentials", retryable=False)
        if isinstance(exc, e.permission_denied):
            return ProviderError("provider denied permission", retryable=False)
        if isinstance(exc, e.not_found):
            return ProviderError("provider model or endpoint not found", retryable=False)
        if isinstance(exc, e.rate_limit):
            return RateLimitedError("provider rate limited", retryable=True)
        if isinstance(exc, e.internal_server):
            return ProviderError("provider server error", retryable=True)
        if isinstance(exc, e.api_status) and getattr(exc, "status_code", 0) >= 500:
            return ProviderError("provider server error", retryable=True)
        return ProviderError("provider call failed", retryable=False)

    @staticmethod
    def _to_result(response: Any) -> ModelResult:
        text = getattr(response, "output_text", None)
        model = getattr(response, "model", None)
        # Never rewrite or invent a model id. An empty id can never equal call.model_id, so the
        # gateway rejects it as PROVIDER_INVALID_RESPONSE.
        return ModelResult(
            text=text if isinstance(text, str) else "",
            model_id=model if isinstance(model, str) else "",
        )
