"""Offline tests for the OpenAI provider. No network, no real key, no real SDK required.

The fake client and fake SDK error classes below exist only in this test module.
"""

import importlib.util
import sys
import time
import unittest
from types import SimpleNamespace
from unittest import mock

from pydantic import SecretStr

from sanour_ai.config.settings import ConfigError
from sanour_ai.errors import ErrorCode, SanourError
from sanour_ai.models.base import ModelCall, ModelProvider, ModelResult, ProviderError
from sanour_ai.models.capabilities import ModelCapabilities, ModelProfile
from sanour_ai.models.gateway import ModelGateway
from sanour_ai.providers import openai_provider as op
from sanour_ai.providers.openai_provider import (
    CONNECT_TIMEOUT_S,
    POOL_TIMEOUT_S,
    READ_TIMEOUT_S,
    WRITE_TIMEOUT_S,
    OpenAIProvider,
    RateLimitedError,
    SdkErrorTypes,
    load_api_key,
)

SECRET = "sk-FAKETESTKEY0123456789ABCDEF"  # fake, test-only


class FakeSdkError(Exception):
    def __init__(self, text="raw server text with " + SECRET, status_code=None):
        super().__init__(text)
        self.status_code = status_code


class FakeOpenAIError(FakeSdkError): ...
class FakeAuth(FakeOpenAIError): ...
class FakePerm(FakeOpenAIError): ...
class FakeNotFound(FakeOpenAIError): ...
class FakeRateLimit(FakeOpenAIError): ...
class FakeInternal(FakeOpenAIError): ...
class FakeStatus(FakeOpenAIError): ...
class FakeConn(FakeOpenAIError): ...
class FakeTimeout(FakeConn): ...  # subclass, as in the real SDK


FAKE_ERRORS = SdkErrorTypes(
    base=FakeOpenAIError,
    authentication=FakeAuth,
    permission_denied=FakePerm,
    not_found=FakeNotFound,
    rate_limit=FakeRateLimit,
    internal_server=FakeInternal,
    api_timeout=FakeTimeout,
    api_connection=FakeConn,
    api_status=FakeStatus,
)


class FakeClient:
    def __init__(self, outcome=None):
        self.calls = []
        self._outcome = outcome
        self.responses = SimpleNamespace(create=self._create)

    def _create(self, **kwargs):
        self.calls.append(kwargs)
        if isinstance(self._outcome, BaseException):
            raise self._outcome
        if callable(self._outcome):
            return self._outcome()
        return self._outcome or SimpleNamespace(output_text="hello", model="gpt-test")


def tuple_timeout(remaining):
    return (
        min(CONNECT_TIMEOUT_S, remaining),
        min(READ_TIMEOUT_S, remaining),
        min(WRITE_TIMEOUT_S, remaining),
        min(POOL_TIMEOUT_S, remaining),
    )


def make_provider(outcome=None):
    client = FakeClient(outcome)
    provider = OpenAIProvider(
        SecretStr(SECRET), client=client, errors=FAKE_ERRORS, timeout_factory=tuple_timeout
    )
    return provider, client


def call(model="gpt-test", seconds=5.0):
    return ModelCall(
        model_id=model, prompt="hi", max_output_tokens=64, deadline=time.monotonic() + seconds
    )


class ApiKeyTests(unittest.TestCase):
    def test_missing_key_raises_without_echo(self):
        with self.assertRaises(ConfigError) as ctx:
            load_api_key({})
        self.assertIn(op.ENV_OPENAI_API_KEY, str(ctx.exception))

    def test_blank_key_rejected(self):
        with self.assertRaises(ConfigError):
            load_api_key({op.ENV_OPENAI_API_KEY: "   "})

    def test_key_read_from_env_and_not_leaked_in_repr(self):
        key = load_api_key({op.ENV_OPENAI_API_KEY: SECRET})
        self.assertIsInstance(key, SecretStr)
        self.assertNotIn(SECRET, repr(key))
        self.assertNotIn(SECRET, str(key))

    def test_key_not_leaked_through_provider_errors(self):
        provider, _ = make_provider(FakeAuth("bad key " + SECRET, status_code=401))
        with self.assertRaises(ProviderError) as ctx:
            provider.generate(call())
        self.assertNotIn(SECRET, str(ctx.exception))
        self.assertNotIn(SECRET, repr(ctx.exception))

    def test_default_client_built_with_zero_retries(self):
        fake_openai = mock.Mock()
        with mock.patch.dict("sys.modules", {"openai": fake_openai}):
            op._build_default_client(SecretStr(SECRET))
        fake_openai.OpenAI.assert_called_once_with(api_key=SECRET, max_retries=0)


class TimeoutTypeTests(unittest.TestCase):
    def test_default_timeout_uses_httpx2_with_capped_values(self):
        fake_httpx2 = mock.Mock()
        with mock.patch.dict(sys.modules, {"httpx2": fake_httpx2}):
            op._default_timeout(0.5)
        fake_httpx2.Timeout.assert_called_once_with(connect=0.5, read=0.5, write=0.5, pool=0.5)

    def test_default_timeout_uses_configured_values_for_large_budget(self):
        fake_httpx2 = mock.Mock()
        with mock.patch.dict(sys.modules, {"httpx2": fake_httpx2}):
            op._default_timeout(60)
        fake_httpx2.Timeout.assert_called_once_with(
            connect=CONNECT_TIMEOUT_S, read=READ_TIMEOUT_S,
            write=WRITE_TIMEOUT_S, pool=POOL_TIMEOUT_S,
        )

    @unittest.skipUnless(
        importlib.util.find_spec("httpx2") is not None,
        "httpx2 2.13.1 not installed here; real-type check runs only where it is",
    )
    def test_real_httpx2_timeout_type(self):
        import httpx2

        value = op._default_timeout(0.5)
        self.assertIsInstance(value, httpx2.Timeout)
        self.assertLessEqual(value.read, 0.5)


class DeadlineTests(unittest.TestCase):
    def test_expired_deadline_fails_before_any_io(self):
        provider, client = make_provider()
        expired = ModelCall(model_id="gpt-test", prompt="x", max_output_tokens=8,
                            deadline=time.monotonic() - 1)
        with self.assertRaises(ProviderError) as ctx:
            provider.generate(expired)
        self.assertTrue(ctx.exception.retryable)
        self.assertEqual(client.calls, [])

    def test_missing_deadline_fails_before_any_io(self):
        provider, client = make_provider()
        with self.assertRaises(ProviderError) as ctx:
            provider.generate(ModelCall(model_id="gpt-test", prompt="x", max_output_tokens=8))
        self.assertFalse(ctx.exception.retryable)
        self.assertEqual(client.calls, [])

    def test_four_timeouts_capped_by_remaining_budget(self):
        provider, client = make_provider()
        provider.generate(call(seconds=0.5))
        timeout = client.calls[0]["timeout"]
        self.assertEqual(len(timeout), 4)
        for value in timeout:
            self.assertLessEqual(value, 0.5)
            self.assertGreater(value, 0)

    def test_timeouts_use_configured_values_when_budget_is_large(self):
        provider, client = make_provider()
        provider.generate(call(seconds=60))
        self.assertEqual(
            client.calls[0]["timeout"],
            (CONNECT_TIMEOUT_S, READ_TIMEOUT_S, WRITE_TIMEOUT_S, POOL_TIMEOUT_S),
        )

    def test_late_response_is_discarded(self):
        def slow():
            time.sleep(0.05)
            return SimpleNamespace(output_text="late", model="gpt-test")

        provider, _ = make_provider(slow)
        with self.assertRaises(ProviderError) as ctx:
            provider.generate(call(seconds=0.01))
        self.assertTrue(ctx.exception.retryable)


class RequestShapeTests(unittest.TestCase):
    def test_request_arguments(self):
        provider, client = make_provider()
        provider.generate(call())
        self.assertEqual(len(client.calls), 1)
        kwargs = client.calls[0]
        self.assertEqual(kwargs["model"], "gpt-test")
        self.assertEqual(kwargs["input"], "hi")
        self.assertEqual(kwargs["max_output_tokens"], 64)
        self.assertIs(kwargs["store"], False)

    def test_provider_satisfies_contract(self):
        provider, _ = make_provider()
        self.assertIsInstance(provider, ModelProvider)
        self.assertEqual(provider.name, "openai")


class ResponseTests(unittest.TestCase):
    def test_valid_response(self):
        provider, _ = make_provider()
        result = provider.generate(call())
        self.assertEqual(result, ModelResult(text="hello", model_id="gpt-test"))

    def test_mismatched_model_id_is_passed_through_not_rewritten(self):
        other = SimpleNamespace(output_text="hi", model="gpt-other")
        provider, _ = make_provider(other)
        result = provider.generate(call(model="gpt-test"))
        self.assertEqual(result.model_id, "gpt-other")
        self.assertNotEqual(result.model_id, "gpt-test")

    def test_missing_model_id_becomes_empty_and_cannot_match(self):
        provider, _ = make_provider(SimpleNamespace(output_text="hi"))
        result = provider.generate(call(model="gpt-test"))
        self.assertEqual(result.model_id, "")

    def test_non_text_output_becomes_empty(self):
        provider, _ = make_provider(SimpleNamespace(output_text=None, model="gpt-test"))
        self.assertEqual(provider.generate(call()).text, "")


class ErrorMappingTests(unittest.TestCase):
    def assert_mapped(self, exc, retryable, expected_cls=ProviderError):
        provider, client = make_provider(exc)
        with self.assertRaises(ProviderError) as ctx:
            provider.generate(call())
        self.assertIs(type(ctx.exception), expected_cls)
        self.assertEqual(ctx.exception.retryable, retryable)
        self.assertNotIn(SECRET, str(ctx.exception))
        self.assertEqual(len(client.calls), 1)  # zero retries
        return ctx.exception

    def test_401(self):
        self.assert_mapped(FakeAuth(status_code=401), False)

    def test_403(self):
        self.assert_mapped(FakePerm(status_code=403), False)

    def test_404(self):
        self.assert_mapped(FakeNotFound(status_code=404), False)

    def test_429_is_rate_limited(self):
        exc = self.assert_mapped(FakeRateLimit(status_code=429), True, RateLimitedError)
        self.assertEqual(exc.error_code, "provider_rate_limited")

    def test_5xx(self):
        self.assert_mapped(FakeInternal(status_code=503), True)
        self.assert_mapped(FakeStatus(status_code=502), True)

    def test_connection_error(self):
        self.assert_mapped(FakeConn(), True)

    def test_timeout_is_checked_before_connection(self):
        self.assert_mapped(FakeTimeout(), True)

    def test_unknown_exception_is_not_retryable(self):
        self.assert_mapped(RuntimeError("boom " + SECRET), False)


class GatewayCompatibilityTests(unittest.TestCase):
    def setUp(self):
        self.profile = ModelProfile(
            alias="openai_default",
            provider="openai",
            model_id="gpt-test",
            capabilities=ModelCapabilities(
                text_generation=True, max_context_tokens=8192, max_output_tokens=4096
            ),
            runs_locally=False,
        )

    def gateway(self, provider):
        return ModelGateway({"openai": provider}, max_concurrent_calls=2)

    def test_success_through_gateway(self):
        provider, _ = make_provider()
        result = self.gateway(provider).generate(
            self.profile, call(), time.monotonic() + 5
        )
        self.assertEqual(result.text, "hello")

    def test_model_mismatch_rejected_by_gateway(self):
        provider, _ = make_provider(SimpleNamespace(output_text="hi", model="gpt-other"))
        with self.assertRaises(SanourError) as ctx:
            self.gateway(provider).generate(self.profile, call(), time.monotonic() + 5)
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_INVALID_RESPONSE)

    def test_missing_model_rejected_by_gateway(self):
        provider, _ = make_provider(SimpleNamespace(output_text="hi"))
        with self.assertRaises(SanourError) as ctx:
            self.gateway(provider).generate(self.profile, call(), time.monotonic() + 5)
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_INVALID_RESPONSE)


if __name__ == "__main__":
    unittest.main()
