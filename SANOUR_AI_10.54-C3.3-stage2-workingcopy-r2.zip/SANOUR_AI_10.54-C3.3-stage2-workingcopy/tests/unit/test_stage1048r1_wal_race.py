"""Stage 10.54-C3.1: regression for the first-open race in the stage 10.48-R1 repository.
Root cause (docs/RACE_DIAGNOSIS_10_54C31.md): a journal-mode switch overlapping another opener on a new file can answer
SQLITE_BUSY at once. The fix serializes first opens with a blocking flock. These tests are deterministic: they hold the
lock or inject an answer with a proxy; no timing decides the result (the waiting test only checks that a blocked open
stays blocked while the lock is held)."""

import fcntl
import os
import sqlite3
import tempfile
import threading
import time
import unittest
from unittest import mock

from sanour_ai.ledger import sqlite_repository as R
from sanour_ai.ledger.repository import LedgerStorageError
from tests.unit.test_stage1048 import rec


class Proxy:
    def __init__(self, conn, plan):
        self._c = conn
        self._plan = plan

    def execute(self, sql, *a):
        if "journal_mode=WAL" in sql:
            self._plan["calls"] += 1
            if self._plan["answers"]:
                raise sqlite3.OperationalError(self._plan["answers"].pop(0))
        return self._c.execute(sql, *a)

    def __getattr__(self, name):
        return getattr(self._c, name)


def connect_with(plan):
    real = sqlite3.connect
    return mock.patch.object(R.sqlite3, "connect", side_effect=lambda *a, **k: Proxy(real(*a, **k), plan))


class FirstOpenRace(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory()
        self.path = os.path.join(self._td.name, "usage.db")

    def tearDown(self):
        self._td.cleanup()

    def test_an_open_waits_while_another_opener_holds_the_lock(self):
        fd = os.open(self.path + ".openlock", os.O_RDWR | os.O_CREAT, 0o600)
        fcntl.flock(fd, fcntl.LOCK_EX)
        result = {}

        def opener():
            repo = R.SqliteUsageRepository(self.path)
            result["ok"] = repo.append(rec("lock-1"))
            repo.close()

        t = threading.Thread(target=opener, daemon=True)
        t.start()
        try:
            t.join(timeout=0.5)
            self.assertTrue(t.is_alive(), "the open did not wait for the lock")
        finally:
            os.close(fd)                         # release
        t.join(timeout=20)
        self.assertFalse(t.is_alive())
        self.assertEqual(result.get("ok"), True)

    def test_a_busy_answer_on_the_switch_is_raised_once_not_retried(self):
        plan = {"answers": ["database is locked"], "calls": 0}
        with connect_with(plan):
            with self.assertRaises(LedgerStorageError):
                R.SqliteUsageRepository(self.path)
        self.assertEqual(plan["calls"], 1)

    def test_the_lock_is_released_after_a_failed_open(self):
        plan = {"answers": ["database is locked"], "calls": 0}
        with connect_with(plan):
            with self.assertRaises(LedgerStorageError):
                R.SqliteUsageRepository(self.path)
        result = {}

        def reopen():                                  # bounded: a leaked lock would block this thread forever
            repo = R.SqliteUsageRepository(self.path)
            result["ok"] = repo.append(rec("after-fail"))
            repo.close()

        t = threading.Thread(target=reopen, daemon=True)
        t.start()
        t.join(timeout=10)
        self.assertFalse(t.is_alive(), "the lock was not released after a failed open")
        self.assertEqual(result.get("ok"), True)

    def test_a_normal_open_is_unchanged(self):
        repo = R.SqliteUsageRepository(self.path)
        try:
            self.assertTrue(repo.append(rec("plain-1")))
        finally:
            repo.close()
        c = sqlite3.connect(self.path)
        try:
            self.assertEqual(c.execute("PRAGMA journal_mode").fetchone()[0], "wal")
        finally:
            c.close()


if __name__ == "__main__":
    unittest.main()
