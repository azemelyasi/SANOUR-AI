"""Stage 10.54-A: persistent evidence ledger foundation. Offline, no network, no keys, no providers."""

import ast
import hashlib
import json
import os
import pathlib
import sqlite3
import subprocess
import sys
import tempfile
import textwrap
import threading
import unittest
from datetime import datetime, timedelta, timezone

from sanour_ai.persistence import (
    EvidenceLedger, GovernanceEventLedger, IdempotencyConflict, Ledger, LedgerBusyError, LedgerStorageError,
    LinkRejected, RecordRejected, SchemaError,
)
from sanour_ai.persistence import canonical as C
from sanour_ai.persistence import migrations as M

ROOT = pathlib.Path(__file__).resolve().parents[2]
SRC = ROOT / "src"
T0 = datetime(2026, 1, 1, tzinfo=timezone.utc)
ENV = {**os.environ, "PYTHONPATH": f"{SRC}{os.pathsep}{ROOT}", "PYTHONDONTWRITEBYTECODE": "1"}


def clock():
    return T0


def run_py(code, *args, check=True):
    p = subprocess.run([sys.executable, "-c", textwrap.dedent(code), *args], env=ENV, capture_output=True,
                       text=True, timeout=120)
    if check and p.returncode != 0:
        raise AssertionError(f"subprocess failed rc={p.returncode}: {p.stderr[-600:]}")
    return p


class Base(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.path = os.path.join(self._tmp.name, "ledger.db")
        self.led = None

    def open(self, **kw):
        kw.setdefault("clock", clock)
        led = Ledger(self.path, **kw)
        self.addCleanup(led.close)
        return led

    def raw(self):
        c = sqlite3.connect(self.path, isolation_level=None)
        self.addCleanup(c.close)
        return c

    def ev_args(self, eid="EV-1", artifact=b"artifact-bytes", **kw):
        a = dict(evidence_id=eid, provider_id="openai", criterion="sdk_transport_conformance",
                 kind="LIVE", supports=True, artifact=artifact, source="live://run/1", reviewer="rev",
                 recorded_by="rec", verified_at=T0 - timedelta(days=1), method="live_api_probe",
                 software="probe", software_version="1.0", note="reviewed run")
        a.update(kw)
        return a


# ---------------------------------------------------------------- schema
class SchemaCreation(Base):
    def test_tables_triggers_indexes_exist(self):
        self.open()
        c = self.raw()
        names = {(t, n) for t, n in c.execute("SELECT type, name FROM sqlite_master")}
        for t in ("ledger_records", "ledger_links", "schema_migrations"):
            self.assertIn(("table", t), names)
        for g in ("ledger_records_no_update", "ledger_records_no_delete", "ledger_records_no_replace",
                  "ledger_links_no_update", "ledger_links_no_delete", "ledger_links_no_replace",
                  "schema_migrations_no_update", "schema_migrations_no_delete", "schema_migrations_no_replace"):
            self.assertIn(("trigger", g), names)
        self.assertIn(("index", "ledger_links_target"), names)

    def test_version_recorded(self):
        led = self.open()
        self.assertEqual(led.schema_version(), M.LATEST_VERSION)
        self.assertEqual(self.raw().execute("PRAGMA user_version").fetchone()[0], M.LATEST_VERSION)

    def test_wal_and_full_synchronous(self):
        led = self.open()
        self.assertEqual(self.raw().execute("PRAGMA journal_mode").fetchone()[0], "wal")
        self.assertEqual(led._conn.execute("PRAGMA synchronous").fetchone()[0], 2)   # FULL
        self.assertEqual(led._conn.execute("PRAGMA foreign_keys").fetchone()[0], 1)
        self.assertEqual(led._conn.execute("PRAGMA trusted_schema").fetchone()[0], 0)

    def test_bad_paths_refused(self):
        for p in (":memory:", "", "a\x00b", "x" * 2000, None, 5):
            with self.assertRaises(LedgerStorageError):
                Ledger(p)
        with self.assertRaises(LedgerStorageError):
            Ledger(os.path.join(self._tmp.name, "no_such_dir", "x.db"))
        with self.assertRaises(LedgerStorageError):
            Ledger(self.path, busy_timeout_ms=-1)

    def _patched_connect(self, answers):
        real = Ledger._connect

        class Wrap:
            def __init__(self, conn):
                self._c = conn

            def execute(self, sql, *a):
                for key, value in answers.items():
                    if sql.strip().upper() == key:
                        return type("R", (), {"fetchone": lambda _s: (value,)})()
                return self._c.execute(sql, *a)

            def __getattr__(self, name):
                return getattr(self._c, name)
        return real, lambda self, *, readonly: Wrap(real(self, readonly=readonly))

    def test_open_refused_when_wal_unavailable(self):
        real, wrapped = self._patched_connect({"PRAGMA JOURNAL_MODE=WAL": "delete"})
        Ledger._connect = wrapped
        try:
            with self.assertRaises(LedgerStorageError):
                Ledger(self.path)
        finally:
            Ledger._connect = real

    def test_open_refused_when_integrity_check_fails(self):
        real, wrapped = self._patched_connect({"PRAGMA QUICK_CHECK": "row 3 missing from index"})
        Ledger._connect = wrapped
        try:
            with self.assertRaises(LedgerStorageError):
                Ledger(self.path)
        finally:
            Ledger._connect = real

    def test_corrupt_file_refused(self):
        pathlib.Path(self.path).write_bytes(b"this is not a sqlite database" * 100)
        with self.assertRaises(LedgerStorageError):
            Ledger(self.path)

    def test_check_constraints_enforced_in_sql(self):
        self.open()
        c = self.raw()
        with self.assertRaises(sqlite3.IntegrityError):   # seq 1 must have genesis prev_hash
            c.execute("INSERT INTO ledger_records VALUES ('evidence',1,'a','K','t',?,?,?,x'00')",
                      ("1" * 64, "2" * 64, "3" * 64))
        with self.assertRaises(sqlite3.IntegrityError):   # short hash
            c.execute("INSERT INTO ledger_records VALUES ('evidence',1,'a','K','t',?,'abc',?,x'00')",
                      ("0" * 64, "3" * 64))


# ---------------------------------------------------------------- migrations
class Migrations(Base):
    def test_upgrade_from_v1_keeps_data_and_chain(self):
        old = Ledger(self.path, clock=clock, migrations=(M.V1,))
        for i in range(3):
            old.append("governance", f"g{i}", "GATE", {"i": i})
        self.assertEqual(old.schema_version(), 1)
        head = old.head("governance")
        old.close()
        new = self.open()
        self.assertEqual(new.schema_version(), M.LATEST_VERSION)
        self.assertEqual(new.head("governance"), head)
        self.assertTrue(new.verify().ok)
        new.revoke("governance", "g1", event_kind="REVOKED", actor="a", reason="no longer valid")  # v2 table works
        self.assertEqual(new.standing("governance", "g1"), "revoked")

    def test_migration_applied_by_another_opener_in_the_gap_is_skipped(self):
        real, state = M.check_applied, {"busy": False}

        def racing(applied, migrations):
            pending = real(applied, migrations)
            if not state["busy"]:
                state["busy"] = True
                Ledger(self.path, clock=clock).close()   # another opener finishes every migration first
            return pending
        M.check_applied = racing
        try:
            led = self.open()
        finally:
            M.check_applied = real
        self.assertEqual(led.schema_version(), M.LATEST_VERSION)
        self.assertEqual(self.raw().execute("SELECT COUNT(*) FROM schema_migrations").fetchone()[0], M.LATEST_VERSION)

    def test_reopen_is_idempotent(self):
        self.open().close()
        n = self.raw().execute("SELECT COUNT(*) FROM schema_migrations").fetchone()[0]
        self.open().close()
        self.assertEqual(self.raw().execute("SELECT COUNT(*) FROM schema_migrations").fetchone()[0], n)

    def test_database_newer_than_code_refused(self):
        self.open().close()
        with self.assertRaises(SchemaError):
            Ledger(self.path, clock=clock, migrations=(M.V1,))

    def test_checksum_drift_refused(self):
        self.open().close()
        drift = M.Migration(1, "ledger_records", M.V1.statements + ("SELECT 1",), M.V1.sqlite_only)
        with self.assertRaises(SchemaError):
            Ledger(self.path, clock=clock, migrations=(drift, M.V2, M.V3))

    def test_checksum_stored_matches_code(self):
        self.open()
        rows = dict(self.raw().execute("SELECT version, checksum FROM schema_migrations"))
        self.assertEqual(rows, {m.version: m.checksum for m in M.MIGRATIONS})

    def test_released_migration_checksums_pinned(self):
        self.assertEqual(
            [m.checksum for m in M.MIGRATIONS[:2]],
            json.loads((ROOT / "docs" / "MIGRATION_CHECKSUMS_10_54A.json").read_text())["checksums"])
        self.assertEqual(
            [m.checksum for m in M.MIGRATIONS],
            json.loads((ROOT / "docs" / "MIGRATION_CHECKSUMS_10_54B.json").read_text())["checksums"])

    def test_failed_migration_rolls_back_completely(self):
        self.open().close()
        bad = M.Migration(M.LATEST_VERSION + 1, "bad", ("CREATE TABLE half_done (x INTEGER)", "THIS IS NOT SQL"))
        with self.assertRaises(Exception):
            Ledger(self.path, clock=clock, migrations=M.MIGRATIONS + (bad,))
        c = self.raw()
        self.assertIsNone(c.execute("SELECT name FROM sqlite_master WHERE name='half_done'").fetchone())
        self.assertEqual(c.execute("SELECT MAX(version) FROM schema_migrations").fetchone()[0], M.LATEST_VERSION)
        self.open()   # still opens with the released migrations

    def test_bad_migration_lists_refused(self):
        for lst in ((), (M.V2,), (M.V1, M.V1)):
            with self.assertRaises(SchemaError):
                Ledger(self.path, migrations=lst)

    def test_gap_in_applied_versions_refused(self):
        self.open().close()
        c = self.raw()
        c.execute("DROP TRIGGER schema_migrations_no_delete")
        c.execute("DELETE FROM schema_migrations WHERE version=1")
        with self.assertRaises(SchemaError):
            Ledger(self.path, clock=clock)

    def test_migration_rows_are_append_only(self):
        self.open()
        c = self.raw()
        with self.assertRaises(sqlite3.DatabaseError):
            c.execute("UPDATE schema_migrations SET name='x'")
        with self.assertRaises(sqlite3.DatabaseError):
            c.execute("DELETE FROM schema_migrations")

    def test_concurrent_first_open_in_processes(self):
        code = """
            import sys
            from sanour_ai.persistence import Ledger
            l = Ledger(sys.argv[1]); print(l.schema_version()); l.close()
        """
        for rnd in range(3):
            path = os.path.join(self._tmp.name, f"race{rnd}.db")
            procs = [subprocess.Popen([sys.executable, "-c", textwrap.dedent(code), path], env=ENV,
                                      stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True) for _ in range(8)]
            for p in procs:
                out, err = p.communicate(timeout=120)
                self.assertEqual(p.returncode, 0, err[-400:])
                self.assertEqual(out.strip(), str(M.LATEST_VERSION))
            c = sqlite3.connect(path)
            self.assertEqual(c.execute("SELECT COUNT(*) FROM schema_migrations").fetchone()[0], M.LATEST_VERSION)
            c.close()


# ---------------------------------------------------------------- restart
class Persistence(Base):
    WRITER = """
        import os, sys
        from sanour_ai.persistence import Ledger
        l = Ledger(sys.argv[1])
        for i in range(int(sys.argv[2])):
            l.append("evidence", "%s-%d" % (sys.argv[3], i), "EVIDENCE_ADDED", {"i": i})
        os._exit(0)   # no close, no cleanup: committed data must already be durable
    """

    def test_survives_process_exit_without_close(self):
        run_py(self.WRITER, self.path, "5", "a")
        led = self.open()
        self.assertEqual(len(led.records("evidence")), 5)
        self.assertTrue(led.verify().ok)
        run_py(self.WRITER, self.path, "3", "b")   # a second process continues the same chain
        self.assertEqual(led.head("evidence")[0], 8)
        self.assertTrue(led.verify().ok)

    def test_crash_before_commit_leaves_nothing(self):
        self.open().append("evidence", "keep", "EVIDENCE_ADDED", {"a": 1})
        run_py("""
            import os, sys
            from sanour_ai.persistence import Ledger
            l = Ledger(sys.argv[1])
            l.append("evidence", "old", "EVIDENCE_ADDED", {"x": 1})
            def boom(*a, **k): os._exit(9)    # die inside the transaction, after both inserts
            l._insert_link = boom
            l.supersede("evidence", "old", "new", "EVIDENCE_ADDED", {"x": 2}, event_kind="EVIDENCE_SUPERSEDED", actor="a")
        """, self.path, check=False)
        led = self.open()
        self.assertIsNone(led.get("evidence", "new"))
        self.assertIsNone(led.get("evidence", "supersede:old"))
        self.assertEqual(led.standing("evidence", "old"), "active")
        self.assertTrue(led.verify().ok)

    def test_hashes_identical_after_restart(self):
        led = self.open()
        r = led.append("evidence", "e", "EVIDENCE_ADDED", {"a": 1}).record
        led.close()
        r2 = self.open().get("evidence", "e")
        self.assertEqual((r.seq, r.prev_hash, r.record_hash, r.canonical_bytes),
                         (r2.seq, r2.prev_hash, r2.record_hash, r2.canonical_bytes))


# ---------------------------------------------------------------- atomicity
class Atomicity(Base):
    def test_failed_supersede_rolls_back_both_records(self):
        led = self.open()
        led.append("evidence", "old", "EVIDENCE_ADDED", {"x": 1})
        before = led.head("evidence")

        def boom(*a, **k):
            raise sqlite3.IntegrityError("injected")
        real, led._insert_link = led._insert_link, boom
        with self.assertRaises(Exception):
            led.supersede("evidence", "old", "new", "EVIDENCE_ADDED", {"x": 2}, event_kind="EVIDENCE_SUPERSEDED", actor="a")
        self.assertEqual(led.head("evidence"), before)
        self.assertIsNone(led.get("evidence", "new"))
        self.assertEqual(led.standing("evidence", "old"), "active")
        led._insert_link = real
        led.supersede("evidence", "old", "new", "EVIDENCE_ADDED", {"x": 2}, event_kind="EVIDENCE_SUPERSEDED", actor="a")
        self.assertEqual(led.standing("evidence", "old"), "superseded")
        self.assertTrue(led.verify().ok)

    def test_write_lock_released_after_failure(self):
        led = self.open()
        with self.assertRaises(RecordRejected):
            led.append("evidence", "bad id!", "K", {})
        with self.assertRaises(Exception):
            led.supersede("evidence", "missing", "n", "KIND", {}, event_kind="EV", actor="a")
        self.assertEqual(led.append("evidence", "ok", "KIND", {}).record.seq, 1)

    def test_rejected_input_writes_nothing(self):
        led = self.open()
        for bad in ({"f": 1.5}, {"b": b"x"}, {"s": {1, 2}}, {"k": float("nan")}, [1], "str"):
            with self.assertRaises(RecordRejected):
                led.append("evidence", "e", "KIND", bad)
        self.assertEqual(led.head("evidence")[0], 0)

    def test_busy_writer_raises_and_writes_nothing(self):
        led = self.open(busy_timeout_ms=100)
        holder = self.raw()
        holder.execute("BEGIN IMMEDIATE")
        with self.assertRaises(LedgerBusyError):
            led.append("evidence", "e", "KIND", {})
        holder.execute("ROLLBACK")
        self.assertEqual(led.append("evidence", "e", "KIND", {}).record.seq, 1)

    def test_closed_ledger_refuses(self):
        led = self.open()
        led.close()
        with self.assertRaises(LedgerStorageError):
            led.append("evidence", "e", "KIND", {})
        with self.assertRaises(LedgerStorageError):
            led.get("evidence", "e")


# ---------------------------------------------------------------- idempotency / duplicates
class Idempotency(Base):
    def test_replay_returns_same_record(self):
        led = self.open()
        a = led.append("governance", "g", "GATE", {"v": 1})
        b = led.append("governance", "g", "GATE", {"v": 1})
        self.assertFalse(a.replayed)
        self.assertTrue(b.replayed)
        self.assertEqual(a.record, b.record)
        self.assertEqual(len(led.records("governance")), 1)

    def test_same_id_different_content_conflicts(self):
        led = self.open()
        led.append("governance", "g", "GATE", {"v": 1})
        for kind, payload in (("GATE", {"v": 2}), ("OTHER", {"v": 1})):
            with self.assertRaises(IdempotencyConflict):
                led.append("governance", "g", kind, payload)
        self.assertEqual(len(led.records("governance")), 1)

    def test_replay_independent_of_clock_and_key_order(self):
        led = self.open(clock=lambda: T0)
        led.append("governance", "g", "GATE", {"a": 1, "b": 2})
        led.close()
        led2 = self.open(clock=lambda: T0 + timedelta(hours=5))
        r = led2.append("governance", "g", "GATE", {"b": 2, "a": 1})
        self.assertTrue(r.replayed)
        self.assertEqual(r.record.recorded_at, T0.isoformat(timespec="microseconds"))

    def test_same_id_allowed_in_different_streams(self):
        led = self.open()
        led.append("evidence", "x", "K", {"a": 1})
        led.append("governance", "x", "K", {"a": 2})
        self.assertEqual(led.head("evidence")[0], 1)
        self.assertEqual(led.head("governance")[0], 1)

    def test_concurrent_identical_inserts_write_once(self):
        led = self.open()
        res, errs = [], []

        def go():
            try:
                res.append(led.append("evidence", "same", "K", {"v": 1}))
            except Exception as e:   # pragma: no cover
                errs.append(e)
        ts = [threading.Thread(target=go) for _ in range(16)]
        [t.start() for t in ts]
        [t.join() for t in ts]
        self.assertEqual(errs, [])
        self.assertEqual(sum(not r.replayed for r in res), 1)
        self.assertEqual(len({r.record.record_hash for r in res}), 1)
        self.assertEqual(len(led.records("evidence")), 1)

    def test_concurrent_identical_inserts_two_processes(self):
        code = """
            import sys
            from sanour_ai.persistence import Ledger
            l = Ledger(sys.argv[1])
            n = sum(not l.append("evidence", "same", "K", {"v": 1}).replayed for _ in range(20))
            print(n)
        """
        ps = [subprocess.Popen([sys.executable, "-c", textwrap.dedent(code), self.path], env=ENV,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True) for _ in range(4)]
        created = 0
        for p in ps:
            out, err = p.communicate(timeout=120)
            self.assertEqual(p.returncode, 0, err[-400:])
            created += int(out)
        self.assertEqual(created, 1)
        self.assertEqual(len(self.open().records("evidence")), 1)

    def test_duplicate_row_rejected_by_database(self):
        led = self.open()
        r = led.append("evidence", "dup", "K", {"a": 1}).record
        c = self.raw()
        row = c.execute("SELECT * FROM ledger_records").fetchone()
        with self.assertRaises(sqlite3.IntegrityError):
            c.execute("INSERT INTO ledger_records VALUES (?,?,?,?,?,?,?,?,?)", row)
        with self.assertRaises(sqlite3.IntegrityError):   # same id, new seq
            c.execute("INSERT INTO ledger_records VALUES (?,?,?,?,?,?,?,?,?)",
                      (row[0], 2, row[2], row[3], row[4], r.record_hash, "9" * 64, row[7], row[8]))

    def test_same_content_different_ids_are_distinct_records(self):
        led = self.open()
        a = led.append("evidence", "a", "K", {"v": 1}).record
        b = led.append("evidence", "b", "K", {"v": 1}).record
        self.assertEqual(a.content_sha256, b.content_sha256)
        self.assertNotEqual(a.record_hash, b.record_hash)
        self.assertEqual(b.prev_hash, a.record_hash)


# ---------------------------------------------------------------- concurrency
class Concurrency(Base):
    def test_threaded_writers_contiguous_chain(self):
        led = self.open()
        errs = []

        def go(n):
            try:
                for i in range(25):
                    led.append("evidence", f"t{n}-{i}", "K", {"n": n, "i": i})
            except Exception as e:   # pragma: no cover
                errs.append(e)
        ts = [threading.Thread(target=go, args=(n,)) for n in range(8)]
        [t.start() for t in ts]
        [t.join() for t in ts]
        self.assertEqual(errs, [])
        recs = led.records("evidence", limit=1000)
        self.assertEqual([r.seq for r in recs], list(range(1, 201)))
        self.assertTrue(led.verify().ok)

    def test_two_instances_one_file(self):
        a, b = self.open(), self.open()
        errs = []

        def go(led, tag):
            try:
                for i in range(40):
                    led.append("governance", f"{tag}{i}", "K", {"i": i})
            except Exception as e:   # pragma: no cover
                errs.append(e)
        ts = [threading.Thread(target=go, args=(a, "a")), threading.Thread(target=go, args=(b, "b"))]
        [t.start() for t in ts]
        [t.join() for t in ts]
        self.assertEqual(errs, [])
        self.assertEqual(a.head("governance")[0], 80)
        self.assertTrue(b.verify().ok)

    def test_multi_process_writers(self):
        code = """
            import sys
            from sanour_ai.persistence import Ledger
            l = Ledger(sys.argv[1])
            for i in range(30):
                l.append("evidence", "%s-%d" % (sys.argv[2], i), "K", {"i": i})
        """
        ps = [subprocess.Popen([sys.executable, "-c", textwrap.dedent(code), self.path, f"p{n}"], env=ENV,
                               stderr=subprocess.PIPE, text=True) for n in range(4)]
        for p in ps:
            _, err = p.communicate(timeout=180)
            self.assertEqual(p.returncode, 0, err[-400:])
        led = self.open()
        self.assertEqual(led.head("evidence")[0], 120)
        self.assertTrue(led.verify().ok)

    def test_readers_run_during_writes_and_see_consistent_chain(self):
        led = self.open()
        stop, errs, seen = threading.Event(), [], []

        def writer():
            for i in range(80):
                led.append("evidence", f"w{i}", "K", {"i": i})
            stop.set()

        def reader():
            last = 0
            try:
                while not stop.is_set():
                    rep = led.verify("evidence")
                    if not rep.ok:
                        errs.append(rep.problems)
                    h = led.head("evidence")[0]
                    if h < last:
                        errs.append("head went backwards")
                    last = h
                seen.append(last)
            except Exception as e:   # pragma: no cover
                errs.append(e)
        ts = [threading.Thread(target=writer)] + [threading.Thread(target=reader) for _ in range(4)]
        [t.start() for t in ts]
        [t.join() for t in ts]
        self.assertEqual(errs, [])
        self.assertEqual(led.head("evidence")[0], 80)

    def test_reader_snapshot_not_affected_by_open_write(self):
        led = self.open()
        led.append("evidence", "a", "K", {})
        holder = self.raw()
        holder.execute("BEGIN IMMEDIATE")
        holder.execute("INSERT INTO ledger_records VALUES ('evidence',2,'zz','K','t',?,?,?,x'00')",
                       (led.head("evidence")[1], "7" * 64, "8" * 64))
        self.assertEqual(led.head("evidence")[0], 1)   # uncommitted row invisible; reader is not blocked
        holder.execute("ROLLBACK")

    def test_one_read_context_is_one_snapshot(self):
        a, b = self.open(), self.open()
        a.append("evidence", "e1", "K", {})
        with a._read() as c:
            n1 = c.execute("SELECT COUNT(*) FROM ledger_records").fetchone()[0]
            b.append("evidence", "e2", "K", {})          # committed by another connection mid-read
            n2 = c.execute("SELECT COUNT(*) FROM ledger_records").fetchone()[0]
        self.assertEqual((n1, n2), (1, 1))
        self.assertEqual(a.head("evidence")[0], 2)

    def test_reader_cannot_write(self):
        led = self.open()
        with led._read() as c:
            with self.assertRaises(sqlite3.OperationalError):
                c.execute("INSERT INTO ledger_links VALUES ('evidence',2,'revokes',1)")


# ---------------------------------------------------------------- append-only
class AppendOnly(Base):
    def seeded(self):
        led = self.open()
        for i in range(4):
            led.append("evidence", f"e{i}", "K", {"i": i})
        led.revoke("evidence", "e0", event_kind="REV", actor="a", reason="because reasons")
        return led

    def test_sql_update_and_delete_refused_on_every_table(self):
        self.seeded()
        c = self.raw()
        for stmt in ("UPDATE ledger_records SET kind='X'", "DELETE FROM ledger_records",
                     "DELETE FROM ledger_records WHERE seq=1", "UPDATE ledger_links SET relation='revokes'",
                     "DELETE FROM ledger_links", "UPDATE schema_migrations SET name='x'",
                     "DELETE FROM schema_migrations"):
            with self.assertRaises(sqlite3.DatabaseError, msg=stmt) as cm:
                c.execute(stmt)
            self.assertIn("append-only", str(cm.exception))
        self.assertTrue(self.open().verify().ok)

    def test_insert_or_replace_cannot_overwrite(self):
        led = self.seeded()
        c = self.raw()
        row = c.execute("SELECT * FROM ledger_records WHERE seq=1 AND stream='evidence'").fetchone()
        with self.assertRaises(sqlite3.DatabaseError):
            c.execute("INSERT OR REPLACE INTO ledger_records VALUES (?,?,?,?,?,?,?,?,?)",
                      row[:4] + ("t2",) + row[5:])
        for tbl, row in (("ledger_links", "('evidence',5,'revokes',1)"),
                         ("schema_migrations", "(1,'x','%s','t')" % ("a" * 64))):
            with self.assertRaises(sqlite3.DatabaseError):
                c.execute(f"INSERT OR REPLACE INTO {tbl} VALUES {row}")
        self.assertTrue(led.verify().ok)

    def test_no_mutating_methods_in_public_api(self):
        for cls in (Ledger, EvidenceLedger, GovernanceEventLedger):
            for name in dir(cls):
                self.assertFalse(any(w in name.lower() for w in ("update", "delete", "remove", "truncate", "overwrite", "edit")),
                                 f"{cls.__name__}.{name}")

    def test_tamper_with_guards_dropped_is_detected(self):
        led = self.seeded()
        c = self.raw()
        for t in ("update", "delete"):
            c.execute(f"DROP TRIGGER ledger_records_no_{t}")
        rep = led.verify()
        self.assertFalse(rep.ok)
        self.assertTrue(any(p.startswith("guard_missing") for _, p in rep.problems))

    def _tamper(self, sql, params=()):
        led = self.seeded()
        c = self.raw()
        c.execute("DROP TRIGGER ledger_records_no_update")
        c.execute("DROP TRIGGER ledger_records_no_delete")
        c.execute(sql, params)
        return led.verify("evidence")

    def codes(self, rep):
        return {p for _, p in rep.problems if not p.startswith("guard_missing")}

    def test_edited_bytes_detected(self):
        rep = self._tamper("UPDATE ledger_records SET canonical_bytes=replace(canonical_bytes, x'7b2269223a31', x'7b2269223a39') WHERE seq=2")
        self.assertIn("record_hash_mismatch", self.codes(rep))

    def test_edited_bytes_with_recomputed_hash_breaks_next_link(self):
        led = self.seeded()
        r = led.get("evidence", "e1")
        forged = r.canonical_bytes.replace(b'"i":1', b'"i":7')
        c = self.raw()
        c.execute("DROP TRIGGER ledger_records_no_update")
        c.execute("PRAGMA foreign_keys=OFF")
        c.execute("UPDATE ledger_records SET canonical_bytes=?, record_hash=? WHERE seq=?",
                  (forged, hashlib.sha256(forged).hexdigest(), r.seq))
        codes = self.codes(led.verify("evidence"))
        self.assertIn("prev_hash_mismatch", codes)       # seq 3 still points at the old hash
        self.assertIn("content_digest_mismatch", codes)  # and the content digest no longer matches

    def test_non_canonical_bytes_detected_even_with_consistent_hash(self):
        led = self.seeded()
        last = led.records("evidence")[-1]
        pretty = json.dumps(json.loads(last.canonical_bytes), indent=1, sort_keys=True).encode()
        c = self.raw()
        c.execute("DROP TRIGGER ledger_records_no_update")
        c.execute("UPDATE ledger_records SET canonical_bytes=?, record_hash=? WHERE stream='evidence' AND seq=?",
                  (pretty, hashlib.sha256(pretty).hexdigest(), last.seq))
        self.assertIn("not_canonical", self.codes(led.verify("evidence")))

    def test_edited_column_detected(self):
        rep = self._tamper("UPDATE ledger_records SET kind='FORGED' WHERE seq=2 AND stream='evidence'")
        self.assertIn("columns_differ_from_bytes", self.codes(rep))

    def test_deleted_middle_record_detected(self):
        led = self.seeded()
        c = self.raw()
        c.execute("DROP TRIGGER ledger_records_no_delete")
        c.execute("PRAGMA foreign_keys=OFF")
        c.execute("DELETE FROM ledger_records WHERE seq=2 AND stream='evidence'")
        codes = self.codes(led.verify("evidence"))
        self.assertTrue({"sequence_gap", "prev_hash_mismatch"} <= codes)

    def test_truncated_tail_is_visible_through_exported_head(self):
        led = self.seeded()
        exported = led.head("evidence")
        c = self.raw()
        # tail truncation keeps an internally valid chain, so only the exported head can expose it
        c.execute("PRAGMA foreign_keys=OFF")
        c.execute("DROP TRIGGER ledger_records_no_delete")
        c.execute("DROP TRIGGER ledger_links_no_delete")
        c.execute("DELETE FROM ledger_links")
        c.execute("DELETE FROM ledger_records WHERE seq=5 AND stream='evidence'")
        self.assertNotEqual(led.head("evidence"), exported)

    def test_swapped_link_target_detected(self):
        led = self.seeded()
        c = self.raw()
        c.execute("DROP TRIGGER ledger_links_no_update")
        c.execute("UPDATE ledger_links SET target_seq=2")
        self.assertIn("link_mismatch", self.codes(led.verify("evidence")))


# ---------------------------------------------------------------- supersession / revocation
class Supersession(Base):
    def setUp(self):
        super().setUp()
        self.led = self.open()
        self.ev = EvidenceLedger(self.led)
        self.ev.add(**self.ev_args("EV-1"))

    def test_supersede_appends_and_keeps_old_bytes(self):
        before = self.led.get("evidence", "EV-1")
        new, event = self.ev.supersede("EV-1", **self.ev_args("EV-2", artifact=b"newer"), actor="rev")
        self.assertEqual(self.ev.standing("EV-1"), "superseded")
        self.assertEqual(self.ev.standing("EV-2"), "active")
        self.assertEqual(self.led.get("evidence", "EV-1"), before)
        self.assertEqual([r.seq for r in self.led.records("evidence")], [1, 2, 3])
        self.assertEqual(event.record.kind, "EVIDENCE_SUPERSEDED")
        self.assertEqual(new.record.payload["supersedes"], "EV-1")
        self.assertTrue(self.ev.verify().ok)

    def test_cannot_supersede_twice_or_revoked_or_missing_or_self(self):
        self.ev.supersede("EV-1", **self.ev_args("EV-2"), actor="rev")
        with self.assertRaises(LinkRejected):
            self.ev.supersede("EV-1", **self.ev_args("EV-3", artifact=b"other"), actor="rev")
        self.ev.add(**self.ev_args("EV-4"))
        self.ev.revoke("EV-4", "rev", "withdrawn by reviewer")
        with self.assertRaises(LinkRejected):
            self.ev.supersede("EV-4", **self.ev_args("EV-5"), actor="rev")
        with self.assertRaises(LinkRejected):
            self.ev.supersede("NOPE", **self.ev_args("EV-6"), actor="rev")
        with self.assertRaises(LinkRejected):
            self.led.supersede("evidence", "EV-2", "EV-2", "K", {}, event_kind="E", actor="a")
        self.assertIsNone(self.ev.get("EV-3"))
        self.assertIsNone(self.ev.get("EV-5"))

    def test_supersede_replay_is_noop(self):
        a = self.ev.supersede("EV-1", **self.ev_args("EV-2"), actor="rev")
        b = self.ev.supersede("EV-1", **self.ev_args("EV-2"), actor="rev")
        self.assertTrue(b[0].replayed and b[1].replayed)
        self.assertEqual(a[1].record.record_hash, b[1].record.record_hash)
        self.assertEqual(self.led.head("evidence")[0], 3)

    def test_supersede_different_provider_or_criterion_refused(self):
        with self.assertRaises(RecordRejected):
            self.ev.supersede("EV-1", **self.ev_args("EV-2", provider_id="grok"), actor="rev")
        with self.assertRaises(RecordRejected):
            self.ev.supersede("EV-1", **self.ev_args("EV-2", criterion="other"), actor="rev")

    def test_supersede_replay_with_different_content_refused(self):
        self.ev.supersede("EV-1", **self.ev_args("EV-2"), actor="rev")
        with self.assertRaises(LinkRejected):   # same replacement id, different artifact
            self.ev.supersede("EV-1", **self.ev_args("EV-2", artifact=b"different"), actor="rev")
        with self.assertRaises(LinkRejected):   # different actor changes the event content
            self.ev.supersede("EV-1", **self.ev_args("EV-2"), actor="someone-else")
        self.assertEqual(self.led.head("evidence")[0], 3)

    def test_revoke_and_replay_and_conflict(self):
        r = self.ev.revoke("EV-1", "rev", "withdrawn by reviewer")
        self.assertEqual(self.ev.standing("EV-1"), "revoked")
        again = self.ev.revoke("EV-1", "rev", "withdrawn by reviewer")
        self.assertTrue(again.replayed)
        self.assertEqual(again.record.record_hash, r.record.record_hash)
        with self.assertRaises(LinkRejected):
            self.ev.revoke("EV-1", "rev", "a different reason entirely")
        self.assertEqual(self.led.head("evidence")[0], 2)

    def test_revoke_validation(self):
        for actor, reason in (("rev", "no"), ("", "valid reason"), ("  ", "valid reason")):
            with self.assertRaises(RecordRejected):
                self.ev.revoke("EV-1", actor, reason)
        with self.assertRaises(LinkRejected):
            self.ev.revoke("EV-404", "rev", "valid reason")
        self.assertEqual(self.ev.standing("EV-1"), "active")

    def test_revoke_wins_over_superseded(self):
        self.ev.supersede("EV-1", **self.ev_args("EV-2"), actor="rev")
        self.ev.revoke("EV-1", "rev", "found to be wrong")
        self.assertEqual(self.ev.standing("EV-1"), "revoked")

    def test_links_unique_at_sql_level(self):
        self.ev.revoke("EV-1", "rev", "withdrawn by reviewer")
        self.ev.add(**self.ev_args("EV-9"))
        self.ev.revoke("EV-9", "rev", "withdrawn by reviewer")
        c = self.raw()
        with self.assertRaises(sqlite3.IntegrityError):   # same target revoked by a second event
            c.execute("INSERT INTO ledger_links VALUES ('evidence',4,'revokes',1)")
        with self.assertRaises(sqlite3.IntegrityError):   # target must precede the event
            c.execute("INSERT INTO ledger_links VALUES ('evidence',1,'supersedes',1)")

    def test_unknown_standing_raises(self):
        with self.assertRaises(KeyError):
            self.ev.standing("EV-404")

    def test_governance_events_supersede_and_revoke(self):
        g = GovernanceEventLedger(self.led)
        g.append("G-1", "GATE_OPENED", actor="op", subject="openai")
        g.append("G-2", "GATE_OPENED", actor="op", subject="grok")
        g.supersede("G-1", "G-3", "GATE_OPENED", actor="op", subject="openai", detail={"v": 2})
        g.revoke("G-2", "op", "opened in error")
        self.assertEqual((g.standing("G-1"), g.standing("G-2"), g.standing("G-3")), ("superseded", "revoked", "active"))
        self.assertTrue(g.verify().ok)


# ---------------------------------------------------------------- evidence integrity
class EvidenceIntegrity(Base):
    def setUp(self):
        super().setUp()
        self.led = self.open()
        self.ev = EvidenceLedger(self.led)

    def test_artifact_hash_computed_from_bytes(self):
        r = self.ev.add(**self.ev_args(artifact=b"hello")).record
        self.assertEqual(r.payload["artifact_sha256"], hashlib.sha256(b"hello").hexdigest())
        self.assertTrue(self.ev.verify_artifact("EV-1", b"hello"))
        self.assertFalse(self.ev.verify_artifact("EV-1", b"hellp"))

    def test_claimed_hash_checked_not_trusted(self):
        good = hashlib.sha256(b"x").hexdigest()
        self.ev.add(**self.ev_args(artifact=b"x", claimed_sha256=good.upper()))
        with self.assertRaises(RecordRejected):
            self.ev.add(**self.ev_args("EV-2", artifact=b"x", claimed_sha256="0" * 64))
        self.assertIsNone(self.ev.get("EV-2"))

    def test_artifact_bytes_not_stored(self):
        self.ev.add(**self.ev_args(artifact=b"UNIQUE-ARTIFACT-MARKER-12345"))
        blob = b"".join(p.read_bytes() for p in pathlib.Path(self._tmp.name).iterdir())
        self.assertNotIn(b"UNIQUE-ARTIFACT-MARKER-12345", blob)

    def test_record_hash_is_sha256_of_stored_bytes(self):
        r = self.ev.add(**self.ev_args()).record
        self.assertEqual(r.record_hash, hashlib.sha256(r.canonical_bytes).hexdigest())
        raw = self.raw().execute("SELECT canonical_bytes, record_hash FROM ledger_records").fetchone()
        self.assertEqual(hashlib.sha256(raw[0]).hexdigest(), raw[1])

    def test_independent_reimplementation_of_canonical_bytes(self):
        r = self.ev.add(**self.ev_args()).record
        expect = json.dumps({"v": 1, "stream": "evidence", "seq": 1, "record_id": "EV-1", "kind": "EVIDENCE_ADDED",
                             "recorded_at": r.recorded_at, "prev_hash": "0" * 64, "payload": r.payload},
                            sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("ascii")
        self.assertEqual(r.canonical_bytes, expect)

    def test_chain_links_and_sequence(self):
        recs = [self.ev.add(**self.ev_args(f"EV-{i}", artifact=f"a{i}".encode())).record for i in range(1, 6)]
        self.assertEqual(recs[0].prev_hash, "0" * 64)
        for a, b in zip(recs, recs[1:]):
            self.assertEqual(b.prev_hash, a.record_hash)
            self.assertEqual(b.seq, a.seq + 1)
        self.assertEqual(self.led.head("evidence"), (5, recs[-1].record_hash))

    def test_unicode_and_key_order_canonical(self):
        a = self.led.append("evidence", "u1", "K", {"b": "é✓", "a": [1, {"z": None, "y": True}]}).record
        self.assertIn(b"\\u00e9\\u2713", a.canonical_bytes)
        self.assertLess(a.canonical_bytes.index(b'"a"'), a.canonical_bytes.index(b'"b"'))

    def test_validation_errors(self):
        for kw in (dict(artifact=b""), dict(artifact="text"), dict(source=" "), dict(supports="yes"),
                   dict(verified_at=datetime(2026, 1, 1)), dict(artifact=b"x" * (10 * 1024 * 1024 + 1))):
            with self.assertRaises(RecordRejected, msg=list(kw)):
                self.ev.add(**self.ev_args("EV-X", **kw))
        self.assertEqual(self.led.head("evidence")[0], 0)

    def test_id_stream_kind_validation(self):
        for bad in ("", " x", "a b", "x" * 129, "ü", None, 5, "-lead"):
            with self.assertRaises(RecordRejected):
                self.led.append("evidence", bad, "K", {})
        for bad in ("lower", "", "1X", "X" * 65):
            with self.assertRaises(RecordRejected):
                self.led.append("evidence", "ok", bad, {})
        with self.assertRaises(RecordRejected):
            self.led.append("providers", "ok", "K", {})

    def test_payload_limits(self):
        deep = cur = {}
        for _ in range(C.MAX_DEPTH + 2):
            cur["n"] = {}
            cur = cur["n"]
        for bad in (deep, {"s": "x" * (C.MAX_STRING + 1)}, {1: "int key"}, {"n": 2**70},
                    {"l": ["x" * 60_000] * 30}):
            with self.assertRaises(RecordRejected):
                self.led.append("evidence", "p", "K", bad)

    def test_ledger_report_counts(self):
        for i in range(3):
            self.ev.add(**self.ev_args(f"EV-{i}", artifact=bytes([i + 1])))
        rep = self.led.verify()
        self.assertEqual((rep.ok, rep.records), (True, 3))


class GovernancePersistence(Base):
    def test_events_persist_with_independent_chain(self):
        led = self.open()
        g, e = GovernanceEventLedger(led), EvidenceLedger(led)
        e.add(**self.ev_args())
        a = g.append("G-1", "PROVIDER_STATE_CHANGED", actor="op", subject="openai", detail={"to": "VALIDATED"}).record
        b = g.append("G-2", "REPORT_ISSUED", actor="op", subject="RR-1").record
        self.assertEqual((a.seq, a.prev_hash), (1, "0" * 64))
        self.assertEqual(b.prev_hash, a.record_hash)
        led.close()
        again = GovernanceEventLedger(self.open())
        self.assertEqual(again.get("G-1").payload["detail"], {"to": "VALIDATED"})
        self.assertTrue(again.verify().ok)

    def test_validation(self):
        g = GovernanceEventLedger(self.open())
        for actor, subject in (("", "s"), ("a", " ")):
            with self.assertRaises(RecordRejected):
                g.append("G", "EV", actor=actor, subject=subject)
        with self.assertRaises(RecordRejected):
            g.append("G", "lowercase", actor="a", subject="s")
        with self.assertRaises(RecordRejected):
            g.append("G", "EV", actor="a", subject="s", detail={"x": 1.5})

    def test_idempotent_event(self):
        g = GovernanceEventLedger(self.open())
        g.append("G", "EV", actor="a", subject="s")
        self.assertTrue(g.append("G", "EV", actor="a", subject="s").replayed)
        with self.assertRaises(IdempotencyConflict):
            g.append("G", "EV", actor="b", subject="s")


# ---------------------------------------------------------------- secrets
class SecretLeakage(Base):
    SECRETS = ("sk-ABCDEFGH12345678", "api_key=hunter2hunter2", "Authorization: Bearer abcdef123456",
               "-----BEGIN RSA PRIVATE KEY-----")

    def test_secret_like_values_refused_and_never_written(self):
        led = self.open()
        for s in self.SECRETS:
            with self.assertRaises(RecordRejected) as cm:
                led.append("evidence", "s", "K", {"note": f"prefix {s} suffix"})
            self.assertNotIn(s, str(cm.exception))
            with self.assertRaises(RecordRejected):
                led.append("evidence", "s", "K", {"list": [s]})
            with self.assertRaises(RecordRejected):
                led.append("evidence", "s", "K", {s: "v"})
        with self.assertRaises(RecordRejected):
            led.append("evidence", "s", "K", {"api_key": "plainvalue"})
        with self.assertRaises(RecordRejected):
            led.append("evidence", "s", "K", {"nested": {"password": "x"}})
        self.assertEqual(led.head("evidence")[0], 0)
        led.close()
        blob = b"".join(p.read_bytes() for p in pathlib.Path(self._tmp.name).iterdir())
        for s in self.SECRETS + ("hunter2hunter2", "plainvalue"):
            self.assertNotIn(s.encode(), blob)

    def test_empty_secret_named_field_is_fine(self):
        self.open().append("evidence", "ok", "K", {"token": "", "password": None, "token_count": 5})

    def test_secret_in_evidence_fields_refused(self):
        ev = EvidenceLedger(self.open())
        with self.assertRaises(RecordRejected):
            ev.add(**self.ev_args(note="used sk-ABCDEFGH12345678 to call"))

    def test_error_messages_do_not_leak_content(self):
        led = self.open()
        led.append("evidence", "e", "K", {"v": "visible-marker-1"})
        with self.assertRaises(IdempotencyConflict) as cm:
            led.append("evidence", "e", "K", {"v": "visible-marker-2"})
        self.assertNotIn("visible-marker", str(cm.exception))
        self.assertNotIn(self.path, str(cm.exception))

    def test_storage_errors_are_generic(self):
        pathlib.Path(self.path).write_bytes(b"garbage-secret-sk-ABCDEFGH12345678" * 50)
        with self.assertRaises(LedgerStorageError) as cm:
            Ledger(self.path)
        self.assertNotIn("sk-", str(cm.exception))
        self.assertNotIn(self.path, str(cm.exception))

    def test_no_api_key_environment_needed(self):
        env = {k: v for k, v in ENV.items() if "KEY" not in k.upper() and "TOKEN" not in k.upper()}
        p = subprocess.run([sys.executable, "-c",
                            "import sys; from sanour_ai.persistence import Ledger; l=Ledger(sys.argv[1]); "
                            "l.append('evidence','e','K',{'a':1}); print(l.verify().ok)", self.path],
                           env=env, capture_output=True, text=True, timeout=60)
        self.assertEqual(p.stdout.strip(), "True", p.stderr[-300:])


# ---------------------------------------------------------------- runtime isolation
class RuntimeIsolation(unittest.TestCase):
    PKG = SRC / "sanour_ai" / "persistence"
    ALLOWED_INTERNAL = ("sanour_ai.persistence", "sanour_ai.security.redaction")

    def imports(self, path):
        out = set()
        for node in ast.walk(ast.parse(path.read_text())):
            if isinstance(node, ast.Import):
                out |= {a.name for a in node.names}
            elif isinstance(node, ast.ImportFrom) and node.module and not node.level:
                out.add(node.module)
        return out

    def test_persistence_imports_only_stdlib_and_redaction(self):
        stdlib = set(sys.stdlib_module_names)
        for f in self.PKG.glob("*.py"):
            for mod in self.imports(f):
                top = mod.split(".")[0]
                if top == "sanour_ai":
                    self.assertTrue(any(mod == a or mod.startswith(a + ".") for a in self.ALLOWED_INTERNAL), f"{f.name}: {mod}")
                else:
                    self.assertIn(top, stdlib, f"{f.name}: {mod}")
                self.assertNotIn(top, {"socket", "urllib", "http", "ssl", "requests", "httpx", "asyncio"})

    def test_import_loads_no_provider_readiness_or_core_modules(self):
        p = run_py("""
            import sys, json
            import sanour_ai.persistence
            bad = [m for m in sys.modules if m.startswith(("sanour_ai.providers", "sanour_ai.readiness",
                   "sanour_ai.core", "sanour_ai.models", "sanour_ai.composition", "sanour_ai.governance",
                   "sanour_ai.ledger"))]
            net = [m for m in ("socket", "ssl", "urllib.request", "http.client", "httpx", "requests", "openai")
                   if m in sys.modules]
            print(json.dumps([bad, net]))
        """)
        self.assertEqual(json.loads(p.stdout), [[], []])

    def test_core_does_not_import_readiness_or_persistence(self):
        for f in (SRC / "sanour_ai" / "core").glob("*.py"):
            for mod in self.imports(f):
                self.assertFalse(mod.startswith(("sanour_ai.readiness", "sanour_ai.persistence")), f"{f.name}: {mod}")

    def test_readiness_does_not_import_persistence_yet(self):
        for f in (SRC / "sanour_ai" / "readiness").glob("*.py"):
            for mod in self.imports(f):
                self.assertFalse(mod.startswith("sanour_ai.persistence"), f"{f.name}: {mod}")

    def test_no_provider_names_or_execution_in_persistence_sources(self):
        text = "\n".join(f.read_text().lower() for f in self.PKG.glob("*.py"))
        for word in ("openai", "anthropic", "gemini", "grok", "retry", "fallback", "auto_select", "subprocess", "urlopen"):
            self.assertFalse(word in text, word)

    def test_public_error_codes_unchanged(self):
        from sanour_ai.errors import ErrorCode
        self.assertEqual([(e.name, e.value) for e in ErrorCode], [
            ("INVALID_REQUEST", "invalid_request"), ("NO_ELIGIBLE_MODEL", "no_eligible_model"),
            ("PROVIDER_FAILED", "provider_failed"), ("PROVIDER_TIMEOUT", "provider_timeout"),
            ("PROVIDER_OVERLOADED", "provider_overloaded"), ("PROVIDER_RATE_LIMITED", "provider_rate_limited"),
            ("PROVIDER_INVALID_RESPONSE", "provider_invalid_response"),
            ("PROVIDER_CONTENT_BLOCKED", "provider_content_blocked"), ("INTERNAL_ERROR", "internal_error")])

    def test_persistence_errors_are_not_public_error_codes(self):
        from sanour_ai import errors
        from sanour_ai.persistence import errors as pe
        self.assertFalse(hasattr(errors, "LedgerError"))
        self.assertFalse(issubclass(pe.LedgerError, errors.SanourError))

    def test_deadline_and_semaphore_settings_unchanged(self):
        from sanour_ai.config import settings
        src = (SRC / "sanour_ai" / "config" / "settings.py").read_text()
        self.assertIn("SANOUR_MAX_CONCURRENT_PROVIDER_CALLS", src)
        self.assertNotIn("persistence", src)

    def test_tests_run_without_network_env(self):
        self.assertEqual(os.environ.get("SANOUR_ALLOW_NETWORK"), None)


if __name__ == "__main__":
    unittest.main()
