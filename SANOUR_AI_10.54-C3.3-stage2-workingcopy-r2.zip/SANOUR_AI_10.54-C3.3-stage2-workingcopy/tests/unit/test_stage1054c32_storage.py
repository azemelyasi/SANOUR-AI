"""Stage 10.54-C3.2: shared first-open lock for the usage repository and both governance paths, the fail-closed
behavior where fcntl is missing, and multi-process first opens. Deterministic waits (a held lock keeps an opener
blocked); the multi-process test runs real processes. This is NOT a Windows test: no Windows host is used."""

import fcntl
import json
import os
import pathlib
import subprocess
import sys
import tempfile
import textwrap
import threading
import unittest

from sanour_ai.governance.sink import DurableSqliteSink, SinkFailed
from sanour_ai.governance.store import GovernanceStore, GovernanceStorageError
from sanour_ai.integrity import AuditError, AuditTrail
from sanour_ai.ledger.repository import LedgerStorageError
from sanour_ai.ledger.sqlite_repository import SqliteUsageRepository
from sanour_ai.storage_lock import LockUnavailable, exclusive_open_lock
from tests.unit.test_stage1048 import rec

ROOT = pathlib.Path(__file__).resolve().parents[2]
SRC = ROOT / "src"
ENV = {**os.environ, "PYTHONPATH": f"{SRC}{os.pathsep}{ROOT}", "PYTHONDONTWRITEBYTECODE": "1"}


def held(path):
    fd = os.open(path + ".openlock", os.O_RDWR | os.O_CREAT, 0o600)
    fcntl.flock(fd, fcntl.LOCK_EX)
    return fd


class OpenLockAcrossComponents(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory()
        self.d = self._td.name

    def tearDown(self):
        self._td.cleanup()

    def _open_waits(self, factory, path):
        fd = held(path)
        done = {}

        def go():
            obj = factory(path)
            done["obj"] = obj
            obj.close()

        t = threading.Thread(target=go, daemon=True)
        t.start()
        try:
            t.join(timeout=0.5)
            self.assertTrue(t.is_alive(), "the open did not wait for the lock")
        finally:
            os.close(fd)
        t.join(timeout=20)
        self.assertFalse(t.is_alive())
        self.assertIn("obj", done)

    def test_usage_repository_first_open_waits(self):
        self._open_waits(SqliteUsageRepository, os.path.join(self.d, "u.db"))

    def test_governance_store_first_open_waits(self):
        self._open_waits(GovernanceStore, os.path.join(self.d, "g.db"))

    def test_governance_sink_first_open_waits(self):
        self._open_waits(DurableSqliteSink, os.path.join(self.d, "s.db"))

    def test_in_memory_governance_store_is_not_locked_and_works(self):
        store = GovernanceStore(":memory:")
        store.close()

    def test_lock_is_released_after_a_refused_governance_open(self):
        path = os.path.join(self.d, "refused.db")
        pathlib.Path(path).write_bytes(b"this is not a sqlite database at all" * 4)
        with self.assertRaises(Exception):
            GovernanceStore(path)
        fd = os.open(path + ".openlock", os.O_RDWR | os.O_CREAT, 0o600)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)      # would raise if a previous open leaked the lock
        finally:
            os.close(fd)


class MissingFcntlFailsClosed(unittest.TestCase):
    """Simulates a platform without fcntl (in a child process). It shows the degraded behavior; it is not a Windows test."""

    def test_modules_import_and_every_open_is_refused_with_a_typed_error(self):
        code = textwrap.dedent("""
            import sys, json, os, tempfile
            sys.modules["fcntl"] = None
            import sanour_ai.ledger.sqlite_repository as R
            import sanour_ai.governance.store as S
            import sanour_ai.governance.sink as K
            import sanour_ai.integrity.audit as A
            d = tempfile.mkdtemp()
            res = {}
            for name, fn, err in (
                ("usage", lambda: R.SqliteUsageRepository(os.path.join(d, "u.db")), R.LedgerStorageError),
                ("store", lambda: S.GovernanceStore(os.path.join(d, "g.db")), S.GovernanceStorageError),
                ("sink", lambda: K.DurableSqliteSink(os.path.join(d, "s.db")), K.SinkFailed),
            ):
                try:
                    fn(); res[name] = "opened"
                except err:
                    res[name] = "refused"
                except Exception as e:
                    res[name] = "other:" + type(e).__name__
            try:
                A.AuditTrail(os.path.join(d, "a.jsonl")).record("backup", "a" * 64, "ok"); res["audit"] = "written"
            except A.AuditError:
                res["audit"] = "refused"
            print(json.dumps(res))
        """)
        r = subprocess.run([sys.executable, "-c", code], env=ENV, capture_output=True, text=True, timeout=120)
        self.assertEqual(r.returncode, 0, r.stderr[-400:])
        self.assertEqual(json.loads(r.stdout.strip().splitlines()[-1]),
                         {"usage": "refused", "store": "refused", "sink": "refused", "audit": "refused"})

    def test_lock_helper_reports_unavailability_without_import_error(self):
        code = textwrap.dedent("""
            import sys, json, tempfile, os
            sys.modules["fcntl"] = None
            import sanour_ai.storage_lock as L
            try:
                with L.exclusive_open_lock(os.path.join(tempfile.mkdtemp(), "x.db")):
                    print(json.dumps("entered"))
            except L.LockUnavailable:
                print(json.dumps("refused"))
        """)
        r = subprocess.run([sys.executable, "-c", code], env=ENV, capture_output=True, text=True, timeout=60)
        self.assertEqual(json.loads(r.stdout.strip().splitlines()[-1]), "refused")


class MultiProcessFirstOpen(unittest.TestCase):
    CHILD = textwrap.dedent("""
        import sys
        from sanour_ai.governance.store import GovernanceStore
        p = sys.argv[1]
        s = GovernanceStore(p)
        s.close()
        print("ok")
    """)

    def test_three_processes_opening_a_new_governance_file_all_succeed(self):
        for trial in range(8):
            with tempfile.TemporaryDirectory() as d:
                path = os.path.join(d, "g.db")
                ps = [subprocess.Popen([sys.executable, "-c", self.CHILD, path], env=ENV,
                                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True) for _ in range(3)]
                for p in ps:
                    out, err = p.communicate(timeout=120)
                    self.assertEqual(p.returncode, 0, f"trial {trial}: {err[-300:]}")
                    self.assertEqual(out.strip(), "ok")


if __name__ == "__main__":
    unittest.main()
