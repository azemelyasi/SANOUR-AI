"""Cross-process lock for FIRST OPENS of a SQLite file (Stage 10.54-C3.2).

Why: a journal-mode switch overlapping another opener on a new file can answer SQLITE_BUSY at once
(docs/RACE_DIAGNOSIS_10_54C31.md, docs/GOVERNANCE_WAL_RACE_10_54C32.md). A blocking kernel lock serializes the opens.

Platform scope (stated, not claimed beyond it):
- POSIX with `fcntl` (Linux and macOS): `fcntl.flock`. Linux was exercised in this project. macOS was NOT exercised.
- Platforms without `fcntl` (Windows): the lock cannot be taken, so callers REFUSE to open (fail closed). This module
  does not implement a Windows lock. Windows support is therefore NOT claimed.
Only the first open is locked. In-memory paths are not locked.
"""

from __future__ import annotations

import os
from collections.abc import Iterator
from contextlib import contextmanager

try:
    import fcntl
except ImportError:          # no fcntl on this platform: locking is unavailable, opening is refused
    fcntl = None


class LockUnavailable(RuntimeError):
    """The platform cannot take the open lock, or the lock file cannot be created. Nothing was opened."""


@contextmanager
def exclusive_open_lock(path: str) -> Iterator[None]:
    if path == ":memory:":
        yield
        return
    if fcntl is None:
        raise LockUnavailable("file locking is not available on this platform")
    try:
        fd = os.open(path + ".openlock", os.O_RDWR | os.O_CREAT, 0o600)
    except OSError:
        raise LockUnavailable("lock file could not be created") from None
    try:
        fcntl.flock(fd, fcntl.LOCK_EX)
        yield
    finally:
        os.close(fd)          # closing the descriptor releases the lock
