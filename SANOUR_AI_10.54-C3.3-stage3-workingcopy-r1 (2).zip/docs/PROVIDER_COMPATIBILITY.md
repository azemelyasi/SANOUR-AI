# Provider compatibility contracts (Stage 10.51)

Source of truth: `src/sanour_ai/providers/compatibility.py`. Checked by `tests/unit/test_stage1051_compat.py`.

## Contract record (schema 1)
Fields: `provider` (registry key), `adapter` (class), `contract_version`, `surface`, `auth_method`, `endpoint`,
`sdk_pins` (exact package versions, empty when no SDK is used), `verified_production` (reviewed evidence only).

| Provider | Adapter | Surface | Auth | SDK pins | Endpoint (pinned in code) | verified_production |
|---|---|---|---|---|---|---|
| openai | OpenAIProvider | openai_responses | sdk_bearer_client | openai==3.45.0, httpx2==2.13.1 | https://api.openai.com/v1 | False |
| anthropic | AnthropicProvider | anthropic_messages | x_api_key_header | none | https://api.anthropic.com/v1/messages | False |
| gemini | GeminiProvider | gemini_generate_content | x_goog_api_key_header | none | https://generativelanguage.googleapis.com/v1beta/models/ | False |
| grok | GrokProvider | grok_chat_completions | bearer_header | none | https://api.x.ai/v1/chat/completions | False |
| grok_responses | XaiResponsesProvider | grok_responses | bearer_header | none | https://api.x.ai/v1/responses | False |

Tests check that each record equals the adapter's own class attributes and module constants. A drift fails the suite.

## Two decisions, kept apart
- Compatibility: the pinned packages are present at the pinned versions, and the attributes the adapter needs are
  present. Checked before the production client is built.
- Production approval: a separate reviewed fact (`verified_production`). It is False for every provider here. Passing
  compatibility or mock tests does not change it.

## Fail-closed rules
- `require_sdk("openai")` runs in `_build_default_client`, after the environment check and before the SDK is imported.
  A missing package or a version other than the pin raises `ConfigError`. The message names the failed rule only,
  never a version or value.
- Injected clients (test seam only) do not pass through this gate. Production never accepts an injected provider
  (composition refuses it).
- The existing attribute checks in `validate_client` still run on every request (see `OPENAI_SDK_SURFACE.md`).

## No fallback, no retry, no auto-select
- A compatibility refusal is a construction error. Composition turns it into a refusal of the runtime. Nothing
  selects another provider, and nothing retries.
- Test: a broken adapter (500, or refused at construction) does not change another adapter's result, transport calls,
  or behavior (`FailureIsolation`).

## Boundary
- Only `providers/openai_provider.py` may import `openai` or `httpx2`/`httpx` (static AST check). The compatibility
  module is stdlib only.

## Not claimed
- No SDK runtime behavior is verified here. The pinned packages are not installable in the current sandbox.
- No provider is production-ready.
