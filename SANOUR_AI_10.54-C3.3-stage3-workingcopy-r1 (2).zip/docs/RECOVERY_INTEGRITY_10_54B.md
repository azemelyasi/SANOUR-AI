# Recovery and integrity verification (Stage 10.54-B)

Additive to Stage 10.54-A. New module `sanour_ai.persistence.recovery`, migration V3 (`ledger_checkpoints`), two new error
classes. V1 and V2 are byte-identical to 10.54-A (checksums pinned in `docs/MIGRATION_CHECKSUMS_10_54A.json` and tested).
Not wired into the runtime. No backup, restore, repair or rebuild exists (stage 10.54-C).

## What it does
- `verify_integrity(ledger, anchors=None)`: read-only. Runs SQLite `integrity_check` and `foreign_key_check`, the 10.54-A chain
  verification for both streams, supersession/revocation group completeness, every checkpoint (own chain, hash, canonical form,
  columns versus bytes, monotone, agrees with the record at its sequence, not ahead of the ledger), and optional external anchors.
  Findings are `(stream, seq, code)` only: never payloads, record ids, reasons, paths or SQL.
- `create_checkpoint(ledger, stream)`: appends `{stream, cp_seq, record_seq, head_hash, schema_version, created_at, prev_cp_hash}`
  (hashed canonical bytes, append-only table with the same update/delete/replace guards). The head is read inside the write
  transaction. Refused when the ledger is behind or disagrees with its last checkpoint, or the head bytes do not match their hash.
  Same head again is a no-op.
- `export_anchor` + `AnchorLog`: the same facts written OUTSIDE the database to a hash-chained JSON-lines file (fsynced). An older
  anchor, or a different head at the same sequence, is refused. A crash mid-append leaves an unfinished tail that is reported and
  dropped by the next append.
- `recover(path, anchors=None)`: open after an abrupt stop (SQLite discards uncommitted work and replays the committed WAL), take
  the write lock once (proves no dead writer holds it), passive WAL checkpoint, full integrity report. It never writes, repairs
  or removes a ledger record; an unclean report is returned, not fixed.
- `Ledger.append` now rejects the reserved id prefixes `supersede:` and `revoke:` (they could otherwise fake an event without its link).
  This is the only behaviour change to 10.54-A code.

## Detection matrix (each row has a test that tampers a real database file)
| Damage | Reported as |
|---|---|
| edited content | `record_hash_mismatch` (+ seq) |
| deleted middle record | `sequence_gap`, `prev_hash_mismatch` |
| reordered rows / changed seq / changed prev_hash | `columns_differ_from_bytes`, `prev_hash_mismatch`, `sequence_gap` |
| fully self-consistent rewrite of part of the chain | `checkpoint_record_mismatch` (needs an earlier checkpoint) |
| truncated tail | `ledger_behind_checkpoint`, `ledger_behind_anchor` |
| whole file replaced by a consistent forgery | only `anchor_mismatch`, and only with an external anchor |
| forged/edited/regressed checkpoint | `checkpoint_*` codes |
| anchor file edited / reordered / regressed / partial tail | `anchor_log_tampered`, `anchor_log_regressed`, `anchor_partial_tail` |
| half-finished supersession/revocation | `event_without_link`, `supersession_replacement_missing` |
| removed guard triggers | `guard_missing:*` |

## Limits (stated, and where tested)
- The anchor protects only if it is stored where an attacker of the database file cannot also rewrite it. Nothing here enforces that.
- Deleting the newest complete lines of the anchor log leaves a valid shorter log and is NOT detected (`test_dropping_whole_newest_lines_is_not_detectable`).
- A forger who rewrites the ledger AND its checkpoints AND has no anchor to compare with is undetectable (`test_whole_file_rewrite_detected_only_by_external_anchor`).
- Records after the newest checkpoint/anchor are only protected by the hash chain itself.
- A single anchor writer is assumed; concurrent anchor writers can interleave lines (the chain would then flag the log).
- `recover` does not fix anything and does not claim to; SQLite itself performs crash recovery.
- Verified on Linux, Python 3.12, local filesystem only. Not run on Windows or network filesystems. Power-loss durability is not simulated (process kills only; the OS page cache survives a process kill).
- Not covered: backup, restore, repair, retention, encryption at rest.
