# Stage 10.54-C3.2: operating-system compatibility of the first-open lock

| Platform | What the code does | Exercised here? | Status |
|---|---|---|---|
| Linux | `fcntl.flock` (kernel lock on the open file description) | YES: all tests, real processes, 5 full-suite runs | Verified in this environment |
| macOS | `fcntl` exists; `flock` is available (BSD semantics) | NO (no macOS host) | NOT verified. Expected to work; not claimed |
| Windows | `fcntl` does not exist. `storage_lock` imports it inside try/except; the lock reports "unavailable" and every opener is REFUSED (fail closed) | Only a simulation of a missing `fcntl` module (child process). No Windows host | Windows is NOT supported by this lock. Opening a store on Windows is refused. Not a Windows test |

Before this stage, `sqlite_repository.py` and `integrity/audit.py` imported `fcntl` at module top. On a platform without
`fcntl` that makes the module fail to import, which is a crash rather than a clear refusal. Now the import is guarded and
the open is refused with a typed error (tests `MissingFcntlFailsClosed`).

Why no Windows lock was written: a Windows implementation (msvcrt.locking or LockFileEx) is untested here. Writing it
without a Windows test would be a claim without evidence. The proper next step is a Windows-hosted test run.

Other limits: network filesystems (NFS, SMB) do not reliably honor flock; the lock is for local files only, and this is not
checked at runtime.
