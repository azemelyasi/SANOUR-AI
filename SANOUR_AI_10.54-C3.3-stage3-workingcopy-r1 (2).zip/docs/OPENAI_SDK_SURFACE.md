# OpenAI adapter: SDK and httpx2 surface (Stage 10.50)

Scope: every place `src/sanour_ai/providers/openai_provider.py` reads something that is not the adapter's own state.
Enforced by `tests/unit/test_stage1050_private_surface.py` (static, SDK-free). Changing this list means a reviewed
change to that test and to this document.

## 1. Private attributes (underscore names on SDK or httpx2 objects)

| Attribute | Object | Read in | Role | Classification |
|---|---|---|---|---|
| `_client` | SDK client | `validate_client` | the httpx2 client the SDK uses | Necessary for the check. No documented public alternative verified. |
| `_custom_headers` | SDK client | `validate_client` | headers set after construction | Necessary: catches header overrides added after construction. |
| `_trust_env` | httpx2 client | `validate_client` | ignores proxy and TLS environment variables | Necessary: a security property. Tested by changing it after construction. |
| `_mounts` | httpx2 client | `validate_client` | per-host transports or proxies | Necessary: refuses explicit proxy or per-host routing. |
| `_transport` | httpx2 client | `validate_client` | transport object | Necessary: its type and TLS settings are checked. |
| `_pool` | httpx2 transport | `_transport_problems` | connection pool | Necessary to reach the proxy and TLS settings. |
| `_proxy_url` | httpx2 pool | `_transport_problems` | explicit proxy | Necessary: refuses explicit proxies. |
| `_ssl_context` | httpx2 pool | `_transport_problems` | TLS context | Necessary: refuses disabled certificate or hostname checks. |

## 2. What was decided, and why no replacement was made

- None of the eight reads was replaced in Stage 10.50. Each one guards a security property (proxy, TLS, environment
  trust, extra routing). A public-API substitute would have to be confirmed against the real SDK and httpx2 packages
  (`openai==3.45.0`, `httpx2==2.13.1`). Those packages were not installable in the R8/R10 environment, so no
  substitute could be verified, and an unverified substitute would weaken a fail-closed check.
- The adapter already builds its own httpx2 client (`_build_http_client`, `trust_env=False`) and passes it to the SDK
  client. A future change could replace some reads with an identity check on objects the adapter created. That
  design would not detect a later mutation of those objects, so it is a trade-off, not a free replacement. Not done.
- Public-looking names that the adapter reads without a leading underscore (`api_key`, `auth_headers`, `base_url`,
  `organization`, `project`, `max_retries`, `workload_identity`, `default_query`, `default_headers`, `responses.create`,
  response `status`, `output_text`, `model`, `usage`, error `body`, `status_code`, `response.headers`) are also
  unverified against the real SDK. They are not private, but they are not verified either.

## 3. Required evidence before any change here

1. Run `sdk-env/run_sdk_suite.sh` (SANOUR_REQUIRE_SDK=1) with the pinned packages.
2. Confirm each attribute in section 1 exists and has the type the check expects.
3. Confirm the exception hierarchy used by `default_sdk_error_types`.
4. Only then consider a replacement, one attribute at a time, with the same test that proves the refusal.
