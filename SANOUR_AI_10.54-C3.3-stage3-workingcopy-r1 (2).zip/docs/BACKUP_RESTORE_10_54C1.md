# Stage 10.54-C1: backup and restore (reconstructed)

Status: RECONSTRUCTED on top of the verified 10.54-B archive. The 10.54-C files from the earlier environment were
not recoverable, so this stage was rebuilt from the B tree. Its results are reported as new results, not as recovered.

## What it does
- `create_backup(source, new_dir, anchor=None)`: SQLite online backup API (one consistent snapshot), verified as a
  private copy (migrations against this code, SQLite integrity, both chains, checkpoints, anchor facts), then published
  as a new directory with `ledger.sqlite` and `manifest.json`.
- `manifest.json` (canonical JSON): file name, size, SHA-256; migration name and checksum per version; per-stream head
  sequence, head hash, record count and checkpoint count; optional anchor facts; `manifest_sha256` over the rest.
- `restore_backup(backup_dir, new_path, anchors=None)`: refuses an existing destination or sidecar, checks the manifest
  hash, shape, migrations and file hash, copies to a private temporary file, re-verifies the copy (including external
  anchors and the manifest's heads and counts), then publishes with `os.link`, which never overwrites. The temporary
  file is always removed.

## Where it lives
`src/sanour_ai/backup/`. It is a separate top-level package on purpose: the 10.54-B boundary guard keeps
`sanour_ai.persistence` free of backup code, and that guard is unchanged.

## Limits (C1)
- No power-loss testing. `fsync` is called but its effect is not tested in-process.
- `create_backup` checks that the destination is absent, then renames. A directory created at the same instant could be
  replaced if it is empty. Restore publication (`os.link`) has no such window.
- A process killed mid-backup can leave a hidden `.sanour-backup-*` directory; it is never published. A process killed
  mid-restore can leave a hidden `.sanour-restore-*.tmp` file next to the destination; it is never published.
- Backup and restore are not wired into Core, providers, or Readiness. No public ErrorCode was added.
- Not production-ready. No real provider, key, or network is involved.
