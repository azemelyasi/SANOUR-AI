# Stage 10.54-C3.1: architecture and security review (findings, not claims)

Status: review of the C3 tree plus one minimal fix. Not production ready. Baseline 10.7 not verified.

## 1. Ledger hook bypass
- The 10.54 `Ledger` (persistence) accepts `commit_hooks`, and `open_guarded_ledger` installs `ChainTailHook`.
  A caller that calls `Ledger(...)` without hooks gets no integrity hook. Nothing in the type system prevents it.
- Current production paths (inventory of `src/`, this stage):
  - `composition/runtime.py` builds `SqliteUsageRepository` (ledger/sqlite_repository.py) and `GovernanceStore`
    (governance/store.py). These are the stage 10.4x stores. They do NOT use the 10.54 `Ledger` and have NO integrity hook.
  - No production module constructs the 10.54 `Ledger`, `EvidenceLedger` or `GovernanceEventLedger`.
  - Therefore, today, production writes bypass the 10.54 hooks by construction. The hooks protect only code that is not
    yet connected to production.
- Future risk: a new module in an allowed package (persistence, integrity, backup) can build an unhooked `Ledger`; the
  facades accept any `Ledger`. The repository scan test catches a direct `Ledger(` call outside those packages. It does NOT
  catch: `SqliteUsageRepository(` or `GovernanceStore(` used for the 10.54 purpose, and any `Ledger(` inside an allowed
  package. The scan test name is misleading about this scope and is documented here.
- Side effects of a stricter rule (for example, making facades require hooks) were not proven safe and were NOT added.

## 2. Backup restore: crash after publication
- Backup: the manifest is written into a staging directory before the rename. A crash after the rename leaves a complete,
  verifiable backup. A crash before the rename leaves only a staging directory (swept).
- Restore: the destination is created by `os.link` of a verified copy. A crash after the link leaves a complete destination
  and a temporary hard link (swept). The process that died never returned a result, so the caller cannot know the outcome.
- Detection of the destination state: `verify_backup(dir)` (backup) and `restore_backup` refusals (existing destination).
  Re-running a restore after a crash is refused because the destination exists. Correct recovery is: verify the existing
  destination, do not re-run blindly.
- Wrong-success risk: the code never reports success before the verification of the same file. An ambiguous state exists only
  for the caller (no result received). It is not a silent success.
- Not proven: durability of the directory entry after the rename (fsync of the parent is called; its effect is not tested).

## 3. Integrity: what each check covers
- `ChainTailHook`: newest 16 records per stream, guard triggers, migration checksums, checkpoint consistency. Per commit.
  Records outside the window are not checked by it (tested).
- `full_integrity` / `verify_integrity`: every record of both chains (sequence, previous hash, record hash, canonical bytes
  vs columns, content digest), guards, migrations, checkpoints, anchors when supplied, expected counts when supplied.
- Signatures: the store has hashes, not signatures. Any party able to rewrite the whole database can recompute every hash.
  The statement "data is signed" is NOT correct for this code; it is hash-chained.
- Consistent rewrite of history: a local re-hash of every record after a change passes every local check. Only an external
  anchor (kept outside the database) detects it. Tested in `test_external_anchor_catches_a_consistent_rewrite_of_history`.
  The anchor's protection depends on where it is stored; this code does not control that location.

## 4. Readiness and Governance: connection status
- Readiness: `readiness/backup_status.py` (pure function) exists. It is NOT called by any runtime path. Its inputs are
  collected by `integrity/composition.py`. Status: available, not connected.
- Governance (`governance/store.py`, `governance/sink.py`): its own SQLite store. Not connected to the integrity ports,
  the 10.54 Ledger, or the hooks. Status: independent, no integrity connection.
- Integrity ports (`integrity/ports.py`, `LocalBackupPort`): available, used by tests; not used by any runtime path.
- No new connection was created in C3.1, because none has a proven requirement and an architecture review.

## 5. Other findings (not changed)
- Same WAL-switch pattern without retry in `governance/store.py:314` and `governance/sink.py:70` (may have the same race on
  new files; not measured).
- `backup_status` reports a live ledger's WAL sidecar as blocked (conservative; documented).
- The 10.48 repository's error mapping discards the SQLite error text (`from None`), which made the flake hard to diagnose.
  Not changed in this stage.
