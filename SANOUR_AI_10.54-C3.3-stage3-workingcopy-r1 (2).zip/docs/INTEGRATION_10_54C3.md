# Stage 10.54-C3: final integrity, crash consistency and boundary enforcement (reconstructed on C2)

Status: built on the verified C2 working copy. Earlier C files were not recovered; these are new results. Not production
ready. Baseline 10.7 was not verified (unavailable here). No provider, key, network or fallback was added.

## 1. Composition boundary (what is enforced, and where)
- `sanour_ai/integrity/composition.py` is the ONLY module that combines persistence, integrity, backup and readiness.
- `open_guarded_ledger(path)` is the sanctioned way to open a production ledger; it installs `ChainTailHook`.
- Repository tests (static scan) forbid: Core importing readiness, integrity, backup, composition or persistence;
  readiness importing persistence, integrity, backup or composition; governance importing backup or touching
  `manifest.json` / `ledger.sqlite`; any package outside persistence/integrity/backup constructing `Ledger(` or the facades.
- Current state, stated plainly: no production module yet constructs a ledger, so the scan is a guard for future code.
  The facades `EvidenceLedger` and `GovernanceEventLedger` still accept any `Ledger`; a caller who builds an unhooked
  Ledger in an allowed package can bypass the hook. The hook is not enforced by the type system.
- Readiness is a pure function (`readiness/backup_status.py`) over a plain snapshot. Facts are gathered in composition.

## 2. Integrity: window vs full check
- `ChainTailHook`: the newest 16 records per stream, guard triggers, migration checksums, checkpoint consistency. Runs on
  every commit. It does NOT cover records outside its window (a test proves this by design).
- `full_integrity(ledger, anchors, expected)`: every record of both chains (sequence, links, hashes, canonical bytes vs
  columns, content digest), guard triggers, migrations, every checkpoint, external anchors when given, and expected
  heads/counts when given. Read-only. Use this for any claim of integrity.
- Detected in tests: record deleted, record moved, metadata column changed, recorded_at changed, checkpoint changed,
  consistent rewrite of history caught only by an external anchor (a local chain re-hash passes every local check).

## 3. Defect found and fixed in C3
`AnchorLog.append` returned early for an identical anchor without repairing a torn last line, so the torn line survived.
Fixed in `persistence/recovery.py` (`_drop_torn_tail`). Test: `test_crash_while_appending_an_anchor...`.
Note: this changes B-stage code (persistence). The B tests still pass.

## 4. Single-writer policy (audit)
- Audit appends are serialized across processes with an exclusive `flock` on `<audit>.lock` (the lock file is not a
  ledger sidecar and holds no data). A second writer waits up to `lock_timeout_s` (default 5 s), then is refused with
  `AuditError`. It never blocks forever. Tested with two processes and with a held lock.
- Ledger writes are serialized by SQLite (`BEGIN IMMEDIATE`) across processes. Two writer processes were tested: all records
  committed, sequence contiguous, full check passes.
- Backup and restore publication: restore publishes with `os.link` (no overwrite, atomic); backup checks absence and renames.
  Two backup processes or two restore processes to the same destination: exactly one succeeds (tested).
- Not claimed: multi-machine coordination, network filesystems, or any lock across hosts.

## 5. Crash consistency: what remains after a death, per state
Deaths are real child processes that call `os._exit(137)` at an injection point (no cleanup runs, as with SIGKILL).
Answers: 1 = data left behind; 2 = integrity kept; 3 = incomplete state published; 4 = safe recovery; 5 = manual action.

| State | 1. Left behind | 2. Integrity | 3. Incomplete published | 4. Safe recovery | 5. Manual |
|---|---|---|---|---|---|
| Backup dies after SQLite copy | `.sanour-backup-*` staging dir | source untouched | no | `sweep_stale_temporaries` | no |
| Backup dies while writing manifest | staging dir with half manifest | source untouched | no | sweep | no |
| Backup dies before rename | complete staging dir | source untouched | no | sweep | no |
| Backup dies after rename | complete backup (manifest written before rename) | verifies | no | use it | no (fsync of parent not proven) |
| Restore dies after copy | `.sanour-restore-*.tmp` | destination absent | no | sweep | no |
| Restore dies during journal switch | tmp plus possible `tmp-wal/-shm` | destination absent | no | sweep removes tmp and its sidecars | no |
| Restore dies before link | complete verified tmp | destination absent | no | sweep, then restore again | no |
| Restore dies after link | complete destination (verifies); tmp hard link | destination verifies | no | sweep removes tmp | YES: the caller got no result. Re-running restore is refused (destination exists). Verify the existing destination instead. |
| Anchor append dies mid-line | torn last line in anchor log | torn line NOT trusted (reported as `anchor_partial_tail`) | no | next append repairs it | no |
| Writer dies mid-transaction | uncommitted transaction discarded by SQLite (WAL) | not re-tested in C3; covered by the 10.54-B SIGKILL and multiprocess tests (those tests remain unchanged) | no | reopen | no |
| Sidecar left next to a destination | `-wal`/`-shm`/`-journal` file | restore refuses to start if present before finalize | no | remove the sidecar after confirming no process holds the file | YES |

## 6. Fault injection (I/O)
- ENOSPC while writing the manifest: `BackupError`, nothing published, no staging left (tested).
- EIO on fsync of the restore copy: `RestoreError`, nothing published, copy removed (tested).
- EXDEV on link: `RestoreError`, no overwrite (tested).
- Sidecar appearing during the journal switch: refused (tested).

## 7. Known limits (not proven, not claimed)
- Power loss and kernel crashes: `fsync` is called on the paths listed in code; its effect is NOT tested. Proving durability
  needs a power-cut or block-level fault rig on the target hardware.
- The restore-after-link ambiguity above needs an operator check.
- `backup_status` reports a live ledger's WAL sidecar as blocked. That is conservative: a running writer is not a fault, and
  the status should be read when no writer is active.
- Performance numbers are one run on this sandbox (see PERFORMANCE_10_54C3.md). No cross-machine claim.
- Readiness and governance are not wired to a live production path yet; the boundary is enforced by tests, not by runtime.
