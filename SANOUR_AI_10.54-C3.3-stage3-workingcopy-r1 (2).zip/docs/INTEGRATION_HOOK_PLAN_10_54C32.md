# Stage 10.54-C3.2: integrity hook and composition, inventory and plan

## 1. Write paths (inventory of the tree at C3.2)
| Write path | Where | Commit hook? | Integrity port? | Used in production? |
|---|---|---|---|---|
| Usage records (`INSERT INTO usage_records`) | ledger/sqlite_repository.py:206 | NO | NO | YES, via composition/runtime.py |
| Governance reservations, costs, outbox, budgets, quotas, pricing, migrations | governance/store.py (about 14 write statements) | NO | NO | YES, via composition/runtime.py |
| Audit receipts and inbox | governance/sink.py (lines 104, 107) | NO | NO | YES, via admission.py (default sink) |
| 10.54 evidence and governance ledger (append-only) | persistence/ledger.py | OPTIONAL (commit_hooks) | via integrity/composition.py | NO (no production caller) |
| Backup and restore publication | backup/archive.py | n/a | n/a | NO (not wired to runtime) |

Note: the `integrity` word in those modules matches `PRAGMA integrity_check` and `integrity_ok()`, not a hook.

## 2. Unhooked writes: can they be used by accident?
Yes. The production write paths in the first table have no hook and no port. Nothing in the type system or in a runtime check
prevents their use, and they are the ones the running system uses. The 10.54 hooks protect a ledger that the running system does
not use. This is the most important finding of this stage.

## 3. Plan (proposal only; nothing implemented here)
- Hook points: Usage and Governance writes would need either (a) the same guarded commit hook inside their own transactions,
  or (b) a separate append-only evidence ledger that every write is also recorded into, in the same transaction.
  Option (b) needs a schema decision and a migration; that is a public-contract change and needs explicit approval.
- Composition: `composition/runtime.py` is the only place that builds the stores. It would call an integrity factory
  (in `integrity/composition.py`) that builds the stores with the hook installed. Readiness and Governance do not import it.
- Boundary guard: a test that the stores are built only through that factory. The current scan does NOT cover
  `SqliteUsageRepository(` or `GovernanceStore(`, so it must be extended, and that extension needs a review first.
- Side effects not proven: hook cost on the usage write path (measured only for the 10.54 ledger: about 0.1 ms per append in
  C3), locking interaction with the existing sqlite_repository lock, and migration of existing stores.

## 4. Status
- Designed: this plan. Not implemented: runtime wiring, store hooks, factory, extended guard.
- Connected today: none of the integrity ports is used by any runtime path.
