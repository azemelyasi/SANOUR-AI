# Stage 10.54-C3.2: governance first-open race

## Question
Do `governance/store.py` (GovernanceStore) and `governance/sink.py` (DurableSqliteSink) have the first-open race found in the
usage repository (C3.1)?

## Evidence (real classes, 3 concurrent processes, same harness for all)
| Path | File state | Opens | Failing before the fix | Failing after the fix |
|---|---|---|---|---|
| GovernanceStore | new | 450 | 2 (GovernanceStorageError; captured statement: `PRAGMA journal_mode=WAL`, `database is locked`) | 0 |
| GovernanceStore | pre-existing WAL file | 180 | 0 | not re-run after fix |
| DurableSqliteSink | new | 450 | 1 (raw OperationalError; statement: `PRAGMA journal_mode=WAL`, `database is locked`) | 0 |

Conclusion (proven by the captured statement and error): both paths have the same race, at the same statement, on new files.
Rates are low (2/450 and 1/450), so the count alone is weak; the captured statement is the stronger evidence.

## Fix
Both first opens now run inside `storage_lock.exclusive_open_lock` (blocking flock on `<file>.openlock`), the same mechanism
as the usage repository. No retry loop was added (the stage 10.37 guard forbids it). The store's open code moved into `_open`
with no logic change; the sink's open lines are unchanged apart from the lock.

## Not changed
`persistence/ledger.py` already retries its WAL switch (B stage) and is NOT covered by the lock. It has not been measured
under this harness in this stage. Its retry loop is a bounded deadline loop; it is not replaced here.

## Tests
`tests/unit/test_stage1054c32_storage.py`: first open waits for a held lock (usage, store, sink); in-memory store works;
a refused open releases the lock; missing `fcntl` refuses every open with a typed error; 3 processes opening a new store
file succeed in 8 trials.
