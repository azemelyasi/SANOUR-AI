# Stage 10.54-C3.1: diagnosis of test_stage1048r1 (intermittent failure)

## Symptom
In a full-suite run of C3, `test_concurrent_processes_still_neither_lose_nor_duplicate_with_reports` failed once in three:
three child processes open the same new database file at the same time. A child died in `SqliteUsageRepository.__init__`
with `LedgerStorageError` (the original SQLite error is discarded with `from None`).
The same test failed once in six isolated runs on the untouched 10.54-B tree, so it predates C3.

## Evidence
1. Isolated runs of the test on C3: 20 of 20 passed. The failure needs concurrent first-opens, not the test body.
2. Replica of the open sequence (same pragmas in the same order, no repository code, `diag` harness outside the tree):
   - new file, plain: 9 failing opens out of 630 (6 of 450 in one run, 3 of 180 in another). All 9 that were logged failed
     at `PRAGMA journal_mode=WAL` with `OperationalError: database is locked`, returned after about 0.2 ms, although
     `busy_timeout` was 10 s. So the busy handler was not waiting.
   - pre-created WAL file, plain: 0 of 450 failing opens. The mode switch is skipped there.
   - new file with a bounded retry on the mode switch: 0 of 450 failing opens.
   - pre-created file with the retry: 0 of 450.
3. The real class (`SqliteUsageRepository`) before the fix: 1 failing open out of 450 concurrent opens. Its SQLite error text
   was not captured, because the class discards it. The rate is low, so this count alone is weak evidence.
4. The 10.54-B persistence ledger (`persistence/ledger.py`, `_open_writer`) already retries the same switch for the same reason
   (its comment says SQLite does not always apply busy_timeout to a journal-mode switch on a new file). The 10.48-R1 repository did not.

## Root cause (established as far as measured)
`PRAGMA journal_mode=WAL` on a new database file, opened concurrently by another process, can return SQLITE_BUSY immediately,
without waiting on `busy_timeout`. The repository had no retry there, so the open failed. Evidence: items 2 and 3 with the
timing of 0.2 ms. The retry removes the failures in the replica (0 of 450 with retry, 6 of 450 without, same workload).

Not established: why SQLite returns BUSY without waiting in this case (that is SQLite internals). We do not claim more than the
measured behavior.

## Fix (minimal, root-cause level)
A first retry loop was tried first and REJECTED: the architecture guard in stage 10.37 forbids retry loops in repository
code, and a loop would have bypassed that rule. The fix is a serialization instead, with no retry and no polling:
`ledger/sqlite_repository.py`: opening a database serializes on a blocking `flock` on `<file>.openlock` (kernel wait,
released when the open finishes or fails). Overlapping openers can no longer run the journal-mode switch together.
The lock covers only the open, not the appends. The 10.48-R1 behavior is otherwise unchanged.

Limitation of this fix: a process that holds the lock and hangs blocks other openers (no timeout). The open is short
and local, so this was accepted; it is recorded here, not hidden.

## Regression tests
`tests/unit/test_stage1048r1_wal_race.py` (4 tests, deterministic): an open waits while another opener holds the lock; an
injected busy answer on the switch is raised once (no retry); a failed open releases the lock; a normal open is unchanged.

## Results after the fix
- Real class, 150 trials of 3 concurrent opens on new files: 0 failing opens of 450.
- The originally failing test: 20 of 20 isolated runs passed.
- Replica with the lock (diagnostic harness, same statements): new file 0 of 450 failing opens; pre-created file 0 of 180.

## Same pattern elsewhere (NOT changed, NOT verified)
`persistence/ledger.py` already retries. These switch journal mode without a retry and may have the same race on a new file:
`governance/store.py:314`, `governance/sink.py:70`. They were not measured in this stage and were not changed.
