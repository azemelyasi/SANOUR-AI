# Persistent Evidence Ledger foundation (Stage 10.54-A)

Package: `sanour_ai.persistence`. Standard library only. Offline. No provider code, no readiness import.
It is **not wired into** `SanourCore`, the Gateway, or the readiness package in this stage. Nothing in the request
path changed, so the deadline and the worker semaphore are untouched.

## Model
Two streams (`evidence`, `governance`). Each is its own hash chain: `seq` starts at 1, `prev_hash` of record 1 is 64 zeros.
One record = one canonical byte string (UTF-8 JSON, sorted keys, no whitespace, ASCII-escaped) holding
`v, stream, seq, record_id, kind, recorded_at, prev_hash, payload`. `record_hash = SHA-256(those exact bytes)`.
The same bytes are stored in `canonical_bytes`. `verify()` re-hashes stored bytes and never trusts a stored hash column.
Payloads may hold dict (str keys), list, str, int, bool, None. Floats are refused: their text form is not portable.
Artifact bytes are hashed by `EvidenceLedger` and never stored.

## Tables (schema v2)
- `ledger_records`: PK `(stream, seq)`, `UNIQUE(stream, record_id)`, `UNIQUE(record_hash)`, CHECKs on lengths and on genesis.
- `ledger_links` (v2): `(stream, event_seq, relation, target_seq)`; relation is `supersedes` or `revokes`; a target can be
  superseded once and revoked once; the target must precede the event; foreign keys to `ledger_records`.
- `schema_migrations`: version, name, checksum, applied_at.

## Guarantees and how they are enforced
| Requirement | Mechanism |
|---|---|
| Atomic | every write is one `BEGIN IMMEDIATE` transaction; supersession writes replacement, event and link together or not at all |
| Idempotent | `record_id` is the idempotency key; same id + same content (`kind`+`payload`) returns the stored record with `replayed=True`; same id + different content raises `IdempotencyConflict`. Replay does not depend on time or key order |
| Append-only | triggers refuse UPDATE, DELETE and clashing INSERT (`INSERT OR REPLACE` bypasses delete triggers, so a BEFORE INSERT guard covers it); the API has no update/delete method |
| Tamper evidence | `verify()` checks sequence, `prev_hash`, hash of stored bytes, canonical form, columns versus bytes, content digest, link targets, and that every guard trigger still exists |
| Supersession / revocation | new append-only events plus a link row; the old record's bytes never change. `standing()` returns active / superseded / revoked (revoked wins) |
| Durability | WAL, `synchronous=FULL`, foreign keys on, `trusted_schema=OFF`; opening fails if WAL cannot be enabled or `quick_check` is not `ok` |
| Concurrency | each read uses its own short, query-only connection and one snapshot; one writer at a time (in-process lock plus SQLite write lock, so several processes are safe); busy timeout then `LedgerBusyError` |
| Secrets | strings and keys are screened with the project redactor plus PEM private-key headers; non-empty values under secret-named keys are refused; errors never echo content or paths |
| Migrations | append-only list; checksum stored and compared on open; newer-than-code, drifted or gapped databases are refused; each migration is one transaction; `docs/MIGRATION_CHECKSUMS_10_54A.json` pins released checksums |

## Limits (stated plainly)
- A party that can rewrite the whole file can rebuild a consistent chain. Tail truncation leaves a valid shorter chain.
  Export `head(stream)` to somewhere else and compare it. Not solved here.
- Dropping the triggers is possible for anyone with file write access. It is detected by `verify()`, not prevented.
- WAL needs a local filesystem with working shared memory; network filesystems are unsupported (open fails if WAL is refused).
- Wall-clock `recorded_at` is the caller's clock and is part of the hashed bytes; it is not a trusted timestamp.
- Failure of the process between COMMIT and the return value leaves a committed record; retry with the same `record_id` is safe.
- Not in this stage: backup, restore, recovery, repair (10.54-B, 10.54-C), wiring into readiness, retention, encryption at rest.

## PostgreSQL compatibility (design only, nothing run against PostgreSQL)
- Portable: table and column layout, TEXT / INTEGER types, CHECK, UNIQUE, FOREIGN KEY, indexes, `?` parameters only
  (use `%s` or `$n` in a PostgreSQL driver), no SQLite-only functions in queries, explicit `seq` instead of rowid/AUTOINCREMENT.
- Translate: `BLOB` to `BYTEA`; the 9 guard triggers (listed in `Migration.sqlite_only`) become `BEFORE UPDATE/DELETE`
  triggers raising an exception plus a unique-violation (replace is not a thing in PostgreSQL, so the clash guard is unnecessary);
  `BEGIN IMMEDIATE` becomes `BEGIN` + `pg_advisory_xact_lock(hash(stream))` or `SELECT ... FOR UPDATE` on the head row;
  `PRAGMA user_version` is dropped (use `schema_migrations`). Hashes are over the stored bytes, so they survive a copy as long
  as `canonical_bytes` is copied byte for byte.
- Floats are banned from payloads precisely so canonical bytes never depend on a database's number formatting.

## Not claimed
No Baseline 10.7 file was read for modification or changed. Baseline integrity is not verified or claimed in this stage.
