# Technical debt register (Stage 10.51)

| ID | Warning | Origin (file and symbol) | Status | Action |
|---|---|---|---|---|
| D1 | ResourceWarning: unclosed file | tests/unit/test_stage1049r3_outbox.py (receipts read), test_stage1049r5_atomicity.py (sink_contract source read), test_stage1049r4_delivery.py (deliver*.json), test_stage1049r4_sink.py (out*.json, dist*.json) | FIXED in 10.51 | Replaced with `pathlib.Path(...).read_text()` (closes the file). Verified: 0 ResourceWarnings in those four modules. |
| D2 | Exception in thread sanour-settle-openai (printed traceback) | tests/unit/test_stage1043.py::RuntimeAfterBaseException::test_runtime_reaches_shutdown_when_all_providers_are_settled. The settler thread (src/sanour_ai/models/gateway.py, _settle_when_idle) re-raises SettlementAborted after a provider close() raised CloseAbort (a BaseException). The class did not patch threading.excepthook. | FIXED in 10.51 (test-side) | Patched threading.excepthook in that one test. The production behavior (sanitized re-raise, bookkeeping before re-raise) is unchanged and still tested by SettlerCleanup. |
| D3 | DeprecationWarning: ModelCatalog deprecated | src/sanour_ai/models/catalog.py (emitted on use). Reached from tests/unit/test_catalog.py and tests/unit/test_stage1036.py. Attributed to pydantic in the output because of the call stack. | OPEN | ModelCatalog is kept for compatibility and is not used operationally. Decide: remove (needs approval, public-ish surface) or keep the warning. |
| D4 | ResourceWarning: Enable tracemalloc (follow-up line) | Same as D1 | FIXED with D1 | none |
| D5 | Skipped SDK-dependent tests (62) | tests/unit/test_openai_provider.py, tests/integration/test_production_openai_path.py, placeholder in test_stage1037_conformance.py, two R8-R1 SDK tests | OPEN | Needs an environment with openai==3.45.0 and httpx2==2.13.1 (sdk-env/run_sdk_suite.sh with SANOUR_REQUIRE_SDK=1). |
| D6 | Unverified SDK attributes read by validate_client | src/sanour_ai/providers/openai_provider.py (8 names, docs/OPENAI_SDK_SURFACE.md) | OPEN | Verify against the real SDK. |
| D7 | Equivalent or weak mutants | C8 (SDK import outside the boundary) is killed by an import error, not by the boundary assertion; R7 G1 and R8 O5 are equivalent | OPEN (documented) | Strengthen the boundary mutant with a non-failing import if needed. |

Measurement: the "after" state of the test run was checked by re-running the four edited modules with `-W default`
(0 ResourceWarnings) and test_stage1043 (0 printed thread exceptions).
