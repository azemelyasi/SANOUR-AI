# Provider Operational Readiness Framework (Stage 10.52)

Package: `src/sanour_ai/readiness/`. Offline, pure, deterministic. No network, no keys, no retry, no fallback, no auto-select.

## Model
- 12 criteria (`Criterion`): SDK/transport conformance, authentication security, model identity verification, deadline compliance,
  worker lifecycle and settlement, concurrency and capacity, error classification, usage accounting, audit integrity,
  response size limits, failure isolation, operational evidence.
- Status per criterion: PASS / FAIL / UNVERIFIED / NOT_APPLICABLE.
- Evidence kinds, never merged: LIVE, LOCAL_TEST, MOCK_TEST, DOCUMENTATION.

## Rules (engine.py)
1. Any contradicting evidence, of any kind, makes the criterion FAIL (beats a waiver and beats live support).
2. PASS needs at least one supporting LIVE record with a named reviewer and the sha256 of its artifact.
3. Local tests, mock tests and documents can only give UNVERIFIED, never PASS.
4. NOT_APPLICABLE is allowed only for SDK/transport conformance, with a written reason. Every other criterion is mandatory.
5. Provider status is the strictest criterion: FAIL > UNVERIFIED > PASS > NOT_APPLICABLE.
6. `production_ready` only when no criterion is FAIL or UNVERIFIED. It is a report value; it does not change the production gate.

## Extension
`ReadinessRegistry.register_provider()` plus `add_evidence()` / `add_waiver()`. A new provider needs no engine change.
`current_evidence.py` holds today's evidence for the five providers; every reference is a real file (tested).

## Current state
All five providers (openai, anthropic, gemini, grok, grok_responses): overall UNVERIFIED, not production ready, zero LIVE evidence.
Run `render_markdown(assess_all(default_registry()))` for the report.

## Remaining limits
- No live evidence exists, so nothing can PASS. This is correct, not a defect.
- LIVE evidence is accepted on reviewer name and artifact hash; the framework cannot check that the artifact is genuine.
- A hung provider call still holds its worker slot until restart (unchanged from earlier stages).
- Evidence entries in `current_evidence.py` are hand-maintained; tests check the files exist, not that they prove the claim.
- Mutation testing is hand-rolled (`tools/mutation_1052.py`), 25 mutants: 23 killed, 2 survivors proven equivalent (see comment in the script).
