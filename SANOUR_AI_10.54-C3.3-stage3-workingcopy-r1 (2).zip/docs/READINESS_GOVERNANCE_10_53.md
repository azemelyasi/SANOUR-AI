# Readiness evidence integrity, governance and lifecycle (Stage 10.53)

All code is in `src/sanour_ai/readiness/`. Standard library plus `sanour_ai` only. Offline-first: nothing here opens a
socket, reads a key, retries, falls back or selects a provider. The core (`core`, `models`, `composition`, `providers`)
never imports this package (a test enforces it), and this package never runs a user request.

## Modules and responsibilities
- `chain.py`: `AppendOnlyLog`, a hash-chained append-only log. No delete, update or truncate. One implementation shared by all three logs.
- `evidence_store.py`: schema v1 `EvidenceRecord` (evidence_id, provider_id, criterion, kind, artifact_sha256, source, reviewer,
  recorded_by, verified_at, method, software, software_version, note, supersedes). Hash is computed from the bytes; a claimed hash
  is only compared. Replacement is `supersede`, withdrawal is `revoke`; both are logged and old records stay.
  Standing: VALID, STALE (past 2/3 of life), EXPIRED, SUPERSEDED, REVOKED. Life: LIVE 90 days, local/mock 180, docs 365.
  `conflicts()` lists criteria with current live evidence both for and against.
- `governance.py`: `GovernedReadiness`. Reuses the 10.52 engine per criterion. PASS needs current, intact LIVE evidence. A broken store
  makes every criterion UNVERIFIED. Optional `artifact_resolver` re-hashes artifacts at evaluation time; mismatch is FAIL.
  Every status change is logged with reason and evidence ids. `issue_report` freezes a report (date, criteria spec version and digest,
  evidence log head, per-evidence sha256) and `get_report` re-verifies it against the log, so later evidence never alters old reports.
  `SPECS` is the versioned criteria registry (append only; v1 digest is pinned by a test; enum/spec mismatch fails closed).
- `lifecycle.py`: REGISTERED, CONFIGURED, VALIDATED, OPERATIONAL, SUSPENDED, RETIRED. Explicit transition table, role per target,
  mandatory reason, validator must differ from configurer, RETIRED terminal, every attempt (including denials) logged, refusal leaves state unchanged.
  It does not import or read readiness: OPERATIONAL is not production ready.
- `current_state.py`: today's five providers, built from the 10.52 entries with real hashes of the referenced repository files.

## LIVE acceptance (fail closed)
Source must be `live://...`; method one of `live_api_probe`, `operator_witnessed_run`, `independent_audit`; reviewer must be on the
store's authorized list and differ from the recorder; timestamp not in the future; no mock/fake/stub/fixture/simulated/synthetic/dummy
marker in source, method, software, note or artifact; no secret-shaped text. Non-live kinds can be recorded but never produce PASS.

## Authenticity limits (not solved, by design)
- The store proves these bytes had this hash when recorded and who was named. It cannot prove the artifact came from a real provider call.
- The reviewer is a string checked against a list supplied by the caller. There is no cryptographic identity or signature.
- Mock detection is keyword screening. A determined forger can avoid the keywords; a genuine artifact containing such a word is refused.
- The hash chain is in process memory. Code with memory access can rebuild a consistent chain. Export `head_hash` and the report digests
  to an external place to get real tamper evidence. Nothing is persisted to disk in this stage.
- Reports are stored in memory only; a restart loses them.
- Clock is injectable and trusted. A wrong system clock affects expiry.

## Other remaining limits
- No provider has LIVE evidence, so none can PASS; all five are UNVERIFIED and not production ready.
- Hung provider calls still hold their worker slot until restart (unchanged).
- 62 SDK tests skip because `openai` and `httpx2` are not installed; they are not counted as passed.
- Redaction is pattern based (`security/redaction.py`); unusual secret shapes can slip through.
- `current_evidence.py` (10.52) is still the hand-kept source for non-live entries.
