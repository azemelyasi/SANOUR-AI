# Tree manifest: method and the unexplained difference

## Method used by this project
- Scope: every regular file under the project root (`find . -type f`), no directories, no symlinks.
- Entry: `sha256sum` of each file.
- Order: sorted by path, byte order (`sort -z` on NUL-separated paths).
- Digest: sha256 of the concatenated `sha256sum` output lines (format `<hash>  ./<path>`).
- Bytecode caches are part of the tree. Run the suite with `PYTHONDONTWRITEBYTECODE=1` and remove `__pycache__` before
  measuring. Otherwise the manifest changes.

Command:
    find . -type f -print0 | sort -z | xargs -0 sha256sum | sha256sum

## Verified facts (this sandbox)
- R8 tree (167 files) gives 2d2eedc72e73fcc31e7f7e422c1238ee3e96ba294d9d6792532372c2175165e3.
- The same tree after two test modules were run (49 bytecode files added) gives dc9572350ec0ddc7c8a03d16e654b4e1be0b0c8239b0f55530c193728190b953.
- Other serializations of the R8 tree (not matching Gemini's value):
  - relative paths without `./`, sorted: 18537770b318d605f898f1ae44a598e6d24c4159b8c8d8d38f2b81061c4ce0a2
  - Python path:hash lines, sorted: 18537770b318d605f898f1ae44a598e6d24c4159b8c8d8d38f2b81061c4ce0a2
  - Python NUL-separated path and hash: 920122450df112b39c2424a0a7f38f7d290b300ef893da24fb1a8989bfbbd8e3

## Unexplained difference
- Gemini reported 69c85b0f6a8b64d164e30c32d824b67fc60a0e95da1643b97ab3148728daa9e3 for a tree it tested.
- None of the serializations above gives that value on the R8 tree.
- Its tree was not provided, so per-file comparison is not possible. The likely causes, not confirmed: a tree
  executed under Python 3.11 (bytecode files differ), a different file set, or a different serialization.
- Required to close: `find . -type f | LC_ALL=C sort | xargs sha256sum` output from the tested tree, or the archive
  that was tested.

## Rule
Two manifests are comparable only when the same method, the same file set, and the same bytecode state were used.
Report the method with every hash.
