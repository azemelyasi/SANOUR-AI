# Stage 10.54-C2: runtime integration, commit hooks and audit (reconstructed on C1)

Status: built on the C1 working copy. Earlier C files were not recovered, so C2 results are new results.
Not production ready. Baseline 10.7 was not verified.

## Architecture
- **Commit hooks** (`persistence/ledger.py`, optional `commit_hooks=`). Each hook runs inside the open write transaction,
  after the change and before COMMIT. A hook that raises rolls the transaction back (fail closed). Hooks are read-only.
  They run for migrations too, so a hook that refuses also refuses an open on a bad database.
- **Integrity hook** (`integrity/hooks.py`, `ChainTailHook`). Checks: append-only guard triggers exist for every table
  that exists; applied migration checksums equal this code's; the newest `tail` records per stream (default 16) are
  contiguous, hash-correct and linked; the latest checkpoint per stream is not ahead of the ledger and matches its record.
  Full-chain, anchor and restore checks stay on demand in `verify_integrity` and `restore_backup`.
- **Backup port** (`integrity/ports.py`, `BackupPort` protocol, `LocalBackupPort`). The only door from the integrity layer to
  backup and restore: `backup`, `restore`, `verify`. Each call is audited on success or refusal.
- **Audit trail** (`integrity/audit.py`). JSON-lines, append-only, one line per distinct event (id = hash of operation,
  target reference, outcome and code). Repeats are not written again. A torn last line from a crash is dropped before the next
  append. Fields: version, id, operation, outcome, fixed code. No paths, messages, payloads or keys.
- **Verify and sweep** (`backup/archive.py`). `verify_backup` runs the full restore check into a private temporary directory
  and removes it. `sweep_stale_temporaries` removes only the `.sanour-restore-*.tmp` (with sidecars) and `.sanour-backup-*`
  entries a killed process left. It must be run only when no backup or restore is active in that directory.

## Sidecar gap from C1 (closed)
C1 checked for sidecars after the WAL switch only, and SQLite may silently remove a stale `-shm` during that switch,
so the check could never fire for that case. C2 refuses any sidecar present BEFORE the finalize step (it is refused, not
removed: a stale rollback journal could otherwise roll the copy back), and keeps the post-switch check. Tests:
`test_finalize_refuses_a_leftover_sidecar`, `test_restored_database_has_no_sidecar_files`.

## Boundaries
- Core, composition, models, providers, readiness and governance must not import `sanour_ai.integrity` or
  `sanour_ai.backup`. Tested.
- Readiness and Governance are not wired to the port in C2. Readiness still cannot import persistence (the 10.54-B
  boundary guard). Connecting a status view is deferred and not claimed.
- No public ErrorCode was added. No provider, key, network or fallback code. Migrations V1 to V3 are unchanged.

## fsync: what is and is not proven
- Proven by tests: sequence of operations, refusal before publication, no overwrite of an existing destination, removal of
  temporaries after an exception and after a SIGKILL of a real process (sweep). `fsync` is called on audit appends and
  restore copies; its durability is not tested.
- NOT proven here: durability after power loss or a kernel crash, and behavior on a specific disk or filesystem. Those need
  a power-cut or fault-injection rig on the target hardware. `fsync` is called; its effect is not tested in-process.

## Limits
- Hooks verify a window (default 16 records per stream) per commit, not the whole chain. Whole-chain checks run on demand.
- The audit trail assumes a single writer per file. Its lock is in-process only.
- `sweep_stale_temporaries` is an operator action. Running it during an active restore could remove that restore's temporary file.
- Concurrency is tested with threads and separate processes on one machine, not across machines.
