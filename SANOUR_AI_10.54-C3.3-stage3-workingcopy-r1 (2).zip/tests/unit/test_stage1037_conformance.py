"""Stage 10.37 provider conformance. One shared suite, run against every adapter in readiness.ADAPTERS.

Fake transports only. No SDK, no network, no real key. A test that needs the OpenAI SDK is skipped
with the reason stated. Conformance means the adapter follows the shared contract. It does not mean
the provider is enabled: xAI Responses stays out of production.
"""

import json
import time
import unittest
from unittest import mock

from pydantic import SecretStr

from sanour_ai.errors import ErrorCode, FailureKind, SanourError
from sanour_ai.models.base import ModelCall, ModelResult, ProviderError
from sanour_ai.models.capabilities import ModelCapabilities, ModelProfile, ProviderCapabilities
from sanour_ai.models.gateway import ModelGateway
from sanour_ai.models.request_identity import RequestIdentity
from sanour_ai.providers import common, readiness
from sanour_ai.providers.common import DeadlineExpired, HttpResult, IncompleteResponseError
from sanour_ai.providers.contract import contract_violations, identity_of

SECRET = "STAGE1037-CONF-SECRET-KY"  # fake, test-only
MODEL = "conf-model-1037"
PROMPT = "STAGE1037-CONF-PROMPT-JH"


class RecordingTransport:
    def __init__(self, status=200, body=b"", headers=None, raise_exc=None, sleep=0.0):
        self.status, self.body, self.headers = status, body, headers or {}
        self.raise_exc, self.sleep = raise_exc, sleep
        self.requests = []

    def __call__(self, url, headers, body, timeout):
        self.requests.append((url, dict(headers), body, timeout))
        if self.sleep:
            time.sleep(self.sleep)
        if self.raise_exc is not None:
            raise self.raise_exc
        return HttpResult(self.status, self.body, self.headers)


def call(budget=5.0, model=MODEL):
    return ModelCall(model_id=model, prompt=PROMPT, max_output_tokens=16, deadline=time.monotonic() + budget)


SPECS = {
    "anthropic": {
        "class": "AnthropicProvider", "auth_header": "x-api-key", "host": "api.anthropic.com",
        "success": {"stop_reason": "end_turn", "content": [{"type": "text", "text": "hi"}], "model": MODEL},
        "incomplete": {"stop_reason": "max_tokens", "content": [{"type": "text", "text": "x"}], "model": MODEL},
        "model_in_body": True,
        "retry_5xx": True,
    },
    "gemini": {
        "class": "GeminiProvider", "auth_header": "x-goog-api-key", "host": "generativelanguage.googleapis.com",
        "success": {"candidates": [{"finishReason": "STOP", "content": {"parts": [{"text": "hi"}]}}],
                    "modelVersion": MODEL},
        "incomplete": {"candidates": [{"finishReason": "MAX_TOKENS", "content": {"parts": [{"text": "x"}]}}],
                       "modelVersion": MODEL},
        "model_in_body": False,  # the model id is in the URL path, validated by the adapter
        "retry_5xx": True,
    },
    "grok": {
        "class": "GrokProvider", "auth_header": "authorization", "host": "api.x.ai",
        "success": {"choices": [{"finish_reason": "stop", "message": {"content": "hi"}}], "model": MODEL},
        "incomplete": {"choices": [{"finish_reason": "length", "message": {"content": "x"}}], "model": MODEL},
        "model_in_body": True,
        "retry_5xx": True,
    },
    "grok_responses": {
        "class": "XaiResponsesProvider", "auth_header": "authorization", "host": "api.x.ai",
        "success": {"status": "completed", "model": MODEL,
                    "output": [{"type": "message", "content": [{"type": "output_text", "text": "hi"}]}]},
        "incomplete": {"status": "incomplete", "output": []},
        "model_in_body": True,
        "retry_5xx": False,  # 5xx is NOT VERIFIED for this surface and fails closed (not retryable)
    },
}


def _adapter_class(name):
    module = {"anthropic": "anthropic_provider", "gemini": "gemini_provider", "grok": "grok_provider",
              "grok_responses": "xai_responses_provider"}[name]
    import importlib
    return getattr(importlib.import_module(f"sanour_ai.providers.{module}"), SPECS[name]["class"])


class ConformanceMixin:
    """Shared checks. Subclasses set `provider` and provide the spec through SPECS."""

    provider = None

    @property
    def spec(self):
        return SPECS[self.provider]

    @property
    def cls(self):
        return _adapter_class(self.provider)

    def adapter(self, transport):
        return self.cls(SecretStr(SECRET), transport=transport)

    # identity and contract
    def test_identity_conforms_to_the_shared_contract(self):
        self.assertEqual(contract_violations(self.cls), [])

    def test_declared_surface_matches_the_readiness_matrix(self):
        row = next(r for r in readiness.rows() if r.provider_id == self.provider)
        self.assertEqual(identity_of(self.cls).surface, row.surface)
        self.assertEqual(identity_of(self.cls).surface, self.cls.surface)

    # response contract
    def test_success_is_normalised_into_a_model_result(self):
        t = RecordingTransport(body=json.dumps(self.spec["success"]).encode())
        result = self.adapter(t).generate(call())
        self.assertIsInstance(result, ModelResult)
        self.assertEqual(result.text, "hi")
        self.assertEqual(result.reported_model_id, MODEL)

    def test_incomplete_body_is_never_a_success(self):
        t = RecordingTransport(body=json.dumps(self.spec["incomplete"]).encode())
        with self.assertRaises(IncompleteResponseError):
            self.adapter(t).generate(call())

    def test_invalid_body_is_never_a_success(self):
        t = RecordingTransport(body=b"not json at all")
        try:
            result = self.adapter(t).generate(call())
        except ProviderError:
            return
        self.assertEqual(result.text, "")  # the gateway refuses an empty answer

    def test_response_size_limit_is_enforced(self):
        t = RecordingTransport(body=b"x" * (common.MAX_RESPONSE_BYTES + 1))
        with self.assertRaises(ProviderError) as ctx:
            self.adapter(t).generate(call())
        self.assertEqual(str(ctx.exception), "provider response too large")

    # request contract
    def test_request_carries_the_requested_model_and_a_pinned_https_endpoint(self):
        t = RecordingTransport(body=json.dumps(self.spec["success"]).encode())
        self.adapter(t).generate(call())
        url, _headers, body, _timeout = t.requests[0]
        self.assertTrue(url.startswith("https://" + self.spec["host"] + "/"))
        if self.spec["model_in_body"]:
            self.assertEqual(json.loads(body)["model"], MODEL)
        else:
            self.assertIn(MODEL, url)

    def test_model_id_outside_the_identifier_shape_is_refused_before_io(self):
        t = RecordingTransport(body=json.dumps(self.spec["success"]).encode())
        with self.assertRaises(ProviderError):
            self.adapter(t).generate(call(model="../escape"))
        self.assertEqual(t.requests, [])

    def test_secret_is_only_in_the_auth_header(self):
        t = RecordingTransport(body=json.dumps(self.spec["success"]).encode())
        self.adapter(t).generate(call())
        url, headers, body, _timeout = t.requests[0]
        self.assertIn(SECRET, headers[self.spec["auth_header"]])
        self.assertNotIn(SECRET, url)
        self.assertNotIn(SECRET, body.decode("utf-8"))

    def test_secret_never_appears_in_an_error(self):
        t = RecordingTransport(status=401, body=("bad " + SECRET).encode())
        with self.assertRaises(ProviderError) as ctx:
            self.adapter(t).generate(call())
        self.assertNotIn(SECRET, str(ctx.exception))
        self.assertNotIn(SECRET, repr(vars(ctx.exception)))

    # deadline
    def test_expired_deadline_sends_nothing(self):
        t = RecordingTransport(body=json.dumps(self.spec["success"]).encode())
        expired = ModelCall(model_id=MODEL, prompt="p", max_output_tokens=8, deadline=time.monotonic() - 1)
        with self.assertRaises(ProviderError) as ctx:
            self.adapter(t).generate(expired)
        self.assertTrue(ctx.exception.retryable)
        self.assertEqual(t.requests, [])

    def test_a_response_arriving_after_the_deadline_is_refused(self):
        class SlowTransport(RecordingTransport):
            def __call__(self, *args, **kwargs):
                time.sleep(0.15)  # fake delay in the test transport: no network is involved
                return super().__call__(*args, **kwargs)
        t = SlowTransport(body=json.dumps(self.spec["success"]).encode())
        with self.assertRaises(ProviderError) as ctx:
            self.adapter(t).generate(call(0.05))
        self.assertEqual(str(ctx.exception), "response arrived after deadline")
        self.assertTrue(ctx.exception.retryable)

    def test_the_one_request_deadline_reaches_the_transport(self):
        t = RecordingTransport(body=json.dumps(self.spec["success"]).encode())
        c = call(20.0)
        self.adapter(t).generate(c)
        timeout = t.requests[0][3]
        self.assertEqual(timeout.deadline, c.deadline)
        self.assertLessEqual(float(timeout), 20.0)

    def test_deadline_expiry_during_transport_is_a_retryable_deadline_failure(self):
        # Stage 10.38: DeadlineExpired means the central deadline passed, so it is a deadline failure.
        t = RecordingTransport(raise_exc=DeadlineExpired("late"))
        with self.assertRaises(ProviderError) as ctx:
            self.adapter(t).generate(call())
        self.assertEqual(str(ctx.exception), "deadline expired during provider call")
        self.assertIs(ctx.exception.kind, FailureKind.DEADLINE_IN_CALL)
        self.assertTrue(ctx.exception.retryable)

    # no retry, no fallback
    def test_transport_failure_is_attempted_exactly_once(self):
        t = RecordingTransport(raise_exc=OSError("reset"))
        with self.assertRaises(ProviderError):
            self.adapter(t).generate(call())
        self.assertEqual(len(t.requests), 1)

    def test_server_error_is_attempted_exactly_once(self):
        t = RecordingTransport(status=503, body=b"{}")
        with self.assertRaises(ProviderError) as ctx:
            self.adapter(t).generate(call())
        self.assertEqual(len(t.requests), 1)
        self.assertEqual(ctx.exception.retryable, self.spec["retry_5xx"])

    # lifecycle
    def test_close_is_idempotent_when_present(self):
        adapter = self.adapter(RecordingTransport())
        close = getattr(adapter, "close", None)
        if close is None:
            self.skipTest("adapter holds no resources")
        close()
        close()

    def test_gateway_round_trip_keeps_one_attempt_and_the_identity(self):
        t = RecordingTransport(body=json.dumps(self.spec["success"]).encode())
        adapter = self.adapter(t)
        profile = ModelProfile(alias="conf_1037", provider=self.provider, model_id=MODEL,
                               capabilities=ModelCapabilities(text_generation=True, max_context_tokens=8192,
                                                              max_output_tokens=512),
                               runs_locally=False, api_surface=self.cls.surface)
        gateway = ModelGateway({self.provider: adapter}, max_concurrent_calls=1)
        try:
            result = gateway.generate(profile, call(), time.monotonic() + 5,
                                      identity=RequestIdentity.for_profile("r" * 32, profile))
            self.assertEqual(result.text, "hi")
            self.assertEqual(len(t.requests), 1)
        finally:
            gateway.shutdown(0.1)

    def test_shutdown_refuses_new_calls_without_provider_io(self):
        t = RecordingTransport(body=json.dumps(self.spec["success"]).encode())
        adapter = self.adapter(t)
        profile = ModelProfile(alias="conf_1037", provider=self.provider, model_id=MODEL,
                               capabilities=ModelCapabilities(text_generation=True, max_context_tokens=8192,
                                                              max_output_tokens=512),
                               runs_locally=False, api_surface=self.cls.surface)
        gateway = ModelGateway({self.provider: adapter}, max_concurrent_calls=1)
        gateway.shutdown(0.1)
        with self.assertRaises(SanourError):
            gateway.generate(profile, call(), time.monotonic() + 5,
                             identity=RequestIdentity.for_profile("r" * 32, profile))
        self.assertEqual(t.requests, [])


class AnthropicConformanceTests(ConformanceMixin, unittest.TestCase):
    provider = "anthropic"


class GeminiConformanceTests(ConformanceMixin, unittest.TestCase):
    provider = "gemini"


class GrokConformanceTests(ConformanceMixin, unittest.TestCase):
    provider = "grok"


class GrokResponsesConformanceTests(ConformanceMixin, unittest.TestCase):
    provider = "grok_responses"


class OpenAIConformanceTests(unittest.TestCase):
    """The OpenAI adapter needs the SDK for every request. Its request-level checks are skipped here."""

    def test_identity_conforms_to_the_shared_contract(self):
        from sanour_ai.providers.openai_provider import OpenAIProvider
        self.assertEqual(contract_violations(OpenAIProvider), [])

    def test_request_level_conformance_needs_the_sdk(self):
        from tests.sdk_gate import sdk_or_skip
        sdk_or_skip(self, "openai and httpx2 not installed: request-level conformance is skipped, not passed")
        # Placeholder: request-level checks live in tests/unit/test_openai_provider.py. Never a pass here.
        self.skipTest("request-level conformance is covered in test_openai_provider; this placeholder never passes")


class SharedTransportPolicyTests(unittest.TestCase):
    def test_redirects_refused_and_environment_proxies_ignored_for_every_adapter(self):
        handlers = {type(h).__name__ for h in common.OPENER.handlers}
        self.assertIn("RefuseRedirects", handlers)
        # No ProxyHandler is installed, so urllib never reads HTTP(S)_PROXY from the environment.
        # If one ever appears, it must carry no proxies.
        for h in common.OPENER.handlers:
            if type(h).__name__ == "ProxyHandler":
                self.assertEqual(h.proxies, {})


if __name__ == "__main__":
    unittest.main()
