"""Stage 10.49-R8-R2: the SDK gate. Stdlib only. Verifies the gate's behavior, never SDK behavior.

Requires that a missing SDK is a visible failure when SANOUR_REQUIRE_SDK=1, and a counted skip otherwise.
"""

import os
import subprocess
import sys
import unittest
from unittest import mock

from tests import sdk_gate

REPO = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))


def _child_env(**extra):
    env = {k: v for k, v in os.environ.items() if k != sdk_gate.REQUIRE_ENV}
    env.update(extra)
    env["PYTHONPATH"] = os.path.join(REPO, "src") + os.pathsep + REPO
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    return env


class GateBehavior(unittest.TestCase):
    def test_detection_matches_an_independent_import_lookup_in_every_environment(self):
        import importlib.util
        expected = all(importlib.util.find_spec(name) is not None for name in ("openai", "httpx2"))
        self.assertEqual(sdk_gate.sdk_available(), expected)

    def test_default_mode_marks_sdk_tests_as_skipped_when_the_sdk_is_absent(self):
        if sdk_gate.sdk_available():
            self.skipTest("SDK present here: the absent-SDK path is not exercised")
        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop(sdk_gate.REQUIRE_ENV, None)

            class Probe(unittest.TestCase):
                def test_x(self):
                    pass

            decorated = sdk_gate.sdk_marker()(Probe)
            self.assertTrue(decorated.__unittest_skip__)
            self.assertIn("not installed", decorated.__unittest_skip_why__)

    def test_required_mode_raises_at_import_when_the_sdk_is_absent(self):
        if sdk_gate.sdk_available():
            self.skipTest("SDK present here: the absent-SDK path is not exercised")
        with mock.patch.dict(os.environ, {sdk_gate.REQUIRE_ENV: "1"}):
            with self.assertRaises(ImportError) as caught:
                sdk_gate.sdk_marker()
        self.assertIn("SANOUR_REQUIRE_SDK=1", str(caught.exception))

    def test_required_mode_fails_the_test_body_when_the_sdk_is_absent(self):
        if sdk_gate.sdk_available():
            self.skipTest("SDK present here: the absent-SDK path is not exercised")
        with mock.patch.dict(os.environ, {sdk_gate.REQUIRE_ENV: "1"}):
            with self.assertRaises(AssertionError):
                sdk_gate.sdk_or_skip(self)

    def test_default_mode_sdk_or_skip_skips_and_does_not_pass(self):
        if sdk_gate.sdk_available():
            self.skipTest("SDK present here: the absent-SDK path is not exercised")
        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop(sdk_gate.REQUIRE_ENV, None)
            with self.assertRaises(unittest.SkipTest):
                sdk_gate.sdk_or_skip(self)

    def test_strict_import_of_the_sdk_test_modules_fails_loudly_when_the_sdk_is_absent(self):
        if sdk_gate.sdk_available():
            self.skipTest("SDK present here: the absent-SDK path is not exercised")
        for module in ("tests.unit.test_openai_provider", "tests.integration.test_production_openai_path"):
            with self.subTest(module=module):
                result = subprocess.run([sys.executable, "-c", f"import {module}"], cwd=REPO,
                                        env=_child_env(**{sdk_gate.REQUIRE_ENV: "1"}),
                                        capture_output=True, text=True, timeout=120)
                self.assertNotEqual(result.returncode, 0)
                self.assertIn("SANOUR_REQUIRE_SDK=1", result.stderr)

    def test_default_import_of_the_sdk_test_modules_still_succeeds_without_the_sdk(self):
        if sdk_gate.sdk_available():
            self.skipTest("SDK present here: the absent-SDK path is not exercised")
        result = subprocess.run([sys.executable, "-c", "import tests.unit.test_openai_provider"], cwd=REPO,
                                env=_child_env(), capture_output=True, text=True, timeout=120)
        self.assertEqual(result.returncode, 0, result.stderr[-500:])


if __name__ == "__main__":
    unittest.main()
