"""Stage 10.54-C1: consistent online backup, manifest, verified non-overwriting restore. Offline, no keys.
Crash tests kill REAL child processes (SIGKILL); tamper tests edit real SQLite files and re-sign manifests
so that only the intended check can refuse them."""

import json
import os
import pathlib
import signal
import sqlite3
import subprocess
import sys
import tempfile
import textwrap
import threading
import time
import unittest
from datetime import datetime, timezone
from unittest import mock

from sanour_ai.backup import BackupError, RestoreError, create_backup, restore_backup
from sanour_ai.backup import archive as A
from sanour_ai.persistence import Ledger, export_anchor, AnchorLog, verify_integrity
from sanour_ai.persistence import canonical as C
from sanour_ai.persistence import migrations as M

ROOT = pathlib.Path(__file__).resolve().parents[2]
SRC = ROOT / "src"
T0 = datetime(2026, 1, 1, tzinfo=timezone.utc)
ENV = {**os.environ, "PYTHONPATH": f"{SRC}{os.pathsep}{ROOT}", "PYTHONDONTWRITEBYTECODE": "1"}
CLOCK = lambda: "2026-01-01T00:00:00+00:00"


def fresh_source(d, n=5, gov=1):
    path = os.path.join(d, "ledger.sqlite")
    led = Ledger(path, clock=lambda: T0)
    for i in range(n):
        led.append("evidence", f"e{i}", "EVIDENCE", {"n": i})
    for i in range(gov):
        led.append("governance", f"g{i}", "GOVERNANCE", {"n": i})
    return led, path


def resign(bdir, mutate):
    """Apply `mutate(manifest_dict, db_path)` to a backup directory and recompute the manifest hash."""
    mpath = os.path.join(bdir, A.MANIFEST_NAME)
    m = json.loads(pathlib.Path(mpath).read_text())
    m.pop("manifest_sha256")
    mutate(m, os.path.join(bdir, A.DB_NAME))
    m["files"][0]["sha256"], m["files"][0]["size"] = A._digest(os.path.join(bdir, A.DB_NAME))[0], \
        os.path.getsize(os.path.join(bdir, A.DB_NAME))
    m["manifest_sha256"] = C.sha256_hex(C.dumps(m))
    pathlib.Path(mpath).write_bytes(C.dumps(m))


def raw_edit(db, sql, args=()):
    """Test-only: removes the append-only guards of THIS scratch copy, then runs one edit."""
    c = sqlite3.connect(db)
    try:
        for (name,) in c.execute("SELECT name FROM sqlite_master WHERE type='trigger' AND name LIKE '%_no_%'").fetchall():
            c.execute(f"DROP TRIGGER {name}")
        c.execute(sql, args)
        c.commit()
    finally:
        c.close()


def leftovers(d):
    return sorted(n for n in os.listdir(d) if n.startswith((A._RESTORE_TMP, A._BACKUP_TMP)) or n.endswith(".tmp"))


class Base(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory()
        self.d = self._td.name
        self.led, self.src = fresh_source(self.d)

    def tearDown(self):
        self.led.close()
        self._td.cleanup()

    def backup(self, name="bk", **kw):
        kw.setdefault("clock", CLOCK)
        return create_backup(self.src, os.path.join(self.d, name), **kw)

    def restore(self, bname="bk", name="restored.sqlite", **kw):
        return restore_backup(os.path.join(self.d, bname), os.path.join(self.d, name), **kw)


# ---------------------------------------------------------------- 1. consistent online backup
class ConsistentBackup(Base):
    def test_backup_is_verified_and_records_heads_and_counts(self):
        r = self.backup(anchor=export_anchor(self.led, "evidence"))
        m = json.loads(pathlib.Path(self.d, "bk", A.MANIFEST_NAME).read_bytes())
        self.assertEqual(m["streams"]["evidence"]["records"], 5)
        self.assertEqual(m["streams"]["governance"]["records"], 1)
        self.assertEqual(m["streams"]["evidence"]["head_seq"], 5)
        self.assertEqual(m["migrations"], [{"version": v.version, "name": v.name, "checksum": v.checksum}
                                           for v in M.MIGRATIONS])
        self.assertEqual(m["anchor"]["seq"], 5)
        self.assertEqual(r.manifest_sha256, m["manifest_sha256"])
        self.assertEqual(sorted(os.listdir(os.path.join(self.d, "bk"))), [A.DB_NAME, A.MANIFEST_NAME])

    def test_backup_is_consistent_while_a_writer_appends(self):
        stop, errs = threading.Event(), []

        def writer():
            i = 0
            while not stop.is_set() and i < 400:
                try:
                    self.led.append("evidence", f"w{i}", "EVIDENCE", {"i": i})
                except Exception as exc:          # pragma: no cover - reported below
                    errs.append(exc)
                i += 1

        t = threading.Thread(target=writer)
        t.start()
        try:
            for k in range(3):
                self.backup(f"bk{k}")
        finally:
            stop.set()
            t.join()
        self.assertEqual(errs, [])
        for k in range(3):
            m = json.loads(pathlib.Path(self.d, f"bk{k}", A.MANIFEST_NAME).read_bytes())
            r = self.restore(f"bk{k}", f"r{k}.sqlite")
            self.assertEqual(r.streams["evidence"]["records"], m["streams"]["evidence"]["records"])

    def test_source_is_not_modified_by_backup(self):
        before = pathlib.Path(self.src).read_bytes()
        self.led.close()
        self.backup()
        self.led = Ledger(self.src, clock=lambda: T0)
        self.assertEqual(verify_integrity(self.led).ok, True)
        self.assertEqual(self.led.schema_version(), M.LATEST_VERSION)
        self.assertTrue(len(before) > 0)

    def test_backup_refuses_existing_destination_and_missing_source(self):
        self.backup()
        with self.assertRaises(BackupError):
            self.backup()
        with self.assertRaises(BackupError):
            create_backup(os.path.join(self.d, "nope.sqlite"), os.path.join(self.d, "x"))

    def test_backup_refuses_a_source_whose_chain_is_broken(self):
        self.led.close()
        raw_edit(self.src, "UPDATE ledger_records SET canonical_bytes = ? WHERE stream='evidence' AND seq=2",
                 (b'{"tampered":true}',))
        self.led = Ledger(self.src, clock=lambda: T0)
        with self.assertRaises(BackupError):
            self.backup()
        self.assertFalse(os.path.exists(os.path.join(self.d, "bk")))
        self.assertEqual(leftovers(self.d), [])


# ---------------------------------------------------------------- 2. manifest and file integrity
class ManifestAndFiles(Base):
    def test_manifest_tampering_is_refused(self):
        self.backup()
        p = os.path.join(self.d, "bk", A.MANIFEST_NAME)
        text = pathlib.Path(p).read_text()
        pathlib.Path(p).write_text(text.replace('"records":5', '"records":4', 1))
        with self.assertRaises(RestoreError):
            self.restore()
        self.assertFalse(os.path.exists(os.path.join(self.d, "restored.sqlite")))

    def test_manifest_that_is_not_canonical_is_refused(self):
        self.backup()
        p = os.path.join(self.d, "bk", A.MANIFEST_NAME)
        pathlib.Path(p).write_text(json.dumps(json.loads(pathlib.Path(p).read_text()), indent=2))
        with self.assertRaises(RestoreError):
            self.restore()

    def test_file_hash_mismatch_is_refused(self):
        self.backup()
        db = os.path.join(self.d, "bk", A.DB_NAME)
        with open(db, "r+b") as fh:
            fh.seek(-1, os.SEEK_END)
            last = fh.read(1)
            fh.seek(-1, os.SEEK_END)
            fh.write(bytes([last[0] ^ 0xFF]))
        with self.assertRaises(RestoreError):
            self.restore()
        self.assertFalse(os.path.exists(os.path.join(self.d, "restored.sqlite")))

    def test_missing_backup_file_is_refused(self):
        self.backup()
        os.unlink(os.path.join(self.d, "bk", A.DB_NAME))
        with self.assertRaises(RestoreError):
            self.restore()

    def test_extra_file_in_backup_directory_is_not_trusted(self):
        self.backup()
        pathlib.Path(self.d, "bk", "extra.bin").write_bytes(b"x")
        r = self.restore()          # listed files are the only ones read
        self.assertEqual(r.streams["evidence"]["records"], 5)


# ---------------------------------------------------------------- 3. migration and chain integrity
class MigrationAndChains(Base):
    def test_migration_checksum_mismatch_in_manifest_is_refused(self):
        self.backup()

        def bad(m, _db):
            m["migrations"][0]["checksum"] = "0" * 64
        resign(os.path.join(self.d, "bk"), bad)
        with self.assertRaises(RestoreError):
            self.restore()

    def test_migration_checksum_mismatch_in_database_is_refused(self):
        self.backup()
        db = os.path.join(self.d, "bk", A.DB_NAME)
        raw_edit(db, "UPDATE schema_migrations SET checksum=? WHERE version=1", ("0" * 64,))
        resign(os.path.join(self.d, "bk"), lambda m, _db: None)
        with self.assertRaises(RestoreError):
            self.restore()
        self.assertFalse(os.path.exists(os.path.join(self.d, "restored.sqlite")))

    def test_chain_integrity_failure_is_refused_even_with_a_resigned_manifest(self):
        self.backup()
        db = os.path.join(self.d, "bk", A.DB_NAME)
        raw_edit(db, "UPDATE ledger_records SET canonical_bytes = ? WHERE stream='evidence' AND seq=3",
                 (b'{"forged":1}',))
        resign(os.path.join(self.d, "bk"), lambda m, _db: None)
        with self.assertRaises(RestoreError):
            self.restore()
        self.assertFalse(os.path.exists(os.path.join(self.d, "restored.sqlite")))
        self.assertEqual(leftovers(self.d), [])

    def test_stream_heads_that_do_not_match_manifest_are_refused(self):
        self.backup()

        def bad(m, _db):
            m["streams"]["evidence"]["records"] = 99
        resign(os.path.join(self.d, "bk"), bad)
        with self.assertRaises(RestoreError):
            self.restore()

    def test_anchor_ahead_of_the_ledger_is_refused(self):
        self.backup()

        def bad(m, _db):
            m["anchor"] = {"stream": "evidence", "seq": 50, "head_hash": "1" * 64, "schema_version": 3,
                           "created_at": CLOCK()}
        resign(os.path.join(self.d, "bk"), bad)
        with self.assertRaises(RestoreError):
            self.restore()

    def test_anchor_hash_mismatch_is_refused(self):
        self.backup(anchor=export_anchor(self.led, "evidence"))

        def bad(m, _db):
            m["anchor"]["head_hash"] = "2" * 64
        resign(os.path.join(self.d, "bk"), bad)
        with self.assertRaises(RestoreError):
            self.restore()

    def test_external_anchor_log_detects_a_forked_history(self):
        a = export_anchor(self.led, "evidence")
        log = AnchorLog(os.path.join(self.d, "anchors.log"))
        log.append(a)
        self.backup(anchor=a)
        self.assertEqual(self.restore(name="ok.sqlite", anchors=log).streams["evidence"]["records"], 5)
        # a different, internally valid history with the same length: the anchor must catch it
        d2 = os.path.join(self.d, "fork")
        os.mkdir(d2)
        fork = Ledger(os.path.join(d2, "ledger.sqlite"), clock=lambda: T0)
        for i in range(5):
            fork.append("evidence", f"e{i}", "EVIDENCE", {"n": i + 100})
        fork.close()
        create_backup(os.path.join(d2, "ledger.sqlite"), os.path.join(self.d, "fork_bk"), clock=CLOCK)
        with self.assertRaises(RestoreError):
            restore_backup(os.path.join(self.d, "fork_bk"), os.path.join(self.d, "bad.sqlite"), anchors=log)
        self.assertFalse(os.path.exists(os.path.join(self.d, "bad.sqlite")))


# ---------------------------------------------------------------- 4. restore destination rules
class RestoreDestination(Base):
    def test_existing_destination_is_refused_and_untouched(self):
        self.backup()
        target = os.path.join(self.d, "restored.sqlite")
        pathlib.Path(target).write_bytes(b"precious")
        with self.assertRaises(RestoreError):
            self.restore()
        self.assertEqual(pathlib.Path(target).read_bytes(), b"precious")
        self.assertEqual(leftovers(self.d), [])

    def test_existing_sidecar_alone_is_refused(self):
        self.backup()
        pathlib.Path(self.d, "restored.sqlite-wal").write_bytes(b"x")
        with self.assertRaises(RestoreError):
            self.restore()
        self.assertFalse(os.path.exists(os.path.join(self.d, "restored.sqlite")))

    def test_destination_created_during_restore_is_not_overwritten(self):
        self.backup()
        real_link = os.link
        target = os.path.join(self.d, "restored.sqlite")

        def racing_link(src, dst, *a, **k):
            pathlib.Path(dst).write_bytes(b"created by someone else")
            return real_link(src, dst, *a, **k)

        with mock.patch.object(A.os, "link", side_effect=racing_link):
            with self.assertRaises(RestoreError):
                self.restore()
        self.assertEqual(pathlib.Path(target).read_bytes(), b"created by someone else")
        self.assertEqual(leftovers(self.d), [])

    def test_missing_destination_parent_is_refused(self):
        self.backup()
        with self.assertRaises(RestoreError):
            restore_backup(os.path.join(self.d, "bk"), os.path.join(self.d, "no_such_dir", "r.sqlite"))

    def test_restored_database_is_a_normal_working_ledger(self):
        self.backup()
        self.restore()
        led = Ledger(os.path.join(self.d, "restored.sqlite"), clock=lambda: T0)
        try:
            self.assertTrue(verify_integrity(led).ok)
            led.append("evidence", "after-restore", "EVIDENCE", {})
            self.assertEqual(led.head("evidence")[0], 6)
        finally:
            led.close()


# ---------------------------------------------------------------- 5. no partial publication
class NoPartialPublication(Base):
    def test_failure_during_copy_leaves_no_destination_and_no_temp(self):
        self.backup()
        with mock.patch.object(A, "_verify_db", side_effect=RestoreError("injected")):
            with self.assertRaises(RestoreError):
                self.restore()
        self.assertFalse(os.path.exists(os.path.join(self.d, "restored.sqlite")))
        self.assertEqual(leftovers(self.d), [])

    def test_interrupt_during_restore_leaves_no_destination(self):
        self.backup()
        with mock.patch.object(A, "_finalize", side_effect=KeyboardInterrupt):
            with self.assertRaises(KeyboardInterrupt):
                self.restore()
        self.assertFalse(os.path.exists(os.path.join(self.d, "restored.sqlite")))
        self.assertEqual(leftovers(self.d), [])

    def test_failure_during_backup_publishes_nothing(self):
        with mock.patch.object(A, "_finalize", side_effect=BackupError("injected")):
            with self.assertRaises(BackupError):
                self.backup()
        self.assertFalse(os.path.exists(os.path.join(self.d, "bk")))
        self.assertEqual(leftovers(self.d), [])

    def test_failure_before_link_keeps_an_existing_restore_target_intact(self):
        self.backup()
        target = os.path.join(self.d, "restored.sqlite")
        pathlib.Path(target).write_bytes(b"keep me")
        with mock.patch.object(A, "_verify_db", side_effect=RestoreError("injected")):
            with self.assertRaises(RestoreError):
                self.restore()
        self.assertEqual(pathlib.Path(target).read_bytes(), b"keep me")


# ---------------------------------------------------------------- 6. repeated backup and restore
class Repeated(Base):
    def test_backup_restore_backup_restore_keeps_heads_identical(self):
        self.backup("b1")
        r1 = self.restore("b1", "r1.sqlite")
        led = Ledger(os.path.join(self.d, "r1.sqlite"), clock=lambda: T0)
        led.append("evidence", "more", "EVIDENCE", {})
        led.close()
        b2 = create_backup(os.path.join(self.d, "r1.sqlite"), os.path.join(self.d, "b2"), clock=CLOCK)
        r2 = self.restore("b2", "r2.sqlite")
        self.assertEqual(r2.streams["evidence"]["head_hash"], b2.streams["evidence"]["head_hash"])
        self.assertEqual(r2.streams["evidence"]["records"], r1.streams["evidence"]["records"] + 1)
        self.assertEqual(r1.streams["governance"], r2.streams["governance"])

    def test_same_source_twice_gives_identical_stream_heads(self):
        a = self.backup("x1")
        b = self.backup("x2")
        self.assertEqual(a.streams, b.streams)
        self.assertEqual(a.manifest_sha256 != "", True)

    def test_manifest_is_canonical_and_stable_for_identical_inputs(self):
        self.backup("m1")
        self.backup("m2")
        m1 = json.loads(pathlib.Path(self.d, "m1", A.MANIFEST_NAME).read_bytes())
        m2 = json.loads(pathlib.Path(self.d, "m2", A.MANIFEST_NAME).read_bytes())
        self.assertEqual(m1["streams"], m2["streams"])
        self.assertEqual(m1["migrations"], m2["migrations"])
        self.assertEqual(pathlib.Path(self.d, "m1", A.MANIFEST_NAME).read_bytes(),
                         C.dumps({**{k: v for k, v in m1.items() if k != "manifest_sha256"},
                                  "manifest_sha256": m1["manifest_sha256"]}))


# ---------------------------------------------------------------- 7. crash and concurrency (real processes)
CHILD_BACKUP = """
import sys
from sanour_ai.backup import create_backup
src, out = sys.argv[1], sys.argv[2]
for k in range(10000):
    create_backup(src, f"{out}_{k}", clock=lambda: "2026-01-01T00:00:00+00:00")
"""

CHILD_RESTORE = """
import sys
from sanour_ai.backup import restore_backup
bdir, out = sys.argv[1], sys.argv[2]
for k in range(10000):
    restore_backup(bdir, f"{out}_{k}.sqlite")
"""


class CrashAndConcurrency(Base):
    def test_sigkill_during_backup_never_publishes_a_partial_backup(self):
        out = os.path.join(self.d, "kb")
        p = subprocess.Popen([sys.executable, "-c", textwrap.dedent(CHILD_BACKUP), self.src, out], env=ENV,
                             stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        try:
            time.sleep(1.5)
            p.send_signal(signal.SIGKILL)
        finally:
            p.wait(timeout=30)
            p.stderr.close()
        published = [n for n in os.listdir(self.d) if n.startswith("kb_")]
        self.assertTrue(published, "expected at least one completed backup before the kill")
        for name in published:
            r = restore_backup(os.path.join(self.d, name), os.path.join(self.d, f"v_{name}.sqlite"))
            self.assertEqual(r.streams["evidence"]["records"], 5)

    def test_sigkill_during_restore_never_publishes_a_partial_database(self):
        self.backup("src_bk")
        out = os.path.join(self.d, "kr")
        p = subprocess.Popen([sys.executable, "-c", textwrap.dedent(CHILD_RESTORE),
                              os.path.join(self.d, "src_bk"), out], env=ENV,
                             stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        try:
            time.sleep(1.5)
            p.send_signal(signal.SIGKILL)
        finally:
            p.wait(timeout=30)
            p.stderr.close()
        made = [n for n in os.listdir(self.d) if n.startswith("kr_") and n.endswith(".sqlite")]
        self.assertTrue(made, "expected at least one completed restore before the kill")
        for name in made:
            led = Ledger(os.path.join(self.d, name), clock=lambda: T0)
            try:
                self.assertTrue(verify_integrity(led).ok)
                self.assertEqual(led.head("evidence")[0], 5)
            finally:
                led.close()

    def test_concurrent_restores_to_distinct_destinations_all_verify(self):
        self.backup("cbk")
        errs = []

        def go(k):
            try:
                restore_backup(os.path.join(self.d, "cbk"), os.path.join(self.d, f"c{k}.sqlite"))
            except Exception as exc:       # pragma: no cover - reported below
                errs.append(exc)

        ts = [threading.Thread(target=go, args=(k,)) for k in range(4)]
        [t.start() for t in ts]
        [t.join() for t in ts]
        self.assertEqual(errs, [])
        self.assertEqual(leftovers(self.d), [])

    def test_concurrent_restores_to_the_same_destination_publish_exactly_one(self):
        self.backup("sbk")
        results = []

        def go():
            try:
                restore_backup(os.path.join(self.d, "sbk"), os.path.join(self.d, "same.sqlite"))
                results.append("ok")
            except RestoreError:
                results.append("refused")

        ts = [threading.Thread(target=go) for _ in range(4)]
        [t.start() for t in ts]
        [t.join() for t in ts]
        self.assertEqual(sorted(results), ["ok", "refused", "refused", "refused"])
        led = Ledger(os.path.join(self.d, "same.sqlite"), clock=lambda: T0)
        try:
            self.assertTrue(verify_integrity(led).ok)
        finally:
            led.close()


# ---------------------------------------------------------------- 9. hardening (mutation-driven)
class Hardening(Base):
    def test_manifest_hash_catches_an_edit_that_no_other_check_sees(self):
        self.backup()
        mp = os.path.join(self.d, "bk", A.MANIFEST_NAME)
        m = json.loads(pathlib.Path(mp).read_text())
        m["created_at"] = "2030-01-01T00:00:00+00:00"          # not covered by any other check
        pathlib.Path(mp).write_bytes(C.dumps(m))               # stale manifest_sha256 kept on purpose
        with self.assertRaises(RestoreError):
            self.restore()

    def test_wrong_manifest_version_or_kind_is_refused_even_when_resigned(self):
        self.backup("v1")
        resign(os.path.join(self.d, "v1"), lambda m, _db: m.__setitem__("v", 2))
        with self.assertRaises(RestoreError):
            restore_backup(os.path.join(self.d, "v1"), os.path.join(self.d, "v1.sqlite"))
        self.backup("k1")
        resign(os.path.join(self.d, "k1"), lambda m, _db: m.__setitem__("kind", "other"))
        with self.assertRaises(RestoreError):
            restore_backup(os.path.join(self.d, "k1"), os.path.join(self.d, "k1.sqlite"))

    def test_corrupted_private_copy_is_refused_before_verification(self):
        self.backup()
        real_copy = A._copy_exclusive

        def corrupt(src, dst):
            real_copy(src, dst)
            with open(dst, "ab") as fh:
                fh.write(b"junk")

        with mock.patch.object(A, "_copy_exclusive", side_effect=corrupt):
            with self.assertRaises(RestoreError):
                self.restore()
        self.assertFalse(os.path.exists(os.path.join(self.d, "restored.sqlite")))
        self.assertEqual(leftovers(self.d), [])

    def test_symlinked_backup_file_is_refused(self):
        self.backup()
        db = os.path.join(self.d, "bk", A.DB_NAME)
        real = os.path.join(self.d, "elsewhere.sqlite")
        os.rename(db, real)
        os.symlink(real, db)
        with self.assertRaises(RestoreError):
            self.restore()
        self.assertFalse(os.path.exists(os.path.join(self.d, "restored.sqlite")))

    def test_symlinked_manifest_is_refused(self):
        self.backup()
        mp = os.path.join(self.d, "bk", A.MANIFEST_NAME)
        real = os.path.join(self.d, "elsewhere.json")
        os.rename(mp, real)
        os.symlink(real, mp)
        with self.assertRaises(RestoreError):
            self.restore()

    def test_oversized_manifest_is_refused(self):
        self.backup()
        pathlib.Path(self.d, "bk", A.MANIFEST_NAME).write_bytes(b" " * (A._MAX_MANIFEST_BYTES + 1))
        with self.assertRaises(RestoreError):
            self.restore()

    def test_backup_refuses_an_anchor_ahead_of_the_source(self):
        from sanour_ai.persistence import Anchor
        bogus = Anchor("evidence", 999, "3" * 64, M.LATEST_VERSION, CLOCK())
        with self.assertRaises(BackupError):
            self.backup(anchor=bogus)
        self.assertFalse(os.path.exists(os.path.join(self.d, "bk")))

    def test_directory_created_during_backup_is_not_replaced(self):
        real_verify = A._verify_db

        def race(*a, **k):
            os.mkdir(os.path.join(self.d, "bk"))             # an EMPTY directory appears at the destination
            return real_verify(*a, **k)

        with mock.patch.object(A, "_verify_db", side_effect=race):
            with self.assertRaises(BackupError):
                self.backup()
        self.assertTrue(os.path.isdir(os.path.join(self.d, "bk")))
        self.assertEqual(os.listdir(os.path.join(self.d, "bk")), [])


# ---------------------------------------------------------------- 10. security and scope
# ---------------------------------------------------------------- 8. scope and architecture
class ScopeAndArchitecture(unittest.TestCase):
    PKG = SRC / "sanour_ai" / "backup"

    def test_backup_package_does_not_import_core_readiness_or_providers(self):
        for f in self.PKG.glob("*.py"):
            text = f.read_text()
            for bad in ("sanour_ai.core", "sanour_ai.readiness", "sanour_ai.providers", "sanour_ai.models",
                        "sanour_ai.composition"):
                self.assertNotIn(bad, text, f"{f.name} mentions {bad}")

    def test_core_and_providers_do_not_depend_on_backup(self):
        for pkg in ("core", "composition", "models", "providers", "readiness"):
            for f in (SRC / "sanour_ai" / pkg).glob("*.py"):
                self.assertNotIn("sanour_ai.backup", f.read_text(), f"{pkg}/{f.name}")

    def test_no_network_retry_or_fallback_code(self):
        text = "\n".join(f.read_text().lower() for f in self.PKG.glob("*.py"))
        for word in ("openai", "anthropic", "gemini", "grok", "retry", "retries", "fallback", "auto_select",
                     "urlopen", "socket", "requests", "httpx"):
            self.assertFalse(word in text, word)

    def test_no_public_error_code_added(self):
        from sanour_ai.errors import ErrorCode
        self.assertEqual(len(list(ErrorCode)), 9)

    def test_migrations_v1_to_v3_unchanged(self):
        self.assertEqual([m.version for m in M.MIGRATIONS], [1, 2, 3])
        self.assertEqual(M.MIGRATIONS[0].checksum, "11d5be7a61fa5309f1dd29699f6b38e3a12cc7e98cb6a4948fe88dc20397584b")
        self.assertEqual(M.MIGRATIONS[1].checksum, "9f689360cfab2ed9745b263038354fd9184c868531e7921a71f2b86de4dbb305")
        self.assertEqual(M.MIGRATIONS[2].checksum, "3e77820b2c70fe38fdab02ce1acc0d410c6eb6d3d7dd214bdf264b9f66a587c0")


if __name__ == "__main__":
    unittest.main()
