"""Stage 10.54-B: chain verification, checkpoints, anchors, crash recovery, concurrency. Offline, no keys.
Crash tests kill REAL child processes (os._exit inside a transaction, SIGKILL); nothing is simulated by mocks."""

import hashlib
import json
import os
import pathlib
import signal
import sqlite3
import subprocess
import sys
import tempfile
import textwrap
import threading
import time
import unittest
from datetime import datetime, timedelta, timezone

from sanour_ai.persistence import (
    Anchor, AnchorError, AnchorLog, EvidenceLedger, Finding, GovernanceEventLedger, Ledger, LedgerBusyError, RecordRejected,
    RecoveryError, checkpoints, create_checkpoint, export_anchor, latest_checkpoint, recover, verify_integrity,
)
from sanour_ai.persistence import canonical as C
from sanour_ai.persistence import migrations as M

ROOT = pathlib.Path(__file__).resolve().parents[2]
SRC = ROOT / "src"
T0 = datetime(2026, 1, 1, tzinfo=timezone.utc)
ENV = {**os.environ, "PYTHONPATH": f"{SRC}{os.pathsep}{ROOT}", "PYTHONDONTWRITEBYTECODE": "1"}
MARK = "LEAKMARKER-QX7431"


def clock():
    return T0


def py(code, *args, **kw):
    return subprocess.run([sys.executable, "-c", textwrap.dedent(code), *map(str, args)], env=ENV,
                          capture_output=True, text=True, timeout=120, **kw)


_PROCS = []


def popen(code, *args):
    p = subprocess.Popen([sys.executable, "-c", textwrap.dedent(code), *map(str, args)], env=ENV,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    _PROCS.append(p)
    return p


class Base(unittest.TestCase):
    def tearDown(self):
        while _PROCS:
            p = _PROCS.pop()
            if p.poll() is None:
                p.kill()
            p.wait(timeout=30)
            for f in (p.stdout, p.stderr):
                if f:
                    f.close()

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.dir = self._tmp.name
        self.path = os.path.join(self.dir, "ledger.db")
        self.anchor_path = os.path.join(self.dir, "anchors.jsonl")

    def open(self, path=None, **kw):
        kw.setdefault("clock", clock)
        led = Ledger(path or self.path, **kw)
        self.addCleanup(led.close)
        return led

    def raw(self, path=None):
        c = sqlite3.connect(path or self.path, isolation_level=None)
        self.addCleanup(c.close)
        return c

    def unguard(self, c, *tables):
        for t in tables:
            for op in ("update", "delete", "replace"):
                c.execute(f"DROP TRIGGER IF EXISTS {t}_no_{op}")
        c.execute("PRAGMA foreign_keys=OFF")

    def seed(self, n=6, marker=False):
        """Evidence stream: n records (+1 revocation); governance: 3 events. Checkpoints and anchors taken."""
        led = self.open()
        for i in range(1, n + 1):
            led.append("evidence", f"EV-{i}", "EVIDENCE_ADDED", {"i": i, "note": MARK if marker else "x"})
        led.revoke("evidence", "EV-1", event_kind="EVIDENCE_REVOKED", actor="rev", reason="withdrawn by reviewer")
        for i in range(1, 4):
            led.append("governance", f"G-{i}", "GATE", {"i": i})
        log = AnchorLog(self.anchor_path)
        for s in ("evidence", "governance"):
            log.append(export_anchor(led, s))
        return led, log

    def rows(self, path=None):
        c = sqlite3.connect(path or self.path)
        try:
            return c.execute("SELECT * FROM ledger_records ORDER BY stream, seq").fetchall()
        finally:
            c.close()


# ---------------------------------------------------------------- 1. chain verification
class ChainVerification(Base):
    def test_clean_ledger_reports_ok(self):
        led, log = self.seed()
        rep = verify_integrity(led, log)
        self.assertTrue(rep.ok, rep.findings)
        self.assertEqual(rep.heads["evidence"][0], 7)
        self.assertEqual(rep.heads["governance"][0], 3)

    def test_empty_ledger_reports_ok(self):
        self.assertTrue(verify_integrity(self.open()).ok)

    def codes(self, led, log=None):
        return verify_integrity(led, log).codes()

    def test_content_change_located(self):
        led, log = self.seed()
        c = self.raw()
        self.unguard(c, "ledger_records")
        c.execute("UPDATE ledger_records SET canonical_bytes=replace(canonical_bytes, CAST('\"i\":3' AS BLOB), CAST('\"i\":9' AS BLOB)) "
                  "WHERE stream='evidence' AND seq=3")
        rep = verify_integrity(led, log)
        self.assertFalse(rep.ok)
        self.assertIn(("evidence", 3, "record_hash_mismatch"), {(f.stream, f.seq, f.code) for f in rep.findings})

    def test_middle_record_deletion_located(self):
        led, log = self.seed()
        c = self.raw()
        self.unguard(c, "ledger_records", "ledger_links")
        c.execute("DELETE FROM ledger_links")
        c.execute("DELETE FROM ledger_records WHERE stream='evidence' AND seq=4")
        rep = verify_integrity(led, log)
        got = {(f.stream, f.code) for f in rep.findings}
        self.assertIn(("evidence", "sequence_gap"), got)
        self.assertIn(("evidence", "prev_hash_mismatch"), got)
        self.assertIn(("evidence", 5), {(f.stream, f.seq) for f in rep.findings})

    def test_reordering_detected(self):
        led, log = self.seed()
        c = self.raw()
        self.unguard(c, "ledger_records", "ledger_links")
        c.execute("DELETE FROM ledger_links")
        c.execute("UPDATE ledger_records SET seq=99 WHERE stream='evidence' AND seq=2")
        c.execute("UPDATE ledger_records SET seq=2 WHERE stream='evidence' AND seq=3")
        c.execute("UPDATE ledger_records SET seq=3 WHERE stream='evidence' AND seq=99")
        rep = verify_integrity(led, log)
        self.assertFalse(rep.ok)
        self.assertTrue({"columns_differ_from_bytes", "prev_hash_mismatch"} <= rep.codes())

    def test_sequence_change_detected(self):
        led, log = self.seed()
        c = self.raw()
        self.unguard(c, "ledger_records", "ledger_links")
        c.execute("DELETE FROM ledger_links")
        c.execute("UPDATE ledger_records SET seq=seq+10 WHERE stream='governance' AND seq=3")
        rep = verify_integrity(led, log)
        self.assertTrue({"sequence_gap", "columns_differ_from_bytes"} <= rep.codes())

    def test_prev_hash_change_detected(self):
        led, log = self.seed()
        c = self.raw()
        self.unguard(c, "ledger_records")
        c.execute("UPDATE ledger_records SET prev_hash=? WHERE stream='evidence' AND seq=3", ("a" * 64,))
        rep = verify_integrity(led, log)
        self.assertIn(("evidence", 3, "prev_hash_mismatch"), {(f.stream, f.seq, f.code) for f in rep.findings})

    def test_checkpoint_record_inconsistency_detected(self):
        led, log = self.seed()
        c = self.raw()
        self.unguard(c, "ledger_records", "ledger_links")
        # forge a fully self-consistent rewrite of record 3 and everything after it (all hashes recomputed)
        recs = led.records("evidence")
        prev = recs[1].record_hash
        for r in recs[2:]:
            body = json.loads(r.canonical_bytes)
            body["prev_hash"] = prev
            if r.seq == 3:
                body["payload"]["i"] = 333
            raw = C.dumps(body)
            h = C.sha256_hex(raw)
            c.execute("UPDATE ledger_records SET canonical_bytes=?, record_hash=?, prev_hash=?, content_sha256=? "
                      "WHERE stream='evidence' AND seq=?",
                      (raw, h, prev, C.content_digest(body["kind"], body["payload"]), r.seq))
            prev = h
        rep = verify_integrity(led)             # no anchor given: the in-database checkpoint alone must catch it
        self.assertIn("checkpoint_record_mismatch", rep.codes())
        self.assertNotIn("record_hash_mismatch", rep.codes())   # the forgery itself is internally consistent

    def test_truncation_detected_by_checkpoint_and_anchor(self):
        led, log = self.seed()
        c = self.raw()
        self.unguard(c, "ledger_records", "ledger_links")
        c.execute("DELETE FROM ledger_links")
        c.execute("DELETE FROM ledger_records WHERE stream='evidence' AND seq>5")
        self.assertIn("ledger_behind_checkpoint", self.codes(led))
        self.assertIn("ledger_behind_anchor", self.codes(led, log))

    def test_whole_file_rewrite_detected_only_by_external_anchor(self):
        led, log = self.seed()
        led.close()
        forged_path = os.path.join(self.dir, "forged.db")
        f = Ledger(forged_path, clock=clock)
        for i in range(1, 7):
            f.append("evidence", f"EV-{i}", "EVIDENCE_ADDED", {"i": i, "note": "FORGED" if i == 3 else "x"})
        f.revoke("evidence", "EV-1", event_kind="EVIDENCE_REVOKED", actor="rev", reason="withdrawn by reviewer")
        for i in range(1, 4):
            f.append("governance", f"G-{i}", "GATE", {"i": i})
        for s in ("evidence", "governance"):
            create_checkpoint(f, s)
        f.close()
        for ext in ("", "-wal", "-shm"):
            try:
                os.remove(self.path + ext)
            except FileNotFoundError:
                pass
        os.replace(forged_path, self.path)
        for ext in ("-wal", "-shm"):
            try:
                os.remove(forged_path + ext)
            except FileNotFoundError:
                pass
        again = self.open()
        self.assertTrue(verify_integrity(again).ok)                    # internally consistent: nothing inside can tell
        rep = verify_integrity(again, log)
        self.assertIn("anchor_mismatch", rep.codes())                  # the outside copy of the head can

    def test_report_never_contains_payload_or_ids(self):
        led, log = self.seed(marker=True)
        c = self.raw()
        self.unguard(c, "ledger_records")
        c.execute("UPDATE ledger_records SET canonical_bytes=replace(canonical_bytes, CAST('x' AS BLOB), CAST('y' AS BLOB)) WHERE seq=2 AND stream='evidence'")
        c.execute("UPDATE ledger_records SET record_hash=? WHERE seq=3 AND stream='evidence'", ("b" * 64,))
        rep = verify_integrity(led, log)
        text = repr(rep) + str(rep.findings)
        for secret in (MARK, "EV-2", "EV-3", "withdrawn by reviewer", self.path, "SELECT"):
            self.assertNotIn(secret, text)
        for f in rep.findings:
            self.assertRegex(f.code, r"^[a-z_0-9:\-A-Z]+$")

    def test_incomplete_supersession_group_detected(self):
        led = self.open()
        ev = EvidenceLedger(led)
        kw = dict(provider_id="p", criterion="c", kind="LIVE", supports=True, artifact=b"a", source="live://x",
                  reviewer="r", recorded_by="u", verified_at=T0 - timedelta(days=1), method="m", software="s",
                  software_version="1", note="n")
        ev.add(evidence_id="EV-1", **kw)
        ev.supersede("EV-1", evidence_id="EV-2", **{**kw, "artifact": b"b"}, actor="r")
        self.assertTrue(verify_integrity(led).ok)
        c = self.raw()
        self.unguard(c, "ledger_links")
        c.execute("DELETE FROM ledger_links")
        self.assertIn("event_without_link", verify_integrity(led).codes())

    def test_reserved_event_ids_cannot_be_forged_through_append(self):
        led = self.open()
        for rid in ("supersede:EV-1", "revoke:EV-1"):
            with self.assertRaises(RecordRejected):
                led.append("evidence", rid, "EVIDENCE_REVOKED", {})
        self.assertEqual(led.head("evidence")[0], 0)

    def test_foreign_key_violation_reported(self):
        led, log = self.seed()
        c = self.raw()
        self.unguard(c, "ledger_links")
        c.execute("INSERT INTO ledger_links VALUES ('evidence', 6, 'supersedes', 0)")
        self.assertIn("foreign_key_violation", verify_integrity(led, log).codes())

    def test_sqlite_structural_corruption_reported(self):
        led = self.open()
        for i in range(300):
            led.append("evidence", f"e{i}", "K", {"pad": "p" * 200, "i": i})
        led.close()
        size = os.path.getsize(self.path)
        with open(self.path, "r+b") as fh:           # overwrite a middle page with garbage after a clean close
            fh.seek((size // 4096 // 2) * 4096)
            fh.write(os.urandom(4096))
        try:
            led = Ledger(self.path, clock=clock)
        except Exception:
            return                                   # refused at open: also a valid outcome
        self.addCleanup(led.close)
        try:
            rep = verify_integrity(led)
        except Exception:
            return                                   # damage surfaced as a storage error
        self.assertFalse(rep.ok)

    def test_guard_removal_reported(self):
        led, log = self.seed()
        self.raw().execute("DROP TRIGGER ledger_checkpoints_no_update")
        self.assertIn("guard_missing:ledger_checkpoints_no_update", self.codes(led, log))


# ---------------------------------------------------------------- 3. checkpoints
class Checkpoints(Base):
    def test_checkpoint_fields_and_chain(self):
        led = self.open()
        led.append("evidence", "e1", "K", {})
        cp1, new1 = create_checkpoint(led, "evidence")
        led.append("evidence", "e2", "K", {})
        cp2, new2 = create_checkpoint(led, "evidence")
        self.assertTrue(new1 and new2)
        self.assertEqual((cp1.cp_seq, cp1.record_seq, cp1.schema_version, cp1.created_at),
                         (1, 1, M.LATEST_VERSION, T0.isoformat(timespec="microseconds")))
        self.assertEqual(cp1.head_hash, led.get("evidence", "e1").record_hash)
        self.assertEqual((cp2.cp_seq, cp2.prev_cp_hash, cp2.record_seq), (2, cp1.cp_hash, 2))
        self.assertEqual(cp2.cp_hash, hashlib.sha256(cp2.canonical_bytes).hexdigest())
        self.assertEqual(len(checkpoints(led, "evidence")), 2)
        self.assertEqual(latest_checkpoint(led, "evidence"), cp2)
        self.assertIsNone(latest_checkpoint(led, "governance"))

    def test_same_head_is_noop(self):
        led = self.open()
        led.append("governance", "g", "K", {})
        a, na = create_checkpoint(led, "governance")
        b, nb = create_checkpoint(led, "governance")
        self.assertEqual((na, nb, a), (True, False, b))
        self.assertEqual(len(checkpoints(led, "governance")), 1)

    def test_empty_stream_checkpoint(self):
        cp, _ = create_checkpoint(self.open(), "evidence")
        self.assertEqual((cp.record_seq, cp.head_hash), (0, "0" * 64))

    def test_both_streams_independent(self):
        led = self.open()
        led.append("evidence", "e", "K", {})
        create_checkpoint(led, "evidence")
        create_checkpoint(led, "governance")
        self.assertEqual(latest_checkpoint(led, "evidence").record_seq, 1)
        self.assertEqual(latest_checkpoint(led, "governance").record_seq, 0)

    def test_stale_state_refused_not_accepted_as_new(self):
        led, _ = self.seed()
        c = self.raw()
        self.unguard(c, "ledger_records", "ledger_links")
        c.execute("DELETE FROM ledger_links")
        c.execute("DELETE FROM ledger_records WHERE stream='evidence' AND seq>4")
        before = len(checkpoints(led, "evidence"))
        with self.assertRaises(RecoveryError):
            create_checkpoint(led, "evidence")
        self.assertEqual(len(checkpoints(led, "evidence")), before)

    def test_checkpoint_refused_when_record_disagrees(self):
        led, _ = self.seed()
        c = self.raw()
        self.unguard(c, "ledger_records")
        c.execute("UPDATE ledger_records SET record_hash=? WHERE stream='evidence' AND seq=7", ("c" * 64,))
        with self.assertRaises(RecoveryError):
            create_checkpoint(led, "evidence")

    def test_checkpoint_refused_when_head_bytes_do_not_match_hash(self):
        led = self.open()
        led.append("evidence", "e", "K", {"a": 1})
        c = self.raw()
        self.unguard(c, "ledger_records")
        c.execute("UPDATE ledger_records SET canonical_bytes=CAST('zz' AS BLOB)")
        with self.assertRaises(RecoveryError):
            create_checkpoint(led, "evidence")

    def test_checkpoint_table_is_append_only(self):
        self.seed()
        c = self.raw()
        for sql in ("UPDATE ledger_checkpoints SET record_seq=0", "DELETE FROM ledger_checkpoints"):
            with self.assertRaises(sqlite3.DatabaseError):
                c.execute(sql)
        row = c.execute("SELECT * FROM ledger_checkpoints").fetchone()
        with self.assertRaises(sqlite3.DatabaseError):
            c.execute("INSERT OR REPLACE INTO ledger_checkpoints VALUES (?,?,?,?,?,?,?,?,?)", row[:5] + ("x",) + row[6:])

    def _cp_tamper(self, sql, params=()):
        led, _ = self.seed()
        c = self.raw()
        self.unguard(c, "ledger_checkpoints")
        c.execute(sql, params)
        return verify_integrity(led)

    def test_tampered_checkpoint_bytes_detected(self):
        rep = self._cp_tamper("UPDATE ledger_checkpoints SET canonical_bytes=replace(canonical_bytes, CAST('evidence' AS BLOB), CAST('evidencX' AS BLOB)) WHERE stream='evidence'")
        self.assertIn("checkpoint_hash_mismatch", rep.codes())

    def test_tampered_checkpoint_column_detected(self):
        rep = self._cp_tamper("UPDATE ledger_checkpoints SET record_seq=2 WHERE stream='evidence'")
        self.assertIn("checkpoint_columns_differ_from_bytes", rep.codes())

    def test_tampered_checkpoint_head_hash_detected(self):
        rep = self._cp_tamper("UPDATE ledger_checkpoints SET head_hash=? WHERE stream='evidence'", ("d" * 64,))
        self.assertTrue({"checkpoint_columns_differ_from_bytes", "checkpoint_record_mismatch"} <= rep.codes())

    def test_forged_regressed_checkpoint_detected(self):
        led, _ = self.seed()
        led.append("evidence", "EV-9", "K", {})
        last, _ = create_checkpoint(led, "evidence")
        old = led.get("evidence", "EV-2")
        raw = json.dumps({"v": 1, "stream": "evidence", "cp_seq": last.cp_seq + 1, "record_seq": old.seq,
                          "head_hash": old.record_hash, "schema_version": last.schema_version,
                          "created_at": last.created_at, "prev_cp_hash": last.cp_hash},
                         sort_keys=True, separators=(",", ":")).encode()
        c = self.raw()
        c.execute("INSERT INTO ledger_checkpoints VALUES ('evidence',?,?,?,?,?,?,?,?)",
                  (last.cp_seq + 1, old.seq, old.record_hash, last.schema_version, last.created_at, last.cp_hash,
                   hashlib.sha256(raw).hexdigest(), raw))
        rep = verify_integrity(led)
        self.assertIn("checkpoint_regressed", rep.codes())
        with self.assertRaises(RecoveryError) as cm:
            # the newest (forged, older) checkpoint is now "last": a newer head must not be silently accepted over it
            c2 = self.raw()
            self.unguard(c2, "ledger_records", "ledger_links")
            c2.execute("DELETE FROM ledger_links")
            c2.execute("DELETE FROM ledger_records WHERE stream='evidence' AND seq>?", (old.seq - 1,))
            create_checkpoint(led, "evidence")
        self.assertNotIn(MARK, str(cm.exception))

    def test_checkpoint_gap_and_wrong_prev_detected(self):
        led, _ = self.seed()
        led.append("evidence", "more", "K", {})
        create_checkpoint(led, "evidence")
        c = self.raw()
        self.unguard(c, "ledger_checkpoints")
        c.execute("UPDATE ledger_checkpoints SET prev_cp_hash=? WHERE stream='evidence' AND cp_seq=2", ("e" * 64,))
        rep = verify_integrity(led)
        self.assertTrue({"checkpoint_prev_mismatch", "checkpoint_columns_differ_from_bytes"} & rep.codes())

    def test_schema_version_ahead_detected(self):
        rep = self._cp_tamper("UPDATE ledger_checkpoints SET schema_version=99 WHERE stream='evidence'")
        self.assertIn("checkpoint_schema_version_ahead", rep.codes())

    def test_checkpoints_survive_restart(self):
        led, _ = self.seed()
        cp = latest_checkpoint(led, "evidence")
        led.close()
        self.assertEqual(latest_checkpoint(self.open(), "evidence"), cp)

    def test_concurrent_checkpoints_and_writes_keep_chain_valid(self):
        led = self.open()
        stop, errs = threading.Event(), []

        def writer():
            for i in range(60):
                led.append("evidence", f"w{i}", "K", {"i": i})
            stop.set()

        def cper():
            try:
                while not stop.is_set():
                    create_checkpoint(led, "evidence")
                create_checkpoint(led, "evidence")
            except Exception as e:   # pragma: no cover
                errs.append(e)
        ts = [threading.Thread(target=writer)] + [threading.Thread(target=cper) for _ in range(3)]
        [t.start() for t in ts]
        [t.join() for t in ts]
        self.assertEqual(errs, [])
        cps = checkpoints(led, "evidence")
        self.assertEqual([c.cp_seq for c in cps], list(range(1, len(cps) + 1)))
        self.assertEqual([c.record_seq for c in cps], sorted({c.record_seq for c in cps}))   # strictly increasing
        self.assertTrue(verify_integrity(led).ok)


# ---------------------------------------------------------------- external anchors
class Anchors(Base):
    def test_roundtrip_and_repeat(self):
        led, log = self.seed()
        anchors, issues = log.read()
        self.assertEqual((len(anchors), issues), (2, []))
        self.assertFalse(log.append(export_anchor(led, "evidence")))
        self.assertEqual(len(log.read()[0]), 2)

    def test_ledger_ahead_of_anchor_is_fine(self):
        led, log = self.seed()
        led.append("evidence", "later", "K", {})
        self.assertTrue(verify_integrity(led, log).ok)
        self.assertTrue(log.append(export_anchor(led, "evidence")))
        self.assertTrue(verify_integrity(led, log).ok)

    def test_older_anchor_refused(self):
        led, log = self.seed()
        newer = export_anchor(led, "evidence")
        old = Anchor("evidence", 2, led.get("evidence", "EV-2").record_hash, newer.schema_version, newer.created_at)
        with self.assertRaises(AnchorError):
            log.append(old)
        self.assertEqual(len(log.read()[0]), 2)

    def test_conflicting_head_at_same_seq_refused(self):
        led, log = self.seed()
        a = export_anchor(led, "evidence")
        with self.assertRaises(AnchorError):
            log.append(Anchor(a.stream, a.seq, "f" * 64, a.schema_version, a.created_at))

    def test_tampered_line_detected(self):
        led, log = self.seed()
        text = pathlib.Path(self.anchor_path).read_text()
        pathlib.Path(self.anchor_path).write_text(text.replace('"seq":7', '"seq":6', 1))
        _, issues = log.read()
        self.assertTrue(any("tampered" in i for i in issues))
        self.assertIn("anchor_log_tampered", verify_integrity(led, log).codes())
        with self.assertRaises(AnchorError):
            log.append(export_anchor(led, "evidence"))

    def test_removed_first_line_breaks_chain(self):
        led, log = self.seed()
        lines = pathlib.Path(self.anchor_path).read_text().splitlines(True)
        pathlib.Path(self.anchor_path).write_text("".join(lines[1:]))
        self.assertTrue(any("tampered" in i for i in log.read()[1]))

    def test_partial_tail_reported_and_repaired_on_next_append(self):
        led, log = self.seed()
        with open(self.anchor_path, "ab") as fh:
            fh.write(b'{"anchor":{"v":1,"stre')           # a crash in the middle of an append
        anchors, issues = log.read()
        self.assertEqual((len(anchors), issues), (2, ["anchor_partial_tail"]))
        led.append("evidence", "later", "K", {})
        self.assertTrue(log.append(export_anchor(led, "evidence")))
        anchors, issues = log.read()
        self.assertEqual((len(anchors), issues), (3, []))

    def test_dropping_whole_newest_lines_is_not_detectable(self):
        """Honest limit: an attacker who deletes the newest complete anchor lines leaves a valid shorter log."""
        led, log = self.seed()
        lines = pathlib.Path(self.anchor_path).read_text().splitlines(True)
        pathlib.Path(self.anchor_path).write_text("".join(lines[:-1]))
        anchors, issues = log.read()
        self.assertEqual((len(anchors), issues), (1, []))

    def test_missing_log_is_empty_not_error(self):
        self.assertEqual(AnchorLog(os.path.join(self.dir, "none.jsonl")).read(), ([], []))

    def test_bad_paths(self):
        for p in ("", "a\x00b", None, "x" * 2000):
            with self.assertRaises(AnchorError):
                AnchorLog(p)


# ---------------------------------------------------------------- 2. crash recovery (real processes)
CRASH = """
    import os, sys
    from sanour_ai.persistence import Ledger
    path, point, op = sys.argv[1], sys.argv[2], sys.argv[3]
    led = Ledger(path)
    if point == "before_txn":
        os._exit(9)
    class P:
        def __init__(self, c): self._c = c
        def execute(self, sql, *a):
            if sql == "COMMIT" and point == "before_commit":
                os._exit(9)                      # every INSERT done, COMMIT not executed
            r = self._c.execute(sql, *a)
            if sql == "COMMIT" and point == "after_commit":
                os._exit(9)                      # committed, caller never got the return value
            return r
        def __getattr__(self, n): return getattr(self._c, n)
    led._conn = P(led._conn)
    if op == "append":
        led.append("evidence", "crash-1", "K", {"v": 1})
    elif op == "supersede":
        led.supersede("evidence", "base", "crash-new", "K", {"v": 2}, event_kind="EVIDENCE_SUPERSEDED", actor="a")
    elif op == "revoke":
        led.revoke("evidence", "base", event_kind="EVIDENCE_REVOKED", actor="a", reason="because reasons")
    os._exit(0)
"""


class CrashRecovery(Base):
    def prepare(self):
        led = self.open()
        led.append("evidence", "base", "K", {"b": 1})
        led.append("governance", "g", "K", {"g": 1})
        create_checkpoint(led, "evidence")
        before = self.rows()
        led.close()
        return before

    def crash(self, point, op):
        p = py(CRASH, self.path, point, op)
        self.assertEqual(p.returncode, 9 if point != "none" else 0, p.stderr[-400:])

    def test_crash_before_and_during_transaction_leave_nothing(self):
        for point in ("before_txn", "before_commit"):
            for op in ("append", "supersede", "revoke"):
                with self.subTest(point=point, op=op):
                    self.setUp()
                    before = self.prepare()
                    self.crash(point, op)
                    rep = recover(self.path)
                    self.assertTrue(rep.clean, rep.integrity.findings if rep.integrity else None)
                    self.assertEqual(self.rows(), before)          # byte-identical: nothing partial, nothing rewritten
                    led = self.open()
                    self.assertIsNone(led.get("evidence", "crash-1"))
                    self.assertEqual(led.standing("evidence", "base"), "active")
                    self._tmp.cleanup()

    def test_crash_after_commit_keeps_record_and_retry_is_idempotent(self):
        before = self.prepare()
        self.crash("after_commit", "append")
        rep = recover(self.path)
        self.assertTrue(rep.clean)
        after = self.rows()
        self.assertTrue(set(before) <= set(after))                  # every historical row byte-identical
        self.assertEqual(len(after), len(before) + 1)
        led = self.open()
        r = led.append("evidence", "crash-1", "K", {"v": 1})        # the client retries after the crash
        self.assertTrue(r.replayed)
        self.assertEqual(len(self.rows()), len(before) + 1)         # no duplicate
        with self.assertRaises(Exception):
            led.append("evidence", "crash-1", "K", {"v": 999})      # different content is still refused

    def test_crash_after_commit_supersede_and_revoke_are_whole(self):
        for op in ("supersede", "revoke"):
            with self.subTest(op=op):
                self.setUp()
                self.prepare()
                self.crash("after_commit", op)
                rep = recover(self.path)
                self.assertTrue(rep.clean, rep.integrity.findings)
                led = self.open()
                self.assertEqual(led.standing("evidence", "base"), "superseded" if op == "supersede" else "revoked")
                self._tmp.cleanup()

    def test_recovery_never_modifies_ledger_rows_even_when_damaged(self):
        led, log = self.seed()
        led.close()
        c = self.raw()
        self.unguard(c, "ledger_records")
        c.execute("UPDATE ledger_records SET prev_hash=? WHERE stream='evidence' AND seq=4", ("a" * 64,))
        snapshot = self.rows()
        rep = recover(self.path, log)
        self.assertFalse(rep.clean)
        self.assertIn("prev_hash_mismatch", rep.integrity.codes())
        self.assertEqual(self.rows(), snapshot)                     # reported, not "repaired"

    def test_sigkill_during_write_stream_loses_nothing_acknowledged(self):
        code = """
            import sys
            from sanour_ai.persistence import Ledger
            led = Ledger(sys.argv[1]); i = 0
            while True:
                led.append("evidence", "k%d" % i, "K", {"i": i})
                print(i, flush=True); i += 1
        """
        base = self.open()
        base.append("evidence", "pre", "K", {})
        base.close()
        before = self.rows()
        p = popen(code, self.path)
        acked = []
        deadline = time.time() + 60
        while len(acked) < 40 and time.time() < deadline:
            line = p.stdout.readline()
            if not line:
                break
            acked.append(int(line))
        os.kill(p.pid, signal.SIGKILL)
        p.wait(timeout=30)
        self.assertGreaterEqual(len(acked), 40)
        self.assertTrue(pathlib.Path(self.path + "-wal").exists())   # the crash left a real WAL behind
        rep = recover(self.path)
        self.assertTrue(rep.clean, rep.integrity.findings)
        led = self.open()
        for i in acked:                                              # every acknowledged append is durable
            self.assertIsNotNone(led.get("evidence", f"k{i}"), i)
        recs = led.records("evidence", limit=10_000)
        self.assertEqual([r.seq for r in recs], list(range(1, len(recs) + 1)))
        self.assertTrue(set(before) <= set(self.rows()))
        led.append("evidence", "after", "K", {})                     # and the ledger keeps working
        self.assertTrue(verify_integrity(led).ok)

    def test_sigkill_writer_holding_write_lock_does_not_block_others_forever(self):
        code = """
            import sqlite3, sys, time
            c = sqlite3.connect(sys.argv[1], isolation_level=None)
            c.execute("BEGIN IMMEDIATE"); print("locked", flush=True); time.sleep(120)
        """
        led = self.open(busy_timeout_ms=200)
        p = popen(code, self.path)
        self.assertEqual(p.stdout.readline().strip(), "locked")
        with self.assertRaises(LedgerBusyError):
            led.append("evidence", "x", "K", {})
        os.kill(p.pid, signal.SIGKILL)
        p.wait(timeout=30)
        t = time.time()
        self.assertEqual(led.append("evidence", "x", "K", {}).record.seq, 1)
        self.assertLess(time.time() - t, 5)
        rep = recover(self.path)
        self.assertTrue(rep.clean)

    def test_recover_reports_busy_when_a_live_writer_holds_the_lock(self):
        self.open().close()
        p = popen("""
            import sqlite3, sys, time
            c = sqlite3.connect(sys.argv[1], isolation_level=None)
            c.execute("BEGIN IMMEDIATE"); print("locked", flush=True); time.sleep(60)
        """, self.path)
        try:
            self.assertEqual(p.stdout.readline().strip(), "locked")
            with self.assertRaises(LedgerBusyError):
                recover(self.path, busy_timeout_ms=150)
        finally:
            p.kill()
            p.wait(timeout=30)

    def test_recover_on_corrupt_file_raises_generic_error(self):
        pathlib.Path(self.path).write_bytes(b"not a database " + MARK.encode() * 100)
        with self.assertRaises(Exception) as cm:
            recover(self.path)
        self.assertNotIn(MARK, str(cm.exception))
        self.assertNotIn(self.path, str(cm.exception))

    def test_recover_report_for_clean_database(self):
        led, log = self.seed()
        led.close()
        rep = recover(self.path, log)
        self.assertTrue(rep.clean)
        self.assertEqual(rep.schema_version, M.LATEST_VERSION)
        self.assertGreaterEqual(rep.wal_pages_checkpointed, 0)


# ---------------------------------------------------------------- targeted checks added after mutation review
class TargetedChecks(Base):
    def forge_cp(self, c, which, **changes):
        """Rewrite a checkpoint row so its bytes, hash and columns are internally consistent (a careful forger)."""
        row = c.execute("SELECT stream, cp_seq, record_seq, head_hash, schema_version, created_at, prev_cp_hash "
                        "FROM ledger_checkpoints WHERE stream='evidence' AND cp_seq=?", (which,)).fetchone()
        d = dict(zip(("stream", "cp_seq", "record_seq", "head_hash", "schema_version", "created_at", "prev_cp_hash"), row))
        old_seq = d["cp_seq"]
        d.update(changes)
        raw = changes.get("_raw") or C.dumps({"v": 1, **d})
        c.execute("UPDATE ledger_checkpoints SET cp_seq=?, prev_cp_hash=?, canonical_bytes=?, cp_hash=? "
                  "WHERE stream='evidence' AND cp_seq=?", (d["cp_seq"], d["prev_cp_hash"], raw, C.sha256_hex(raw), old_seq))

    def only(self, led):
        return {c for c in verify_integrity(led).codes() if not c.startswith("guard_missing")}

    def two_checkpoints(self):
        led, log = self.seed()
        led.append("evidence", "more", "K", {})
        create_checkpoint(led, "evidence")
        c = self.raw()
        self.unguard(c, "ledger_checkpoints")
        return led, log, c

    def test_consistent_forgery_with_wrong_prev_is_reported_as_prev_mismatch(self):
        led, _, c = self.two_checkpoints()
        self.forge_cp(c, 2, prev_cp_hash="e" * 64)
        self.assertEqual(self.only(led), {"checkpoint_prev_mismatch"})

    def test_consistent_forgery_with_gap_in_checkpoint_sequence(self):
        led, _, c = self.two_checkpoints()
        self.forge_cp(c, 2, cp_seq=3)
        self.assertIn("checkpoint_sequence_gap", verify_integrity(led).codes())

    def test_consistent_forgery_with_non_canonical_bytes(self):
        led, _, c = self.two_checkpoints()
        row = c.execute("SELECT canonical_bytes FROM ledger_checkpoints WHERE stream='evidence' AND cp_seq=2").fetchone()
        pretty = json.dumps(json.loads(row[0]), indent=2, sort_keys=True).encode()
        self.forge_cp(c, 2, _raw=pretty)
        self.assertEqual(self.only(led), {"checkpoint_not_canonical"})

    def test_checkpoint_refused_when_an_earlier_checkpoint_no_longer_matches(self):
        led = self.open()
        for i in range(1, 8):
            led.append("evidence", f"e{i}", "K", {"i": i})
        create_checkpoint(led, "evidence")                      # checkpoint at seq 7
        led.append("evidence", "e8", "K", {})                   # head is now seq 8 and intact
        c = self.raw()
        self.unguard(c, "ledger_records")
        c.execute("UPDATE ledger_records SET record_hash=? WHERE stream='evidence' AND seq=7", ("c" * 64,))
        with self.assertRaises(RecoveryError):
            create_checkpoint(led, "evidence")

    def anchor_line(self, anchor, prev, pretty=False):
        body = {"anchor": anchor, "prev": prev}
        full = {**body, "line_hash": C.sha256_hex(C.dumps(body))}
        text = json.dumps(full, indent=1, sort_keys=True) if pretty else C.dumps(full).decode()
        return text.replace("\n", " ") if pretty else text, full["line_hash"]

    def anc(self, stream="evidence", seq=1, head="a" * 64):
        return {"v": 1, "stream": stream, "seq": seq, "head_hash": head, "schema_version": 3, "created_at": "t"}

    def write_log(self, entries):
        prev, lines = "0" * 64, []
        for a, pretty in entries:
            text, prev = self.anchor_line(a, prev, pretty)
            lines.append(text)
        pathlib.Path(self.anchor_path).write_text("\n".join(lines) + "\n")
        return AnchorLog(self.anchor_path)

    def test_regressed_anchor_line_reported(self):
        log = self.write_log([(self.anc(seq=7), False), (self.anc(seq=5), False)])
        anchors, issues = log.read()
        self.assertEqual((len(anchors), issues), (2, ["anchor_line_2_regressed"]))
        led = self.open()
        self.assertIn("anchor_log_regressed", verify_integrity(led, log).codes())

    def test_valid_hash_but_non_canonical_line_rejected(self):
        log = self.write_log([(self.anc(seq=1), True)])
        anchors, issues = log.read()
        self.assertEqual((anchors, issues), ([], ["anchor_line_1_tampered"]))

    def test_unknown_stream_in_anchor_rejected(self):
        log = self.write_log([(self.anc(stream="other"), False)])
        self.assertEqual(log.read(), ([], ["anchor_line_1_tampered"]))

    def test_nothing_after_a_broken_link_is_returned(self):
        log = self.write_log([(self.anc(seq=1), False), (self.anc(seq=2, head="b" * 64), False), (self.anc(seq=3, head="c" * 64), False)])
        lines = pathlib.Path(self.anchor_path).read_text().splitlines()
        lines[1] = lines[1].replace('"seq":2', '"seq":9')
        pathlib.Path(self.anchor_path).write_text("\n".join(lines) + "\n")
        anchors, issues = log.read()
        self.assertEqual([a.seq for a in anchors], [1])                 # line 3 is intact but untrusted
        self.assertEqual(issues, ["anchor_line_2_tampered"])

    def test_anchor_append_is_fsynced(self):
        led, log = self.seed()
        led.append("evidence", "later", "K", {})
        calls = []
        real = os.fsync
        os.fsync = lambda fd: (calls.append(fd), real(fd))[1]
        try:
            log.append(export_anchor(led, "evidence"))
        finally:
            os.fsync = real
        self.assertTrue(calls)

    def test_supersession_with_missing_replacement_reported(self):
        led = self.open()
        led.append("evidence", "old", "K", {})
        led.supersede("evidence", "old", "new", "K", {"v": 2}, event_kind="EVIDENCE_SUPERSEDED", actor="a")
        c = self.raw()
        self.unguard(c, "ledger_records", "ledger_links")
        c.execute("DELETE FROM ledger_links")
        c.execute("DELETE FROM ledger_records WHERE record_id='new'")
        c.execute("INSERT INTO ledger_links VALUES ('evidence', 3, 'supersedes', 1)")
        self.assertIn("supersession_replacement_missing", verify_integrity(led).codes())

    def test_dropped_ledger_guard_reported_with_structural_code(self):
        led, log = self.seed()
        self.raw().execute("DROP TRIGGER ledger_records_no_delete")
        rep = verify_integrity(led, log)
        self.assertIn(Finding("-", 0, "guard_missing:ledger_records_no_delete"), rep.findings)

    def test_sqlite_index_corruption_reported(self):
        led = self.open()
        for i in range(40):
            led.append("evidence", f"e{i}", "KIND", {"i": i})
        led.close()
        c = sqlite3.connect(self.path)
        root = c.execute("SELECT rootpage FROM sqlite_master WHERE name='ledger_records_kind'").fetchone()[0]
        page = c.execute("PRAGMA page_size").fetchone()[0]
        c.close()
        with open(self.path, "r+b") as fh:
            fh.seek((root - 1) * page + page - 12)
            fh.write(b"\xff" * 8)                                  # damage index cell content, keep the page parsable
        led = Ledger(self.path, clock=clock)
        self.addCleanup(led.close)
        self.assertIn("sqlite_integrity_failed", verify_integrity(led).codes())

    def test_recover_checks_anchors_when_given(self):
        led, log = self.seed()
        led.close()
        lines = pathlib.Path(self.anchor_path).read_text()
        pathlib.Path(self.anchor_path).write_text(lines.replace('"seq":7', '"seq":6', 1))
        rep = recover(self.path, log)
        self.assertFalse(rep.clean)
        self.assertIn("anchor_log_tampered", rep.integrity.codes())
        self.assertIsNotNone(rep.integrity)


# ---------------------------------------------------------------- 4. concurrency
class Concurrency(Base):
    def test_multi_process_writers_readers_and_a_killed_writer(self):
        self.open().close()
        writer = """
            import sys
            from sanour_ai.persistence import Ledger
            led = Ledger(sys.argv[1]); tag = sys.argv[2]
            for i in range(int(sys.argv[3])):
                led.append(sys.argv[4], "%s-%d" % (tag, i), "K", {"i": i})
                print("%s-%d" % (tag, i), flush=True)
        """
        procs = [popen(writer, self.path, f"p{n}", 25, "evidence" if n % 2 else "governance") for n in range(4)]
        victim = popen(writer, self.path, "victim", 100000, "evidence")
        led = self.open()
        stop, errs = threading.Event(), []

        def reader():
            try:
                while not stop.is_set():
                    rep = verify_integrity(led)
                    if not rep.ok:
                        errs.append(rep.findings)
                    create_checkpoint(led, "evidence")
            except Exception as e:   # pragma: no cover
                errs.append(e)
        rs = [threading.Thread(target=reader) for _ in range(2)]
        [r.start() for r in rs]
        acked = {"evidence": [], "governance": []}
        victim_acked = []
        for _ in range(15):
            victim_acked.append(victim.stdout.readline().strip())
        os.kill(victim.pid, signal.SIGKILL)
        victim.wait(timeout=30)
        for n, p in enumerate(procs):
            out, err = p.communicate(timeout=180)
            self.assertEqual(p.returncode, 0, err[-400:])
            acked["evidence" if n % 2 else "governance"] += out.split()
        stop.set()
        [r.join() for r in rs]
        self.assertEqual(errs, [])
        for s in ("evidence", "governance"):
            recs = led.records(s, limit=10_000)
            self.assertEqual([r.seq for r in recs], list(range(1, len(recs) + 1)))      # no duplicate or missing seq
            ids = [r.record_id for r in recs]
            self.assertEqual(len(ids), len(set(ids)))
            for a in acked[s]:
                self.assertIn(a, ids)
        ids = {r.record_id for r in led.records("evidence", limit=10_000)}
        for a in victim_acked:
            self.assertIn(a, ids)                                                   # acknowledged before the kill
        self.assertTrue(verify_integrity(led).ok)
        self.assertEqual(len(acked["evidence"]) + len(acked["governance"]), 100)

    def test_no_fork_two_instances_same_head(self):
        a, b = self.open(), self.open()
        a.append("evidence", "x", "K", {})
        errs = []

        def go(led, tag):
            try:
                for i in range(30):
                    led.append("evidence", f"{tag}{i}", "K", {})
            except Exception as e:   # pragma: no cover
                errs.append(e)
        ts = [threading.Thread(target=go, args=(a, "a")), threading.Thread(target=go, args=(b, "b"))]
        [t.start() for t in ts]
        [t.join() for t in ts]
        self.assertEqual(errs, [])
        recs = a.records("evidence", limit=1000)
        self.assertEqual(len({r.prev_hash for r in recs}), len(recs))     # every record has a distinct predecessor
        self.assertTrue(verify_integrity(a).ok)

    def test_primary_key_blocks_a_second_record_at_the_same_seq(self):
        led = self.open()
        led.append("evidence", "x", "K", {})
        c = self.raw()
        row = list(c.execute("SELECT * FROM ledger_records").fetchone())
        row[2], row[6] = "other", "9" * 64
        with self.assertRaises(sqlite3.IntegrityError):
            c.execute("INSERT INTO ledger_records VALUES (?,?,?,?,?,?,?,?,?)", row)


# ---------------------------------------------------------------- 5/6. security and scope
class ScopeAndSecurity(unittest.TestCase):
    PKG = SRC / "sanour_ai" / "persistence"

    def test_public_error_codes_unchanged(self):
        from sanour_ai.errors import ErrorCode
        self.assertEqual([(e.name, e.value) for e in ErrorCode], [
            ("INVALID_REQUEST", "invalid_request"), ("NO_ELIGIBLE_MODEL", "no_eligible_model"),
            ("PROVIDER_FAILED", "provider_failed"), ("PROVIDER_TIMEOUT", "provider_timeout"),
            ("PROVIDER_OVERLOADED", "provider_overloaded"), ("PROVIDER_RATE_LIMITED", "provider_rate_limited"),
            ("PROVIDER_INVALID_RESPONSE", "provider_invalid_response"),
            ("PROVIDER_CONTENT_BLOCKED", "provider_content_blocked"), ("INTERNAL_ERROR", "internal_error")])

    def test_no_backup_restore_or_runtime_wiring(self):
        import sanour_ai.persistence as P
        for name in dir(P):
            self.assertFalse(any(w in name.lower() for w in ("backup", "restore", "repair", "rebuild")), name)
        for f in self.PKG.glob("*.py"):
            self.assertNotIn(".backup(", f.read_text())
        for pkg in ("core", "composition", "models", "providers", "readiness"):
            for f in (SRC / "sanour_ai" / pkg).glob("*.py"):
                self.assertNotIn("sanour_ai.persistence", f.read_text(), f"{pkg}/{f.name}")

    def test_no_provider_network_or_fallback_code(self):
        text = "\n".join(f.read_text().lower() for f in self.PKG.glob("*.py"))
        for word in ("openai", "anthropic", "gemini", "grok", "retry", "fallback", "auto_select", "urlopen", "socket"):
            self.assertFalse(word in text, word)

    def test_import_loads_no_forbidden_modules(self):
        p = py("""
            import sys, json
            import sanour_ai.persistence
            bad = [m for m in sys.modules if m.startswith(("sanour_ai.providers", "sanour_ai.readiness", "sanour_ai.core",
                   "sanour_ai.models", "sanour_ai.composition", "sanour_ai.governance", "sanour_ai.ledger"))]
            net = [m for m in ("socket", "ssl", "urllib.request", "http.client", "httpx", "requests", "openai") if m in sys.modules]
            print(json.dumps([bad, net]))
        """)
        self.assertEqual(json.loads(p.stdout), [[], []])

    def test_stage_10_54_a_surface_preserved(self):
        import sanour_ai.persistence as P
        for name in ("Ledger", "EvidenceLedger", "GovernanceEventLedger", "AppendResult", "StoredRecord", "VerifyReport",
                     "IdempotencyConflict", "LinkRejected", "SchemaError", "RecordRejected", "LATEST_VERSION"):
            self.assertTrue(hasattr(P, name), name)
        a = json.loads((ROOT / "docs" / "MIGRATION_CHECKSUMS_10_54A.json").read_text())["checksums"]
        self.assertEqual([m.checksum for m in M.MIGRATIONS[:2]], a)    # V1 and V2 byte-identical to 10.54-A

    def test_error_text_is_fixed_and_content_free(self):
        for exc in (RecoveryError("x"), AnchorError("y")):
            self.assertNotIn(MARK, str(exc))
        src = (SRC / "sanour_ai" / "persistence" / "recovery.py").read_text()
        import re
        for m in re.finditer(r"raise (?:RecoveryError|AnchorError)\((.*?)\)", src):
            self.assertNotIn("{", m.group(1))     # no f-string interpolation of data into error text


if __name__ == "__main__":
    unittest.main()
