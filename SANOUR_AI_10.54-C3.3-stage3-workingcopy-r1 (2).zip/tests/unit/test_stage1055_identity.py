"""C3.3 Stage 1: database identity classification. Fixture databases only, in temporary directories.

The identity values below are TEST-ONLY placeholders. They are not the final application_id values (U1 open).
"""

import ast
import hashlib
import os
import pathlib
import shutil
import sqlite3
import tempfile
import unittest

from sanour_ai.storage import identity as I
from sanour_ai.storage.identity import (
    IdentityState,
    SPECS,
    SubsystemId,
    classify,
    classify_facts,
    read_facts,
    validate_identities,
)

TEST_IDS = {
    SubsystemId.LEDGER: 0x7E000001,
    SubsystemId.USAGE: 0x7E000002,
    SubsystemId.GOVERNANCE: 0x7E000003,
    SubsystemId.SINK: 0x7E000004,
}

# Structures built from the observed table sets (see SPECS). Used to create realistic fixtures.
LEDGER_TABLES = ["ledger_records", "ledger_links", "ledger_checkpoints", "schema_migrations"]
USAGE_TABLES = ["usage_records"]
GOV_TABLES = sorted(SPECS[SubsystemId.GOVERNANCE].tables)
SINK_TABLES = ["audit_receipts", "audit_inbox"]


def make_db(path, tables, *, app_id=0, user_version=0):
    conn = sqlite3.connect(path)
    try:
        for name in tables:
            conn.execute(f"CREATE TABLE {name} (x INTEGER)")
        conn.execute(f"PRAGMA application_id={int(app_id)}")
        conn.execute(f"PRAGMA user_version={int(user_version)}")
        conn.commit()
    finally:
        conn.close()
    return path


def _write_garbage(path):
    with open(path, "wb") as fh:
        fh.write(b"this is not a database" * 100)


def _write_empty(path):
    with open(path, "wb"):
        pass


def digest_dir(d):
    out = {}
    for name in sorted(os.listdir(d)):
        p = os.path.join(d, name)
        st = os.stat(p)
        with open(p, "rb") as fh:
            out[name] = (hashlib.sha256(fh.read()).hexdigest(), st.st_size, st.st_mtime_ns)
    return out


class _TempDirCase(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.mkdtemp(prefix="stage1055_")
        self.d = self._td

    def tearDown(self):
        shutil.rmtree(self._td, ignore_errors=True)

    def p(self, name):
        return os.path.join(self.d, name)


class EnumAndConfig(unittest.TestCase):
    def test_nine_identity_states(self):
        self.assertEqual(len(IdentityState), 9)
        self.assertEqual({s.name for s in IdentityState},
                         {"NEW", "OWNED", "OWNED_OLDER", "OWNED_NEWER", "FOREIGN", "UNSTAMPED_KNOWN",
                          "MIXED", "UNKNOWN", "DAMAGED"})

    def test_four_subsystems(self):
        self.assertEqual({s.name for s in SubsystemId}, {"LEDGER", "USAGE", "GOVERNANCE", "SINK"})

    def test_valid_configuration_accepted(self):
        self.assertEqual(validate_identities(TEST_IDS), TEST_IDS)

    def test_missing_subsystem_refused(self):
        bad = dict(TEST_IDS)
        del bad[SubsystemId.SINK]
        with self.assertRaises(ValueError):
            validate_identities(bad)

    def test_extra_or_non_mapping_refused(self):
        with self.assertRaises(ValueError):
            validate_identities(list(TEST_IDS.items()))
        extra = dict(TEST_IDS)
        extra["other"] = 5
        with self.assertRaises(ValueError):
            validate_identities(extra)

    def test_zero_is_reserved(self):
        bad = dict(TEST_IDS)
        bad[SubsystemId.SINK] = 0
        with self.assertRaises(ValueError):
            validate_identities(bad)

    def test_duplicate_values_refused(self):
        bad = dict(TEST_IDS)
        bad[SubsystemId.SINK] = TEST_IDS[SubsystemId.USAGE]
        with self.assertRaises(ValueError):
            validate_identities(bad)

    def test_out_of_range_and_bool_refused(self):
        bad = dict(TEST_IDS)
        bad[SubsystemId.SINK] = 2**31
        with self.assertRaises(ValueError):
            validate_identities(bad)
        bad[SubsystemId.SINK] = True
        with self.assertRaises(ValueError):
            validate_identities(bad)

    def test_module_imports_only_standard_library(self):
        src = pathlib.Path(I.__file__).read_text(encoding="utf-8")
        for node in ast.walk(ast.parse(src)):
            if isinstance(node, ast.Import):
                for a in node.names:
                    self.assertFalse(a.name.startswith("sanour_ai"), a.name)
            if isinstance(node, ast.ImportFrom) and node.module:
                self.assertFalse(node.module.startswith("sanour_ai"), node.module)


class PureClassification(unittest.TestCase):
    """Table-driven, using in-memory facts (no files)."""

    def facts(self, tables, app=0, uv=0, qc="ok", readable=True, size=4096, exists=True, error=None):
        return I.FileFacts(exists=exists, size=size, readable=readable, application_id=app,
                           user_version=uv, quick_check=qc, tables=frozenset(tables), error=error)

    def cls(self, facts, expected=None):
        return classify_facts(facts, identities=TEST_IDS, expected=expected).state

    def test_new_absent_and_zero_bytes(self):
        self.assertIs(self.cls(self.facts([], exists=False, size=0, readable=False)), IdentityState.NEW)
        self.assertIs(self.cls(self.facts([], size=0, readable=False)), IdentityState.NEW)

    def test_damaged_unreadable_and_failed_quick_check(self):
        self.assertIs(self.cls(self.facts([], readable=False, qc=None, error="not a SQLite database")),
                      IdentityState.DAMAGED)
        self.assertIs(self.cls(self.facts(USAGE_TABLES, app=TEST_IDS[SubsystemId.USAGE], uv=1,
                                          qc="*** corrupt ***")), IdentityState.DAMAGED)

    def test_owned_when_identity_and_structure_agree(self):
        f = self.facts(USAGE_TABLES, app=TEST_IDS[SubsystemId.USAGE], uv=1)
        c = classify_facts(f, identities=TEST_IDS, expected=SubsystemId.USAGE)
        self.assertIs(c.state, IdentityState.OWNED)
        self.assertIs(c.owner, SubsystemId.USAGE)

    def test_owned_older_and_newer_versions(self):
        self.assertIs(self.cls(self.facts(USAGE_TABLES, app=TEST_IDS[SubsystemId.USAGE], uv=0),
                               SubsystemId.USAGE), IdentityState.OWNED_OLDER)
        self.assertIs(self.cls(self.facts(USAGE_TABLES, app=TEST_IDS[SubsystemId.USAGE], uv=2),
                               SubsystemId.USAGE), IdentityState.OWNED_NEWER)

    def test_foreign_only_when_stamped_and_expected_differs(self):
        f = self.facts(USAGE_TABLES, app=TEST_IDS[SubsystemId.USAGE], uv=1)
        c = classify_facts(f, identities=TEST_IDS, expected=SubsystemId.LEDGER)
        self.assertIs(c.state, IdentityState.FOREIGN)
        self.assertIs(c.owner, SubsystemId.USAGE)

    def test_unstamped_known_structure_reports_owner_and_is_not_foreign(self):
        f = self.facts(USAGE_TABLES, app=0, uv=1)
        c = classify_facts(f, identities=TEST_IDS, expected=SubsystemId.LEDGER)
        self.assertIs(c.state, IdentityState.UNSTAMPED_KNOWN)
        self.assertIs(c.owner, SubsystemId.USAGE)

    def test_mixed_when_two_subsystems_touched(self):
        self.assertIs(self.cls(self.facts(LEDGER_TABLES + USAGE_TABLES, app=0, uv=3)), IdentityState.MIXED)
        self.assertIs(self.cls(self.facts(LEDGER_TABLES + GOV_TABLES, app=TEST_IDS[SubsystemId.LEDGER], uv=3)),
                      IdentityState.MIXED)

    def test_shared_table_alone_does_not_prove_ownership(self):
        self.assertIs(self.cls(self.facts(["schema_migrations"], app=0, uv=0)), IdentityState.UNKNOWN)

    def test_unknown_when_unrecognized_tables_present(self):
        self.assertIs(self.cls(self.facts(USAGE_TABLES + ["mystery"], app=0, uv=1)), IdentityState.UNKNOWN)

    def test_unknown_when_empty_non_sqlite_structure(self):
        self.assertIs(self.cls(self.facts([], app=0, uv=0)), IdentityState.UNKNOWN)


class ConflictingAndMalformedMetadata(unittest.TestCase):
    def cls(self, tables, app, uv, expected=None, qc="ok"):
        f = I.FileFacts(exists=True, size=4096, readable=True, application_id=app, user_version=uv,
                        quick_check=qc, tables=frozenset(tables))
        return classify_facts(f, identities=TEST_IDS, expected=expected)

    def test_unrecognized_application_id_is_unknown(self):
        self.assertIs(self.cls(USAGE_TABLES, 0x12345678, 1).state, IdentityState.UNKNOWN)

    def test_identity_conflicts_with_structure(self):
        # claims usage, but the structure is the ledger's
        c = self.cls(LEDGER_TABLES, TEST_IDS[SubsystemId.USAGE], 3, expected=SubsystemId.USAGE)
        self.assertIs(c.state, IdentityState.UNKNOWN)

    def test_identity_without_any_structure_is_unknown(self):
        self.assertIs(self.cls([], TEST_IDS[SubsystemId.LEDGER], 3).state, IdentityState.UNKNOWN)

    def test_identity_with_mixed_structure_is_mixed_not_owned(self):
        c = self.cls(USAGE_TABLES + LEDGER_TABLES, TEST_IDS[SubsystemId.USAGE], 1, expected=SubsystemId.USAGE)
        self.assertIs(c.state, IdentityState.MIXED)

    def test_identity_with_missing_signature_table_is_unknown(self):
        # governance identity, but only a non-signature table: must not be OWNED
        c = self.cls(["budgets"], TEST_IDS[SubsystemId.GOVERNANCE], 0, expected=SubsystemId.GOVERNANCE)
        self.assertIs(c.state, IdentityState.UNKNOWN)

    def test_negative_user_version_is_malformed(self):
        self.assertIs(self.cls(USAGE_TABLES, TEST_IDS[SubsystemId.USAGE], -1).state, IdentityState.UNKNOWN)
        self.assertIs(self.cls(USAGE_TABLES, 0, -1).state, IdentityState.UNKNOWN)

    def test_negative_application_id_is_malformed(self):
        self.assertIs(self.cls(USAGE_TABLES, -5, 1).state, IdentityState.UNKNOWN)

    def test_version_metadata_on_unversioned_subsystem_is_conflicting(self):
        c = self.cls(SINK_TABLES, TEST_IDS[SubsystemId.SINK], 7, expected=SubsystemId.SINK)
        self.assertIs(c.state, IdentityState.UNKNOWN)

    def test_unstamped_file_newer_than_code_is_unknown(self):
        self.assertIs(self.cls(USAGE_TABLES, 0, 9).state, IdentityState.UNKNOWN)

    def test_damaged_overrides_a_matching_identity(self):
        c = self.cls(USAGE_TABLES, TEST_IDS[SubsystemId.USAGE], 1, expected=SubsystemId.USAGE, qc="malformed")
        self.assertIs(c.state, IdentityState.DAMAGED)


class ApplicationIdAloneIsNotProof(unittest.TestCase):
    """A correct application_id must never be enough for OWNED or UNSTAMPED_KNOWN."""

    def test_stamped_with_every_wrong_structure_is_never_owned(self):
        structures = {
            "ledger": LEDGER_TABLES, "usage": USAGE_TABLES, "gov": GOV_TABLES, "sink": SINK_TABLES,
            "empty": [], "mixed": LEDGER_TABLES + USAGE_TABLES, "unknown": ["x_table"],
        }
        for sub, ident in TEST_IDS.items():
            for label, tables in structures.items():
                f = I.FileFacts(exists=True, size=4096, readable=True, application_id=ident,
                                user_version=0, quick_check="ok", tables=frozenset(tables))
                state = classify_facts(f, identities=TEST_IDS, expected=sub).state
                if label == sub.value.replace("governance", "gov").replace("ledger", "ledger"):
                    continue
                self.assertNotIn(state, (IdentityState.OWNED, IdentityState.OWNED_OLDER,
                                         IdentityState.OWNED_NEWER, IdentityState.UNSTAMPED_KNOWN),
                                 f"{sub} id with {label} structure -> {state}")

    def test_correct_identity_on_a_damaged_file_is_damaged(self):
        f = I.FileFacts(exists=True, size=4096, readable=False, application_id=TEST_IDS[SubsystemId.USAGE],
                        user_version=1, quick_check=None, tables=frozenset(), error="read failed")
        self.assertIs(classify_facts(f, identities=TEST_IDS).state, IdentityState.DAMAGED)


class FileReaderAndNoWrites(_TempDirCase):
    def test_every_state_from_real_files(self):
        """Each case: (file name, builder, expected subsystem, expected state). Every state must appear."""
        U, L = SubsystemId.USAGE, SubsystemId.LEDGER
        cases = [
            ("absent.db", None, U, IdentityState.NEW),
            ("zero.db", _write_empty, U, IdentityState.NEW),
            ("garbage.db", _write_garbage, U, IdentityState.DAMAGED),
            ("u0.db", lambda p: make_db(p, USAGE_TABLES, app_id=0, user_version=1), U, IdentityState.UNSTAMPED_KNOWN),
            ("u1.db", lambda p: make_db(p, USAGE_TABLES, app_id=TEST_IDS[U], user_version=1), U, IdentityState.OWNED),
            ("u2.db", lambda p: make_db(p, USAGE_TABLES, app_id=TEST_IDS[U], user_version=0), U, IdentityState.OWNED_OLDER),
            ("u3.db", lambda p: make_db(p, USAGE_TABLES, app_id=TEST_IDS[U], user_version=5), U, IdentityState.OWNED_NEWER),
            ("uf.db", lambda p: make_db(p, USAGE_TABLES, app_id=TEST_IDS[U], user_version=1), L, IdentityState.FOREIGN),
            ("lx.db", lambda p: make_db(p, LEDGER_TABLES, app_id=TEST_IDS[U], user_version=3), U, IdentityState.UNKNOWN),
            ("mix.db", lambda p: make_db(p, LEDGER_TABLES + USAGE_TABLES, app_id=0, user_version=3), U, IdentityState.MIXED),
            ("unk.db", lambda p: make_db(p, USAGE_TABLES, app_id=0x12345678, user_version=1), U, IdentityState.UNKNOWN),
            ("ut.db", lambda p: make_db(p, USAGE_TABLES + ["mystery"], app_id=0, user_version=1), U, IdentityState.UNKNOWN),
        ]
        seen = set()
        for name, build, expected, want in cases:
            path = self.p(name)
            if build is not None:
                build(path)
            got = classify(path, identities=TEST_IDS, expected=expected).state
            self.assertIs(got, want, name)
            seen.add(got)
        self.assertEqual(seen, set(IdentityState))

    def test_real_wal_database_is_refused_and_creates_no_sidecars(self):
        """Stage 1 reader guard (O5): a live WAL database is refused before any SQLite connection, so no -wal or
        -shm is created and the database bytes and directory stay unchanged."""
        from sanour_ai.ledger.sqlite_repository import SqliteUsageRepository
        path = self.p("wal_usage.db")
        SqliteUsageRepository(path).close()
        before = digest_dir(self.d)
        for _ in range(3):
            with self.assertRaises(I.LiveWalRefused):
                classify(path, identities=TEST_IDS, expected=SubsystemId.USAGE)
        after = digest_dir(self.d)
        self.assertEqual(before, after)
        self.assertFalse(any(n.endswith(("-wal", "-shm")) for n in after))

    def test_truncated_database_is_damaged(self):
        path = make_db(self.p("t.db"), USAGE_TABLES, app_id=TEST_IDS[SubsystemId.USAGE], user_version=1)
        with open(path, "r+b") as fh:
            fh.truncate(120)
        self.assertIs(classify(path, identities=TEST_IDS, expected=SubsystemId.USAGE).state,
                      IdentityState.DAMAGED)

    def test_classification_does_not_write_to_fixtures(self):
        paths = {
            "u1": make_db(self.p("u1.db"), USAGE_TABLES, app_id=TEST_IDS[SubsystemId.USAGE], user_version=1),
            "u0": make_db(self.p("u0.db"), USAGE_TABLES, app_id=0, user_version=1),
            "mix": make_db(self.p("mix.db"), LEDGER_TABLES + USAGE_TABLES, app_id=0, user_version=3),
            "gar": None,
        }
        with open(self.p("gar.db"), "wb") as fh:
            fh.write(b"junk" * 500)
        before = digest_dir(self.d)
        for path in [paths["u1"], paths["u0"], paths["mix"], self.p("gar.db"), self.p("absent.db")]:
            classify(path, identities=TEST_IDS, expected=SubsystemId.USAGE)
            read_facts(path)
        after = digest_dir(self.d)
        self.assertEqual(before, after)
        self.assertEqual(sorted(after), sorted(before))
        self.assertFalse(any(n.endswith(("-journal", "-wal", "-shm")) for n in after))

    def test_classification_does_not_stamp_or_alter_identity(self):
        path = make_db(self.p("u0.db"), USAGE_TABLES, app_id=0, user_version=1)
        classify(path, identities=TEST_IDS, expected=SubsystemId.USAGE)
        conn = sqlite3.connect(path)
        try:
            self.assertEqual(conn.execute("PRAGMA application_id").fetchone()[0], 0)
            self.assertEqual(conn.execute("PRAGMA user_version").fetchone()[0], 1)
        finally:
            conn.close()


class SpecsMatchRealConstructors(_TempDirCase):
    """Builds fixture databases with the EXISTING constructors (no stamping in current code) and checks that
    the observed table sets in SPECS match. Also confirms the constructors leave application_id at 0."""

    def test_spec_tables_match_real_schema(self):
        from sanour_ai.ledger.sqlite_repository import SqliteUsageRepository
        from sanour_ai.governance.sink import DurableSqliteSink
        from sanour_ai.governance.store import GovernanceStore
        from sanour_ai.persistence.ledger import Ledger

        built = {}
        for sub, factory in [
            (SubsystemId.LEDGER, lambda p: Ledger(p).close()),
            (SubsystemId.USAGE, lambda p: SqliteUsageRepository(p).close()),
            (SubsystemId.GOVERNANCE, lambda p: GovernanceStore(p).close()),
            (SubsystemId.SINK, lambda p: DurableSqliteSink(p).close()),
        ]:
            path = self.p(sub.value + ".db")
            factory(path)
            conn = sqlite3.connect(path)
            try:
                tables = frozenset(r[0] for r in conn.execute(
                    "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"))
                app = conn.execute("PRAGMA application_id").fetchone()[0]
                uv = conn.execute("PRAGMA user_version").fetchone()[0]
            finally:
                conn.close()
            built[sub] = (tables, app, uv)
            self.assertEqual(tables, SPECS[sub].tables, sub)
            self.assertEqual(app, 0, "constructor must not stamp in Stage 1 scope")
            self.assertLessEqual(SPECS[sub].signature, tables, sub)
            if SPECS[sub].schema_version is not None:
                self.assertEqual(uv, SPECS[sub].schema_version, sub)

    def test_real_unstamped_wal_files_are_refused_by_the_guard(self):
        """Real stores are WAL-mode, so Stage 1 no longer classifies them from a live path (O5)."""
        from sanour_ai.ledger.sqlite_repository import SqliteUsageRepository
        path = self.p("real_usage.db")
        SqliteUsageRepository(path).close()
        with self.assertRaises(I.LiveWalRefused):
            classify(path, identities=TEST_IDS, expected=SubsystemId.USAGE)


class LiveWalGuard(_TempDirCase):
    """O5 narrow guard: refuse WAL-mode databases and -wal/-shm sidecars before any SQLite connection."""

    def _no_sqlite(self):
        from unittest import mock
        return mock.patch("sqlite3.connect", side_effect=AssertionError("sqlite must not be opened"))

    def _wal_db(self, name, tables=USAGE_TABLES, app_id=0, user_version=1):
        path = make_db(self.p(name), tables, app_id=app_id, user_version=user_version)
        conn = sqlite3.connect(path)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.close()                         # last close removes -wal and -shm; header now says WAL
        with open(path, "rb") as fh:
            self.assertEqual(fh.read(20)[18:20], b"\x02\x02")
        self.assertFalse(os.path.exists(path + "-wal") or os.path.exists(path + "-shm"))
        return path

    def test_wal_header_database_refused_before_any_sqlite_connection(self):
        path = self._wal_db("w.db")
        before = digest_dir(self.d)
        with self._no_sqlite(), self.assertRaises(I.LiveWalRefused):
            read_facts(path)
        self.assertEqual(before, digest_dir(self.d))

    def test_wal_sidecar_present_refused_and_sidecar_untouched(self):
        path = make_db(self.p("rb.db"), USAGE_TABLES, app_id=0, user_version=1)
        with open(path + "-wal", "wb") as fh:
            fh.write(b"")
        before = digest_dir(self.d)
        with self._no_sqlite(), self.assertRaises(I.LiveWalRefused):
            read_facts(path)
        self.assertEqual(before, digest_dir(self.d))

    def test_shm_sidecar_only_refused(self):
        path = make_db(self.p("sh.db"), USAGE_TABLES, app_id=0, user_version=1)
        with open(path + "-shm", "wb") as fh:
            fh.write(b"\x00" * 32)
        with self._no_sqlite(), self.assertRaises(I.LiveWalRefused):
            read_facts(path)

    def test_rollback_mode_database_is_read_exactly_as_before(self):
        path = make_db(self.p("rb2.db"), USAGE_TABLES, app_id=0, user_version=1)
        c = classify(path, identities=TEST_IDS, expected=SubsystemId.USAGE)
        self.assertIs(c.state, IdentityState.UNSTAMPED_KNOWN)
        self.assertFalse(any(n.endswith(("-wal", "-shm")) for n in os.listdir(self.d)))

    def test_non_sqlite_with_wal_bytes_is_damaged_not_refused(self):
        """Magic is checked first: garbage that happens to have 2 at header bytes 18-19 is not a WAL database."""
        path = self.p("fake.db")
        blob = bytearray(b"junk" * 600)
        blob[18] = 2
        blob[19] = 2
        with open(path, "wb") as fh:
            fh.write(bytes(blob))
        self.assertIs(classify(path, identities=TEST_IDS).state, IdentityState.DAMAGED)

    def test_absent_and_zero_bytes_are_not_refused(self):
        self.assertIs(classify(self.p("none.db"), identities=TEST_IDS).state, IdentityState.NEW)
        open(self.p("empty.db"), "wb").close()
        self.assertIs(classify(self.p("empty.db"), identities=TEST_IDS).state, IdentityState.NEW)

    def test_every_subsystem_constructor_output_is_refused(self):
        from sanour_ai.ledger.sqlite_repository import SqliteUsageRepository
        from sanour_ai.governance.sink import DurableSqliteSink
        from sanour_ai.governance.store import GovernanceStore
        from sanour_ai.persistence.ledger import Ledger
        for name, factory in [
            ("l.db", lambda p: Ledger(p).close()),
            ("u.db", lambda p: SqliteUsageRepository(p).close()),
            ("g.db", lambda p: GovernanceStore(p).close()),
            ("s.db", lambda p: DurableSqliteSink(p).close()),
        ]:
            path = self.p(name)
            factory(path)
            with self.assertRaises(I.LiveWalRefused, msg=name):
                read_facts(path)

    def test_classify_propagates_refusal_and_guard_does_not_change_nine_states(self):
        self.assertEqual(len(IdentityState), 9)
        path = self._wal_db("w2.db")
        with self.assertRaises(I.LiveWalRefused):
            classify(path, identities=TEST_IDS, expected=SubsystemId.USAGE)


if __name__ == "__main__":
    unittest.main()
