"""Stage 10.54-C3: full-chain integrity, crash consistency (real child processes), cross-process races, I/O faults,
readiness status, and architecture boundary guards. Offline, no keys. Crash points are injected in CHILD processes
by test-side patches (os._exit = abrupt death with no cleanup); no fault is simulated inside the parent."""

import errno
import fcntl
import hashlib
import json
import os
import pathlib
import re
import sqlite3
import subprocess
import sys
import tempfile
import textwrap
import threading
import time
import unittest
from datetime import datetime, timezone
from unittest import mock

from sanour_ai.backup import BackupError, RestoreError, create_backup, restore_backup, sweep_stale_temporaries, verify_backup
from sanour_ai.backup import archive as A
from sanour_ai.integrity import AuditError, AuditTrail, backup_status, full_integrity, open_guarded_ledger
from sanour_ai.integrity import IntegrityHookError
from sanour_ai.persistence import AnchorLog, Ledger, create_checkpoint, export_anchor
from sanour_ai.persistence import canonical as C
from sanour_ai.persistence import migrations as M
from sanour_ai.readiness.backup_status import assess_backup_status

ROOT = pathlib.Path(__file__).resolve().parents[2]
SRC = ROOT / "src"
T0 = datetime(2026, 1, 1, tzinfo=timezone.utc)
ENV = {**os.environ, "PYTHONPATH": f"{SRC}{os.pathsep}{ROOT}", "PYTHONDONTWRITEBYTECODE": "1"}
CLOCK = lambda: "2026-01-01T00:00:00+00:00"
INJECTED = 137


def raw_edit(db, sql, args=()):
    """Test-only: one edit with guards removed, then guards restored, so only the check under test can refuse."""
    c = sqlite3.connect(db)
    try:
        guards = c.execute("SELECT name, sql FROM sqlite_master WHERE type='trigger' AND name LIKE '%_no_%'").fetchall()
        for name, _ in guards:
            c.execute(f"DROP TRIGGER {name}")
        c.execute(sql, args)
        for _, create in guards:
            c.execute(create)
        c.commit()
    finally:
        c.close()


def rewrite_from(db, stream, seq0, new_payload):
    """Test-only attacker: changes one payload and re-hashes every later record so the chain stays internally valid."""
    c = sqlite3.connect(db)
    try:
        guards = c.execute("SELECT name, sql FROM sqlite_master WHERE type='trigger' AND name LIKE '%_no_%'").fetchall()
        for name, _ in guards:
            c.execute(f"DROP TRIGGER {name}")
        rows = c.execute("SELECT seq, canonical_bytes FROM ledger_records WHERE stream=? AND seq>=? ORDER BY seq",
                         (stream, seq0)).fetchall()
        prev = c.execute("SELECT record_hash FROM ledger_records WHERE stream=? AND seq=?",
                         (stream, seq0 - 1)).fetchone()[0] if seq0 > 1 else C.GENESIS_HASH
        for seq, raw in rows:
            body = json.loads(raw)
            if seq == seq0:
                body["payload"] = new_payload
            body["prev_hash"] = prev
            body["content_sha256"] = C.content_digest(body["kind"], body["payload"])
            raw2 = C.dumps(body)
            h = C.sha256_hex(raw2)
            c.execute("UPDATE ledger_records SET canonical_bytes=?, record_hash=?, prev_hash=?, content_sha256=? "
                      "WHERE stream=? AND seq=?", (raw2, h, prev, body["content_sha256"], stream, seq))
            prev = h
        for name, create in guards:
            c.execute(create)
        c.commit()
    finally:
        c.close()


def resign(bdir, mutate):
    mpath = os.path.join(bdir, A.MANIFEST_NAME)
    m = json.loads(pathlib.Path(mpath).read_text())
    m.pop("manifest_sha256")
    mutate(m)
    m["files"][0]["sha256"], m["files"][0]["size"] = A._digest(os.path.join(bdir, A.DB_NAME))[0], \
        os.path.getsize(os.path.join(bdir, A.DB_NAME))
    m["manifest_sha256"] = C.sha256_hex(C.dumps(m))
    pathlib.Path(mpath).write_bytes(C.dumps(m))


def sidecars(path):
    return [s for s in ("-wal", "-shm", "-journal") if os.path.lexists(path + s)]


def temporaries(d):
    return [n for n in os.listdir(d) if n.startswith((A._RESTORE_TMP, A._BACKUP_TMP))]


def child(code, *args):
    return subprocess.run([sys.executable, "-c", textwrap.dedent(code), *map(str, args)], env=ENV,
                          capture_output=True, text=True, timeout=120)


class Base(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory()
        self.d = self._td.name
        self.src = os.path.join(self.d, "ledger.sqlite")
        self.led = open_guarded_ledger(self.src, clock=lambda: T0)
        for i in range(20):
            self.led.append("evidence", f"e{i}", "EVIDENCE", {"n": i})
        self.led.append("governance", "g0", "GOVERNANCE", {"n": 0})

    def tearDown(self):
        self.led.close()
        self._td.cleanup()

    def reopen(self):
        self.led.close()
        self.led = open_guarded_ledger(self.src, clock=lambda: T0)

    def make_backup(self, name="bk"):
        return create_backup(self.src, os.path.join(self.d, name), clock=CLOCK)


# ---------------------------------------------------------------- 1. full chain: beyond the 16-record window
class FullChain(Base):
    def test_clean_ledger_passes_the_full_check(self):
        fi = full_integrity(self.led)
        self.assertTrue(fi.ok, fi.codes)
        self.assertEqual(fi.streams["evidence"]["records"], 20)

    def test_tamper_outside_the_hook_window_is_caught_only_by_the_full_check(self):
        self.reopen()
        raw_edit(self.src, "UPDATE ledger_records SET canonical_bytes=? WHERE stream='evidence' AND seq=2",
                 (b'{"x":1}',))
        self.reopen()
        self.led.append("evidence", "ok-append", "EVIDENCE", {})     # hook window (last 16) is clean: commit passes
        fi = full_integrity(self.led)
        self.assertFalse(fi.ok)
        self.assertIn("record_hash_mismatch", fi.codes)          # the specific check, not "any of several"

    def test_deleted_middle_record_is_detected(self):
        self.reopen()
        raw_edit(self.src, "DELETE FROM ledger_records WHERE stream='evidence' AND seq=10")
        self.reopen()
        fi = full_integrity(self.led)
        self.assertIn("sequence_gap", fi.codes)
        self.assertIn("prev_hash_mismatch", fi.codes)

    def test_moved_record_is_detected(self):
        self.reopen()
        raw_edit(self.src, "UPDATE ledger_records SET seq=1000 WHERE stream='evidence' AND seq=4")
        raw_edit(self.src, "UPDATE ledger_records SET seq=4 WHERE stream='evidence' AND seq=5")
        raw_edit(self.src, "UPDATE ledger_records SET seq=5 WHERE stream='evidence' AND seq=1000")
        self.reopen()
        fi = full_integrity(self.led)
        self.assertFalse(fi.ok)
        self.assertIn("columns_differ_from_bytes", fi.codes)   # swapped seq columns disagree with the signed bytes
        self.assertIn("prev_hash_mismatch", fi.codes)          # and the links no longer follow the order

    def test_metadata_column_change_is_detected(self):
        self.reopen()
        raw_edit(self.src, "UPDATE ledger_records SET kind='FORGED' WHERE stream='evidence' AND seq=7")
        self.reopen()
        fi = full_integrity(self.led)
        self.assertIn("columns_differ_from_bytes", fi.codes)

    def test_recorded_at_column_change_is_detected(self):
        self.reopen()
        raw_edit(self.src, "UPDATE ledger_records SET recorded_at='1999-01-01T00:00:00+00:00' WHERE stream='evidence' AND seq=9")
        self.reopen()
        self.assertIn("columns_differ_from_bytes", full_integrity(self.led).codes)

    def test_checkpoint_tamper_is_detected(self):
        create_checkpoint(self.led, "evidence")
        self.reopen()
        raw_edit(self.src, "UPDATE ledger_checkpoints SET head_hash=? WHERE stream='evidence'", ("9" * 64,))
        self.reopen()
        self.assertIn("checkpoint_record_mismatch", full_integrity(self.led).codes)

    def test_checkpoint_ahead_of_truncated_history_is_detected(self):
        create_checkpoint(self.led, "evidence")
        self.reopen()
        raw_edit(self.src, "DELETE FROM ledger_records WHERE stream='evidence' AND seq=20")
        self.reopen()
        self.assertIn("ledger_behind_checkpoint", full_integrity(self.led).codes)

    def test_dropped_guard_trigger_is_detected_by_the_full_check(self):
        self.reopen()
        c = sqlite3.connect(self.src)
        c.execute("DROP TRIGGER ledger_records_no_update")
        c.commit()
        c.close()
        self.reopen()
        self.assertIn("guard_missing:ledger_records_no_update", full_integrity(self.led).codes)

    def test_failed_commit_is_rolled_back_and_the_next_write_still_works(self):
        state = {"fail": True}

        def once(conn):
            if state["fail"]:
                state["fail"] = False
                raise IntegrityHookError("commit refused: injected once")

        self.led.close()
        self.led = Ledger(self.src, clock=lambda: T0, commit_hooks=(once,))
        before = self.led.head("evidence")[0]
        with self.assertRaises(IntegrityHookError):
            self.led.append("evidence", "refused", "EVIDENCE", {})
        self.assertEqual(self.led.head("evidence")[0], before)
        self.led.append("evidence", "after", "EVIDENCE", {})          # no transaction left open by the refusal
        self.assertEqual(self.led.head("evidence")[0], before + 1)

    def test_external_anchor_catches_a_consistent_rewrite_of_history(self):
        a = export_anchor(self.led, "evidence")
        log = AnchorLog(os.path.join(self.d, "anchors.log"))
        log.append(a)
        self.assertTrue(full_integrity(self.led, anchors=log).ok)
        self.reopen()
        rewrite_from(self.src, "evidence", 3, {"n": 999})            # re-hash every record after seq 3: no local break
        self.reopen()
        fi = full_integrity(self.led, anchors=log)
        self.assertIn("anchor_mismatch", fi.codes)
        self.assertFalse({"sequence_gap", "prev_hash_mismatch", "record_hash_mismatch"} & set(fi.codes), fi.codes)

    def test_expected_counts_and_heads_are_reconciled(self):
        fi = full_integrity(self.led)
        expected = {k: v for k, v in fi.streams.items()}
        self.assertTrue(full_integrity(self.led, expected=expected).ok)
        bad = {**expected, "evidence": {**expected["evidence"], "records": 19}}
        self.assertIn("expected_streams_mismatch", full_integrity(self.led, expected=bad).codes)

    def test_hook_window_is_a_fast_guard_and_does_not_replace_the_full_check(self):
        self.reopen()
        raw_edit(self.src, "UPDATE ledger_records SET canonical_bytes=? WHERE stream='evidence' AND seq=1", (b'{"z":0}',))
        self.reopen()
        self.led.append("evidence", "outside-window", "EVIDENCE", {})     # by design: record 1 is outside the window
        self.assertFalse(full_integrity(self.led).ok)


# ---------------------------------------------------------------- 2. readiness: evaluates a snapshot only
class ReadinessStatus(Base):
    def test_clean_snapshot_is_ready_and_dirty_one_is_blocked_with_reasons(self):
        ok = assess_backup_status({"integrity_verified": True, "integrity_ok": True, "sidecars": 0,
                                   "temporaries": 0, "verified_backup": True})
        self.assertEqual(ok, {"status": "ready", "reasons": []})
        bad = assess_backup_status({"integrity_verified": True, "integrity_ok": False, "sidecars": 1,
                                    "temporaries": 2, "verified_backup": False})
        self.assertEqual(bad["status"], "blocked")
        self.assertEqual(bad["reasons"], ["integrity_failed", "sidecar_present", "temporary_present", "no_verified_backup"])

    def test_missing_facts_never_count_as_ready(self):
        self.assertEqual(assess_backup_status({})["status"], "blocked")

    def test_backup_status_collects_facts_and_readiness_decides(self):
        self.make_backup()
        self.led.close()
        led = open_guarded_ledger(self.src, clock=lambda: T0)
        try:
            st = backup_status(led, os.path.join(self.d, "bk"))
            self.assertIn("sidecar_present", st["reasons"])          # a live writer's WAL is reported, not hidden
        finally:
            led.close()
        self.led = open_guarded_ledger(self.src, clock=lambda: T0)
        self.assertEqual(backup_status(self.led, None)["reasons"][-1], "no_verified_backup")


# ---------------------------------------------------------------- 3. crash consistency (real child processes)
BACKUP_CHILD = """
import os, sys
from sanour_ai.backup import archive as A
stage, src, dest = sys.argv[1], sys.argv[2], sys.argv[3]
def die(): os._exit(137)
if stage == "copy":
    real = A._online_copy
    def f(s, d): real(s, d); die()
    A._online_copy = f
elif stage == "manifest":
    real = A._write_new
    def f(path, data):
        if path.endswith("manifest.json"):
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            os.write(fd, data[: len(data) // 2]); die()
        return real(path, data)
    A._write_new = f
elif stage == "publish":
    real_rename = os.rename
    def f(a, b): die()
    A.os.rename = f
elif stage == "after_publish":
    real_rename = os.rename
    def f(a, b): real_rename(a, b); die()
    A.os.rename = f
try:
    A.create_backup(src, dest, clock=lambda: "2026-01-01T00:00:00+00:00")
except Exception as exc:
    print(type(exc).__name__); sys.exit(2)
sys.exit(0)
"""

RESTORE_CHILD = """
import os, sys, sqlite3
from sanour_ai.backup import archive as A
stage, bdir, dest = sys.argv[1], sys.argv[2], sys.argv[3]
def die(): os._exit(137)
if stage == "copy":
    real = A._copy_exclusive
    def f(s, d): real(s, d); die()
    A._copy_exclusive = f
elif stage == "journal":
    real_connect = sqlite3.connect
    class P:
        def __init__(self, c): self._c = c
        def execute(self, sql, *a):
            if "journal_mode" in sql: die()
            return self._c.execute(sql, *a)
        def close(self): self._c.close()
    A.sqlite3.connect = lambda *a, **k: P(real_connect(*a, **k))
elif stage == "before_link":
    def f(s, d, *a, **k): die()
    A.os.link = f
elif stage == "after_link":
    real_link = os.link
    def f(s, d, *a, **k): real_link(s, d, *a, **k); die()
    A.os.link = f
try:
    A.restore_backup(bdir, dest)
except Exception as exc:
    print(type(exc).__name__); sys.exit(2)
sys.exit(0)
"""


class CrashConsistency(Base):
    def test_sigkill_style_death_at_each_backup_stage_never_leaves_a_partial_backup(self):
        for stage in ("copy", "manifest", "publish", "after_publish"):
            with self.subTest(stage=stage):
                dest = os.path.join(self.d, f"cb_{stage}")
                r = child(BACKUP_CHILD, stage, self.src, dest)
                self.assertEqual(r.returncode, INJECTED, r.stderr[-300:])     # the injection really happened
                if os.path.isdir(dest):
                    self.assertEqual(verify_backup(dest).streams["evidence"]["records"], 20)   # complete or absent
                    self.assertEqual(stage, "after_publish")                # only the after-publish death leaves a backup
                else:
                    self.assertNotIn(stage, ("after_publish",))
                sweep_stale_temporaries(self.d)
                self.assertEqual(temporaries(self.d), [])

    def test_sigkill_style_death_at_each_restore_stage_never_publishes_a_partial_database(self):
        bdir = os.path.join(self.d, "rbk")
        create_backup(self.src, bdir, clock=CLOCK)
        for stage in ("copy", "journal", "before_link", "after_link"):
            with self.subTest(stage=stage):
                dest = os.path.join(self.d, f"rd_{stage}.sqlite")
                r = child(RESTORE_CHILD, stage, bdir, dest)
                self.assertEqual(r.returncode, INJECTED, r.stderr[-300:])
                if os.path.exists(dest):
                    led = Ledger(dest, clock=lambda: T0)
                    try:
                        self.assertTrue(full_integrity(led).ok)
                        self.assertEqual(led.head("evidence")[0], 20)
                    finally:
                        led.close()
                    self.assertEqual(stage, "after_link")
                self.assertEqual(sidecars(dest) if False else [s for s in ("-wal", "-shm", "-journal")
                                                              if os.path.lexists(dest + s) and stage != "after_link"], [])
                sweep_stale_temporaries(self.d)
                self.assertEqual(temporaries(self.d), [])
                for s in ("-wal", "-shm", "-journal"):
                    if os.path.lexists(dest + s):
                        os.unlink(dest + s)

    def test_crash_while_appending_an_anchor_leaves_a_torn_line_that_is_reported_and_repaired(self):
        log_path = os.path.join(self.d, "anchor_crash.log")
        log = AnchorLog(log_path)
        log.append(export_anchor(self.led, "evidence"))
        code = """
            import os, sys
            from sanour_ai.persistence import AnchorLog, Anchor
            real_write = os.write
            def half(fd, data):
                real_write(fd, data[: len(data) // 2]); os._exit(137)
            os.write = half
            AnchorLog(sys.argv[1]).append(Anchor("evidence", 21, "a" * 64, 3, "2026-01-02T00:00:00+00:00"))
        """
        r = child(code, log_path)
        self.assertEqual(r.returncode, INJECTED)
        anchors, issues = log.read()
        self.assertIn("anchor_partial_tail", issues)
        self.assertEqual(len(anchors), 1)                 # the torn anchor is not trusted
        log.append(export_anchor(self.led, "evidence"))   # identical anchor: must repair the tail and add NOTHING
        anchors, issues = log.read()
        self.assertEqual(issues, [])
        self.assertEqual(len(anchors), 1)

    def test_restore_after_a_killed_restore_is_clean(self):
        bdir = os.path.join(self.d, "after_kill")
        create_backup(self.src, bdir, clock=CLOCK)
        dest = os.path.join(self.d, "after_kill.sqlite")
        child(RESTORE_CHILD, "before_link", bdir, dest)
        self.assertEqual(temporaries(self.d).__len__(), 1)
        sweep_stale_temporaries(self.d)
        self.assertEqual(restore_backup(bdir, dest).streams["evidence"]["records"], 20)
        self.assertEqual(temporaries(self.d), [])


# ---------------------------------------------------------------- 4. I/O faults
class IoFaults(Base):
    def test_disk_full_while_writing_the_manifest_publishes_nothing(self):
        dest = os.path.join(self.d, "full_bk")
        with mock.patch.object(A, "_write_new", side_effect=OSError(errno.ENOSPC, "no space")):
            with self.assertRaises(BackupError):
                create_backup(self.src, dest, clock=CLOCK)
        self.assertFalse(os.path.exists(dest))
        self.assertEqual(temporaries(self.d), [])

    def test_fsync_failure_during_restore_publishes_nothing_and_removes_the_copy(self):
        bdir = os.path.join(self.d, "eio_bk")
        create_backup(self.src, bdir, clock=CLOCK)
        dest = os.path.join(self.d, "eio.sqlite")
        real_fsync = os.fsync

        def bad(fd):
            raise OSError(errno.EIO, "I/O error")

        with mock.patch.object(A.os, "fsync", side_effect=bad):
            with self.assertRaises(RestoreError):
                restore_backup(bdir, dest)
        os.fsync = real_fsync
        self.assertFalse(os.path.exists(dest))
        self.assertEqual(temporaries(self.d), [])

    def test_link_failure_other_than_exists_refuses_without_overwrite(self):
        bdir = os.path.join(self.d, "link_bk")
        create_backup(self.src, bdir, clock=CLOCK)
        dest = os.path.join(self.d, "link.sqlite")
        with mock.patch.object(A.os, "link", side_effect=OSError(errno.EXDEV, "cross-device")):
            with self.assertRaises(RestoreError):
                restore_backup(bdir, dest)
        self.assertFalse(os.path.exists(dest))


# ---------------------------------------------------------------- 5. concurrency and single-writer policy
WRITER = """
import sys
from sanour_ai.integrity import open_guarded_ledger
path, tag, n = sys.argv[1], sys.argv[2], int(sys.argv[3])
led = open_guarded_ledger(path)
for i in range(n):
    led.append("evidence", f"{tag}-{i}", "EVIDENCE", {"t": tag, "i": i})
led.close()
"""

AUDITOR = """
import sys
from sanour_ai.integrity import AuditTrail
path, tag = sys.argv[1], sys.argv[2]
a = AuditTrail(path)
for i in range(40):
    a.record("backup", __import__("hashlib").sha256(f"{tag}{i}".encode()).hexdigest(), "ok")
"""


class Concurrency(Base):
    def test_two_writer_processes_on_one_guarded_ledger_commit_every_record_in_order(self):
        ps = [subprocess.Popen([sys.executable, "-c", WRITER, self.src, tag, "40"], env=ENV,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True) for tag in ("a", "b")]
        for p in ps:
            _, err = p.communicate(timeout=120)
            self.assertEqual(p.returncode, 0, err[-300:])
        self.reopen()
        fi = full_integrity(self.led)
        self.assertTrue(fi.ok, fi.codes)
        self.assertEqual(fi.streams["evidence"]["records"], 20 + 80)

    def test_backups_taken_while_a_writer_commits_are_each_consistent(self):
        p = subprocess.Popen([sys.executable, "-c", WRITER, self.src, "w", "150"], env=ENV,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        made = []
        k = 0
        while p.poll() is None and k < 6:
            dest = os.path.join(self.d, f"live{k}")
            try:
                create_backup(self.src, dest, clock=CLOCK)
                made.append(dest)
            except BackupError:
                pass
            k += 1
        _, err = p.communicate(timeout=120)
        self.assertEqual(p.returncode, 0, err[-300:])
        self.assertTrue(made)
        for dest in made:
            r = verify_backup(dest)                          # every backup verifies on its own
            self.assertTrue(r.streams["evidence"]["records"] >= 20)

    def test_two_backup_processes_to_the_same_destination_publish_exactly_one(self):
        dest = os.path.join(self.d, "race_bk")
        ps = [subprocess.Popen([sys.executable, "-c", textwrap.dedent(BACKUP_CHILD_OK), self.src, dest], env=ENV,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True) for _ in range(2)]
        codes = sorted(p.wait(timeout=120) for p in ps)
        self.assertEqual(codes, [0, 2])
        self.assertEqual(verify_backup(dest).streams["evidence"]["records"], 20)

    def test_two_restore_processes_to_the_same_destination_publish_exactly_one(self):
        bdir = os.path.join(self.d, "rr_bk")
        create_backup(self.src, bdir, clock=CLOCK)
        dest = os.path.join(self.d, "rr.sqlite")
        ps = [subprocess.Popen([sys.executable, "-c", textwrap.dedent(RESTORE_OK), bdir, dest], env=ENV,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True) for _ in range(2)]
        codes = sorted(p.wait(timeout=120) for p in ps)
        self.assertEqual(codes, [0, 2])
        self.assertEqual(temporaries(self.d), [])

    def test_sidecar_appearing_and_disappearing_during_restore_never_yields_a_partial_database(self):
        bdir = os.path.join(self.d, "sc_bk")
        create_backup(self.src, bdir, clock=CLOCK)
        dest = os.path.join(self.d, "sc.sqlite")
        stop = threading.Event()

        def toggler():
            while not stop.is_set():
                try:
                    pathlib.Path(dest + "-shm").write_bytes(b"x")
                    os.unlink(dest + "-shm")
                except OSError:
                    pass

        t = threading.Thread(target=toggler)
        t.start()
        outcomes = []
        try:
            for k in range(8):
                target = os.path.join(self.d, f"sc{k}.sqlite")
                try:
                    restore_backup(bdir, target)
                    outcomes.append("ok")
                    self.assertTrue(full_integrity(Ledger(target, clock=lambda: T0)).ok)
                except RestoreError:
                    outcomes.append("refused")
                    self.assertFalse(os.path.exists(target))
        finally:
            stop.set()
            t.join()
        self.assertTrue(set(outcomes) <= {"ok", "refused"})

    def test_audit_writers_in_two_processes_lose_nothing_and_duplicate_nothing(self):
        path = os.path.join(self.d, "xp_audit.jsonl")
        ps = [subprocess.Popen([sys.executable, "-c", AUDITOR, path, tag], env=ENV,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True) for tag in ("p", "q")]
        for p in ps:
            _, err = p.communicate(timeout=120)
            self.assertEqual(p.returncode, 0, err[-300:])
        events = AuditTrail(path).events()
        self.assertEqual(len(events), 80)
        self.assertEqual(len({e["id"] for e in events}), 80)

    def test_audit_refuses_instead_of_blocking_when_another_writer_holds_the_lock(self):
        path = os.path.join(self.d, "held.jsonl")
        fd = os.open(path + ".lock", os.O_RDWR | os.O_CREAT, 0o600)
        fcntl.flock(fd, fcntl.LOCK_EX)
        outcome = {}

        def attempt():
            try:
                AuditTrail(path, lock_timeout_s=0.2).record("backup", "c" * 64, "ok")
                outcome["r"] = "wrote"
            except AuditError:
                outcome["r"] = "refused"

        t = threading.Thread(target=attempt, daemon=True)     # bounded: a waiter that never gives up fails here
        t.start()
        t.join(timeout=10)
        try:
            self.assertFalse(t.is_alive(), "audit writer blocked forever")
            self.assertEqual(outcome.get("r"), "refused")
        finally:
            os.close(fd)
        self.assertTrue(AuditTrail(path).record("backup", "c" * 64, "ok"))

    def test_concurrent_writers_serialize_on_the_database_not_on_the_process(self):
        led2 = open_guarded_ledger(self.src, clock=lambda: T0)
        try:
            errs = []

            def go(led, tag):
                try:
                    for i in range(15):
                        led.append("evidence", f"{tag}{i}", "EVIDENCE", {})
                except Exception as exc:          # reported below
                    errs.append(exc)

            ts = [threading.Thread(target=go, args=(self.led, "x")), threading.Thread(target=go, args=(led2, "y"))]
            [t.start() for t in ts]
            [t.join() for t in ts]
            self.assertEqual(errs, [])
            self.reopen()
            self.assertTrue(full_integrity(self.led).ok)
            self.assertEqual(full_integrity(self.led).streams["evidence"]["records"], 50)
        finally:
            led2.close()


BACKUP_CHILD_OK = """
import sys
from sanour_ai.backup import create_backup, BackupError
try:
    create_backup(sys.argv[1], sys.argv[2], clock=lambda: "2026-01-01T00:00:00+00:00"); sys.exit(0)
except BackupError:
    sys.exit(2)
"""

RESTORE_OK = """
import sys
from sanour_ai.backup import restore_backup, RestoreError
try:
    restore_backup(sys.argv[1], sys.argv[2]); sys.exit(0)
except RestoreError:
    sys.exit(2)
"""


# ---------------------------------------------------------------- 6. architecture and boundary guards
def imports_of(pkg):
    out = {}
    for f in (SRC / "sanour_ai" / pkg).rglob("*.py"):
        out[str(f.relative_to(SRC))] = f.read_text()
    return out


class BoundaryGuards(unittest.TestCase):
    FORBIDDEN_FOR_CORE = ("sanour_ai.readiness", "sanour_ai.integrity", "sanour_ai.backup", "sanour_ai.composition",
                          "sanour_ai.persistence")

    def test_core_does_not_depend_on_readiness_integrity_backup_or_persistence(self):
        for name, text in imports_of("core").items():
            for bad in self.FORBIDDEN_FOR_CORE:
                self.assertNotIn(bad, text, f"{name} imports {bad}")

    def test_readiness_does_not_cross_the_persistence_boundary_or_import_integrity_or_backup(self):
        for name, text in imports_of("readiness").items():
            for bad in ("sanour_ai.persistence", "sanour_ai.integrity", "sanour_ai.backup", "sanour_ai.composition"):
                self.assertNotIn(bad, text, f"{name} imports {bad}")

    def test_governance_never_touches_backup_files_or_the_backup_package(self):
        for name, text in imports_of("governance").items():
            self.assertNotIn("sanour_ai.backup", text, name)
            self.assertNotIn("manifest.json", text, name)
            self.assertNotIn("ledger.sqlite", text, name)

    def test_only_the_composition_layer_combines_readiness_with_persistence_or_backup(self):
        for name, text in imports_of("integrity").items():
            if name.endswith("composition.py"):
                continue
            self.assertNotIn("sanour_ai.readiness", text, name)
        self.assertIn("sanour_ai.readiness", (SRC / "sanour_ai/integrity/composition.py").read_text())

    def test_ledgers_are_constructed_only_inside_the_allowed_packages(self):
        allowed = ("persistence", "integrity", "backup")
        for f in (SRC / "sanour_ai").rglob("*.py"):
            rel = f.relative_to(SRC / "sanour_ai")
            if rel.parts[0] in allowed:
                continue
            text = f.read_text()
            self.assertIsNone(re.search(r"(?<![A-Za-z_])Ledger\(", text), f"{rel} constructs a ledger directly")
            self.assertIsNone(re.search(r"EvidenceLedger\(|GovernanceEventLedger\(", text), str(rel))

    def test_no_mock_or_fake_in_production_packages(self):
        for pkg in ("persistence", "integrity", "backup", "readiness", "core", "governance"):
            for name, text in imports_of(pkg).items():
                self.assertNotIn("unittest.mock", text, name)
                self.assertNotIn("MockProvider", text, name)

    def test_no_retry_fallback_or_auto_select_in_new_packages(self):
        text = "\n".join(t.lower() for pkg in ("integrity", "backup") for t in imports_of(pkg).values())
        for word in ("retry", "retries", "fallback", "auto_select", "openai", "anthropic", "gemini", "grok", "socket",
                     "urlopen", "httpx", "requests"):
            self.assertNotIn(word, text, word)

    def test_audit_module_stores_no_paths_payloads_or_secrets(self):
        src = (SRC / "sanour_ai/integrity/audit.py").read_text()
        self.assertIn("_CODE = re.compile", src)
        self.assertNotIn("payload", src.split("def record")[1])

    def test_no_public_error_code_added(self):
        from sanour_ai.errors import ErrorCode
        self.assertEqual(len(list(ErrorCode)), 9)

    def test_migrations_v1_to_v3_unchanged(self):
        pinned = json.loads((ROOT / "docs" / "MIGRATION_CHECKSUMS_10_54B.json").read_text())["checksums"]
        self.assertEqual([m.checksum for m in M.MIGRATIONS], pinned)


if __name__ == "__main__":
    unittest.main()
