import json
import os
import unittest

from sanour_ai.readiness import (
    Criterion, Evidence, EvidenceKind, NotApplicable, ReadinessRegistry, Status,
    assess, assess_all, default_registry, render_json, render_markdown,
)

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
H = "a" * 64
PROVIDERS = {"openai", "anthropic", "gemini", "grok", "grok_responses"}


def ev(c, kind=EvidenceKind.LIVE, supports=True, **kw):
    if kind is EvidenceKind.LIVE:
        kw.setdefault("reviewer", "rev")
        kw.setdefault("artifact_sha256", H)
    return Evidence(c, kind, supports, "ref", "note", **kw)


def all_live():
    return [ev(c) for c in Criterion]


class Positive(unittest.TestCase):
    def test_twelve_criteria(self):
        self.assertEqual(len(Criterion), 12)

    def test_all_live_is_ready(self):
        a = assess("p", all_live())
        self.assertEqual(a.overall, Status.PASS)
        self.assertTrue(a.production_ready)
        self.assertEqual(a.blockers, ())

    def test_waiver_counts_as_not_applicable(self):
        evs = [ev(c) for c in Criterion if c is not Criterion.SDK_TRANSPORT_CONFORMANCE]
        a = assess("p", evs, [NotApplicable(Criterion.SDK_TRANSPORT_CONFORMANCE, "plain HTTP adapter, no SDK")])
        self.assertTrue(a.production_ready)
        self.assertIn(Status.NOT_APPLICABLE, [r.status for r in a.results])

    def test_extensible_new_provider(self):
        reg = ReadinessRegistry()
        reg.register_provider("newcomer")
        for e in all_live():
            reg.add_evidence("newcomer", e)
        self.assertTrue(assess_all(reg)[0].production_ready)


class Negative(unittest.TestCase):
    def test_no_evidence_unverified(self):
        a = assess("p", [])
        self.assertEqual(a.overall, Status.UNVERIFIED)
        self.assertFalse(a.production_ready)

    def test_non_live_never_passes(self):
        for kind in (EvidenceKind.LOCAL_TEST, EvidenceKind.MOCK_TEST, EvidenceKind.DOCUMENTATION):
            a = assess("p", [ev(c, kind) for c in Criterion])
            self.assertEqual({r.status for r in a.results}, {Status.UNVERIFIED}, kind)
            self.assertFalse(a.production_ready)

    def test_any_contradiction_fails_even_with_live_support(self):
        for kind in EvidenceKind:
            evs = all_live() + [ev(Criterion.DEADLINE_COMPLIANCE, kind, supports=False)]
            a = assess("p", evs)
            self.assertEqual(a.overall, Status.FAIL, kind)
            self.assertFalse(a.production_ready)

    def test_one_unverified_blocks(self):
        a = assess("p", [ev(c) for c in Criterion if c is not Criterion.AUDIT_INTEGRITY])
        self.assertEqual(a.overall, Status.UNVERIFIED)
        self.assertFalse(a.production_ready)
        self.assertEqual(len(a.blockers), 1)

    def test_fail_outranks_unverified(self):
        a = assess("p", [ev(Criterion.USAGE_ACCOUNTING, EvidenceKind.LOCAL_TEST, supports=False)])
        self.assertEqual(a.overall, Status.FAIL)

    def test_contradiction_beats_waiver(self):
        c = Criterion.SDK_TRANSPORT_CONFORMANCE
        a = assess("p", [ev(c, EvidenceKind.MOCK_TEST, supports=False)], [NotApplicable(c, "no sdk used here")])
        self.assertEqual(a.results[0].status, Status.FAIL)

    def test_mandatory_criterion_cannot_be_waived(self):
        with self.assertRaises(ValueError):
            NotApplicable(Criterion.AUTHENTICATION_SECURITY, "we do not care about auth")

    def test_waiver_needs_reason(self):
        with self.assertRaises(ValueError):
            NotApplicable(Criterion.SDK_TRANSPORT_CONFORMANCE, "n/a")

    def test_live_needs_reviewer_and_hash(self):
        c = Criterion.AUDIT_INTEGRITY
        with self.assertRaises(ValueError):
            Evidence(c, EvidenceKind.LIVE, True, "r", "n", reviewer="", artifact_sha256=H)
        with self.assertRaises(ValueError):
            Evidence(c, EvidenceKind.LIVE, True, "r", "n", reviewer="x", artifact_sha256="abc")

    def test_blank_ref_or_note(self):
        with self.assertRaises(ValueError):
            Evidence(Criterion.AUDIT_INTEGRITY, EvidenceKind.LOCAL_TEST, True, " ", "n")
        with self.assertRaises(ValueError):
            Evidence(Criterion.AUDIT_INTEGRITY, EvidenceKind.LOCAL_TEST, True, "r", "")

    def test_registry_errors(self):
        reg = ReadinessRegistry()
        reg.register_provider("a")
        with self.assertRaises(ValueError):
            reg.register_provider("a")
        with self.assertRaises(ValueError):
            reg.register_provider(" ")
        with self.assertRaises(KeyError):
            reg.add_evidence("zzz", ev(Criterion.AUDIT_INTEGRITY))
        with self.assertRaises(ValueError):
            assess(" ", [])

    def test_other_providers_evidence_ignored(self):
        reg = ReadinessRegistry()
        reg.register_provider("a")
        reg.register_provider("b")
        for e in all_live():
            reg.add_evidence("a", e)
        res = {x.provider_id: x for x in assess_all(reg)}
        self.assertTrue(res["a"].production_ready)
        self.assertFalse(res["b"].production_ready)


class Boundary(unittest.TestCase):
    def test_eleven_of_twelve_live(self):
        a = assess("p", all_live()[:-1])
        self.assertFalse(a.production_ready)

    def test_single_live_among_many_mocks_passes_only_that_criterion(self):
        c = Criterion.DEADLINE_COMPLIANCE
        a = assess("p", [ev(c)] + [ev(x, EvidenceKind.MOCK_TEST) for x in Criterion if x is not c])
        st = {r.criterion: r.status for r in a.results}
        self.assertEqual(st[c], Status.PASS)
        self.assertEqual(a.overall, Status.UNVERIFIED)

    def test_deterministic(self):
        r = default_registry()
        self.assertEqual(render_markdown(assess_all(r)), render_markdown(assess_all(r)))


class CurrentState(unittest.TestCase):
    def setUp(self):
        self.reg = default_registry()
        self.res = {a.provider_id: a for a in assess_all(self.reg)}

    def test_five_providers(self):
        self.assertEqual(set(self.res), PROVIDERS)

    def test_none_ready_none_pass(self):
        for a in self.res.values():
            self.assertFalse(a.production_ready)
            self.assertEqual(a.overall, Status.UNVERIFIED)
            self.assertNotIn(Status.PASS, [r.status for r in a.results])

    def test_no_live_evidence_recorded(self):
        for p in PROVIDERS:
            self.assertFalse([e for e in self.reg.evidence(p) if e.kind is EvidenceKind.LIVE])

    def test_every_criterion_covered(self):
        for a in self.res.values():
            self.assertEqual({r.criterion for r in a.results}, set(Criterion))

    def test_evidence_refs_exist(self):
        for p in PROVIDERS:
            for e in self.reg.evidence(p):
                self.assertTrue(os.path.exists(os.path.join(ROOT, e.ref)), e.ref)

    def test_report(self):
        md = render_markdown(list(self.res.values()))
        for p in PROVIDERS:
            self.assertIn(f"`{p}`", md)
        self.assertNotIn("| yes |", md)
        data = json.loads(render_json(list(self.res.values())))
        self.assertEqual(len(data), 5)
        self.assertTrue(all(d["production_ready"] is False and d["blockers"] for d in data))

    def test_no_retry_or_fallback_or_network_in_package(self):
        d = os.path.join(ROOT, "src", "sanour_ai", "readiness")
        for f in os.listdir(d):
            if f.endswith(".py"):
                with open(os.path.join(d, f), encoding='utf-8') as fh:
                    src = fh.read().lower()
                for bad in ("import socket", "import httpx", "import requests", "urllib", "retry(", "fallback("):
                    self.assertNotIn(bad, src, f)


if __name__ == "__main__":
    unittest.main()
