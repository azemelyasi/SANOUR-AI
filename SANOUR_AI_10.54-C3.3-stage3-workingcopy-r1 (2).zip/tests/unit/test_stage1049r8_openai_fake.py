"""Stage 10.49-R8: FAKE-SDK adapter-contract tests for the OpenAI adapter.

IMPORTANT: these tests do NOT verify the OpenAI SDK. They use a fake client, fake exception classes injected
through SdkErrorTypes, and patch the SDK-validation step so that no SDK import is needed. They check what the
ADAPTER sends and how it classifies what the fake returns. They say nothing about how the real SDK behaves.
Real-SDK runtime tests are separate and skip where the SDK is absent (see the R8 report).

No network. No key. The fake client never sends anything.
"""

import time
import unittest
from types import SimpleNamespace
from unittest import mock

from pydantic import SecretStr

from sanour_ai.config.settings import ConfigError
from sanour_ai.errors import FailureKind
from sanour_ai.models.base import ModelCall, ProviderError
from sanour_ai.providers import openai_provider as op
from sanour_ai.providers.common import RateLimitedError
from sanour_ai.providers.openai_provider import SdkErrorTypes

FAKE_KEY = "TESTONLY-r8-dummy-key-0123456789"
MODEL = "fake-model-1"


# Fake exception classes. They stand in for the adapter's injected error types. They are NOT the SDK's classes.
class FakeBase(Exception):
    pass


class FakeAuth(FakeBase):
    pass


class FakePerm(FakeBase):
    pass


class FakeNotFound(FakeBase):
    pass


class FakeRateLimit(FakeBase):
    def __init__(self, body=None, response=None):
        super().__init__("fake 429")
        self.body, self.response = body, response


class FakeInternal(FakeBase):
    pass


class FakeTimeout(FakeBase):
    pass


class FakeConnection(FakeBase):
    pass


class FakeStatus(FakeBase):
    def __init__(self, status_code, body=None):
        super().__init__("fake status")
        self.status_code, self.body = status_code, body


FAKE_ERRORS = SdkErrorTypes(base=FakeBase, authentication=FakeAuth, permission_denied=FakePerm, not_found=FakeNotFound,
                            rate_limit=FakeRateLimit, internal_server=FakeInternal, api_timeout=FakeTimeout,
                            api_connection=FakeConnection, api_status=FakeStatus)


class FakeResponses:
    def __init__(self, result=None, raise_exc=None, before_return=None):
        self.kwargs = []
        self._result, self._raise, self._before = result, raise_exc, before_return

    def create(self, **kwargs):
        self.kwargs.append(kwargs)
        if self._before:
            self._before()
        if self._raise is not None:
            raise self._raise
        return self._result


class FakeClient:
    def __init__(self, responses):
        self.responses = responses
        self.closed = 0

    def close(self):
        self.closed += 1


def ok_response(text="hello", model="reported-model-x", status="completed", usage=True):
    return SimpleNamespace(status=status, output_text=text, model=model,
                           usage=SimpleNamespace(input_tokens=3, output_tokens=2, total_tokens=5) if usage else None)


def call(deadline_in=5.0, max_tokens=64, prompt="hi"):
    return ModelCall(model_id=MODEL, prompt=prompt, max_output_tokens=max_tokens,
                     deadline=time.monotonic() + deadline_in)


class FakeSdkProvider(unittest.TestCase):
    """Builds the adapter with a fake client. validate_client is patched (it needs the real SDK to inspect)."""

    def setUp(self):
        patcher = mock.patch.object(op, "validate_client", side_effect=lambda client, key: None)
        self.validate = patcher.start()
        self.addCleanup(patcher.stop)
        self.timeouts = []

    def build(self, responses, client=None):
        self.responses = responses
        client = client or FakeClient(responses)
        self.client = client
        return op.OpenAIProvider(SecretStr(FAKE_KEY), client=client, errors=FAKE_ERRORS,
                                 timeout_factory=lambda remaining: self.timeouts.append(remaining) or ("t", remaining))

    def expect(self, responses, kind, retry=None, deadline_in=5.0):
        provider = self.build(responses)
        with self.assertRaises(ProviderError) as caught:
            provider.generate(call(deadline_in=deadline_in))
        self.assertEqual(caught.exception.kind, kind)
        if retry is not None:
            self.assertEqual(caught.exception.retryable, retry)
        return caught.exception


class RequestContract(FakeSdkProvider):
    def test_request_arguments_are_model_input_max_tokens_store_false_and_timeout(self):
        provider = self.build(FakeResponses(result=ok_response()))
        provider.generate(call(max_tokens=77, prompt="ping"))
        kwargs = self.responses.kwargs[0]
        self.assertEqual(kwargs["model"], MODEL)
        self.assertEqual(kwargs["input"], "ping")
        self.assertEqual(kwargs["max_output_tokens"], 77)
        self.assertIs(kwargs["store"], False)
        self.assertEqual(len(self.timeouts), 1)
        self.assertLessEqual(self.timeouts[0], 5.0)
        self.assertGreater(self.timeouts[0], 0)

    def test_expired_deadline_fails_before_the_client_is_touched(self):
        responses = FakeResponses(result=ok_response())
        provider = self.build(responses)
        c = ModelCall(model_id=MODEL, prompt="hi", max_output_tokens=8, deadline=time.monotonic() - 1)
        with self.assertRaises(ProviderError) as caught:
            provider.generate(c)
        self.assertEqual(caught.exception.kind, FailureKind.DEADLINE_EXPIRED)
        self.assertEqual(responses.kwargs, [])

    def test_missing_deadline_is_refused(self):
        provider = self.build(FakeResponses(result=ok_response()))
        with self.assertRaises(ProviderError) as caught:
            provider.generate(ModelCall(model_id=MODEL, prompt="hi", max_output_tokens=8, deadline=None))
        self.assertEqual(caught.exception.kind, FailureKind.DEADLINE_MISSING)

    def test_client_changed_after_construction_is_refused_before_send(self):
        responses = FakeResponses(result=ok_response())
        provider = self.build(responses)
        self.validate.side_effect = ConfigError("changed")
        with self.assertRaises(ProviderError) as caught:
            provider.generate(call())
        self.assertEqual(caught.exception.kind, FailureKind.CLIENT_CHANGED)
        self.assertEqual(responses.kwargs, [])

    def test_validation_runs_at_construction_and_before_every_request(self):
        provider = self.build(FakeResponses(result=ok_response()))
        provider.generate(call())
        provider.generate(call())
        self.assertEqual(self.validate.call_count, 3)  # construction + two requests

    def test_one_send_per_generate_call_with_no_adapter_retry(self):
        responses = FakeResponses(raise_exc=FakeInternal("x"))
        provider = self.build(responses)
        with self.assertRaises(ProviderError):
            provider.generate(call())
        self.assertEqual(len(responses.kwargs), 1)


class ResponseMapping(FakeSdkProvider):
    def test_completed_response_yields_text_model_identity_and_usage(self):
        provider = self.build(FakeResponses(result=ok_response(text="answer", model="served-x")))
        result = provider.generate(call())
        self.assertEqual(result.text, "answer")
        self.assertEqual(result.reported_model_id, "served-x")  # not rewritten to the requested id
        self.assertEqual((result.usage.input_tokens, result.usage.output_tokens, result.usage.total_tokens), (3, 2, 5))

    def test_non_string_text_and_model_become_empty_for_the_gateway_to_reject(self):
        provider = self.build(FakeResponses(result=ok_response(text=None, model=7)))
        result = provider.generate(call())
        self.assertEqual(result.text, "")
        self.assertEqual(result.reported_model_id, "")

    def test_incomplete_status_is_never_a_success(self):
        self.expect(FakeResponses(result=ok_response(status="incomplete")), FailureKind.INCOMPLETE_RESPONSE, retry=False)

    def test_unknown_or_missing_status_is_never_a_success(self):
        for status in ("in_progress", "failed", None):
            with self.subTest(status=status):
                self.expect(FakeResponses(result=ok_response(status=status)), FailureKind.INCOMPLETE_RESPONSE)


class ErrorClassification(FakeSdkProvider):
    def test_transport_errors_are_classified_as_timeout_and_connection(self):
        self.expect(FakeResponses(raise_exc=FakeTimeout("t")), FailureKind.CALL_TIMEOUT, retry=True)
        self.expect(FakeResponses(raise_exc=FakeConnection("c")), FailureKind.CONNECTION, retry=True)

    def test_credential_permission_and_model_errors_are_not_retryable(self):
        self.expect(FakeResponses(raise_exc=FakeAuth("a")), FailureKind.AUTHENTICATION, retry=False)
        self.expect(FakeResponses(raise_exc=FakePerm("p")), FailureKind.PERMISSION, retry=False)
        self.expect(FakeResponses(raise_exc=FakeNotFound("n")), FailureKind.MODEL_NOT_FOUND, retry=False)

    def test_rate_limit_is_transient_only_for_the_documented_code(self):
        self.expect(FakeResponses(raise_exc=FakeRateLimit(body={"error": {"code": "slow_down"}})),
                    FailureKind.RATE_LIMIT, retry=True)
        err = self.expect(FakeResponses(raise_exc=FakeRateLimit(body={"error": {"code": "insufficient_quota"}})),
                          FailureKind.LIMIT_REACHED, retry=False)
        self.assertEqual(err.failure_reason, "quota")
        self.expect(FakeResponses(raise_exc=FakeRateLimit(body=None)), FailureKind.LIMIT_REACHED, retry=False)

    def test_reported_unknown_429_body_is_a_non_retryable_limit_sent_once(self):
        # Exact body from the SDK-enabled run: {"error":{"message":"slow"}}. Fake-SDK: the exception is a stand-in.
        responses = FakeResponses(raise_exc=FakeRateLimit(body={"error": {"message": "slow"}}))
        err = self.expect(responses, FailureKind.LIMIT_REACHED, retry=False)
        self.assertEqual(err.failure_reason, "unknown")
        self.assertNotIsInstance(err, RateLimitedError)
        self.assertEqual(len(responses.kwargs), 1)

    def test_confirmed_slow_down_429_is_a_retryable_rate_limit_sent_once(self):
        responses = FakeResponses(raise_exc=FakeRateLimit(body={"error": {"code": "slow_down", "message": "slow"}}))
        err = self.expect(responses, FailureKind.RATE_LIMIT, retry=True)
        self.assertEqual(len(responses.kwargs), 1)
        self.assertEqual(str(err), "provider rate limited")

    def test_server_and_status_errors(self):
        self.expect(FakeResponses(raise_exc=FakeInternal("i")), FailureKind.SERVER_ERROR, retry=True)
        self.expect(FakeResponses(raise_exc=FakeStatus(503)), FailureKind.SERVER_ERROR, retry=True)
        self.expect(FakeResponses(raise_exc=FakeStatus(418)), FailureKind.CALL_FAILED, retry=False)
        # OPENAI_402 is an empty allowlist, so no 402 is treated as billing (documented in the adapter).
        err = self.expect(FakeResponses(raise_exc=FakeStatus(402)), FailureKind.PAYMENT_REQUIRED, retry=False)
        self.assertEqual(err.failure_reason, "unknown")

    def test_sdk_error_text_never_reaches_the_caller(self):
        exc = FakeAuth(f"bad key {FAKE_KEY}")
        err = self.expect(FakeResponses(raise_exc=exc), FailureKind.AUTHENTICATION, retry=False)
        self.assertNotIn(FAKE_KEY, str(err))
        self.assertNotIn(FAKE_KEY, repr(err))

    def test_failure_at_or_after_the_deadline_is_a_deadline_failure(self):
        c = call(deadline_in=0.05)
        provider = self.build(FakeResponses(raise_exc=FakeTimeout("late"), before_return=lambda: time.sleep(0.1)))
        with self.assertRaises(ProviderError) as caught:
            provider.generate(c)
        self.assertEqual(caught.exception.kind, FailureKind.DEADLINE_IN_CALL)

    def test_response_arriving_after_the_deadline_is_refused(self):
        c = call(deadline_in=0.05)
        provider = self.build(FakeResponses(result=ok_response(), before_return=lambda: time.sleep(0.1)))
        with self.assertRaises(ProviderError) as caught:
            provider.generate(c)
        self.assertEqual(caught.exception.kind, FailureKind.DEADLINE_LATE)


class CloseAndHeaders(FakeSdkProvider):
    def test_close_releases_the_client_once_and_tolerates_a_client_without_close(self):
        provider = self.build(FakeResponses(result=ok_response()))
        provider.close()
        self.assertEqual(self.client.closed, 1)
        no_close = SimpleNamespace(responses=FakeResponses(result=ok_response()))
        provider = op.OpenAIProvider(SecretStr(FAKE_KEY), client=no_close, errors=FAKE_ERRORS,
                                     timeout_factory=lambda r: r)
        provider.close()  # must not raise

    def test_header_policy_flags_overrides_and_custom_headers_and_allows_sdk_defaults(self):
        self.assertIsNotNone(op._header_problem("Authorization", "Bearer x"))
        self.assertIsNotNone(op._header_problem("openai-organization", "org-1"))
        self.assertIsNone(op._header_problem("openai-organization", None))  # SDK's unset sentinel is allowed
        self.assertIsNotNone(op._header_problem("x-custom", "1"))
        self.assertIsNone(op._header_problem("content-type", "application/json"))


if __name__ == "__main__":
    unittest.main()
