"""Stage 10.49-R8-R1: bounded-read compatibility. Pure stdlib, no SDK, no network, no pydantic.

Evidence: on Python 3.11.2, urllib.error.HTTPError(..., fp=None) stores an io.StringIO as its body. The old
_read_bounded called read1(), which StringIO does not have, so a 429 with no body crashed the transport with
AttributeError. These tests cover that stream shape and keep every bound in place.
"""

import io
import time
import unittest
import urllib.error
from unittest import mock

from sanour_ai.providers import common


class InfiniteStream:
    """A stream that never ends. Records each requested size, so an unbounded read is visible."""

    def __init__(self, unit=b"x", use_str=False):
        self.unit = unit
        self.use_str = use_str
        self.requests = []

    def _piece(self, n):
        self.requests.append(n)
        n = 1_000_000 if n is None or n < 0 else n  # an unbounded read() would return a huge piece
        data = self.unit * n
        return data.decode() if self.use_str else data

    def read1(self, n):
        return self._piece(n)

    def read(self, n=-1):
        return self._piece(n)


class SlowStream:
    """Text-only stream (no read1) that takes longer than the deadline on each read."""

    def read(self, n=-1):
        time.sleep(0.2)
        return "y" * min(n, 8)


class MissingBodyCompatibility(unittest.TestCase):
    def test_empty_error_body_from_python_is_read_as_empty_bytes(self):
        err = urllib.error.HTTPError("https://example.invalid/x", 429, "x", {}, None)
        opener = mock.Mock()
        opener.open.side_effect = err
        with mock.patch.object(common, "OPENER", opener):
            status, raw = common.default_transport("https://example.invalid/x", {}, b"{}", 1.0)
        self.assertEqual((status, raw), (429, b""))

    def test_text_stream_without_read1_is_read_as_bytes(self):
        self.assertEqual(common._read_bounded(io.StringIO('{"error":{"message":"slow"}}'), 1000,
                                              common._now() + 5, None), b'{"error":{"message":"slow"}}')

    def test_text_error_body_is_bounded_to_the_error_limit(self):
        stream = InfiniteStream(use_str=True)
        body = common._read_bounded(stream, common.MAX_ERROR_BODY_BYTES + 1, common._now() + 5, None)
        self.assertEqual(len(body), common.MAX_ERROR_BODY_BYTES + 1)
        self.assertTrue(all(n <= common.READ_CHUNK_BYTES for n in stream.requests))

    def test_stream_without_read1_is_never_asked_for_an_unbounded_read(self):
        class OnlyRead(InfiniteStream):
            read1 = None  # force the fallback path

        stream = OnlyRead(use_str=True)
        body = common._read_bounded(stream, 100, common._now() + 5, None)
        self.assertEqual(len(body), 100)
        self.assertTrue(stream.requests)
        self.assertTrue(all(0 < n <= 100 for n in stream.requests))

    def test_stream_returning_more_than_requested_is_still_bounded(self):
        class Greedy:
            def read(self, n=-1):
                return b"z" * 1_000_000  # ignores the requested size

        body = common._read_bounded(Greedy(), 100, common._now() + 5, None)
        self.assertLessEqual(len(body), 100)

    def test_success_body_over_the_size_bound_is_detectable_by_length(self):
        limit = common.MAX_RESPONSE_BYTES + 1
        body = common._read_bounded(InfiniteStream(use_str=True), limit, common._now() + 5, None)
        self.assertEqual(len(body), limit)  # the caller refuses anything longer than MAX_RESPONSE_BYTES

    def test_deadline_is_still_enforced_for_streams_without_read1(self):
        with self.assertRaises(common.DeadlineExpired):
            common._read_bounded(SlowStream(), 1000, common._now() + 0.05, None)

    def test_read1_path_is_unchanged_and_still_preferred(self):
        stream = InfiniteStream()
        body = common._read_bounded(stream, 20000, common._now() + 5, None)
        self.assertEqual(len(body), 20000)
        self.assertTrue(all(n <= common.READ_CHUNK_BYTES for n in stream.requests))

    def test_incomplete_declared_length_is_still_refused_on_the_text_path(self):
        with self.assertRaises(common.IncompleteResponseError):
            common._read_bounded(io.StringIO("short"), 1000, common._now() + 5, 100)


if __name__ == "__main__":
    unittest.main()
