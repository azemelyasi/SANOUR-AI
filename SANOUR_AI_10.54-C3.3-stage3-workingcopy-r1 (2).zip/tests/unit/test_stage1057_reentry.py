"""Stage 10.57 Stage 3: thread-local held-path set, same-thread nested refusal, cleanup after failures, realpath
canonicalization. Refusals and injected faults never block, so these run in-process. Same-thread refusal that would
self-deadlock without the check is also run in a child process, which is always killed and reaped in `finally`."""

import fcntl
import os
import pathlib
import subprocess
import sys
import tempfile
import textwrap
import threading
import unittest
from unittest import mock

from sanour_ai.persistence import first_open_lock as L
from sanour_ai.persistence.first_open_lock import LockUnavailable, exclusive_open_lock

ROOT = pathlib.Path(__file__).resolve().parents[2]
ENV = {**os.environ, "PYTHONPATH": f"{ROOT / 'src'}{os.pathsep}{ROOT}", "PYTHONDONTWRITEBYTECODE": "1"}


def open_fds():
    return len(os.listdir("/proc/self/fd"))


def run_child(code, *args, timeout=20):
    """Run a child process and always kill and reap it, even if the parent test fails."""
    p = subprocess.Popen([sys.executable, "-W", "ignore", "-c", code, *args], env=ENV,
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    try:
        out, err = p.communicate(timeout=timeout)
        return p.returncode, out, err
    finally:
        if p.poll() is None:
            p.kill()
        p.wait()


def lock_is_free(path):
    """Non-blocking probe of the canonical parent directory. Never blocks: a leaked lock fails here, not in a hang."""
    fd = os.open(os.path.dirname(os.path.realpath(path)), os.O_RDONLY)
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return False
        fcntl.flock(fd, fcntl.LOCK_UN)
        return True
    finally:
        os.close(fd)


class _ProxyOs:
    """Test-only stand-in for the os module inside storage_lock: lets a test fail os.close for one call."""

    def __init__(self, fail_close_with=None):
        self._fail = fail_close_with

    def __getattr__(self, name):
        return getattr(os, name)

    def close(self, fd):
        if self._fail is not None:
            exc, self._fail = self._fail, None
            os.close(fd)                  # the descriptor is really closed; the reported failure is injected
            raise exc
        return os.close(fd)


class SameThreadRefusal(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory()
        self.d = self._td.name

    def tearDown(self):
        self._td.cleanup()

    def test_same_path_nested_refused_in_same_thread_child(self):
        # Without the check this nested flock would block forever on the same thread: the child guards that.
        code = textwrap.dedent("""
            import os, sys
            from sanour_ai.storage_lock import LockUnavailable, exclusive_open_lock
            p = sys.argv[1]
            with exclusive_open_lock(p):
                try:
                    with exclusive_open_lock(p):
                        print("entered")
                except LockUnavailable:
                    print("refused")
        """)
        rc, out, err = run_child(code, os.path.join(self.d, "a.db"))
        self.assertEqual((rc, out.strip()), (0, "refused"), err[-300:])

    def test_different_path_nested_refused_in_same_thread_child(self):
        code = textwrap.dedent("""
            import sys
            from sanour_ai.storage_lock import LockUnavailable, exclusive_open_lock
            a, b = sys.argv[1], sys.argv[2]
            with exclusive_open_lock(a):
                try:
                    with exclusive_open_lock(b):
                        print("entered")
                except LockUnavailable:
                    print("refused")
        """)
        rc, out, err = run_child(code, os.path.join(self.d, "a.db"), os.path.join(self.d, "b.db"))
        self.assertEqual((rc, out.strip()), (0, "refused"), err[-300:])

    def test_nested_refusal_does_not_disturb_outer_lock_child(self):
        # Child process: a broken check would block this thread on its own flock, so the child is always killed.
        code = textwrap.dedent("""
            import os, sys
            from sanour_ai import storage_lock as L
            from sanour_ai.storage_lock import LockUnavailable, exclusive_open_lock
            a, b = sys.argv[1], sys.argv[2]
            with exclusive_open_lock(a):
                try:
                    with exclusive_open_lock(b):
                        print("entered")
                except LockUnavailable:
                    print("refused")
                print("held" if os.path.realpath(a) in L._thread_held_paths() else "not-held", flush=True)
            print("released" if not L._thread_held_paths() else "still-held", flush=True)
        """)
        rc, out, err = run_child(code, os.path.join(self.d, "a.db"), os.path.join(self.d, "b.db"))
        self.assertEqual((rc, out.split()), (0, ["refused", "held", "released"]), err[-300:])

    def test_memory_path_is_not_registered(self):
        with exclusive_open_lock(":memory:"):
            self.assertEqual(L._thread_held_paths(), set())

    def test_held_set_is_per_thread(self):
        path_a = os.path.join(self.d, "a.db")
        os.mkdir(os.path.join(self.d, "other"))
        path_b = os.path.join(self.d, "other", "b.db")   # other directory: the lock target is the directory
        seen = {}
        with exclusive_open_lock(path_a):
            def other():
                seen["held"] = set(L._thread_held_paths())
                with exclusive_open_lock(path_b):      # another thread may hold its own path: no contention here
                    seen["inner"] = True
            t = threading.Thread(target=other)
            t.start()
            t.join(timeout=30)
            self.assertFalse(t.is_alive())
        self.assertEqual(seen, {"held": set(), "inner": True})


class RegistrationAndCleanup(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory()
        self.d = self._td.name
        self.path = os.path.join(self.d, "x.db")

    def tearDown(self):
        self._td.cleanup()

    def test_path_is_registered_before_flock_is_called(self):
        observed = {}
        real_flock = fcntl.flock

        def spy(fd, op):
            observed["registered"] = os.path.realpath(self.path) in L._thread_held_paths()
            return real_flock(fd, op)

        with mock.patch.object(L.fcntl, "flock", spy):
            with exclusive_open_lock(self.path):
                pass
        self.assertEqual(observed, {"registered": True})

    def test_oserror_from_flock_closes_fd_clears_path_and_chains_cause(self):
        before = open_fds()
        with mock.patch.object(L.fcntl, "flock", side_effect=OSError(5, "injected")):
            with self.assertRaises(LockUnavailable) as cm:
                with exclusive_open_lock(self.path):
                    pass
        self.assertIsInstance(cm.exception.__cause__, OSError)
        self.assertEqual(L._thread_held_paths(), set())
        self.assertEqual(open_fds(), before)
        with exclusive_open_lock(self.path):           # the same thread can take the lock again
            pass

    def test_keyboard_interrupt_in_flock_propagates_and_cleans_up(self):
        before = open_fds()
        with mock.patch.object(L.fcntl, "flock", side_effect=KeyboardInterrupt):
            with self.assertRaises(KeyboardInterrupt):
                with exclusive_open_lock(self.path):
                    pass
        self.assertEqual(L._thread_held_paths(), set())
        self.assertEqual(open_fds(), before)
        self.assertTrue(lock_is_free(self.path))      # no leaked lock before re-acquiring
        with exclusive_open_lock(self.path):
            pass

    def test_oserror_from_os_open_refuses_without_registration(self):
        with mock.patch.object(L.os, "open", side_effect=OSError(13, "injected")):
            with self.assertRaises(LockUnavailable) as cm:
                with exclusive_open_lock(self.path):
                    pass
        self.assertIsInstance(cm.exception.__cause__, OSError)
        self.assertEqual(L._thread_held_paths(), set())

    def test_close_failure_without_body_exception_fails_closed_and_clears_path(self):
        with mock.patch.object(L, "os", _ProxyOs(fail_close_with=OSError(5, "injected close"))):
            with self.assertRaises(LockUnavailable) as cm:
                with exclusive_open_lock(self.path):
                    pass
        self.assertIsInstance(cm.exception.__cause__, OSError)
        self.assertEqual(L._thread_held_paths(), set())

    def test_close_failure_with_body_exception_keeps_original_and_adds_note(self):
        with mock.patch.object(L, "os", _ProxyOs(fail_close_with=OSError(5, "injected close"))):
            with self.assertRaises(ValueError) as cm:
                with exclusive_open_lock(self.path):
                    raise ValueError("body failure")
        self.assertEqual(str(cm.exception), "body failure")
        self.assertTrue(any("close also failed" in n for n in cm.exception.__notes__))
        self.assertEqual(L._thread_held_paths(), set())

    def test_body_exception_releases_and_is_not_rewritten(self):
        with self.assertRaises(ValueError) as cm:
            with exclusive_open_lock(self.path):
                raise ValueError("body")
        self.assertEqual(str(cm.exception), "body")
        self.assertEqual(L._thread_held_paths(), set())
        self.assertTrue(lock_is_free(self.path))      # no leaked lock before re-acquiring
        with exclusive_open_lock(self.path):
            pass


class Canonicalization(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory()
        self.d = self._td.name

    def tearDown(self):
        self._td.cleanup()

    def test_symlink_alias_is_refused_as_nested_in_same_thread_child(self):
        # Child process: a broken check would block this thread on its own flock, so the child is always killed.
        target = os.path.join(self.d, "target.db")
        link = os.path.join(self.d, "link.db")
        open(target, "w").close()
        os.symlink(target, link)
        code = textwrap.dedent("""
            import os, sys
            from sanour_ai import storage_lock as L
            from sanour_ai.storage_lock import LockUnavailable, exclusive_open_lock
            target, link = sys.argv[1], sys.argv[2]
            with exclusive_open_lock(target):
                print("held" if L._thread_held_paths() == {os.path.realpath(target)} else "not-held", flush=True)
                try:
                    with exclusive_open_lock(link):
                        print("entered")
                except LockUnavailable:
                    print("refused")
        """)
        rc, out, err = run_child(code, target, link)
        self.assertEqual((rc, out.split()), (0, ["held", "refused"]), err[-300:])

    def test_lock_target_is_canonical_parent_directory_and_no_file_is_created(self):
        target = os.path.join(self.d, "target.db")
        link = os.path.join(self.d, "link.db")
        open(target, "w").close()
        os.symlink(target, link)
        observed = {}
        real_open = os.open

        def spy(p, flags, mode=0o777, *a, **k):
            observed["path"] = p
            observed["flags"] = flags
            return real_open(p, flags, mode, *a, **k)

        before = sorted(os.listdir(self.d))
        with mock.patch.object(L.os, "open", side_effect=spy):
            with exclusive_open_lock(link):
                pass
        self.assertEqual(observed["path"], self.d)            # canonical parent directory, not a sidecar file
        self.assertEqual(observed["flags"], os.O_RDONLY)      # no O_CREAT: nothing is created
        self.assertEqual(sorted(os.listdir(self.d)), before)  # no lock file left behind


if __name__ == "__main__":
    unittest.main()
