"""Stage 2 (restricted scope) fixture-only tests: owner backup production, manifest validation, inspection,
free-space, sidecars, interruption, failed conversion, busy source, CLI exit codes. Temp dirs only.
Identity values are TEST-ONLY placeholders (U1 deferred)."""

import datetime as dt
import hashlib
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

from sanour_ai.storage import legacy_inventory as L
from sanour_ai.storage import owner_backup as OB
from sanour_ai.storage.identity import SubsystemId

InputError = L.InputError


def read_bytes(path):
    with open(path, "rb") as fh:
        return fh.read()


def read_json(path):
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def write_json(path, obj):
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(obj, fh)

REPO = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
TEST_IDS = {SubsystemId.LEDGER: 0x7E000001, SubsystemId.USAGE: 0x7E000002,
            SubsystemId.GOVERNANCE: 0x7E000003, SubsystemId.SINK: 0x7E000004}
UTC = dt.timezone.utc
NOW = dt.datetime(2026, 11, 9, 12, 0, tzinfo=UTC)


def dir_manifest(d):
    out = {}
    for n in sorted(os.listdir(d)):
        p = os.path.join(d, n)
        st = os.lstat(p)
        if os.path.isdir(p):
            out[n] = ("<dir>", st.st_mtime_ns)
            continue
        out[n] = (hashlib.sha256(read_bytes(p)).hexdigest(), st.st_size, st.st_mtime_ns, st.st_ino)
    st = os.stat(d)
    out["<dir>"] = (st.st_mtime_ns, st.st_ctime_ns)
    return out


def make_rollback_db(path, tables=("usage_records",), app_id=0, user_version=1, rows=5):
    conn = sqlite3.connect(path)
    try:
        for t in tables:
            conn.execute(f"CREATE TABLE {t} (x INTEGER)")
            for i in range(rows):
                conn.execute(f"INSERT INTO {t} VALUES (?)", (i,))
        conn.execute(f"PRAGMA application_id={int(app_id)}")
        conn.execute(f"PRAGMA user_version={int(user_version)}")
        conn.commit()
    finally:
        conn.close()
    return path


class _TempCase(unittest.TestCase):
    def setUp(self):
        self.root = tempfile.mkdtemp(prefix="s1056_")
        self.live = os.path.join(self.root, "live")
        self.stage = os.path.join(self.root, "staging")
        self.rep = os.path.join(self.root, "reports")
        for d in (self.live, self.stage, self.rep):
            os.makedirs(d)

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def make_wal_live(self, name="u.db", app_id=0, user_version=1):
        path = os.path.join(self.live, name)
        c = sqlite3.connect(path, isolation_level=None)
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA wal_autocheckpoint=0")
        c.execute("CREATE TABLE usage_records (x INTEGER)")
        for i in range(40):
            c.execute("INSERT INTO usage_records VALUES (?)", (i,))
        c.execute(f"PRAGMA application_id={int(app_id)}")
        c.execute(f"PRAGMA user_version={int(user_version)}")
        return path, c            # keep connection open: WAL content is uncheckpointed

    def finalized_fixture(self, subsystem="usage", tables=("usage_records",), app_id=0, user_version=1,
                          name=None, rows=5):
        """Owner-style finalized backup built from a rollback fixture via the real manifest builder."""
        src = make_rollback_db(os.path.join(self.root, f"src_{subsystem}_{len(os.listdir(self.root))}.db"),
                               tables=tables, app_id=app_id, user_version=user_version, rows=rows)
        final = os.path.join(self.stage, name or f"{subsystem}-fixture-{len(os.listdir(self.stage))}.sqlite")
        shutil.copyfile(src, final)
        m = OB._build_manifest(final, subsystem, NOW, NOW + dt.timedelta(seconds=2), "src.db",
                              {"application_id": app_id, "user_version": user_version, "page_size":
                               _ps(final), "page_count": _pc(final), "tables": sorted(tables)})
        with open(L.manifest_path_for(final), "w") as fh:
            json.dump(m, fh)
        return final


def _ps(path):
    c = sqlite3.connect(path)
    v = c.execute("PRAGMA page_size").fetchone()[0]
    c.close()
    return v


def _pc(path):
    c = sqlite3.connect(path)
    v = c.execute("PRAGMA page_count").fetchone()[0]
    c.close()
    return v


class ProduceOwnerBackup(_TempCase):
    def setUp(self):
        super().setUp()
        patcher = mock.patch.object(OB, "_utc_now", return_value=NOW)
        patcher.start()
        self.addCleanup(patcher.stop)

    def test_happy_path_produces_rollback_backup_with_manifest_and_no_sidecars(self):
        live, conn = self.make_wal_live()
        try:
            self.assertTrue(os.path.exists(live + "-wal"))
            m = OB.create_owner_backup(live, self.stage, "usage")
        finally:
            conn.close()
        names = sorted(os.listdir(self.stage))
        finals = [n for n in names if n.endswith(".sqlite")]
        self.assertEqual(len(finals), 1)
        final = os.path.join(self.stage, finals[0])
        self.assertEqual(names, sorted([finals[0], finals[0][:-7] + ".manifest.json"]))
        self.assertEqual(read_bytes(final)[18:20], b"\x01\x01")
        self.assertEqual(m["sha256"], hashlib.sha256(read_bytes(final)).hexdigest())
        self.assertEqual(m["journal_mode"], "delete")
        self.assertEqual(m["integrity_check"], "ok")
        self.assertEqual(m["table_names"], ["usage_records"])
        r = sqlite3.connect("file:%s?mode=ro" % final, uri=True)
        self.assertEqual(r.execute("select count(*) from usage_records").fetchone()[0], 40)   # WAL content kept
        r.close()

    def test_source_database_bytes_unchanged_by_owner_procedure(self):
        live = make_rollback_db(os.path.join(self.live, "r.db"), rows=7)
        before = hashlib.sha256(read_bytes(live)).hexdigest()
        OB.create_owner_backup(live, self.stage, "usage")
        self.assertEqual(before, hashlib.sha256(read_bytes(live)).hexdigest())

    def test_staging_inside_live_directory_refused_before_anything_is_created(self):
        live = make_rollback_db(os.path.join(self.live, "r.db"))
        inside = os.path.join(self.live, "stage")
        os.makedirs(inside)
        before = dir_manifest(self.live)
        with self.assertRaises(InputError):
            OB.create_owner_backup(live, inside, "usage")
        self.assertEqual(before, dir_manifest(self.live))

    def test_live_inside_staging_refused(self):
        live = make_rollback_db(os.path.join(self.stage, "r.db"))
        with self.assertRaises(InputError):
            OB.create_owner_backup(live, self.stage, "usage")

    def test_unknown_subsystem_refused(self):
        live = make_rollback_db(os.path.join(self.live, "r.db"))
        with self.assertRaises(InputError):
            OB.create_owner_backup(live, self.stage, "bogus")

    def test_insufficient_free_space_refused_before_any_file_is_created(self):
        live = make_rollback_db(os.path.join(self.live, "r.db"), rows=50)
        with mock.patch.object(L, "free_bytes", return_value=10):
            with self.assertRaises(L.InsufficientSpace):
                OB.create_owner_backup(live, self.stage, "usage")
        self.assertEqual(os.listdir(self.stage), [])

    def test_free_space_boundary(self):
        size = 1_000_000
        need = L.required_free_bytes(size)
        self.assertEqual(need, 2 * size + max(L.OVERHEAD_MIN, int(size * 0.10)))
        with mock.patch.object(L, "free_bytes", return_value=need):
            L.require_free_space(self.stage, need)          # equal: allowed
        with mock.patch.object(L, "free_bytes", return_value=need - 1):
            with self.assertRaises(L.InsufficientSpace):
                L.require_free_space(self.stage, need)      # one byte short: refused

    def test_interrupted_after_copy_leaves_no_final_and_no_manifest(self):
        live = make_rollback_db(os.path.join(self.live, "r.db"))
        with mock.patch.object(OB, "_convert_to_rollback", side_effect=RuntimeError("simulated interruption")):
            with self.assertRaises(RuntimeError):
                OB.create_owner_backup(live, self.stage, "usage")
        self.assertEqual(os.listdir(self.stage), [])

    def test_keyboard_interrupt_before_finalize_leaves_nothing(self):
        live = make_rollback_db(os.path.join(self.live, "r.db"))
        with mock.patch.object(OB, "_finalize", side_effect=KeyboardInterrupt()):
            with self.assertRaises(KeyboardInterrupt):
                OB.create_owner_backup(live, self.stage, "usage")
        self.assertEqual(os.listdir(self.stage), [])

    def test_failed_rollback_conversion_refused_and_nothing_finalized(self):
        live = make_rollback_db(os.path.join(self.live, "r.db"))
        with mock.patch.object(OB, "_set_rollback_mode", return_value="wal"):
            with self.assertRaises(OB._RollbackConversionFailed):
                OB.create_owner_backup(live, self.stage, "usage")
        self.assertEqual(os.listdir(self.stage), [])

    def test_sidecar_appearing_on_copy_refused(self):
        live = make_rollback_db(os.path.join(self.live, "r.db"))
        real = OB._assert_no_sidecars

        def add_wal_then_check(partial):
            open(partial + "-wal", "wb").close()
            return real(partial)
        with mock.patch.object(OB, "_assert_no_sidecars", side_effect=add_wal_then_check):
            with self.assertRaises(OB._SidecarPresent):
                OB.create_owner_backup(live, self.stage, "usage")
        self.assertEqual(os.listdir(self.stage), [])

    def test_failure_between_rename_and_manifest_removes_the_final_file(self):
        live = make_rollback_db(os.path.join(self.live, "r.db"))
        with mock.patch.object(OB, "_write_manifest", side_effect=RuntimeError("manifest write failed")):
            with self.assertRaises(RuntimeError):
                OB.create_owner_backup(live, self.stage, "usage")
        self.assertEqual(os.listdir(self.stage), [])

    def test_manifest_build_failure_leaves_nothing(self):
        live = make_rollback_db(os.path.join(self.live, "r.db"))
        with mock.patch.object(OB, "_build_manifest", side_effect=RuntimeError("manifest build failed")):
            with self.assertRaises(RuntimeError):
                OB.create_owner_backup(live, self.stage, "usage")
        self.assertEqual(os.listdir(self.stage), [])

    def test_corrupted_copy_fails_validation_and_is_removed(self):
        live = make_rollback_db(os.path.join(self.live, "r.db"), rows=3000)
        real = OB._validate_final_bytes

        def corrupt_then_validate(partial):
            with open(partial, "r+b") as fh:
                fh.seek(4096)              # start of page 2: b-tree page header
                fh.write(b"\xff" * 64)
            return real(partial)
        with mock.patch.object(OB, "_validate_final_bytes", side_effect=corrupt_then_validate):
            with self.assertRaises((OB._ValidationFailed, OB._RollbackConversionFailed, sqlite3.DatabaseError)):
                OB.create_owner_backup(live, self.stage, "usage")
        self.assertEqual(os.listdir(self.stage), [])

    def test_public_surface_is_minimal(self):
        public = sorted(n for n in dir(OB) if not n.startswith("_") and n not in ("annotations",)
                        and getattr(getattr(OB, n), "__module__", None) == OB.__name__)
        self.assertEqual(public, ["OwnerBackupError", "create_owner_backup"])
        import inspect
        self.assertEqual(list(inspect.signature(OB.create_owner_backup).parameters),
                         ["source_path", "staging_dir", "subsystem"])


class InspectBackup(_TempCase):
    def inspect(self, path, **kw):
        kw.setdefault("expected", SubsystemId.USAGE)
        kw.setdefault("identities", TEST_IDS)
        return L.inspect_backup(path, **kw)

    def test_valid_owned_backup_is_clean_and_directory_unchanged(self):
        f = self.finalized_fixture(app_id=TEST_IDS[SubsystemId.USAGE], user_version=1)
        before = dir_manifest(self.stage)
        out = self.inspect(f)
        self.assertEqual(out.kind, L.KIND_OK)
        self.assertEqual(out.state, "OWNED")
        self.assertFalse(out.accepted)
        self.assertEqual(out.assurance, "STRICT")
        self.assertEqual(before, dir_manifest(self.stage))

    def test_real_owner_backup_is_inspected_end_to_end(self):
        live, conn = self.make_wal_live()
        try:
            m = OB.create_owner_backup(live, self.stage, "usage")
        finally:
            conn.close()
        final = os.path.join(self.stage, m["backup_file"])
        out = self.inspect(final)
        self.assertEqual(out.kind, L.KIND_OK)
        self.assertEqual(out.owner, "usage")

    def test_missing_manifest_is_unverified(self):
        f = self.finalized_fixture()
        os.remove(L.manifest_path_for(f))
        self.assertEqual(self.inspect(f).reason, L.R_MANIFEST_MISSING)
        self.assertEqual(self.inspect(f).kind, L.KIND_UNVERIFIED)

    def test_invalid_json_manifest_is_unverified(self):
        f = self.finalized_fixture()
        with open(L.manifest_path_for(f), "w") as fh:
            fh.write("{not json")
        self.assertEqual(self.inspect(f).reason, L.R_MANIFEST_INVALID)

    def test_manifest_fields_each_checked(self):
        f = self.finalized_fixture()
        good = read_json(L.manifest_path_for(f))
        cases = {
            "method": ("method", "copy_files"),
            "journal_mode": ("journal_mode", "wal"),
            "header_bytes_18_19": ("header_bytes_18_19", "0202"),
            "integrity_check": ("integrity_check", "bad"),
            "backup_file": ("backup_file", "other.sqlite"),
            "subsystem": ("subsystem", "bogus"),
            "manifest_version": ("manifest_version", 2),
            "sha256_format": ("sha256", "XYZ"),
            "time_order": ("backup_finished_utc", "2000-01-01T00:00:00+00:00"),
            "naive_time": ("backup_started_utc", "2026-11-09T12:00:00"),
        }
        for label, (key, value) in cases.items():
            m = dict(good)
            m[key] = value
            with open(L.manifest_path_for(f), "w") as fh:
                json.dump(m, fh)
            out = self.inspect(f)
            self.assertEqual(out.kind, L.KIND_UNVERIFIED, label)
            self.assertEqual(out.reason, L.R_MANIFEST_INVALID, label)
        with open(L.manifest_path_for(f), "w") as fh:
            json.dump(good, fh)
        self.assertEqual(self.inspect(f).kind, L.KIND_OK)

    def test_manifest_missing_field_is_invalid(self):
        f = self.finalized_fixture()
        m = read_json(L.manifest_path_for(f))
        del m["sha256"]
        write_json(L.manifest_path_for(f), m)
        self.assertEqual(self.inspect(f).reason, L.R_MANIFEST_INVALID)

    def test_altered_backup_bytes_mismatch_manifest(self):
        f = self.finalized_fixture(rows=50)
        with open(f, "r+b") as fh:
            fh.seek(4096 + 10)
            b = fh.read(1)
            fh.seek(4096 + 10)
            fh.write(bytes([b[0] ^ 0x01]))
        out = self.inspect(f)
        self.assertEqual(out.kind, L.KIND_UNVERIFIED)
        self.assertIn(out.reason, (L.R_MANIFEST_MISMATCH, L.R_SNAPSHOT_UNSTABLE))

    def test_manifest_sha_altered_mismatch(self):
        f = self.finalized_fixture()
        m = read_json(L.manifest_path_for(f))
        m["sha256"] = "0" * 64
        write_json(L.manifest_path_for(f), m)
        self.assertEqual(self.inspect(f).reason, L.R_MANIFEST_MISMATCH)

    def test_manifest_size_mismatch(self):
        f = self.finalized_fixture()
        m = read_json(L.manifest_path_for(f))
        m["size_bytes"] += 1
        write_json(L.manifest_path_for(f), m)
        self.assertEqual(self.inspect(f).reason, L.R_MANIFEST_MISMATCH)

    def test_manifest_inconsistent_with_structure(self):
        f = self.finalized_fixture()
        m = read_json(L.manifest_path_for(f))
        m["table_names"] = ["usage_records", "extra"]
        write_json(L.manifest_path_for(f), m)
        self.assertEqual(self.inspect(f).reason, L.R_MANIFEST_INCONSISTENT)

    def test_manifest_claims_other_subsystem_than_structure(self):
        f = self.finalized_fixture(subsystem="usage", app_id=0)
        m = read_json(L.manifest_path_for(f))
        m["subsystem"] = "ledger"
        write_json(L.manifest_path_for(f), m)
        out = self.inspect(f, expected=SubsystemId.USAGE)
        self.assertEqual(out.reason, L.R_MANIFEST_INCONSISTENT)

    def test_wal_mode_input_refused_as_input_error(self):
        f = self.finalized_fixture()
        c = sqlite3.connect(f)
        c.execute("PRAGMA journal_mode=WAL")
        c.close()
        for suffix in ("-wal", "-shm"):
            if os.path.exists(f + suffix):
                os.remove(f + suffix)
        with self.assertRaises(L.InputError):
            self.inspect(f)

    def test_sidecars_refuse_and_journal_is_unverified(self):
        f = self.finalized_fixture()
        for suffix in ("-wal", "-shm"):
            open(f + suffix, "wb").close()
            with self.assertRaises(L.InputError):
                self.inspect(f)
            os.remove(f + suffix)
        open(f + "-journal", "wb").close()
        self.assertEqual(self.inspect(f).reason, L.R_HOT_JOURNAL)

    def test_partial_or_non_sqlite_name_is_input_error(self):
        f = self.finalized_fixture()
        partial = f + ".partial"
        shutil.copyfile(f, partial)
        with self.assertRaises(L.InputError):
            self.inspect(partial)

    def test_missing_input_is_input_error(self):
        with self.assertRaises(L.InputError):
            self.inspect(os.path.join(self.stage, "none.sqlite"))

    def test_size_limit_refuses_before_reading_content(self):
        f = self.finalized_fixture()
        with mock.patch.object(L, "_hash_file", side_effect=AssertionError("must not read")):
            out = self.inspect(f, max_bytes=10)
        self.assertEqual(out.kind, L.KIND_NOT_INSPECTED)
        self.assertEqual(out.reason, L.R_SIZE_LIMIT_EXCEEDED)

    def test_size_limit_default_is_one_gib(self):
        self.assertEqual(L.DEFAULT_MAX_BYTES, 1 << 30)

    def test_symlink_is_not_inspected(self):
        f = self.finalized_fixture()
        link = os.path.join(self.stage, "link.sqlite")
        os.symlink(f, link)
        self.assertEqual(self.inspect(link).reason, L.R_SYMLINK_REFUSED)

    def test_busy_source_is_unverified_with_one_attempt_and_no_retry(self):
        f = self.finalized_fixture()
        holder = sqlite3.connect(f, isolation_level=None)
        holder.execute("BEGIN EXCLUSIVE")
        real_connect = sqlite3.connect
        attempts = []

        def counting(*a, **k):
            attempts.append(1)
            return real_connect(*a, **k)
        try:
            with mock.patch("sanour_ai.storage.legacy_inventory.sqlite3.connect", side_effect=counting):
                out = self.inspect(f)
        finally:
            holder.execute("ROLLBACK")
            holder.close()
        self.assertEqual(out.reason, L.R_SOURCE_BUSY)
        self.assertEqual(len(attempts), 1)

    def test_garbage_with_matching_manifest_is_damaged(self):
        f = os.path.join(self.stage, "junk-garbage.sqlite")
        blob = bytearray(b"not a database" * 300)
        blob[18] = 1
        blob[19] = 1
        with open(f, "wb") as fh:
            fh.write(bytes(blob))
        m = OB._build_manifest(f, "usage", NOW, NOW + dt.timedelta(seconds=1), "x.db",
                              {"application_id": 0, "user_version": 0, "page_size": 512, "page_count": 1,
                               "tables": []})
        write_json(L.manifest_path_for(f), m)
        out = self.inspect(f)
        self.assertEqual((out.kind, out.reason), (L.KIND_REFUSED, L.R_DAMAGED))

    def test_owner_mismatch_is_refused_for_requested_subsystem(self):
        f = self.finalized_fixture(subsystem="usage", tables=("usage_records",), app_id=0)
        out = self.inspect(f, expected=SubsystemId.LEDGER)
        self.assertEqual(out.kind, L.KIND_REFUSED)
        self.assertEqual(out.reason, L.R_REFUSED_FOR_OWNER)

    def test_mixed_structure_is_refused(self):
        f = self.finalized_fixture(subsystem="usage", tables=("usage_records", "ledger_records"))
        out = self.inspect(f)
        self.assertEqual((out.kind, out.state), (L.KIND_REFUSED, "MIXED"))

    def test_unknown_table_is_refused(self):
        f = self.finalized_fixture(subsystem="usage", tables=("usage_records", "mystery"))
        self.assertEqual(self.inspect(f).state, "UNKNOWN")

    def test_foreign_stamped_structure_refused(self):
        f = self.finalized_fixture(subsystem="usage", app_id=TEST_IDS[SubsystemId.USAGE])
        out = self.inspect(f, expected=SubsystemId.LEDGER)
        self.assertEqual(out.kind, L.KIND_REFUSED)

    def test_unstamped_owner_match_is_ok_but_not_accepted(self):
        f = self.finalized_fixture(subsystem="usage", app_id=0)
        out = self.inspect(f)
        self.assertEqual((out.kind, out.state), (L.KIND_OK, "UNSTAMPED_KNOWN"))
        self.assertFalse(out.accepted)

    def test_strict_detects_change_between_reads(self):
        f = self.finalized_fixture(rows=30)

        def flip(path):
            with open(path, "r+b") as fh:
                fh.seek(4096 + 3)
                b = fh.read(1)
                fh.seek(4096 + 3)
                fh.write(bytes([b[0] ^ 0x20]))
        out = self.inspect(f, _between_reads=flip)
        self.assertEqual((out.kind, out.reason), (L.KIND_UNVERIFIED, L.R_SNAPSHOT_UNSTABLE))

    def test_standard_mode_is_labeled_reduced(self):
        f = self.finalized_fixture()
        out = self.inspect(f, strict=False)
        self.assertEqual(out.assurance, "REDUCED")
        self.assertEqual(out.kind, L.KIND_OK)

    def test_identity_config_must_be_complete(self):
        bad = os.path.join(self.root, "ids.json")
        write_json(bad, {"ledger": 1, "usage": 2})
        with self.assertRaises(L.InputError):
            L.load_identity_config(bad)

    def test_report_must_be_outside_input_directory(self):
        f = self.finalized_fixture()
        out = self.inspect(f)
        with self.assertRaises(L.InputError):
            L.write_report(os.path.join(self.stage, "r.json"), f, out)
        L.write_report(os.path.join(self.rep, "r.json"), f, out)
        self.assertEqual(read_json(os.path.join(self.rep, "r.json"))["inspect_only"], True)

    def test_combine_precedence(self):
        combine = L.combine_exit_codes
        self.assertEqual(combine([0, 1, 3, 4]), 1)
        self.assertEqual(combine([0, 3, 4]), 3)
        self.assertEqual(combine([0, 4]), 4)
        self.assertEqual(combine([0]), 0)
        self.assertEqual(combine([2, 1, 3]), 2)


class CliExitCodes(_TempCase):
    def run_cli(self, *args):
        env = {**os.environ, "PYTHONPATH": os.path.join(REPO, "src") + os.pathsep + REPO}
        return subprocess.run([sys.executable, os.path.join(REPO, "tools", "storage_inventory.py"), *args],
                              capture_output=True, text=True, env=env, timeout=120)

    def ids_file(self):
        p = os.path.join(self.root, "ids.json")
        write_json(p, {k.value: v for k, v in TEST_IDS.items()})
        return p

    def test_exit_0_clean(self):
        f = self.finalized_fixture(app_id=TEST_IDS[SubsystemId.USAGE])
        r = self.run_cli(f, "--expected", "usage", "--identities", self.ids_file())
        self.assertEqual(r.returncode, 0, r.stderr)

    def test_exit_1_content_refused(self):
        f = self.finalized_fixture(subsystem="usage")
        r = self.run_cli(f, "--expected", "ledger", "--identities", self.ids_file())
        self.assertEqual(r.returncode, 1, r.stdout + r.stderr)

    def test_exit_2_input_error_missing_identities(self):
        f = self.finalized_fixture()
        r = self.run_cli(f, "--expected", "usage", "--identities", os.path.join(self.root, "nope.json"))
        self.assertEqual(r.returncode, 2)

    def test_exit_2_wal_input(self):
        f = self.finalized_fixture()
        c = sqlite3.connect(f)
        c.execute("PRAGMA journal_mode=WAL")
        c.close()
        for suffix in ("-wal", "-shm"):
            if os.path.exists(f + suffix):
                os.remove(f + suffix)
        r = self.run_cli(f, "--expected", "usage", "--identities", self.ids_file())
        self.assertEqual(r.returncode, 2)

    def test_exit_3_unverified_missing_manifest(self):
        f = self.finalized_fixture()
        os.remove(L.manifest_path_for(f))
        r = self.run_cli(f, "--expected", "usage", "--identities", self.ids_file())
        self.assertEqual(r.returncode, 3)
        self.assertIn("MANIFEST_MISSING", r.stdout)

    def test_exit_4_not_inspected_size_limit(self):
        f = self.finalized_fixture()
        r = self.run_cli(f, "--expected", "usage", "--identities", self.ids_file(), "--max-bytes", "10")
        self.assertEqual(r.returncode, 4)

    def test_standard_flag_reports_reduced(self):
        f = self.finalized_fixture(app_id=TEST_IDS[SubsystemId.USAGE])
        r = self.run_cli(f, "--expected", "usage", "--identities", self.ids_file(), "--assurance", "standard")
        self.assertIn('"assurance": "REDUCED"', r.stdout)

    def test_report_written_outside_input_directory(self):
        f = self.finalized_fixture(app_id=TEST_IDS[SubsystemId.USAGE])
        rep = os.path.join(self.rep, "report.json")
        r = self.run_cli(f, "--expected", "usage", "--identities", self.ids_file(), "--report", rep)
        self.assertEqual(r.returncode, 0)
        self.assertTrue(os.path.exists(rep))
        inside = os.path.join(self.stage, "report.json")
        r2 = self.run_cli(f, "--expected", "usage", "--identities", self.ids_file(), "--report", inside)
        self.assertEqual(r2.returncode, 2)
        self.assertFalse(os.path.exists(inside))


if __name__ == "__main__":
    unittest.main()
