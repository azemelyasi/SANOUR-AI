"""Stage 10.49-R4: the durable audit sink contract and its deduplication. Real child processes for concurrency."""

import json
import pathlib
import os
import sqlite3
import tempfile
import time
import unittest

from sanour_ai.governance.sink import DurableSqliteSink, SinkFailed, SinkOutcomeUnknown, SinkPayloadConflict
from tests.unit.r4_support import spawn_child

SINK_CHILD = r'''
import json, os, sys, time
from sanour_ai.governance.sink import DurableSqliteSink
sinkp, out, go, prefix, n = sys.argv[1:6]
while not os.path.exists(go):
    time.sleep(0.002)
s = DurableSqliteSink(sinkp)
rows = []
for i in range(int(n)):
    r = s.deliver(f"{prefix}{i}", "exposure.resolved", {"request_id": "r", "n": i})
    rows.append([r.outbox_key, r.receipt_id, r.duplicate])
json.dump(rows, open(out, "w"))
'''


class _FailOn:
    def __init__(self, real, prefix):
        self._real, self._prefix = real, prefix

    def execute(self, sql, *args):
        if sql.startswith(self._prefix):
            raise sqlite3.OperationalError("disk I/O error")
        return self._real.execute(sql, *args)

    def close(self):
        self._real.close()


FIELDS = {"request_id": "req-1", "resolution": "write_off", "actor": "ops.alice", "decision": "applied"}


class SinkContract(unittest.TestCase):
    def setUp(self):
        self._dir = tempfile.TemporaryDirectory()
        self.addCleanup(self._dir.cleanup)
        self.path = os.path.join(self._dir.name, "sink.db")
        self.sink = DurableSqliteSink(self.path)
        self.addCleanup(self.sink.close)

    def fail_next(self, prefix):
        real = self.sink._conn  # noqa: SLF001
        self.sink._conn = _FailOn(real, prefix)  # noqa: SLF001
        return real

    def restore(self, real):
        self.sink._conn = real  # noqa: SLF001

    def test_first_delivery_returns_a_new_receipt_after_the_commit(self):
        receipt = self.sink.deliver("gov:1:exposure.resolved", "exposure.resolved", FIELDS)
        self.assertFalse(receipt.duplicate)
        self.assertEqual(self.sink.record_count(), 1)

    def test_duplicate_key_with_the_same_payload_returns_the_original_receipt(self):
        first = self.sink.deliver("gov:1:exposure.resolved", "exposure.resolved", FIELDS)
        again = self.sink.deliver("gov:1:exposure.resolved", "exposure.resolved", dict(FIELDS))
        self.assertTrue(again.duplicate)
        self.assertEqual(again.receipt_id, first.receipt_id)
        self.assertEqual(self.sink.record_count(), 1)

    def test_same_key_with_a_conflicting_payload_fails_closed_and_keeps_the_original(self):
        first = self.sink.deliver("gov:2:exposure.resolved", "exposure.resolved", FIELDS)
        with self.assertRaises(SinkPayloadConflict):
            self.sink.deliver("gov:2:exposure.resolved", "exposure.resolved", dict(FIELDS, actor="ops.bob"))
        self.assertEqual(self.sink.record_count(), 1)
        kept = self.sink.deliver("gov:2:exposure.resolved", "exposure.resolved", FIELDS)
        self.assertEqual(kept.receipt_id, first.receipt_id)
        self.assertTrue(kept.duplicate)

    def test_restart_preserves_deduplication(self):
        first = self.sink.deliver("gov:3:exposure.resolved", "exposure.resolved", FIELDS)
        self.sink.close()
        reopened = DurableSqliteSink(self.path)
        self.addCleanup(reopened.close)
        again = reopened.deliver("gov:3:exposure.resolved", "exposure.resolved", FIELDS)
        self.assertTrue(again.duplicate)
        self.assertEqual(again.receipt_id, first.receipt_id)
        self.assertEqual(reopened.record_count(), 1)

    def test_failure_before_the_commit_is_failed_and_records_nothing(self):
        real = self.fail_next("INSERT INTO audit_receipts")
        with self.assertRaises(SinkFailed):
            self.sink.deliver("gov:4:exposure.resolved", "exposure.resolved", FIELDS)
        self.restore(real)
        self.assertEqual(self.sink.record_count(), 0)

    def test_receipt_and_inbox_rows_are_committed_together_or_not_at_all(self):
        real = self.fail_next("INSERT INTO audit_inbox")  # the receipt row was already written inside the transaction
        with self.assertRaises(SinkFailed):
            self.sink.deliver("gov:5:exposure.resolved", "exposure.resolved", FIELDS)
        self.restore(real)
        self.assertEqual(self.sink.record_count(), 0, "the receipt must roll back with the failed inbox write")
        receipt = self.sink.deliver("gov:5:exposure.resolved", "exposure.resolved", FIELDS)
        self.assertFalse(receipt.duplicate)
        self.assertEqual(self.sink.record_count(), 1)

    def test_begin_failure_is_failed(self):
        real = self.fail_next("BEGIN IMMEDIATE")
        with self.assertRaises(SinkFailed):
            self.sink.deliver("gov:6:exposure.resolved", "exposure.resolved", FIELDS)
        self.restore(real)

    def test_commit_failure_is_outcome_unknown_not_failed(self):
        real = self.fail_next("COMMIT")
        with self.assertRaises(SinkOutcomeUnknown):
            self.sink.deliver("gov:7:exposure.resolved", "exposure.resolved", FIELDS)
        self.restore(real)
        retry = self.sink.deliver("gov:7:exposure.resolved", "exposure.resolved", FIELDS)
        self.assertEqual(self.sink.record_count(), 1, "one logical receipt however many attempts were made")
        self.assertIn(retry.duplicate, (False, True))

    def test_invalid_key_is_refused_before_any_write(self):
        for key in ("", "x" * 97):
            with self.assertRaises(SinkFailed):
                self.sink.deliver(key, "exposure.resolved", FIELDS)
        self.assertEqual(self.sink.record_count(), 0)

    def test_concurrent_processes_delivering_the_same_key_produce_one_receipt(self):
        go = os.path.join(self._dir.name, "go")
        procs, outs = [], []
        for i in range(4):
            out = os.path.join(self._dir.name, f"out{i}.json")
            outs.append(out)
            procs.append(spawn_child(SINK_CHILD, [self.path, out, go, "gov:9:exposure.resolved", "1"]))
        time.sleep(0.2)
        open(go, "w").close()
        for p in procs:
            p.communicate(timeout=60)
            self.assertEqual(p.returncode, 0)
        rows = [row for out in outs for row in json.loads(pathlib.Path(out).read_text(encoding="utf-8"))]
        self.assertEqual(len(rows), 4)
        self.assertEqual(sum(1 for _, _, dup in rows if not dup), 1, "exactly one process records the event")
        self.assertEqual(len({rid for _, rid, _ in rows}), 1, "every process gets the same logical receipt")
        self.assertEqual(self.sink.record_count(), 1)

    def test_concurrent_processes_with_distinct_keys_record_every_event_once(self):
        go = os.path.join(self._dir.name, "go2")
        procs, outs = [], []
        for i in range(3):
            out = os.path.join(self._dir.name, f"dist{i}.json")
            outs.append(out)
            procs.append(spawn_child(SINK_CHILD, [self.path, out, go, f"gov:{100 + i}:", "20"]))
        time.sleep(0.2)
        open(go, "w").close()
        for p in procs:
            p.communicate(timeout=60)
            self.assertEqual(p.returncode, 0)
        rows = [row for out in outs for row in json.loads(pathlib.Path(out).read_text(encoding="utf-8"))]
        self.assertEqual(len(rows), 60)
        self.assertEqual(len({key for key, _, _ in rows}), 60)
        self.assertEqual(len({rid for _, rid, _ in rows}), 60, "every logical event has its own receipt")
        self.assertEqual(sum(1 for _, _, dup in rows if dup), 0)
        self.assertEqual(self.sink.record_count(), 60)


if __name__ == "__main__":
    unittest.main()
