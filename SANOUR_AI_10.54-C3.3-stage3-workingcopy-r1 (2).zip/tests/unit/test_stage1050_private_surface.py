"""Stage 10.50: drift guard for the OpenAI adapter's dependence on private SDK / httpx2 attributes.

SDK-free and stdlib-only. It parses the adapter source with ast and checks that the set of EXTERNAL private names
(attributes of SDK or httpx2 objects, not the adapter's own self._x) and the functions that read them are exactly the
documented inventory. A new private read, a removed check, or a move of a check to another function fails here.

This is a static guard. It does not check that the SDK still has these attributes. That needs the real SDK run.
"""

import ast
import os
import unittest

REPO = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
ADAPTER = os.path.join(REPO, "src", "sanour_ai", "providers", "openai_provider.py")

# Documented inventory (Stage 10.50). name -> the function(s) that read it. Security role in docs/OPENAI_SDK_SURFACE.md.
EXPECTED_SCOPE = {
    "_client": {("validate_client", "getattr")},
    "_custom_headers": {("validate_client", "getattr")},
    "_trust_env": {("validate_client", "getattr")},
    "_mounts": {("validate_client", "getattr")},
    "_transport": {("validate_client", "getattr")},
    "_pool": {("_transport_problems", "getattr")},
    "_proxy_url": {("_transport_problems", "getattr")},
    "_ssl_context": {("_transport_problems", "getattr")},
}


def external_private_scope(source: str) -> dict:
    """name -> set of (enclosing function, access form) for private reads on objects other than the adapter's own self.
    Form is "getattr" (fails closed: a missing attribute becomes None) or "attribute" (raises when missing)."""
    found: dict = {}

    class Visitor(ast.NodeVisitor):
        def __init__(self):
            self.stack = []

        def _function(self, node):
            self.stack.append(node.name)
            self.generic_visit(node)
            self.stack.pop()

        visit_FunctionDef = _function
        visit_AsyncFunctionDef = _function

        def _record(self, name, form):
            found.setdefault(name, set()).add((self.stack[-1] if self.stack else "<module>", form))

        def visit_Call(self, node):
            if (isinstance(node.func, ast.Name) and node.func.id in ("getattr", "setattr", "hasattr")
                    and len(node.args) >= 2 and isinstance(node.args[1], ast.Constant)
                    and isinstance(node.args[1].value, str) and node.args[1].value.startswith("_")
                    and not (isinstance(node.args[0], ast.Name) and node.args[0].id == "self")):
                self._record(node.args[1].value, "getattr")
            self.generic_visit(node)

        def visit_Attribute(self, node):
            base = node.value
            if (node.attr.startswith("_") and not node.attr.startswith("__")
                    and not (isinstance(base, ast.Name) and base.id in ("self", "cls"))):
                self._record(node.attr, "attribute")
            self.generic_visit(node)

    Visitor().visit(ast.parse(source))
    return found


class PrivateSurfaceInventory(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with open(ADAPTER, encoding="utf-8") as handle:
            cls.scope = external_private_scope(handle.read())

    def test_external_private_names_are_exactly_the_documented_inventory(self):
        self.assertEqual(set(self.scope), set(EXPECTED_SCOPE))

    def test_each_private_name_is_read_only_in_its_documented_function(self):
        for name, functions in EXPECTED_SCOPE.items():
            with self.subTest(name=name):
                self.assertEqual(self.scope.get(name), functions)

    def test_the_adapters_own_private_attributes_are_not_counted(self):
        source = "class A:\n    def f(self):\n        return self._client, getattr(self, '_errors', None)\n"
        self.assertEqual(external_private_scope(source), {})

    def test_a_new_external_private_read_is_reported(self):
        source = "def validate_client(client):\n    return getattr(client, '_new_internal', None)\n"
        self.assertEqual(external_private_scope(source), {"_new_internal": {("validate_client", "getattr")}})

    def test_a_direct_external_private_attribute_read_is_reported(self):
        source = "def validate_client(client):\n    return client._sneaky\n"
        self.assertEqual(external_private_scope(source), {"_sneaky": {("validate_client", "attribute")}})

    def test_a_moved_check_changes_its_documented_scope(self):
        source = "def close(x):\n    return x._trust_env\n"
        self.assertEqual(external_private_scope(source)["_trust_env"], {("close", "attribute")})
        self.assertNotEqual(external_private_scope(source)["_trust_env"], EXPECTED_SCOPE["_trust_env"])


if __name__ == "__main__":
    unittest.main()
