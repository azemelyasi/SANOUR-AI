"""Stage 10.54-C2: runtime integration through the backup port, commit hooks, audit, sidecars, crash behavior.
Offline, no keys. Crash tests kill REAL child processes. Tamper tests edit real SQLite files and re-sign manifests
so only the intended check can refuse them."""

import hashlib
import json
import os
import pathlib
import signal
import sqlite3
import subprocess
import sys
import tempfile
import textwrap
import threading
import time
import unittest
from datetime import datetime, timezone
from unittest import mock

from sanour_ai.backup import BackupError, RestoreError, create_backup, restore_backup, sweep_stale_temporaries, verify_backup
from sanour_ai.backup import archive as A
from sanour_ai.integrity import AuditError, AuditTrail, ChainTailHook, IntegrityHookError, LocalBackupPort
from sanour_ai.persistence import Ledger, create_checkpoint, verify_integrity
from sanour_ai.persistence import canonical as C
from sanour_ai.persistence import migrations as M

ROOT = pathlib.Path(__file__).resolve().parents[2]
SRC = ROOT / "src"
T0 = datetime(2026, 1, 1, tzinfo=timezone.utc)
ENV = {**os.environ, "PYTHONPATH": f"{SRC}{os.pathsep}{ROOT}", "PYTHONDONTWRITEBYTECODE": "1"}
CLOCK = lambda: "2026-01-01T00:00:00+00:00"


def hooked(path, **kw):
    return Ledger(path, clock=lambda: T0, commit_hooks=(ChainTailHook(),), **kw)


def fresh_source(d, n=5):
    path = os.path.join(d, "ledger.sqlite")
    led = hooked(path)
    for i in range(n):
        led.append("evidence", f"e{i}", "EVIDENCE", {"n": i})
    led.append("governance", "g0", "GOVERNANCE", {"n": 0})
    return led, path


def resign(bdir, mutate):
    mpath = os.path.join(bdir, A.MANIFEST_NAME)
    m = json.loads(pathlib.Path(mpath).read_text())
    m.pop("manifest_sha256")
    mutate(m, os.path.join(bdir, A.DB_NAME))
    m["files"][0]["sha256"], m["files"][0]["size"] = A._digest(os.path.join(bdir, A.DB_NAME))[0], \
        os.path.getsize(os.path.join(bdir, A.DB_NAME))
    m["manifest_sha256"] = C.sha256_hex(C.dumps(m))
    pathlib.Path(mpath).write_bytes(C.dumps(m))


def raw_edit(db, sql, args=()):
    """Test-only: runs one edit with the append-only guards removed, then RESTORES them, so a later refusal can only come
    from the check under test (not from a missing guard)."""
    c = sqlite3.connect(db)
    try:
        guards = c.execute("SELECT name, sql FROM sqlite_master WHERE type='trigger' AND name LIKE '%_no_%'").fetchall()
        for name, _ in guards:
            c.execute(f"DROP TRIGGER {name}")
        c.execute(sql, args)
        for _, create in guards:
            c.execute(create)
        c.commit()
    finally:
        c.close()


def drop_guards(db):
    """Test-only: leaves the guards removed on purpose (used to test the guard check itself)."""
    c = sqlite3.connect(db)
    try:
        for (name,) in c.execute("SELECT name FROM sqlite_master WHERE type='trigger' AND name LIKE '%_no_%'").fetchall():
            c.execute(f"DROP TRIGGER {name}")
        c.commit()
    finally:
        c.close()


def leftovers(d):
    return sorted(n for n in os.listdir(d) if n.startswith((A._RESTORE_TMP, A._BACKUP_TMP)))


class Base(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory()
        self.d = self._td.name
        self.led, self.src = fresh_source(self.d)
        self.port = LocalBackupPort(AuditTrail(os.path.join(self.d, "audit.jsonl")))

    def tearDown(self):
        self.led.close()
        self._td.cleanup()

    def backup(self, name="bk"):
        return create_backup(self.src, os.path.join(self.d, name), clock=CLOCK)

    def restore(self, bname="bk", name="restored.sqlite"):
        return restore_backup(os.path.join(self.d, bname), os.path.join(self.d, name))


# ---------------------------------------------------------------- 1-2. port: connection and refusals
class PortConnection(Base):
    def test_port_round_trip_is_audited_once_per_distinct_event(self):
        self.port.backup(self.src, os.path.join(self.d, "pbk"))
        r = self.port.restore(os.path.join(self.d, "pbk"), os.path.join(self.d, "pr.sqlite"))
        self.assertEqual(r.streams["evidence"]["records"], 5)
        self.port.verify(os.path.join(self.d, "pbk"))
        ops = [(e["op"], e["outcome"]) for e in self.port.__dict__["_audit"].events()]
        self.assertEqual(ops, [("backup", "ok"), ("restore", "ok"), ("verify", "ok")])

    def test_invalid_backup_is_refused_and_the_refusal_is_audited(self):
        with self.assertRaises(BackupError):
            self.port.backup(os.path.join(self.d, "missing.sqlite"), os.path.join(self.d, "nope"))
        ev = self.port.__dict__["_audit"].events()
        self.assertEqual([(e["op"], e["outcome"], e["code"]) for e in ev], [("backup", "refused", "BackupError")])
        self.assertNotIn(self.d, pathlib.Path(self.d, "audit.jsonl").read_text())   # no paths in the audit

    def test_verify_is_read_only_and_leaves_nothing_behind(self):
        self.backup("vbk")
        before = sorted(os.listdir(self.d))
        verify_backup(os.path.join(self.d, "vbk"))
        self.assertEqual(sorted(os.listdir(self.d)), before)


# ---------------------------------------------------------------- 3-8. restore refusals and no partial publication
class RestoreRefusals(Base):
    def test_manipulated_manifest_is_refused(self):                 # 3
        self.backup()
        mp = os.path.join(self.d, "bk", A.MANIFEST_NAME)
        pathlib.Path(mp).write_text(pathlib.Path(mp).read_text().replace('"records":5', '"records":4', 1))
        with self.assertRaises(RestoreError):
            self.restore()
        self.assertFalse(os.path.exists(os.path.join(self.d, "restored.sqlite")))

    def test_incomplete_backup_file_is_refused(self):               # 4
        self.backup()
        db = os.path.join(self.d, "bk", A.DB_NAME)
        with open(db, "r+b") as fh:
            fh.truncate(os.path.getsize(db) // 2)
        with self.assertRaises(RestoreError):
            self.restore()
        self.assertFalse(os.path.exists(os.path.join(self.d, "restored.sqlite")))

    def test_migration_mismatch_is_refused(self):                   # 5
        self.backup()

        def bad(m, _db):
            m["migrations"][1]["checksum"] = "0" * 64
        resign(os.path.join(self.d, "bk"), bad)
        with self.assertRaises(RestoreError):
            self.restore()

    def test_broken_chain_is_refused_even_with_a_resigned_manifest(self):   # 6
        self.backup()
        raw_edit(os.path.join(self.d, "bk", A.DB_NAME),
                 "UPDATE ledger_records SET canonical_bytes=? WHERE stream='evidence' AND seq=3", (b'{"forged":1}',))
        resign(os.path.join(self.d, "bk"), lambda m, _db: None)
        with self.assertRaises(RestoreError):
            self.restore()
        self.assertFalse(os.path.exists(os.path.join(self.d, "restored.sqlite")))
        self.assertEqual(leftovers(self.d), [])

    def test_existing_destination_is_never_overwritten(self):       # 7
        self.backup()
        target = os.path.join(self.d, "restored.sqlite")
        pathlib.Path(target).write_bytes(b"keep")
        with self.assertRaises(RestoreError):
            self.restore()
        self.assertEqual(pathlib.Path(target).read_bytes(), b"keep")

    def test_destination_created_during_restore_is_not_overwritten(self):   # 7b
        self.backup()
        real_link = os.link

        def racing(src, dst, *a, **k):
            pathlib.Path(dst).write_bytes(b"someone else")
            return real_link(src, dst, *a, **k)

        with mock.patch.object(A.os, "link", side_effect=racing):
            with self.assertRaises(RestoreError):
                self.restore()
        self.assertEqual(pathlib.Path(self.d, "restored.sqlite").read_bytes(), b"someone else")
        self.assertEqual(leftovers(self.d), [])

    def test_failed_restore_never_publishes_a_partial_database(self):   # 8
        self.backup()
        with mock.patch.object(A, "_verify_db", side_effect=RestoreError("injected")):
            with self.assertRaises(RestoreError):
                self.restore()
        self.assertFalse(os.path.exists(os.path.join(self.d, "restored.sqlite")))
        self.assertEqual(leftovers(self.d), [])

    def test_failed_restore_through_the_port_is_audited_as_refused(self):
        self.backup()
        pathlib.Path(self.d, "bk", A.DB_NAME).write_bytes(b"not a database")
        with self.assertRaises(RestoreError):
            self.port.restore(os.path.join(self.d, "bk"), os.path.join(self.d, "p.sqlite"))
        ev = self.port.__dict__["_audit"].events()
        self.assertEqual([(e["op"], e["outcome"]) for e in ev], [("restore", "refused")])
        self.assertFalse(os.path.exists(os.path.join(self.d, "p.sqlite")))


# ---------------------------------------------------------------- 9. sidecars (the C1 gap)
class Sidecars(Base):
    def test_restored_database_has_no_sidecar_files(self):          # 9
        self.backup()
        self.restore()
        dest = os.path.join(self.d, "restored.sqlite")
        self.assertEqual([s for s in ("-wal", "-shm", "-journal") if os.path.lexists(dest + s)], [])

    def test_finalize_refuses_a_leftover_sidecar(self):             # 9b: the C1 gap, now tested directly
        self.backup()
        tmp = os.path.join(self.d, "tmpcopy.sqlite")
        A._copy_exclusive(os.path.join(self.d, "bk", A.DB_NAME), tmp)
        for s in ("-shm", "-journal", "-wal"):
            pathlib.Path(tmp + s).write_bytes(b"x")
            with self.assertRaises(RestoreError):
                A._finalize(tmp, RestoreError)
            self.assertTrue(os.path.exists(tmp + s))                  # refused, not silently removed
            os.unlink(tmp + s)
        A._finalize(tmp, RestoreError)                                # clean file passes
        self.assertEqual([s for s in ("-wal", "-shm", "-journal") if os.path.lexists(tmp + s)], [])

    def test_sweep_removes_only_temporaries_of_a_killed_restore(self):
        self.backup()
        pathlib.Path(self.d, "precious.sqlite").write_bytes(b"keep")
        kept = sorted(os.listdir(self.d))
        pathlib.Path(self.d, f"{A._RESTORE_TMP}abcd.tmp").write_bytes(b"t")
        pathlib.Path(self.d, f"{A._RESTORE_TMP}abcd.tmp-wal").write_bytes(b"t")
        os.mkdir(os.path.join(self.d, f"{A._BACKUP_TMP}ef01"))
        self.assertEqual(sweep_stale_temporaries(self.d), 3)
        self.assertEqual(sorted(os.listdir(self.d)), kept)           # nothing else touched


# ---------------------------------------------------------------- 10, 15. crash behavior (real processes)
CHILD_RESTORE = """
import sys
from sanour_ai.backup import restore_backup
bdir, out = sys.argv[1], sys.argv[2]
for k in range(10000):
    restore_backup(bdir, f"{out}_{k}.sqlite")
"""


class CrashBehavior(Base):
    def test_sigkill_during_restore_publishes_only_complete_databases(self):   # 10
        self.backup("kbk")
        out = os.path.join(self.d, "kr")
        p = subprocess.Popen([sys.executable, "-c", textwrap.dedent(CHILD_RESTORE),
                              os.path.join(self.d, "kbk"), out], env=ENV,
                             stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        try:
            time.sleep(1.5)
            p.send_signal(signal.SIGKILL)
        finally:
            p.wait(timeout=30)
            p.stderr.close()
        made = [n for n in os.listdir(self.d) if n.startswith("kr_") and n.endswith(".sqlite")]
        self.assertTrue(made)
        for name in made:
            led = Ledger(os.path.join(self.d, name), clock=lambda: T0)
            try:
                self.assertTrue(verify_integrity(led).ok)
                self.assertEqual(led.head("evidence")[0], 5)
            finally:
                led.close()
        swept = sweep_stale_temporaries(self.d)
        self.assertGreaterEqual(swept, 0)
        self.assertEqual([n for n in os.listdir(self.d) if n.startswith(A._RESTORE_TMP)], [])


# ---------------------------------------------------------------- 11-14. commit hooks, audit, append-only
class CommitHooks(Base):
    def test_clean_appends_commit_through_the_hook(self):          # 11 (baseline)
        led = hooked(os.path.join(self.d, "h.sqlite"))
        led.append("evidence", "a", "EVIDENCE", {})
        self.assertEqual(led.head("evidence")[0], 1)
        led.close()

    def test_failing_hook_blocks_the_commit(self):                  # 12 (a hook that fails during migration also refuses)
        def boom(conn):
            raise IntegrityHookError("commit refused: injected")
        state = {"armed": False}

        def gated(conn):
            if state["armed"]:
                boom(conn)

        led = Ledger(os.path.join(self.d, "f.sqlite"), clock=lambda: T0, commit_hooks=(gated,))
        state["armed"] = True
        with self.assertRaises(IntegrityHookError):
            led.append("evidence", "a", "EVIDENCE", {})
        self.assertEqual(led.head("evidence")[0], 0)
        led.close()

    def test_integrity_hook_refuses_when_a_guard_was_removed(self):
        drop_guards(self.src)                                          # leaves every guard removed on purpose
        self.led.close()
        self.led = hooked(self.src)
        with self.assertRaises(IntegrityHookError):
            self.led.append("evidence", "x", "EVIDENCE", {})
        self.assertEqual(self.led.head("evidence")[0], 5)

    def test_integrity_hook_refuses_a_broken_chain_and_does_not_repair_it(self):
        self.led.close()
        raw_edit(self.src, "UPDATE ledger_records SET canonical_bytes=? WHERE stream='evidence' AND seq=5",
                 (b'{"forged":true}',))
        self.led = hooked(self.src)
        with self.assertRaises(IntegrityHookError):
            self.led.append("evidence", "x", "EVIDENCE", {})
        c = sqlite3.connect(self.src)
        try:
            self.assertEqual(bytes(c.execute("SELECT canonical_bytes FROM ledger_records WHERE stream='evidence' "
                                             "AND seq=5").fetchone()[0]), b'{"forged":true}')   # untouched
        finally:
            c.close()

    def test_concurrent_appends_with_hooks_all_commit_and_stay_consistent(self):   # 11b
        errs = []

        def go(k):
            try:
                for i in range(25):
                    self.led.append("evidence", f"t{k}-{i}", "EVIDENCE", {"k": k, "i": i})
            except Exception as exc:       # pragma: no cover - reported below
                errs.append(exc)

        ts = [threading.Thread(target=go, args=(k,)) for k in range(4)]
        [t.start() for t in ts]
        [t.join() for t in ts]
        self.assertEqual(errs, [])
        self.assertEqual(self.led.head("evidence")[0], 105)
        self.assertTrue(verify_integrity(self.led).ok)

    def test_audit_does_not_record_the_same_event_twice(self):      # 13
        a = AuditTrail(os.path.join(self.d, "dup.jsonl"))
        self.assertTrue(a.record("backup", "a" * 64, "ok"))
        self.assertFalse(a.record("backup", "a" * 64, "ok"))
        self.assertEqual(len(a.events()), 1)

    def test_audit_rejects_malformed_events_and_damaged_files(self):
        a = AuditTrail(os.path.join(self.d, "bad.jsonl"))
        with self.assertRaises(AuditError):
            a.record("delete", "a" * 64, "ok")
        with self.assertRaises(AuditError):
            a.record("backup", "/tmp/secret/path", "ok")
        a.record("backup", "b" * 64, "ok")
        pathlib.Path(self.d, "bad.jsonl").write_text("{not json}\n")
        with self.assertRaises(AuditError):
            a.events()

    def test_audit_drops_a_torn_last_line_before_appending(self):
        p = os.path.join(self.d, "torn.jsonl")
        a = AuditTrail(p)
        a.record("backup", "c" * 64, "ok")
        with open(p, "ab") as fh:
            fh.write(b'{"v":1,"id":"partial')
        self.assertEqual(len(a.events()), 1)
        a.record("restore", "d" * 64, "ok")
        self.assertEqual(len(a.events()), 2)
        self.assertTrue(pathlib.Path(p).read_bytes().endswith(b"\n"))

    def test_hook_never_rewrites_history(self):                     # 14
        q = "SELECT stream, seq, record_hash, canonical_bytes FROM ledger_records"
        c = sqlite3.connect(self.src)
        before = {(r[0], r[1]): tuple(r) for r in c.execute(q)}
        c.close()
        self.led.append("evidence", "more", "EVIDENCE", {})
        c = sqlite3.connect(self.src)
        after = {(r[0], r[1]): tuple(r) for r in c.execute(q)}
        c.close()
        for key, row in before.items():
            self.assertEqual(after[key], row)                  # every old row byte-identical
        self.assertEqual(len(after), len(before) + 1)

    def test_append_only_guards_still_refuse_updates(self):          # 14b
        c = sqlite3.connect(self.src)
        try:
            with self.assertRaises(sqlite3.IntegrityError):
                c.execute("UPDATE ledger_records SET kind='X' WHERE seq=1")
        finally:
            c.close()


# ---------------------------------------------------------------- 17. each integrity check isolated (mutation-driven)
class IsolatedChecks(Base):
    def reopen(self):
        self.led.close()
        self.led = hooked(self.src)

    def test_tail_record_hash_column_change_is_refused(self):
        self.led.close()
        raw_edit(self.src, "UPDATE ledger_records SET record_hash=? WHERE stream='evidence' AND seq=5", ("7" * 64,))
        self.led = hooked(self.src)
        with self.assertRaises(IntegrityHookError) as cm:
            self.led.append("evidence", "x", "EVIDENCE", {})
        self.assertIn("record_hash_mismatch", str(cm.exception))

    def test_column_only_link_break_is_refused(self):
        self.led.close()
        raw_edit(self.src, "UPDATE ledger_records SET prev_hash=? WHERE stream='evidence' AND seq=5", ("1" * 64,))
        self.led = hooked(self.src)
        with self.assertRaises(IntegrityHookError) as cm:
            self.led.append("evidence", "x", "EVIDENCE", {})
        self.assertIn("chain_link_broken", str(cm.exception))

    def test_migration_checksum_drift_is_refused_by_the_hook(self):
        raw_edit(self.src, "UPDATE schema_migrations SET checksum=? WHERE version=1", ("0" * 64,))
        with self.assertRaises(IntegrityHookError) as cm:
            self.led.append("evidence", "x", "EVIDENCE", {})
        self.assertIn("migration_mismatch", str(cm.exception))

    def test_checkpoint_ahead_of_the_ledger_is_refused_on_any_write(self):
        create_checkpoint(self.led, "evidence")
        self.led.close()
        raw_edit(self.src, "DELETE FROM ledger_records WHERE stream='evidence' AND seq=5")
        self.led = hooked(self.src)
        with self.assertRaises(IntegrityHookError) as cm:
            with self.led._write():                                    # a write with no change still runs the hook
                pass
        self.assertIn("checkpoint_ahead", str(cm.exception))

    def test_checkpoint_mismatch_is_refused(self):
        create_checkpoint(self.led, "evidence")
        self.led.close()
        raw_edit(self.src, "UPDATE ledger_checkpoints SET head_hash=? WHERE stream='evidence'", ("9" * 64,))
        self.led = hooked(self.src)
        with self.assertRaises(IntegrityHookError) as cm:
            with self.led._write():
                pass
        self.assertIn("checkpoint_mismatch", str(cm.exception))


class GapAndSidecarRaces(Base):
    def test_sequence_gap_with_an_intact_link_is_refused(self):
        self.led.close()
        raw_edit(self.src, "UPDATE ledger_records SET seq=7 WHERE stream='evidence' AND seq=5")
        self.led = hooked(self.src)
        with self.assertRaises(IntegrityHookError) as cm:
            self.led.append("evidence", "x", "EVIDENCE", {})
        self.assertIn("sequence_gap", str(cm.exception))

    def test_sidecar_appearing_during_the_journal_switch_is_refused(self):
        self.backup()
        tmp = os.path.join(self.d, "racecopy.sqlite")
        A._copy_exclusive(os.path.join(self.d, "bk", A.DB_NAME), tmp)
        real_connect = sqlite3.connect

        class Racing:
            def __init__(self, conn):
                self._c = conn

            def execute(self, sql, *a):
                r = self._c.execute(sql, *a)
                if "journal_mode" in sql:
                    pathlib.Path(tmp + "-shm").write_bytes(b"x")     # appears AFTER the pre-check, during the switch
                return r

            def close(self):
                self._c.close()

        with mock.patch.object(A.sqlite3, "connect", side_effect=lambda *a, **k: Racing(real_connect(*a, **k))):
            with self.assertRaises(RestoreError):
                A._finalize(tmp, RestoreError)


class AuditDamage(Base):
    def test_non_canonical_or_wrong_version_audit_lines_are_refused(self):
        p = os.path.join(self.d, "damaged.jsonl")
        a = AuditTrail(p)
        a.record("backup", "e" * 64, "ok")
        good = pathlib.Path(p).read_bytes()
        pathlib.Path(p).write_bytes(good.replace(b'{"code"', b'{ "code"', 1))      # valid JSON, not canonical
        with self.assertRaises(AuditError):
            a.events()
        obj = json.loads(good)
        obj["v"] = 2
        pathlib.Path(p).write_bytes(C.dumps(obj) + b"\n")                         # canonical, wrong version
        with self.assertRaises(AuditError):
            a.events()


class VerifyCleanup(Base):
    def test_verify_leaves_nothing_in_the_backup_or_its_parent(self):
        self.backup("vc")
        real = tempfile.mkdtemp
        before_parent = sorted(os.listdir(self.d))
        before_bk = sorted(os.listdir(os.path.join(self.d, "vc")))
        with mock.patch.object(A.tempfile, "mkdtemp", side_effect=lambda prefix="", dir=None: real(prefix=prefix, dir=self.d)):
            verify_backup(os.path.join(self.d, "vc"))
        self.assertEqual(sorted(os.listdir(self.d)), before_parent)
        self.assertEqual(sorted(os.listdir(os.path.join(self.d, "vc"))), before_bk)


# ---------------------------------------------------------------- 15-16. architecture and compatibility
class Architecture(unittest.TestCase):
    def test_core_and_providers_do_not_import_integrity_or_backup(self):   # 15
        for pkg in ("core", "composition", "models", "providers", "readiness", "governance"):
            for f in (SRC / "sanour_ai" / pkg).glob("*.py"):
                text = f.read_text()
                self.assertNotIn("sanour_ai.integrity", text, f"{pkg}/{f.name}")
                self.assertNotIn("sanour_ai.backup", text, f"{pkg}/{f.name}")

    def test_integrity_package_is_offline_and_retry_free(self):
        text = "\n".join(f.read_text().lower() for f in (SRC / "sanour_ai" / "integrity").glob("*.py"))
        for word in ("openai", "anthropic", "gemini", "grok", "retry", "retries", "fallback", "auto_select",
                     "urlopen", "socket", "requests", "httpx", "os.remove", "shutil.rmtree(\"/"):
            self.assertFalse(word in text, word)

    def test_no_public_error_code_added(self):
        from sanour_ai.errors import ErrorCode
        self.assertEqual(len(list(ErrorCode)), 9)

    def test_migrations_v1_to_v3_unchanged(self):                  # 16
        self.assertEqual([m.version for m in M.MIGRATIONS], [1, 2, 3])
        pinned = json.loads((ROOT / "docs" / "MIGRATION_CHECKSUMS_10_54B.json").read_text())["checksums"]
        self.assertEqual([m.checksum for m in M.MIGRATIONS], pinned)

    def test_persistence_public_surface_has_no_integrity_or_backup_names(self):
        import sanour_ai.persistence as P
        for name in dir(P):
            self.assertFalse(any(w in name.lower() for w in ("backup", "restore")), name)


if __name__ == "__main__":
    unittest.main()
