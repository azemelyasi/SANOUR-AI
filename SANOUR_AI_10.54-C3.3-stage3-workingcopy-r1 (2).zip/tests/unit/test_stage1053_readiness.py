"""Stage 10.53: evidence integrity, governance, lifecycle, runtime isolation. Offline, no network, no keys."""

import dataclasses
import hashlib
import json
import os
import re
import threading
import unittest
from datetime import datetime, timedelta, timezone

from sanour_ai.composition.runtime import Runtime
from sanour_ai.models.base import ModelResult
from sanour_ai.models.usage import Usage
from sanour_ai.providers.offline_contract import OfflineTestProvider
from sanour_ai.readiness import (
    AppendOnlyLog, Criterion, EvidenceKind, EvidenceRejected, EvidenceStore, GovernedReadiness, LifecycleError,
    LifecycleState as LS, ProviderLifecycle, Role, Standing, Status, render_report_markdown,
)
from sanour_ai.readiness.chain import Entry
from sanour_ai.readiness.current_state import build_current
from sanour_ai.readiness.governance import SPECS, CriteriaSpec, ReportError, SpecMismatch, current_spec
from sanour_ai.security.redaction import redact
from tests.integration.test_core_flow import make_core, profile
from tests.support import TOLERANCE_SECONDS, GatedProvider, wait_until
from tests.unit.test_stage1047_usage import ALIAS, PROMPT, env

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
T0 = datetime(2026, 11, 8, 12, 0, tzinfo=timezone.utc)
FAKE_KEY = "sk-STAGE1053SECRETKEYTESTONLY0000"


class Clock:
    def __init__(self, t=T0):
        self.t = t

    def __call__(self):
        return self.t


def store(clock=None):
    return EvidenceStore(authorized_reviewers={"rev-a", "rev-b"}, clock=clock or Clock())


def add(s, provider="p1", crit=Criterion.DEADLINE_COMPLIANCE, kind=EvidenceKind.LIVE, supports=True,
        artifact=b"real run output 1", reviewer="rev-a", recorded_by="rec", verified_at=T0 - timedelta(days=1),
        method="live_api_probe", source="live://run/1", note="probe result", **kw):
    return s.add(provider_id=provider, criterion=crit, kind=kind, supports=supports, artifact=artifact,
                 source=source, reviewer=reviewer, recorded_by=recorded_by, verified_at=verified_at,
                 method=method, software="sanour_ai", software_version="10.53", note=note, **kw)


def full_live(s, provider="p1"):
    for c in Criterion:
        add(s, provider, c, artifact=f"{provider}-{c.value}".encode(), source=f"live://{provider}/{c.value}")


class EvidenceIntegrity(unittest.TestCase):
    def test_hash_is_computed_not_trusted(self):
        s = store()
        r = add(s, artifact=b"abc")
        self.assertEqual(r.artifact_sha256, hashlib.sha256(b"abc").hexdigest())
        self.assertEqual(r.schema_version, "1")
        self.assertEqual(r.evidence_id, "EV-000001")

    def test_hash_tampering_claimed_hash_rejected(self):
        with self.assertRaises(EvidenceRejected):
            add(store(), artifact=b"abc", claimed_sha256="0" * 64)
        ok = add(store(), artifact=b"abc", claimed_sha256=hashlib.sha256(b"abc").hexdigest().upper())
        self.assertTrue(ok)

    def test_artifact_tampering_detected_after_the_fact(self):
        s = store()
        r = add(s, artifact=b"original")
        self.assertTrue(s.verify_artifact(r.evidence_id, b"original"))
        self.assertFalse(s.verify_artifact(r.evidence_id, b"original!"))

    def test_resolver_mismatch_turns_pass_into_fail(self):
        s = store()
        full_live(s)
        data = {r.evidence_id: f"p1-{r.criterion.value}".encode() for r in s.records()}
        g = GovernedReadiness(s, clock=Clock(), artifact_resolver=lambda i: data.get(i))
        self.assertTrue(g.evaluate("p1").production_ready)
        first = s.records()[0].evidence_id
        data[first] = b"tampered"
        a = g.evaluate("p1")
        self.assertEqual(a.overall, Status.FAIL)
        self.assertFalse(a.production_ready)
        data.pop(first)  # artifact missing is also fail
        self.assertEqual(g.evaluate("p1").overall, Status.FAIL)

    def test_record_is_frozen_and_store_has_no_delete_or_update(self):
        s = store()
        r = add(s)
        with self.assertRaises(dataclasses.FrozenInstanceError):
            r.supports = False
        for name in ("delete", "remove", "update", "overwrite", "clear", "pop"):
            self.assertFalse(hasattr(s, name), name)
        for name in ("delete", "remove", "update", "clear", "pop", "truncate"):
            self.assertFalse(hasattr(AppendOnlyLog(), name), name)

    def test_replacement_is_traceable(self):
        s = store()
        a = add(s, artifact=b"v1")
        b = add(s, artifact=b"v2", supersedes=a.evidence_id, source="live://run/2")
        self.assertEqual(b.supersedes, a.evidence_id)
        self.assertEqual(s.get(a.evidence_id).artifact_sha256, hashlib.sha256(b"v1").hexdigest())  # old kept
        self.assertEqual(s.standing(a.evidence_id), Standing.SUPERSEDED)
        self.assertEqual(s.standing(b.evidence_id), Standing.VALID)
        kinds = [e.kind for e in s.log.entries()]
        self.assertIn("EVIDENCE_SUPERSEDED", kinds)
        self.assertTrue(s.verify_integrity())

    def test_replacement_rules(self):
        s = store()
        a = add(s)
        with self.assertRaises(EvidenceRejected):
            add(s, supersedes="EV-999999")
        with self.assertRaises(EvidenceRejected):
            add(s, crit=Criterion.AUDIT_INTEGRITY, supersedes=a.evidence_id)
        with self.assertRaises(EvidenceRejected):
            add(s, provider="other", supersedes=a.evidence_id)
        add(s, supersedes=a.evidence_id, source="live://run/2")
        with self.assertRaises(EvidenceRejected):
            add(s, supersedes=a.evidence_id, source="live://run/3")

    def test_deletion_or_edit_of_history_is_detected(self):
        s = store()
        add(s)
        add(s, source="live://run/2")
        self.assertTrue(s.verify_integrity())
        entries = s.log._entries
        saved = list(entries)
        del entries[0]                                       # deletion
        self.assertFalse(s.verify_integrity())
        entries[:] = saved
        e = entries[1]
        entries[1] = Entry(e.seq, e.kind, e.payload.replace("probe", "PROBE"), e.prev_hash, e.hash)  # edit
        self.assertFalse(s.verify_integrity())
        entries[:] = saved
        entries[0], entries[1] = entries[1], entries[0]      # reorder
        self.assertFalse(s.verify_integrity())
        entries[:] = saved
        self.assertTrue(s.verify_integrity())

    def test_in_memory_record_swap_is_detected(self):
        s = store()
        r = add(s)
        s._records[r.evidence_id] = dataclasses.replace(r, supports=False)
        self.assertFalse(s.verify_integrity())

    def test_rejections_are_logged(self):
        s = store()
        with self.assertRaises(EvidenceRejected):
            add(s, reviewer="nobody")
        self.assertEqual([e.kind for e in s.log.entries()], ["EVIDENCE_REJECTED"])
        self.assertEqual(s.records(), ())

    def test_revoke_is_logged_and_final(self):
        s = store()
        r = add(s)
        s.revoke(r.evidence_id, "rev-a", "found wrong run")
        self.assertEqual(s.standing(r.evidence_id), Standing.REVOKED)
        with self.assertRaises(EvidenceRejected):
            s.revoke(r.evidence_id, "rev-a", "again please")
        with self.assertRaises(EvidenceRejected):
            s.revoke(add(s, source="live://x").evidence_id, "", "x")
        with self.assertRaises(KeyError):
            s.revoke("EV-404", "a", "reason ok")


class LiveScreening(unittest.TestCase):
    def test_invalid_reviewer(self):
        for rev in ("", "stranger", "REV-A"):
            with self.assertRaises(EvidenceRejected, msg=rev):
                add(store(), reviewer=rev)

    def test_reviewer_must_be_independent(self):
        with self.assertRaises(EvidenceRejected):
            add(store(), reviewer="rev-a", recorded_by="rev-a")

    def test_mock_and_fake_never_live(self):
        for kw in ({"source": "live://mock/provider"}, {"note": "fake transport run"},
                   {"artifact": b"output from MockProvider"}, {"method": "mock_run"},
                   {"source": "repo://tests/unit/test_x.py"}, {"source": "https://x"}):
            with self.assertRaises(EvidenceRejected, msg=str(kw)):
                add(store(), **kw)

    def test_mock_allowed_as_mock_kind_but_never_passes(self):
        s = store()
        add(s, kind=EvidenceKind.MOCK_TEST, reviewer="", source="repo://t", method="unit", note="mock run")
        g = GovernedReadiness(s, clock=Clock())
        a = g.evaluate("p1")
        self.assertNotIn(Status.PASS, [r.status for r in a.results])

    def test_bad_method_time_and_inputs(self):
        for kw in ({"method": "self_attested"}, {"verified_at": T0 + timedelta(days=1)},
                   {"verified_at": datetime(2026, 1, 1)}, {"artifact": b""}, {"artifact": "str"},
                   {"artifact": b"x" * (10 * 1024 * 1024 + 1)}, {"note": " "}, {"provider_id": " "} if False else {"source": " "}):
            with self.assertRaises(EvidenceRejected, msg=str(kw)):
                add(store(), **kw)

    def test_bad_enums(self):
        with self.assertRaises(EvidenceRejected):
            add(store(), crit="deadline_compliance")
        with self.assertRaises(EvidenceRejected):
            add(store(), kind="live")


class ExpiryAndConflict(unittest.TestCase):
    def test_boundaries(self):
        s = store()
        live = lambda days, src: add(s, verified_at=T0 - timedelta(days=days), source=src)
        fresh, edge, stale, expired = live(1, "live://a"), live(90, "live://b"), live(61, "live://c"), live(91, "live://d")
        self.assertEqual(s.standing(fresh.evidence_id), Standing.VALID)
        self.assertEqual(s.standing(stale.evidence_id), Standing.STALE)
        self.assertEqual(s.standing(edge.evidence_id), Standing.STALE)
        self.assertEqual(s.standing(expired.evidence_id), Standing.EXPIRED)
        self.assertEqual(s.standing(fresh.evidence_id, T0 + timedelta(days=100)), Standing.EXPIRED)

    def test_expired_live_cannot_pass(self):
        c = Clock()
        s = store(c)
        full_live(s)
        g = GovernedReadiness(s, clock=c)
        self.assertTrue(g.evaluate("p1").production_ready)
        c.t = T0 + timedelta(days=200)
        a = g.evaluate("p1")
        self.assertEqual(a.overall, Status.UNVERIFIED)
        self.assertFalse(a.production_ready)
        self.assertIn("expired", a.results[0].reason)

    def test_expired_failure_still_blocks_until_superseded(self):
        c = Clock()
        s = store(c)
        bad = add(s, supports=False, verified_at=T0 - timedelta(days=1))
        c.t = T0 + timedelta(days=400)
        g = GovernedReadiness(s, clock=c)
        r = {x.criterion: x for x in g.evaluate("p1").results}[Criterion.DEADLINE_COMPLIANCE]
        self.assertEqual(r.status, Status.FAIL)
        c.t = T0 + timedelta(days=401)
        add(s, supports=True, supersedes=bad.evidence_id, verified_at=c.t, source="live://fix")
        r = {x.criterion: x for x in g.evaluate("p1").results}[Criterion.DEADLINE_COMPLIANCE]
        self.assertEqual(r.status, Status.PASS)

    def test_conflicting_live_evidence_fails_and_is_listed(self):
        s = store()
        add(s, supports=True)
        add(s, supports=False, source="live://run/2")
        self.assertEqual(s.conflicts("p1"), [Criterion.DEADLINE_COMPLIANCE])
        g = GovernedReadiness(s, clock=Clock())
        r = g.evaluate("p1").results[3]
        self.assertEqual(r.criterion, Criterion.DEADLINE_COMPLIANCE)
        self.assertEqual(r.status, Status.FAIL)
        self.assertIn("conflicting", r.reason)

    def test_no_conflict_across_criteria_or_providers(self):
        s = store()
        add(s, supports=True)
        add(s, supports=False, crit=Criterion.AUDIT_INTEGRITY, source="live://2")
        add(s, supports=False, provider="p2", source="live://3")
        self.assertEqual(s.conflicts("p1"), [])


class Governance(unittest.TestCase):
    def test_pass_only_from_valid_evidence_and_independent_criteria(self):
        s = store()
        add(s)
        a = GovernedReadiness(s, clock=Clock()).evaluate("p1")
        st = {r.criterion: r.status for r in a.results}
        self.assertEqual(st[Criterion.DEADLINE_COMPLIANCE], Status.PASS)
        self.assertEqual(st[Criterion.AUDIT_INTEGRITY], Status.UNVERIFIED)
        self.assertEqual(a.overall, Status.UNVERIFIED)
        self.assertFalse(a.production_ready)

    def test_full_live_is_ready_but_revoke_removes_it(self):
        s = store()
        full_live(s)
        g = GovernedReadiness(s, clock=Clock())
        self.assertTrue(g.evaluate("p1").production_ready)
        s.revoke(s.records()[2].evidence_id, "rev-b", "run was invalid")
        self.assertFalse(g.evaluate("p1").production_ready)

    def test_broken_store_means_nothing_passes(self):
        s = store()
        full_live(s)
        g = GovernedReadiness(s, clock=Clock())
        del s.log._entries[0]
        a = g.evaluate("p1")
        self.assertEqual({r.status for r in a.results}, {Status.UNVERIFIED})
        self.assertFalse(a.production_ready)

    def test_status_changes_have_reason_and_history(self):
        c = Clock()
        s = store(c)
        g = GovernedReadiness(s, clock=c)
        g.evaluate("p1")
        add(s)
        g.evaluate("p1")
        g.evaluate("p1")  # no change: no new entry
        h = g.status_history("p1", Criterion.DEADLINE_COMPLIANCE)
        self.assertEqual([(x["from"], x["to"]) for x in h], [("NONE", "UNVERIFIED"), ("UNVERIFIED", "PASS")])
        self.assertTrue(all(x["reason"] for x in h))
        self.assertEqual(h[1]["evidence"], ["EV-000001"])
        self.assertTrue(g.log.verify())

    def test_criteria_spec_versioned(self):
        spec = current_spec()
        self.assertEqual(spec.version, "1")
        self.assertEqual(spec.digest(), "d92766d3bbf9275112ee4bd5f294fa14469a3b7a3cc0f9922c01fc9faa103bbc")  # released v1 digest, pinned
        # a changed criteria set must be a new version and changes the digest
        other = CriteriaSpec("2", spec.criteria[:-1], spec.waivable, "x")
        self.assertNotEqual(other.digest(), spec.digest())

    def test_spec_enum_mismatch_fails_closed(self):
        import sanour_ai.readiness.governance as gov
        saved = dict(gov.SPECS)
        try:
            gov.SPECS["1"] = CriteriaSpec("1", saved["1"].criteria[:-1], saved["1"].waivable, "broken")
            with self.assertRaises(SpecMismatch):
                GovernedReadiness(store())
        finally:
            gov.SPECS.clear()
            gov.SPECS.update(saved)


class HistoricalReports(unittest.TestCase):
    def test_report_contents(self):
        c = Clock()
        s = store(c)
        add(s)
        g = GovernedReadiness(s, clock=c)
        rid = g.issue_report(("p1",))
        rep = g.get_report(rid)
        self.assertEqual(rep["generated_at"], T0.isoformat())
        self.assertEqual(rep["criteria_spec_version"], "1")
        self.assertEqual(rep["evidence_log_head"], s.head_hash)
        ev = [e for p in rep["providers"] for c_ in p["criteria"] for e in c_["evidence"]]
        self.assertEqual(ev[0]["sha256"], hashlib.sha256(b"real run output 1").hexdigest())
        md = render_report_markdown(rep)
        for needle in (rep["digest"], T0.isoformat(), ev[0]["sha256"][:12], "v1"):
            self.assertIn(needle, md)

    def test_later_evidence_does_not_change_old_report(self):
        c = Clock()
        s = store(c)
        g = GovernedReadiness(s, clock=c)
        rid = g.issue_report(("p1",))
        before = json.dumps(g.get_report(rid), sort_keys=True)
        full_live(s)
        c.t += timedelta(days=1)
        rid2 = g.issue_report(("p1",))
        self.assertEqual(json.dumps(g.get_report(rid), sort_keys=True), before)
        self.assertNotEqual(g.get_report(rid2)["digest"], g.get_report(rid)["digest"])
        self.assertEqual(g.get_report(rid)["providers"][0]["overall"], "UNVERIFIED")
        self.assertEqual(g.get_report(rid2)["providers"][0]["overall"], "PASS")

    def test_report_tampering_detected(self):
        g = GovernedReadiness(store(), clock=Clock())
        rid = g.issue_report(("p1",))
        g._reports[rid] = g._reports[rid].replace("UNVERIFIED", "PASS")
        with self.assertRaises(ReportError):
            g.get_report(rid)

    def test_report_log_tampering_detected(self):
        g = GovernedReadiness(store(), clock=Clock())
        rid = g.issue_report(("p1",))
        g.log._entries.pop()
        with self.assertRaises(ReportError):
            g.get_report(rid)


class Lifecycle(unittest.TestCase):
    def setUp(self):
        self.lc = ProviderLifecycle({"op": frozenset({Role.OPERATOR}), "op2": frozenset({Role.OPERATOR}),
                                     "rv": frozenset({Role.REVIEWER}), "ad": frozenset({Role.ADMIN}),
                                     "nobody": frozenset()})
        self.lc.register("p", "op", "initial registration")

    def to(self, state, actor, reason="valid reason"):
        return self.lc.transition("p", state, actor, reason)

    def walk(self):
        self.to(LS.CONFIGURED, "op")
        self.to(LS.VALIDATED, "rv")
        self.to(LS.OPERATIONAL, "op")

    def test_happy_path_and_history(self):
        self.walk()
        self.assertEqual(self.lc.state("p"), LS.OPERATIONAL)
        self.to(LS.SUSPENDED, "rv")
        self.to(LS.VALIDATED, "rv")
        self.to(LS.OPERATIONAL, "ad")
        self.to(LS.RETIRED, "ad")
        self.assertEqual([h["to"] for h in self.lc.history("p")],
                         ["REGISTERED", "CONFIGURED", "VALIDATED", "OPERATIONAL", "SUSPENDED", "VALIDATED",
                          "OPERATIONAL", "RETIRED"])
        self.assertTrue(self.lc.log.verify())

    def test_every_invalid_transition_refused_state_unchanged(self):
        allowed = {(LS.REGISTERED, LS.CONFIGURED), (LS.REGISTERED, LS.RETIRED), (LS.CONFIGURED, LS.VALIDATED),
                   (LS.CONFIGURED, LS.RETIRED), (LS.VALIDATED, LS.OPERATIONAL), (LS.VALIDATED, LS.CONFIGURED),
                   (LS.VALIDATED, LS.RETIRED), (LS.OPERATIONAL, LS.SUSPENDED), (LS.OPERATIONAL, LS.RETIRED),
                   (LS.SUSPENDED, LS.VALIDATED), (LS.SUSPENDED, LS.RETIRED)}
        for start in LS:
            for target in LS:
                lc = ProviderLifecycle({"ad": frozenset({Role.ADMIN, Role.OPERATOR, Role.REVIEWER}), "ad2": frozenset({Role.REVIEWER})})
                lc.register("q", "ad", "register it")
                path = {LS.REGISTERED: [], LS.CONFIGURED: [LS.CONFIGURED], LS.VALIDATED: [LS.CONFIGURED, LS.VALIDATED],
                        LS.OPERATIONAL: [LS.CONFIGURED, LS.VALIDATED, LS.OPERATIONAL],
                        LS.SUSPENDED: [LS.CONFIGURED, LS.VALIDATED, LS.OPERATIONAL, LS.SUSPENDED],
                        LS.RETIRED: [LS.RETIRED]}[start]
                for step in path:
                    lc.transition("q", step, "ad2" if step is LS.VALIDATED else "ad", "walk to start")
                if (start, target) in allowed:
                    continue
                with self.assertRaises(LifecycleError, msg=f"{start}->{target}"):
                    lc.transition("q", target, "ad", "should be refused")
                self.assertEqual(lc.state("q"), start)

    def test_retired_is_terminal(self):
        self.to(LS.RETIRED, "ad")
        for t in LS:
            with self.assertRaises(LifecycleError):
                self.to(t, "ad")

    def test_unauthorized_transitions(self):
        self.to(LS.CONFIGURED, "op")
        for actor in ("nobody", "ghost", "ad"):
            with self.assertRaises(LifecycleError, msg=actor):
                self.to(LS.VALIDATED, actor)
        with self.assertRaises(LifecycleError):
            self.to(LS.VALIDATED, "op2")          # operator role may not validate (even a different operator)
        self.assertEqual(self.lc.state("p"), LS.CONFIGURED)
        with self.assertRaises(LifecycleError):
            self.to(LS.RETIRED, "op")              # only admin retires

    def test_four_eyes(self):
        lc = ProviderLifecycle({"both": frozenset({Role.OPERATOR, Role.REVIEWER}), "rv": frozenset({Role.REVIEWER})})
        lc.register("p", "both", "register")
        lc.transition("p", LS.CONFIGURED, "both", "configured it")
        with self.assertRaises(LifecycleError):
            lc.transition("p", LS.VALIDATED, "both", "self validate")
        lc.transition("p", LS.VALIDATED, "rv", "independent check")

    def test_reason_required_and_unknown_inputs(self):
        for reason in ("", "abc", None, "    "):
            with self.assertRaises(LifecycleError):
                self.lc.transition("p", LS.CONFIGURED, "op", reason)
        for bad in ("BOGUS", None, 7, "operational"):
            with self.assertRaises(LifecycleError):
                self.lc.transition("p", bad, "op", "valid reason")
        with self.assertRaises(LifecycleError):
            self.lc.transition("zzz", LS.CONFIGURED, "op", "valid reason")
        with self.assertRaises(LifecycleError):
            self.lc.state("zzz")
        with self.assertRaises(LifecycleError):
            self.lc.register("p", "op", "duplicate one")
        with self.assertRaises(LifecycleError):
            self.lc.register("n", "nobody", "not allowed")
        self.assertEqual(self.lc.state("p"), LS.REGISTERED)

    def test_denials_are_logged(self):
        with self.assertRaises(LifecycleError):
            self.to(LS.OPERATIONAL, "op")
        self.assertEqual(self.lc.log.entries()[-1].kind, "DENIED")

    def test_operational_is_not_production_ready(self):
        self.walk()
        s = store()
        g = GovernedReadiness(s, clock=Clock())
        self.assertEqual(self.lc.state("p"), LS.OPERATIONAL)
        self.assertFalse(g.evaluate("p").production_ready)
        import sanour_ai.readiness.lifecycle as m
        with open(m.__file__, encoding="utf-8") as fh:
            src = fh.read()
        self.assertNotIn("readiness.governance", src)
        self.assertNotIn("production_ready", src)

    def test_provider_isolation(self):
        self.lc.register("other", "op", "second provider")
        self.to(LS.CONFIGURED, "op")
        self.assertEqual(self.lc.state("other"), LS.REGISTERED)
        s = store()
        add(s, provider="a")
        g = GovernedReadiness(s, clock=Clock())
        self.assertEqual({r.status for r in g.evaluate("b").results}, {Status.UNVERIFIED})

    def test_concurrent_transitions_only_one_wins(self):
        lc = ProviderLifecycle({"op": frozenset({Role.OPERATOR})})
        lc.register("c", "op", "register it")
        wins, errs = [], []
        def go():
            try:
                lc.transition("c", LS.CONFIGURED, "op", "race attempt")
                wins.append(1)
            except LifecycleError:
                errs.append(1)
        ts = [threading.Thread(target=go) for _ in range(16)]
        [t.start() for t in ts]; [t.join() for t in ts]
        self.assertEqual((len(wins), len(errs)), (1, 15))
        self.assertTrue(lc.log.verify())


class ExtraIntegrity(unittest.TestCase):
    def test_dropped_record_detected(self):
        s = store()
        r = add(s)
        del s._records[r.evidence_id]
        self.assertFalse(s.verify_integrity())

    def test_overall_is_strictest_not_first(self):
        s = store()
        add(s, crit=Criterion.SDK_TRANSPORT_CONFORMANCE)   # first criterion PASS, rest UNVERIFIED
        self.assertEqual(GovernedReadiness(s, clock=Clock()).evaluate("p1").overall, Status.UNVERIFIED)
        add(s, crit=Criterion.OPERATIONAL_EVIDENCE, supports=False, source="live://z")
        self.assertEqual(GovernedReadiness(s, clock=Clock()).evaluate("p1").overall, Status.FAIL)

    def test_report_digest_rewritten_in_log_is_detected(self):
        g = GovernedReadiness(store(), clock=Clock())
        rid = g.issue_report(("p1",))
        body = json.loads(g._reports[rid])
        body["providers"][0]["overall"] = "PASS"
        body.pop("digest")
        from sanour_ai.readiness.chain import canonical, sha256_text
        body["digest"] = sha256_text(canonical(body))          # attacker recomputes the embedded digest
        g._reports[rid] = canonical(body)
        with self.assertRaises(ReportError):                   # but the logged digest no longer matches
            g.get_report(rid)

    def test_report_log_edit_detected_even_with_matching_report(self):
        g = GovernedReadiness(store(), clock=Clock())
        rid = g.issue_report(("p1",))
        e = g.log._entries[-1]
        g.log._entries[-1] = Entry(e.seq, e.kind, e.payload.replace("RR-", "RX-"), e.prev_hash, e.hash)
        with self.assertRaises(ReportError):
            g.get_report(rid)


class ExtraIntegrity2(unittest.TestCase):
    def test_edited_status_history_invalidates_reports(self):
        g = GovernedReadiness(store(), clock=Clock())
        rid = g.issue_report(("p1",))
        e = g.log._entries[0]
        self.assertEqual(e.kind, "STATUS_CHANGE")
        g.log._entries[0] = Entry(e.seq, e.kind, e.payload.replace("UNVERIFIED", "PASS"), e.prev_hash, e.hash)
        with self.assertRaises(ReportError):
            g.get_report(rid)


class Concurrency(unittest.TestCase):
    def test_concurrent_evidence_updates(self):
        s = store()
        def work(n):
            for i in range(25):
                add(s, provider=f"p{n}", artifact=f"{n}-{i}".encode(), source=f"live://{n}/{i}")
        ts = [threading.Thread(target=work, args=(n,)) for n in range(8)]
        [t.start() for t in ts]; [t.join() for t in ts]
        ids = [r.evidence_id for r in s.records()]
        self.assertEqual(len(ids), 200)
        self.assertEqual(len(set(ids)), 200)
        self.assertEqual(ids, sorted(ids))
        self.assertTrue(s.verify_integrity())

    def test_concurrent_supersede_same_record_only_one_wins(self):
        s = store()
        a = add(s)
        res = []
        def go(i):
            try:
                add(s, supersedes=a.evidence_id, source=f"live://r/{i}", artifact=f"x{i}".encode())
                res.append("ok")
            except EvidenceRejected:
                res.append("no")
        ts = [threading.Thread(target=go, args=(i,)) for i in range(12)]
        [t.start() for t in ts]; [t.join() for t in ts]
        self.assertEqual(res.count("ok"), 1)
        self.assertTrue(s.verify_integrity())

    def test_concurrent_evaluate_and_add(self):
        s = store()
        g = GovernedReadiness(s, clock=Clock())
        stop = threading.Event()
        errors = []
        def reader():
            while not stop.is_set():
                try:
                    g.evaluate("p1")
                    g.issue_report(("p1",))
                except Exception as exc:  # pragma: no cover
                    errors.append(exc)
        t = threading.Thread(target=reader); t.start()
        for c in Criterion:
            add(s, crit=c, source=f"live://{c.value}", artifact=c.value.encode())
        stop.set(); t.join()
        self.assertEqual(errors, [])
        self.assertTrue(g.evaluate("p1").production_ready)
        self.assertTrue(g.log.verify())


class SecretLeakage(unittest.TestCase):
    def test_secret_in_any_field_or_artifact_refused(self):
        for kw in ({"note": f"key {FAKE_KEY}"}, {"source": f"live://x?api_key={FAKE_KEY}"},
                   {"artifact": f"Authorization: Bearer {FAKE_KEY}".encode()},
                   {"reviewer": f"token={FAKE_KEY}"}):
            s = store()
            with self.assertRaises(EvidenceRejected):
                add(s, **kw)
            self.assertNotIn(FAKE_KEY, "".join(e.payload for e in s.log.entries()))

    def test_reports_and_logs_contain_no_secret(self):
        s = store()
        add(s)
        g = GovernedReadiness(s, clock=Clock())
        rid = g.issue_report(("p1",))
        blob = json.dumps(g.get_report(rid)) + render_report_markdown(g.get_report(rid))
        blob += "".join(e.payload for e in s.log.entries() + g.log.entries())
        self.assertNotIn(FAKE_KEY, blob)
        self.assertEqual(redact(blob), blob)

    def test_lifecycle_log_redacts_reason(self):
        lc = ProviderLifecycle({"op": frozenset({Role.OPERATOR})})
        lc.register("p", "op", f"registered with token={FAKE_KEY}")
        self.assertNotIn(FAKE_KEY, "".join(e.payload for e in lc.log.entries()))

    def test_runtime_error_does_not_leak_through_readiness(self):
        rt = Runtime.build_for_tests(env())
        _, g = build_current(ROOT)
        g.issue_report()
        out = rt.handle({"profile_alias": ALIAS, "prompt": PROMPT})
        self.assertNotIn("STAGE1047-SECRET-KEY-USAGE-QQ", repr(out) + repr(g.log.entries()))


class CurrentState(unittest.TestCase):
    def test_five_providers_honest_and_real_hashes(self):
        c = Clock(datetime.now(timezone.utc))
        s, g = build_current(ROOT, c)
        self.assertEqual(sorted(s.providers()), ["anthropic", "gemini", "grok", "grok_responses", "openai"])
        for p in s.providers():
            a = g.evaluate(p)
            self.assertEqual(a.overall, Status.UNVERIFIED)
            self.assertFalse(a.production_ready)
            self.assertNotIn(Status.PASS, [r.status for r in a.results])
        r = s.records("openai")[0]
        path = os.path.join(ROOT, r.source.removeprefix("repo://"))
        with open(path, "rb") as fh:
            self.assertEqual(hashlib.sha256(fh.read()).hexdigest(), r.artifact_sha256)
        self.assertFalse([r for r in s.records() if r.kind is EvidenceKind.LIVE])
        self.assertTrue(s.verify_integrity())

    def test_report_for_all_five(self):
        _, g = build_current(ROOT)
        rep = g.get_report(g.issue_report())
        self.assertEqual(len(rep["providers"]), 5)
        self.assertTrue(all(not p["production_ready"] for p in rep["providers"]))


class OfflineAndIsolation(unittest.TestCase):
    def test_no_external_or_network_imports(self):
        d = os.path.join(ROOT, "src", "sanour_ai", "readiness")
        for f in os.listdir(d):
            if f.endswith(".py"):
                with open(os.path.join(d, f), encoding="utf-8") as fh:
                    src = fh.read()
                for m in re.findall(r"^\s*(?:from|import)\s+([A-Za-z_][\w.]*)", src, re.M):
                    top = m.split(".")[0]
                    self.assertIn(top, {"sanour_ai", "__future__", "hashlib", "json", "os", "threading", "dataclasses",
                                        "datetime", "enum", "collections", "re", "typing"}, f"{f}: {m}")
                for bad in ("retry(", "fallback(", "auto_select", "random"):
                    self.assertNotIn(bad, src.lower(), f)

    def test_core_never_imports_readiness(self):
        for sub in ("core", "models", "composition", "providers", "governance", "ledger", "observability"):
            base = os.path.join(ROOT, "src", "sanour_ai", sub)
            for f in os.listdir(base):
                if f.endswith(".py") and f != "readiness.py":
                    with open(os.path.join(base, f), encoding="utf-8") as fh:
                        self.assertNotIn("sanour_ai.readiness", fh.read(), f"{sub}/{f}")


class RuntimeIntegration(unittest.TestCase):
    def test_readiness_failure_does_not_block_or_redirect(self):
        usage = Usage(input_tokens=10, output_tokens=5, total_tokens=15)

        class P(OfflineTestProvider):
            calls = 0
            def generate(self, call):
                P.calls += 1
                return ModelResult(text="ok", reported_model_id=call.model_id, usage=usage)

        rt = Runtime.build_for_tests(env(), provider=P())
        _, g = build_current(ROOT)
        self.assertFalse(any(a.production_ready for a in [g.evaluate(p) for p in ("openai",)]))
        for _ in range(3):
            g.issue_report()
            out = rt.handle({"profile_alias": ALIAS, "prompt": PROMPT})
            self.assertEqual(out.status, "success")
            self.assertEqual(out.model_alias, ALIAS)
        self.assertEqual(P.calls, 3)                                  # exactly one attempt per request
        t = rt.usage_summary()["total"]
        self.assertEqual((t["requests"], t["requests_with_usage"]), (3, 3))
        self.assertEqual(t["tokens"]["total_tokens"]["sum"], 45)       # accounting consistent

    def test_unknown_profile_is_refused_not_redirected(self):
        calls = []
        class P(OfflineTestProvider):
            def generate(self, call):
                calls.append(call)
                return ModelResult(text="ok", reported_model_id=call.model_id)
        rt = Runtime.build_for_tests(env(), provider=P())
        out = rt.handle({"profile_alias": "not_a_profile", "prompt": PROMPT})
        self.assertNotEqual(out.status, "success")
        self.assertEqual(calls, [])

    def test_deadline_preserved_while_governance_runs(self):
        import time
        provider = GatedProvider()
        core = make_core({"mock": provider}, [profile("test_model", "mock")])
        _, g = build_current(ROOT)
        stop = threading.Event()
        t = threading.Thread(target=lambda: [g.evaluate("openai") for _ in iter(stop.is_set, True)])
        t.start()
        try:
            start = time.monotonic()
            resp = core.handle({"profile_alias": "test_model", "prompt": "hi", "timeout_seconds": 0.3})
            elapsed = time.monotonic() - start
        finally:
            stop.set(); t.join(); provider.release_all()
        self.assertEqual(resp.status, "error")
        self.assertLess(elapsed, 0.3 + TOLERANCE_SECONDS + 0.2)
        self.assertEqual(provider.calls, 1)
        wait_until(lambda: core._gateway.in_flight == 0)

    def test_semaphore_held_until_worker_really_returns(self):
        provider = GatedProvider()
        core = make_core({"mock": provider}, [profile("test_model", "mock")], max_concurrent=1)
        _, g = build_current(ROOT)
        first = core.handle({"profile_alias": "test_model", "prompt": "hi", "timeout_seconds": 0.05})
        self.assertEqual(first.status, "error")
        g.issue_report()                                   # governance activity must not free the slot
        self.assertEqual(core._gateway.in_flight, 1)
        second = core.handle({"profile_alias": "test_model", "prompt": "hi", "timeout_seconds": 1})
        self.assertEqual(second.error.code.value if hasattr(second.error.code, "value") else second.error.code,
                         "provider_overloaded")
        self.assertEqual(provider.calls, 1)
        provider.release_all()
        self.assertTrue(wait_until(lambda: core._gateway.in_flight == 0))


if __name__ == "__main__":
    unittest.main()
