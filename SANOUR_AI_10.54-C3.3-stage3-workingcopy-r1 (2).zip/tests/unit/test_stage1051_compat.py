"""Stage 10.51: compatibility contracts, SDK boundary, per-provider failure isolation. Offline. No SDK, no network.

Covers only what is new in this stage. Existing adapter conformance is in earlier modules and is not repeated.
"""

import ast
import importlib.metadata as metadata
import json
import os
import time
import unittest

from pydantic import SecretStr

from sanour_ai.config.settings import ConfigError
from sanour_ai.errors import SanourError
from sanour_ai.models.base import ModelCall
from sanour_ai.models.capabilities import ModelCapabilities, ModelProfile
from sanour_ai.models.gateway import ModelGateway
from sanour_ai.providers import anthropic_provider as ap
from sanour_ai.providers import compatibility as compat
from sanour_ai.providers import gemini_provider as gp
from sanour_ai.providers import grok_provider as grp
from sanour_ai.providers import openai_provider as op
from sanour_ai.providers import xai_responses_provider as xp
from tests.support import request_identity_for as _rid

REPO = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
SRC = os.path.join(REPO, "src")
MODEL = "test-model-1"
KEY = "TESTONLY-stage1051-dummy-key"


class Transport:
    def __init__(self, status, body):
        self.status, self.body, self.calls = status, body, 0

    def __call__(self, url, headers, body, timeout):
        self.calls += 1
        return self.status, self.body


def ok_body(name):
    bodies = {
        "anthropic": {"model": MODEL, "stop_reason": "end_turn", "content": [{"type": "text", "text": "ok"}]},
        "gemini": {"candidates": [{"content": {"parts": [{"text": "ok"}]}, "finishReason": "STOP"}],
                   "modelVersion": MODEL},
        "grok": {"model": MODEL, "choices": [{"finish_reason": "stop", "message": {"content": "ok"}}]},
        "grok_responses": {"model": MODEL, "status": "completed",
                           "output": [{"type": "message", "status": "completed",
                                       "content": [{"type": "output_text", "text": "ok"}]}]},
    }
    return json.dumps(bodies[name]).encode()


def build_http(name, transport):
    cls = {"anthropic": ap.AnthropicProvider, "gemini": gp.GeminiProvider,
           "grok": grp.GrokProvider, "grok_responses": xp.XaiResponsesProvider}[name]
    return cls(SecretStr(KEY), transport=transport)


def profile(name):
    return ModelProfile(alias=f"{name}_profile", provider=name, model_id=MODEL,
                        capabilities=ModelCapabilities(text_generation=True, max_context_tokens=8192,
                                                       max_output_tokens=4096),
                        runs_locally=False)


def call():
    return ModelCall(model_id=MODEL, prompt="hi", max_output_tokens=16, deadline=time.monotonic() + 5)


class ContractMatchesAdapter(unittest.TestCase):
    ADAPTERS = {
        "openai": op.OpenAIProvider, "anthropic": ap.AnthropicProvider, "gemini": gp.GeminiProvider,
        "grok": grp.GrokProvider, "grok_responses": xp.XaiResponsesProvider,
    }

    def test_every_adapter_has_exactly_one_contract_and_the_schema_is_version_1(self):
        self.assertEqual(set(compat.CONTRACTS), set(self.ADAPTERS))
        self.assertEqual(compat.CONTRACT_SCHEMA, 1)

    def test_contract_fields_equal_the_adapter_class_attributes(self):
        for key, cls in self.ADAPTERS.items():
            with self.subTest(provider=key):
                c = compat.CONTRACTS[key]
                self.assertEqual((c.provider, c.adapter), (cls.name, cls.__name__))
                self.assertEqual((c.surface, c.auth_method), (cls.surface, cls.auth_method))
                self.assertTrue(c.contract_version)

    def test_pinned_endpoints_in_the_contract_equal_the_constants_coded_in_each_adapter(self):
        coded = {"openai": op.PINNED_BASE_URL, "anthropic": ap.PINNED_URL, "gemini": gp.PINNED_BASE,
                 "grok": grp.PINNED_URL, "grok_responses": xp.PINNED_URL}
        for key, endpoint in coded.items():
            with self.subTest(provider=key):
                self.assertEqual(compat.CONTRACTS[key].endpoint, endpoint)

    def test_no_provider_is_verified_for_production(self):
        self.assertTrue(all(c.verified_production is False for c in compat.CONTRACTS.values()))

    def test_only_openai_declares_sdk_pins_and_they_match_the_pyproject(self):
        pins = {key: c.sdk_pins for key, c in compat.CONTRACTS.items()}
        self.assertEqual(pins["openai"], (("openai", "3.45.0"), ("httpx2", "2.13.1")))
        self.assertTrue(all(pins[k] == () for k in pins if k != "openai"))
        with open(os.path.join(REPO, "pyproject.toml"), encoding="utf-8") as handle:
            text = handle.read()
        self.assertIn('"openai==3.45.0"', text)
        self.assertIn('"httpx2==2.13.1"', text)


class SdkPinGate(unittest.TestCase):
    @staticmethod
    def lookup(installed):
        def fake(package):
            if package not in installed:
                raise metadata.PackageNotFoundError(package)
            return installed[package]
        return fake

    def test_missing_pinned_package_is_a_named_rule(self):
        problems = compat.sdk_problems(compat.CONTRACTS["openai"], self.lookup({}))
        self.assertEqual(problems, ["openai is not installed", "httpx2 is not installed"])

    def test_wrong_version_is_a_named_rule_and_never_prints_the_version(self):
        problems = compat.sdk_problems(compat.CONTRACTS["openai"],
                                       self.lookup({"openai": "9.9.9", "httpx2": "2.13.1"}))
        self.assertEqual(problems, ["openai is not the pinned version"])
        self.assertNotIn("9.9.9", " ".join(problems))

    def test_exact_pins_pass(self):
        self.assertEqual(compat.sdk_problems(compat.CONTRACTS["openai"],
                                             self.lookup({"openai": "3.45.0", "httpx2": "2.13.1"})), [])

    def test_providers_without_sdk_pins_never_consult_the_lookup(self):
        def boom(package):
            raise AssertionError("no lookup expected")
        for key in ("anthropic", "gemini", "grok", "grok_responses"):
            with self.subTest(provider=key):
                self.assertEqual(compat.sdk_problems(compat.CONTRACTS[key], boom), [])

    def test_require_sdk_refuses_with_rule_names_only(self):
        with self.assertRaises(ConfigError) as caught:
            compat.require_sdk("openai", self.lookup({"openai": "9.9.9", "httpx2": "2.13.1"}))
        text = str(caught.exception)
        self.assertIn("compatibility contract not met for openai", text)
        self.assertIn("not the pinned version", text)
        self.assertNotIn("9.9.9", text)

    def test_unknown_provider_has_no_contract_and_is_refused(self):
        with self.assertRaises(ConfigError):
            compat.require_sdk("no-such-provider", self.lookup({}))

    def test_default_openai_client_build_is_refused_without_the_pinned_sdk(self):
        try:
            metadata.version("openai")
            self.skipTest("openai is installed here: the refusal path is not exercised")
        except metadata.PackageNotFoundError:
            pass
        with self.assertRaises(ConfigError) as caught:
            op._build_default_client(SecretStr(KEY))
        self.assertIn("compatibility contract not met for openai", str(caught.exception))


class SdkBoundary(unittest.TestCase):
    """Only the OpenAI adapter may import the SDK or httpx packages. Static, stdlib only."""
    FORBIDDEN = {"openai", "httpx2", "httpx"}
    ALLOWED = {os.path.join("src", "sanour_ai", "providers", "openai_provider.py")}

    def test_no_other_module_imports_the_sdk_or_httpx(self):
        offenders = []
        for root, _dirs, files in os.walk(SRC):
            for name in files:
                if not name.endswith(".py"):
                    continue
                path = os.path.join(root, name)
                rel = os.path.relpath(path, REPO)
                with open(path, encoding="utf-8") as handle:
                    tree = ast.parse(handle.read())
                for node in ast.walk(tree):
                    names = []
                    if isinstance(node, ast.Import):
                        names = [alias.name.split(".")[0] for alias in node.names]
                    elif isinstance(node, ast.ImportFrom) and node.module:
                        names = [node.module.split(".")[0]]
                    if any(n in self.FORBIDDEN for n in names) and rel not in self.ALLOWED:
                        offenders.append(rel)
        self.assertEqual(offenders, [])

    def test_the_boundary_module_is_stdlib_only(self):
        with open(os.path.join(SRC, "sanour_ai", "providers", "compatibility.py"), encoding="utf-8") as handle:
            tree = ast.parse(handle.read())
        imported = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                imported.update(a.name.split(".")[0] for a in node.names)
            elif isinstance(node, ast.ImportFrom) and node.module:
                imported.add(node.module.split(".")[0])
        self.assertNotIn("openai", imported)
        self.assertNotIn("httpx2", imported)


class FailureIsolation(unittest.TestCase):
    """One adapter failing must not change another adapter's result, usage, or transport calls. No fallback."""
    ORDER = ["anthropic", "gemini", "grok", "grok_responses"]

    def test_each_http_adapter_failing_leaves_the_others_untouched(self):
        for index, broken in enumerate(self.ORDER):
            healthy = self.ORDER[(index + 1) % len(self.ORDER)]
            with self.subTest(broken=broken, healthy=healthy):
                bad_transport = Transport(500, b"{}")
                good_transport = Transport(200, ok_body(healthy))
                providers = {broken: build_http(broken, bad_transport), healthy: build_http(healthy, good_transport)}
                gateway = ModelGateway(providers, max_concurrent_calls=4)
                with self.assertRaises(SanourError):
                    gateway.generate(profile(broken), call(), time.monotonic() + 5, identity=_rid(profile(broken)))
                self.assertEqual(good_transport.calls, 0)  # no fallback to the healthy provider
                self.assertEqual(bad_transport.calls, 1)   # no automatic retry
                result = gateway.generate(profile(healthy), call(), time.monotonic() + 5,
                                          identity=_rid(profile(healthy)))
                self.assertEqual(result.text, "ok")
                self.assertEqual(good_transport.calls, 1)
                self.assertEqual(bad_transport.calls, 1)

    def test_an_adapter_refused_at_construction_is_never_registered_and_others_still_serve(self):
        registry = {}
        try:
            registry["openai"] = op.OpenAIProvider(SecretStr(KEY), client=object())
        except ConfigError:
            pass
        self.assertNotIn("openai", registry)
        good = Transport(200, ok_body("anthropic"))
        registry["anthropic"] = build_http("anthropic", good)
        gateway = ModelGateway(registry, max_concurrent_calls=2)
        self.assertEqual(gateway.generate(profile("anthropic"), call(), time.monotonic() + 5,
                                          identity=_rid(profile("anthropic"))).text, "ok")
        self.assertEqual(good.calls, 1)


if __name__ == "__main__":
    unittest.main()
