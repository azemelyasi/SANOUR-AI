"""Stage 10.43: BaseException-safe settler cleanup, exactly-once notifications, and the final checks.

Offline only: fake providers, no SDK, no network, no key. Every wait is bounded or event-driven.
"""

import threading
import unittest
from unittest import mock

from sanour_ai.providers.offline_contract import OfflineTestProvider
from sanour_ai.composition import production
from sanour_ai.composition.runtime import Runtime, RuntimeState
from sanour_ai.models.gateway import SettlementAborted
from tests.unit import test_stage1039 as base
from tests.unit.test_stage1041 import Probe, make, start_call, settler_threads
from tests.support import wait_until

SECRET = "STAGE1043-SECRET-VALUE-QW"


class CloseAbort(BaseException):
    """A BaseException that close() raises. Not an Exception, so the old code never caught it."""


class AbortingProbe(Probe):
    def close(self):
        super().close()
        raise CloseAbort(SECRET)


class SettlerCleanup(unittest.TestCase):
    def setUp(self):
        self.hook_calls = []
        patcher = mock.patch("threading.excepthook", side_effect=self.hook_calls.append)
        patcher.start()
        self.addCleanup(patcher.stop)

    def test_settler_base_exception_is_recorded_failed_and_fully_cleared(self):  # req 1, 2, 3
        probe = AbortingProbe()
        gw = make(probe)
        events = []
        gw.add_settlement_observer(lambda name, outcome: events.append((name, outcome)))
        t, _ = start_call(gw)
        gw.shutdown(0.01)
        with self.assertLogs(level="WARNING") as captured:
            probe.gate.set()
            t.join(3.0)
            self.assertTrue(probe.settled.wait(2.0))
            self.assertTrue(wait_until(lambda: not settler_threads(), timeout=2.0))
        self.assertIn("CloseAbort", "\n".join(captured.output))       # type name is logged
        self.assertNotIn(SECRET, "\n".join(captured.output))          # the text never is
        self.assertEqual(events, [("mock", "failed")])                 # terminal failure, announced once
        snap = gw.settlement_snapshot()
        self.assertEqual(snap["phases"], {"mock": "failed"})           # not falsely "closing"
        self.assertEqual(snap["active_settlers"], 0)                    # bookkeeping cleared
        self.assertEqual(snap["providers_closing"], 0)
        self.assertEqual(gw.stats().provider_close_failures, 1)
        self.assertEqual(probe.close_calls, 1)
        # The settler ended with a sanitized error: type name only, never the message.
        self.assertEqual(len(self.hook_calls), 1)
        raised = self.hook_calls[0].exc_value
        self.assertIsInstance(raised, SettlementAborted)
        self.assertEqual(str(raised), "CloseAbort")
        self.assertNotIn(SECRET, repr(self.hook_calls[0]))

    def test_repeated_shutdown_never_closes_or_notifies_again(self):  # req 4
        probe = AbortingProbe()
        gw = make(probe)
        events = []
        gw.add_settlement_observer(lambda name, outcome: events.append((name, outcome)))
        t, _ = start_call(gw)
        gw.shutdown(0.01)
        probe.gate.set()
        t.join(3.0)
        self.assertTrue(probe.settled.wait(2.0))
        for _ in range(3):
            gw.shutdown(0.01)
        self.assertEqual(probe.close_calls, 1)
        self.assertEqual(events, [("mock", "failed")])

    def test_idle_provider_base_exception_is_recorded_then_reraised(self):
        probe = AbortingProbe()
        gw = make(probe)
        events = []
        gw.add_settlement_observer(lambda name, outcome: events.append((name, outcome)))
        with self.assertRaises(CloseAbort):
            gw.shutdown(0.01)  # an idle close runs in the caller; the exception is re-raised, not swallowed
        self.assertEqual(events, [("mock", "failed")])
        self.assertEqual(gw.settlement_snapshot()["phases"], {"mock": "failed"})
        self.assertEqual(gw.settlement_snapshot()["active_settlers"], 0)
        self.assertEqual(gw.stats().provider_close_failures, 1)
        self.assertNotIn(SECRET, repr(gw.stats()) + repr(gw.settlement_snapshot()))
        gw.shutdown(0.01)
        self.assertEqual(probe.close_calls, 1)


class RuntimeAfterBaseException(base.Base):
    def test_runtime_reaches_shutdown_when_all_providers_are_settled(self):  # req 4, 5
        hook = mock.patch("threading.excepthook")  # Stage 10.51: the settler's sanitized re-raise is expected here
        hook.start()
        self.addCleanup(hook.stop)
        class AbortClose(base.LifeOpenAI):
            def close(self):
                self.close_count += 1
                raise CloseAbort(SECRET)

        with mock.patch.object(production, "OpenAIProvider", AbortClose), mock.patch.object(production, "_default_test_provider", lambda: AbortClose("test")), \
                mock.patch.object(production, "_sdk_present", return_value=True):
            rt = Runtime.build_for_tests(base.env())
            announcements = []
            rt._registry.add_settlement_listener(lambda: announcements.append(1))
            base.LifeOpenAI.gate = threading.Event()
            result = {}
            t = threading.Thread(target=lambda: result.setdefault(
                "r", rt.handle({"profile_alias": "openai_primary", "prompt": "hi"})))
            t.start()
            self.assertTrue(wait_until(lambda: ("start", None) in base.LifeOpenAI.events, timeout=2.0))
            rt.shutdown(0.01)
            self.assertIs(rt.state, RuntimeState.DRAINING)
            base.LifeOpenAI.gate.set()
            t.join(3.0)
            self.assertTrue(rt.wait_stopped(2.0))                      # not stuck in DRAINING
            self.assertIs(rt.state, RuntimeState.SHUTDOWN)
            stats = rt.stats()
            self.assertEqual(stats["providers"], {"openai": "failed"})
            self.assertEqual(stats["settlement"]["active_settlers"], 0)
            self.assertEqual(stats["settlement"]["providers_closing"], 0)
            self.assertEqual(stats["provider_close_failures"], 1)
            for _ in range(3):
                rt.shutdown(0.01)
            # Runtime.shutdown() returns early once SHUTDOWN; drive the registry's own shutdown path too.
            for _ in range(3):
                rt._registry.shutdown(rt._core.shutdown_target(), 0.01)
            self.assertEqual(sum(1 for a in base.LifeOpenAI.instances if a.close_count), 1)
            self.assertEqual(len(announcements), 1)                    # listeners notified exactly once
            self.assertNotIn(SECRET, repr(stats))

    def test_runtime_idle_base_exception_still_reaches_shutdown(self):
        class AbortClose(base.LifeOpenAI):
            def close(self):
                self.close_count += 1
                raise CloseAbort(SECRET)

        with mock.patch.object(production, "OpenAIProvider", AbortClose), mock.patch.object(production, "_default_test_provider", lambda: AbortClose("test")), \
                mock.patch.object(production, "_sdk_present", return_value=True):
            rt = Runtime.build_for_tests(base.env())
            with self.assertRaises(CloseAbort):
                rt.shutdown(0.01)
            self.assertTrue(rt.wait_stopped(2.0))
            self.assertIs(rt.state, RuntimeState.SHUTDOWN)
            self.assertEqual(rt.stats()["providers"], {"openai": "failed"})


if __name__ == "__main__":
    unittest.main()
