"""Stage 10.49-R3 outbox behaviour, re-based on the Stage 10.49-R4 durable sink and leased claims.

Governance decisions are committed in the governance database. Their audit events are outbox rows in the same
transaction, and are delivered to a separate durable sink only after commit. Crash scenarios use real child processes.
"""

import pathlib
import logging
import os
import sqlite3
import tempfile
import unittest
from decimal import Decimal

from sanour_ai.governance.admission import AdmissionController
from sanour_ai.governance.store import _MIGRATIONS, GovernanceStore
from sanour_ai.governance.types import Settlement
from sanour_ai.models.usage import Usage
from sanour_ai.observability.audit import AuditLogger
from tests.unit.r4_support import ACTOR, CRASH_CHILD, RecordingSink, run_child
from tests.unit.test_stage1049 import BOUNDS, Clock, pricing, profile, request

VALID = Usage(input_tokens=4, output_tokens=2)
ACTUAL_24 = Decimal("0.000024")
WORST_512 = Decimal("0.02048")


class _FailOn:
    """Wraps a connection and fails any statement that starts with the given prefix."""

    def __init__(self, real, prefix):
        self._real, self._prefix = real, prefix

    def execute(self, sql, *args):
        if sql.startswith(self._prefix):
            raise sqlite3.OperationalError("disk I/O error")
        return self._real.execute(sql, *args)

    def close(self):
        self._real.close()


class Base(unittest.TestCase):
    def setUp(self):
        self._dir = tempfile.TemporaryDirectory()
        self.addCleanup(self._dir.cleanup)
        self.path = os.path.join(self._dir.name, "gov.db")
        self.clock = Clock()
        self.s = GovernanceStore(self.path)
        self.addCleanup(self.s.close)
        self.s.upsert_pricing(pricing())
        self.bid = self.s.upsert_budget("global", "", "daily", "USD", "1.00")
        self.audit = AuditLogger(logging.getLogger("test.1049r3"))
        self.sink = RecordingSink(self.path + ".sink", self.path)
        self.addCleanup(self.sink.close)
        self.c = self.controller(self.s, self.audit, self.sink)

    def controller(self, store, audit, sink):
        return AdmissionController(store, audit=audit, bounds=BOUNDS, clock=self.clock,
                                   authorized_actors=frozenset({ACTOR}), sink=sink)

    def q(self, sql, *args):
        conn = sqlite3.connect(self.path)
        try:
            return conn.execute(sql, args).fetchall()
        finally:
            conn.close()

    def one(self, sql, *args):
        return self.q(sql, *args)[0][0]

    def spent(self):
        return Decimal(self.one("SELECT spent FROM budget_windows WHERE budget_id = ?", self.bid))

    def written_off(self):
        return Decimal(self.one("SELECT written_off FROM budget_windows WHERE budget_id = ?", self.bid))

    def exposed(self):
        return Decimal(self.one("SELECT exposed FROM budget_windows WHERE budget_id = ?", self.bid))

    def state(self, rid):
        return self.one("SELECT state FROM reservations WHERE request_id = ?", rid)

    def exposed_request(self):
        t = self.c.admit(request(), profile())
        self.c.settle(t, Settlement("failed", True))
        self.assertEqual(self.state(t.request_id), "exposed")
        return t.request_id

    def log_id_for(self, rid):
        return self.one("SELECT log_id FROM governance_log WHERE request_id = ? AND operation = 'write_off' "
                        "AND outcome = 'ok'", rid)

    def key_for(self, rid):
        return f"gov:{self.log_id_for(rid)}:exposure.resolved"

    def fail_next(self, prefix):
        real = self.s._conn  # noqa: SLF001
        self.s._conn = _FailOn(real, prefix)  # noqa: SLF001
        return real

    def restore(self, real):
        self.s._conn = real  # noqa: SLF001

    def restart(self, sink_cls_path=None):
        """A new process view: fresh governance store, fresh controller, same files. Lease expiry is reached by
        advancing the clock past the lease the crashed worker wrote."""
        sink = RecordingSink(self.path + ".sink", self.path)
        self.addCleanup(sink.close)
        c = AdmissionController(GovernanceStore(self.path), audit=AuditLogger(logging.getLogger("test.restart")),
                                bounds=BOUNDS, clock=self.clock, authorized_actors=frozenset({ACTOR}), sink=sink)
        self.addCleanup(c.close)
        return sink, c

    def run_crash(self, mode, rid):
        receipts = os.path.join(self._dir.name, f"receipts-{mode}.txt")
        done = run_child(CRASH_CHILD, [self.path, self.path + ".sink", mode, receipts, rid])
        seen = pathlib.Path(receipts).read_text(encoding="utf-8").split("\n") if os.path.exists(receipts) else []
        return done.returncode, [line for line in seen if line]

    def sink_row(self, sql, *args):
        conn = sqlite3.connect(self.path + ".sink")
        try:
            return conn.execute(sql, args).fetchone()[0]
        finally:
            conn.close()

    def sink_receipts_total(self, event):
        conn = sqlite3.connect(self.path + ".sink")
        try:
            return conn.execute("SELECT COUNT(*) FROM audit_receipts WHERE event = ?", (event,)).fetchone()[0]
        finally:
            conn.close()

    def sink_receipts(self, key):
        """Logical receipts the sink holds for one outbox key (the sink also holds other events, so count per key)."""
        conn = sqlite3.connect(self.path + ".sink")
        try:
            return conn.execute("SELECT COUNT(*) FROM audit_receipts WHERE outbox_key = ?", (key,)).fetchone()[0]
        finally:
            conn.close()

    def snapshot(self):
        return {
            "write_off_ok": self.one("SELECT COUNT(*) FROM governance_log WHERE operation = 'write_off' "
                                     "AND outcome = 'ok'"),
            "log_rows": self.one("SELECT COUNT(*) FROM governance_log"),
            "resolutions": self.one("SELECT COUNT(*) FROM exposure_resolutions"),
            "written_off": self.written_off(),
            "exposed": self.exposed(),
            "spent": self.spent(),
        }


# ------------------------------------------------------------------ commit boundary
class CommitBoundary(Base):
    def test_transaction_commit_failure_leaves_no_mutation_and_no_success_record(self):
        rid = self.exposed_request()
        self.sink.attempts.clear()
        real = self.fail_next("COMMIT")
        result = self.c.write_off(rid, actor=ACTOR, reason="commit will fail")
        self.restore(real)
        self.assertFalse(result.applied)
        self.assertEqual(result.reason, "storage_error")
        self.assertEqual(self.state(rid), "exposed")
        self.assertEqual(self.exposed(), WORST_512)
        self.assertEqual(self.written_off(), Decimal(0))
        self.assertEqual(self.one("SELECT COUNT(*) FROM exposure_resolutions"), 0)
        self.assertEqual(self.one("SELECT COUNT(*) FROM governance_log WHERE operation = 'write_off' "
                                  "AND outcome = 'ok'"), 0)
        self.assertEqual(self.one("SELECT COUNT(*) FROM audit_outbox WHERE event = 'exposure.resolved'"), 0)
        self.assertEqual(self.sink.attempts, [], "no sink delivery for a rolled-back decision")

    def test_outbox_insert_failure_is_fail_closed_before_commit(self):
        rid = self.exposed_request()
        self.sink.attempts.clear()
        real = self.fail_next("INSERT INTO audit_outbox")
        result = self.c.write_off(rid, actor=ACTOR, reason="outbox write fails")
        self.restore(real)
        self.assertFalse(result.applied)
        self.assertEqual(result.reason, "storage_error")
        self.assertEqual(self.state(rid), "exposed")
        self.assertEqual(self.written_off(), Decimal(0))
        self.assertEqual(self.one("SELECT COUNT(*) FROM exposure_resolutions"), 0)
        self.assertEqual(self.sink.attempts, [])

    def test_no_external_delivery_before_commit_on_any_mutation_path(self):
        rid = self.exposed_request()
        self.sink.attempts.clear()
        self.c.resolve_exposure(self.exposed_request(), VALID, actor=ACTOR)
        self.c.write_off(rid, actor=ACTOR, reason="ordering")
        self.assertTrue(self.sink.attempts)
        self.assertTrue(all(visible for _, _, visible in self.sink.attempts))

    def test_outbox_row_and_governance_decision_commit_together(self):
        rid = self.exposed_request()
        self.sink.down = True
        result = self.c.write_off(rid, actor=ACTOR, reason="atomic pair")
        self.assertTrue(result.applied)
        row = self.q("SELECT o.log_id, o.status, g.operation, g.outcome, g.actor FROM audit_outbox o "
                     "JOIN governance_log g ON g.log_id = o.log_id WHERE o.event = 'exposure.resolved'")
        self.assertEqual(len(row), 1)
        self.assertEqual(row[0][1:], ("failed", "write_off", "ok", ACTOR))
        self.assertEqual(self.one("SELECT COUNT(*) FROM exposure_resolutions WHERE request_id = ?", rid), 1)


# ------------------------------------------------------------------ delivery states
class Delivery(Base):
    def test_confirmed_only_after_the_sink_commit_returns(self):
        rid = self.exposed_request()
        result = self.c.write_off(rid, actor=ACTOR, reason="confirmed")
        self.assertEqual(result.audit_status, "confirmed")
        status, attempts, receipt_id = self.q("SELECT status, attempts, receipt_id FROM audit_outbox "
                                              "WHERE event = 'exposure.resolved'")[0]
        self.assertEqual((status, attempts), ("delivered", 1))
        self.assertEqual(self.sink.receipts[-1].receipt_id, receipt_id)

    def test_audit_sink_failure_is_failed_not_success_and_not_a_rollback(self):
        rid = self.exposed_request()
        self.sink.down = True
        result = self.c.resolve_exposure(rid, VALID, actor=ACTOR, evidence_ref="billing-2026-11-07")
        self.assertTrue(result.applied)
        self.assertEqual(result.audit_status, "failed")
        self.assertEqual(self.state(rid), "settled")
        self.assertEqual(self.spent(), ACTUAL_24)
        self.assertEqual(self.exposed(), Decimal(0))
        status, last_error = self.q("SELECT status, last_error FROM audit_outbox WHERE event = 'exposure.resolved'")[0]
        self.assertEqual((status, last_error), ("failed", "sink_failed"))

    def test_failed_delivery_is_retried_on_recovery_and_never_discarded(self):
        rid = self.exposed_request()
        self.sink.down = True
        self.c.write_off(rid, actor=ACTOR, reason="retry me")
        self.sink.down = False
        sink, c2 = self.restart()
        c2.sweep()
        self.assertEqual(sink.accepted_keys("exposure.resolved"), [self.key_for(rid)])
        self.assertEqual(self.one("SELECT status FROM audit_outbox WHERE event = 'exposure.resolved'"), "delivered")

    def test_duplicate_delivery_is_idempotent_and_returns_the_original_receipt(self):
        rid = self.exposed_request()
        self.c.write_off(rid, actor=ACTOR, reason="once only")
        key = self.key_for(rid)
        original = self.sink.receipts[-1]
        self.assertEqual(self.c.deliver_outbox(), 0)
        self.assertEqual(self.c.deliver_outbox(keys=[key]), 0)
        self.assertEqual(self.sink.accepted_keys("exposure.resolved"), [key])
        self.assertEqual(self.sink_receipts(key), 1)
        again = self.sink.deliver(key, "exposure.resolved", {"request_id": rid, "resolution": "write_off",
                                                             "actor": ACTOR, "decision": "applied"})
        self.assertTrue(again.duplicate)
        self.assertEqual(again.receipt_id, original.receipt_id)


# ------------------------------------------------------------------ crash and restart (real processes)
class CrashRecovery(Base):
    def test_process_crash_after_commit_before_delivery_recovers_exactly_once(self):
        rid = self.exposed_request()
        code, seen = self.run_crash("crash_before_sink", rid)
        self.assertEqual(code, 3, "child must die after the governance commit")
        self.assertEqual(seen, [])
        self.assertEqual(self.state(rid), "written_off")
        self.assertEqual(self.one("SELECT status FROM audit_outbox WHERE event = 'exposure.resolved'"), "pending")
        before = self.snapshot()
        self.clock.now += 61  # the dead worker's lease has expired
        sink, c2 = self.restart()
        c2.sweep()
        self.assertEqual(sink.accepted_keys("exposure.resolved"), [self.key_for(rid)])
        c2.sweep()
        self.assertEqual(sink.accepted_keys("exposure.resolved"), [self.key_for(rid)])
        self.assertEqual(self.one("SELECT status FROM audit_outbox WHERE event = 'exposure.resolved'"), "delivered")
        self.assertEqual(self.snapshot(), before, "recovery adds no decision and moves no money")
        self.assertEqual(self.written_off(), WORST_512)

    def test_crash_after_sink_commit_then_duplicate_delivery_writes_one_receipt(self):
        rid = self.exposed_request()
        code, seen = self.run_crash("crash_after_sink", rid)
        self.assertEqual(code, 4)
        key = self.key_for(rid)
        self.assertEqual(len(seen), 1)
        first_receipt = int(seen[0].split()[1])
        self.assertEqual(self.one("SELECT status FROM audit_outbox WHERE event = 'exposure.resolved'"), "pending")
        before = self.snapshot()
        self.clock.now += 61
        sink, c2 = self.restart()
        c2.sweep()
        self.assertEqual(sink.accepted_keys("exposure.resolved"), [key], "the restarted worker delivers again")
        self.assertTrue(sink.receipts[-1].duplicate)
        self.assertEqual(sink.receipts[-1].receipt_id, first_receipt)
        self.assertEqual(self.sink_receipts(key), 1)
        self.assertEqual(self.snapshot(), before)
        self.assertEqual(self.one("SELECT receipt_id FROM audit_outbox WHERE event = 'exposure.resolved'"),
                         first_receipt)


# ------------------------------------------------------------------ consistency
class Consistency(Base):
    def test_governance_log_and_financial_state_agree(self):
        a = self.c.admit(request(), profile())
        self.c.settle(a, Settlement("completed", True, VALID))
        b = self.exposed_request()
        cc = self.exposed_request()
        self.c.write_off(b, actor=ACTOR, reason="consistency write-off")
        self.c.resolve_exposure(cc, VALID, actor=ACTOR)
        self.assertEqual(self.one("SELECT COUNT(*) FROM reservations"), 3)
        self.assertEqual(self.one("SELECT COUNT(*) FROM reservations r WHERE NOT EXISTS (SELECT 1 FROM governance_log g "
                                  "WHERE g.request_id = r.request_id AND g.operation = 'admit' AND g.outcome = 'ok')"), 0)
        self.assertEqual(self.one("SELECT COUNT(*) FROM exposure_resolutions"), 2)
        self.assertEqual(self.one("SELECT COUNT(*) FROM audit_outbox WHERE event = 'exposure.resolved'"), 2)
        self.assertEqual(self.one("SELECT COUNT(*) FROM audit_outbox o LEFT JOIN governance_log g ON g.log_id = o.log_id "
                                  "WHERE g.log_id IS NULL"), 0)
        self.assertEqual(self.one("SELECT COUNT(*) FROM audit_outbox WHERE status != 'delivered'"), 0)
        self.assertEqual(self.spent(), ACTUAL_24 * 2)
        self.assertEqual(self.written_off(), WORST_512)
        self.assertEqual(self.exposed(), Decimal(0))
        self.assertEqual(Decimal(self.one("SELECT reserved FROM budget_windows WHERE budget_id = ?", self.bid)),
                         Decimal(0))

    def test_settlement_events_are_committed_with_the_settlement_and_confirmed(self):
        a = self.c.admit(request(), profile())
        self.sink.attempts.clear()
        result = self.c.settle(a, Settlement("completed", True, VALID))
        self.assertEqual(result.audit_status, "confirmed")
        rows = self.q("SELECT o.event, o.status, g.operation FROM audit_outbox o JOIN governance_log g "
                      "ON g.log_id = o.log_id WHERE o.event IN ('budget.reconciled', 'quota.reconciled') "
                      "ORDER BY o.event")
        self.assertEqual(rows, [("budget.reconciled", "delivered", "settle_apply"),
                                ("quota.reconciled", "delivered", "settle_apply")])
        self.assertTrue(all(visible for _, _, visible in self.sink.attempts))

    def test_write_off_and_exposure_resolution_are_mutually_exclusive(self):
        b = self.exposed_request()
        self.c.write_off(b, actor=ACTOR, reason="first")
        before = (self.spent(), self.written_off(), self.exposed())
        events_before = self.one("SELECT COUNT(*) FROM audit_outbox")
        late = self.c.resolve_exposure(b, VALID, actor=ACTOR)
        self.assertFalse(late.applied)
        self.assertEqual(late.reason, "not_exposed")
        self.assertEqual((self.spent(), self.written_off(), self.exposed()), before)
        self.assertEqual(self.one("SELECT COUNT(*) FROM audit_outbox"), events_before)
        cc = self.exposed_request()
        self.c.resolve_exposure(cc, VALID, actor=ACTOR)
        before = (self.spent(), self.written_off(), self.exposed())
        late = self.c.write_off(cc, actor=ACTOR, reason="too late")
        self.assertFalse(late.applied)
        self.assertEqual(late.reason, "already_resolved")
        self.assertEqual((self.spent(), self.written_off(), self.exposed()), before)

    def test_admission_refusal_is_logged_and_is_not_a_success(self):
        self.s.upsert_budget("global", "", "daily", "USD", "0.00001")
        with self.assertRaises(Exception):
            self.c.admit(request(), profile())
        self.assertEqual(self.one("SELECT COUNT(*) FROM governance_log WHERE operation = 'admit' AND outcome = 'refused'"), 1)
        self.assertEqual(self.one("SELECT COUNT(*) FROM governance_log WHERE operation = 'admit' AND outcome = 'ok'"), 0)
        self.assertEqual(self.one("SELECT COUNT(*) FROM reservations"), 0)


class OutboxPrivacy(Base):
    def test_outbox_fields_never_carry_reason_or_evidence_text(self):
        rid = self.exposed_request()
        self.c.write_off(rid, actor=ACTOR, reason="SECRET-REASON-TEXT")
        fields = self.one("SELECT fields FROM audit_outbox WHERE event = 'exposure.resolved'")
        self.assertNotIn("SECRET-REASON-TEXT", fields)
        self.assertNotIn(self.path, fields)


class MigrationFive(unittest.TestCase):
    def test_v3_database_upgrades_to_the_leased_outbox_and_keeps_existing_rows(self):
        path = os.path.join(tempfile.mkdtemp(), "v3.db")
        conn = sqlite3.connect(path, isolation_level=None)
        for version in (1, 2, 3):
            for statement in _MIGRATIONS[version].split(";\n"):
                if statement.strip():
                    conn.execute(statement)
        conn.execute("CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, applied_at INTEGER)")
        conn.execute("INSERT INTO schema_migrations VALUES (1, 0), (2, 0), (3, 0)")
        conn.execute("INSERT INTO governance_log (request_id, operation, outcome, actor, at) "
                     "VALUES ('old', 'settle_intent', 'ok', NULL, 0)")
        conn.close()
        store = GovernanceStore(path)
        self.addCleanup(store.close)
        self.assertEqual(store.schema_version(), 6)
        self.assertEqual(store.read(lambda c: c.execute("SELECT COUNT(*) FROM governance_log").fetchone())[0], 1)
        self.assertEqual(store.read(lambda c: c.execute("SELECT COUNT(*) FROM audit_outbox").fetchone())[0], 0)
        self.assertTrue(store.integrity_ok())


if __name__ == "__main__":
    unittest.main()
