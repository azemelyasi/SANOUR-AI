"""Stage 10.57 Stage 3: first-open mutual exclusion across threads and processes, symlink and hardlink aliases,
and concurrent first opens of Ledger, usage repository and audit sink on one file.

No ordering is assumed from flock or threading. Coordination uses threading.Event and pipe lines. A bounded wait is
used only for negative assertions ("this waiter has NOT entered") and as a failure guard. Every child process is
killed and reaped in `finally`.

KNOWN, SEPARATE, NOT FIXED (Stage 3 does not repair it): the Ledger+Governance schema collision on one file. It is
characterized by the exact exceptions captured on the unmodified Stage 2 copy (see the last class). Its status is
independent of the lock and is not represented as fixed.
"""

import fcntl
import os
import select
import subprocess
import sys
import tempfile
import textwrap
import threading
import unittest
from unittest import mock

from sanour_ai import storage_lock as L
from sanour_ai.governance.store import GovernanceStorageError, GovernanceStore
from sanour_ai.ledger.repository import LedgerStorageError as UsageStorageError
from sanour_ai.ledger.sqlite_repository import SqliteUsageRepository
from sanour_ai.governance.sink import DurableSqliteSink
from sanour_ai.persistence.errors import LedgerStorageError
from sanour_ai.persistence.ledger import Ledger
from sanour_ai.storage_lock import LockUnavailable, exclusive_open_lock

import pathlib

ROOT = pathlib.Path(__file__).resolve().parents[2]
ENV = {**os.environ, "PYTHONPATH": f"{ROOT / 'src'}{os.pathsep}{ROOT}", "PYTHONDONTWRITEBYTECODE": "1"}
GUARD_S = 30.0          # failure guard only: never used to order events
SILENCE_S = 0.5         # negative assertion: a waiter must NOT report entry within this bounded window

HOLD_CHILD = textwrap.dedent("""
    import fcntl, sys
    import sanour_ai.storage_lock as L
    real = fcntl.flock
    def spy(fd, op):
        print("blocking", flush=True)        # reached just before the blocking flock call
        return real(fd, op)
    fcntl.flock = spy
    with L.exclusive_open_lock(sys.argv[1]):
        print("in", flush=True)
        sys.stdin.readline()                 # released only when the parent writes a line
        print("out", flush=True)
""")

START_CHILD = textwrap.dedent("""
    import sys
    from sanour_ai.persistence.ledger import Ledger
    from sanour_ai.ledger.sqlite_repository import SqliteUsageRepository
    from sanour_ai.governance.sink import DurableSqliteSink
    path, kind = sys.argv[1], sys.argv[2]
    print("ready", flush=True)
    sys.stdin.readline()                     # parent start barrier: all children are ready before any opens
    try:
        if kind == "ledger":
            Ledger(path).close()
        elif kind == "usage":
            SqliteUsageRepository(path).close()
        else:
            DurableSqliteSink(path).close()
        print("ok", flush=True)
    except Exception as exc:
        print("EXC " + type(exc).__name__ + " ctx=" + type(exc.__context__).__name__ + ": " + str(exc.__context__), flush=True)
""")


class Child:
    """Unbuffered pipes: each line is read byte by byte, so select() on the descriptor never hides buffered data."""

    def __init__(self, code, *args):
        self.p = subprocess.Popen([sys.executable, "-W", "ignore", "-c", code, *args], env=ENV,
                                  stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0)
        self._fd = self.p.stdout.fileno()

    def line(self, timeout=GUARD_S):
        buf = b""
        while True:
            ready, _, _ = select.select([self._fd], [], [], timeout)
            if not ready:
                raise TimeoutError("child produced no line within the failure guard")
            ch = os.read(self._fd, 1)
            if not ch:
                raise EOFError("child closed its output")
            if ch == b"\n":
                return buf.decode().strip()
            buf += ch

    def silent(self, timeout=SILENCE_S):
        ready, _, _ = select.select([self._fd], [], [], timeout)
        return not ready

    def send(self, text="go\n"):
        self.p.stdin.write(text.encode())
        self.p.stdin.flush()

    def kill_and_reap(self):
        if self.p.poll() is None:
            self.p.kill()
        self.p.wait()
        for stream in (self.p.stdin, self.p.stdout, self.p.stderr):
            if stream is not None:
                stream.close()


class ThreadMutualExclusion(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory()
        self.d = self._td.name

    def tearDown(self):
        self._td.cleanup()

    def test_waiting_threads_never_overlap_and_all_progress(self):
        path = os.path.join(self.d, "shared.db")
        real_flock = fcntl.flock
        names = ["w1", "w2", "w3"]
        blocked = {n: threading.Event() for n in names}   # set just before each waiter's blocking flock call
        in_section = []
        max_in = [0]
        state_lock = threading.Lock()
        owner_in = threading.Event()
        release_owner = threading.Event()
        errors = []

        def spy(fd, op):
            ev = blocked.get(threading.current_thread().name)
            if ev is not None:
                ev.set()
            return real_flock(fd, op)

        def enter(name):
            with state_lock:
                in_section.append(name)
                max_in[0] = max(max_in[0], len(in_section))

        def leave(name):
            with state_lock:
                in_section.remove(name)

        def owner():
            try:
                with exclusive_open_lock(path):
                    enter("owner")
                    owner_in.set()
                    if not release_owner.wait(GUARD_S):
                        errors.append("owner release guard hit")
                    leave("owner")
            except BaseException as exc:
                errors.append(repr(exc))

        def waiter(name):
            try:
                with exclusive_open_lock(path):
                    enter(name)
                    leave(name)
            except BaseException as exc:
                errors.append(repr(exc))

        with mock.patch.object(L.fcntl, "flock", spy):
            t_owner = threading.Thread(target=owner, name="owner")
            t_owner.start()
            self.assertTrue(owner_in.wait(GUARD_S))
            waiters = [threading.Thread(target=waiter, args=(n,), name=n) for n in names]
            for t in waiters:
                t.start()
            for n in names:                       # every waiter has reached its blocking flock call
                self.assertTrue(blocked[n].wait(GUARD_S), n)
            self.assertFalse(any(t.is_alive() is False for t in waiters))
            with state_lock:
                self.assertEqual(in_section, ["owner"])   # no waiter is inside while the owner holds
            release_owner.set()
            t_owner.join(GUARD_S)
            for t in waiters:
                t.join(GUARD_S)
                self.assertFalse(t.is_alive())
        self.assertFalse(t_owner.is_alive())
        self.assertEqual(errors, [])
        self.assertEqual(max_in[0], 1)            # never more than one thread inside the critical section
        self.assertEqual(L._thread_held_paths(), set())


class ProcessMutualExclusion(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory()
        self.d = self._td.name
        self.path = os.path.join(self.d, "shared.db")
        self.children = []

    def tearDown(self):
        for c in self.children:
            c.kill_and_reap()
        self._td.cleanup()

    def spawn(self, path=None):
        c = Child(HOLD_CHILD, path or self.path)
        self.children.append(c)
        return c

    def test_second_process_waits_until_holder_releases(self):
        holder = self.spawn()
        self.assertEqual(holder.line(), "blocking")
        self.assertEqual(holder.line(), "in")
        waiter = self.spawn()
        self.assertEqual(waiter.line(), "blocking")
        self.assertTrue(waiter.silent(), "waiter entered while the holder still holds the lock")
        holder.send()
        self.assertEqual(holder.line(), "out")
        self.assertEqual(waiter.line(), "in")
        waiter.send()
        self.assertEqual(waiter.line(), "out")

    def test_stalled_holder_keeps_waiter_out_until_release(self):
        holder = self.spawn()
        self.assertEqual(holder.line(), "blocking")
        self.assertEqual(holder.line(), "in")
        waiter = self.spawn()
        self.assertEqual(waiter.line(), "blocking")
        for _ in range(2):                         # holder stalls; waiter stays out across bounded windows
            self.assertTrue(waiter.silent())
        holder.send()
        self.assertEqual(holder.line(), "out")
        self.assertEqual(waiter.line(), "in")
        waiter.send()

    def test_sigkill_of_holder_releases_lock_to_waiter(self):
        holder = self.spawn()
        self.assertEqual(holder.line(), "blocking")
        self.assertEqual(holder.line(), "in")
        waiter = self.spawn()
        self.assertEqual(waiter.line(), "blocking")
        holder.p.kill()                            # SIGKILL: the kernel drops the flock with the descriptor
        holder.p.wait()
        self.assertEqual(waiter.line(), "in")
        waiter.send()
        self.assertEqual(waiter.line(), "out")


class AliasCoordination(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory()
        self.d = self._td.name
        self.target = os.path.join(self.d, "target.db")
        open(self.target, "w").close()
        self.children = []

    def tearDown(self):
        for c in self.children:
            c.kill_and_reap()
        self._td.cleanup()

    def spawn(self, path):
        c = Child(HOLD_CHILD, path)
        self.children.append(c)
        return c

    def test_symlink_alias_waits_for_thread_holding_target(self):
        link = os.path.join(self.d, "link.db")
        os.symlink(self.target, link)
        real_flock = fcntl.flock
        about_to_block = threading.Event()
        entered = threading.Event()

        def spy(fd, op):
            about_to_block.set()
            return real_flock(fd, op)

        def via_link():
            with exclusive_open_lock(link):
                entered.set()

        with mock.patch.object(L.fcntl, "flock", spy):
            with exclusive_open_lock(self.target):
                t = threading.Thread(target=via_link)
                t.start()
                self.assertTrue(about_to_block.wait(GUARD_S))
                self.assertFalse(entered.wait(SILENCE_S), "symlink alias entered while target is held")
            t.join(GUARD_S)
        self.assertTrue(entered.is_set())
        self.assertFalse(t.is_alive())

    def test_symlink_alias_excludes_target_across_processes(self):
        link = os.path.join(self.d, "link.db")
        os.symlink(self.target, link)
        holder = self.spawn(self.target)
        self.assertEqual(holder.line(), "blocking")
        self.assertEqual(holder.line(), "in")
        waiter = self.spawn(link)
        self.assertEqual(waiter.line(), "blocking")
        self.assertTrue(waiter.silent(), "symlink alias entered while the target is held")
        holder.send()
        self.assertEqual(holder.line(), "out")
        self.assertEqual(waiter.line(), "in")
        waiter.send()

    def test_symlink_in_other_directory_coordinates_with_target_across_processes(self):
        # Canonical parent directory: a symlink living in ANOTHER folder resolves to the target's folder and must wait.
        other_dir = os.path.join(self.d, "elsewhere")
        os.mkdir(other_dir)
        link = os.path.join(other_dir, "link.db")
        os.symlink(self.target, link)
        holder = self.spawn(self.target)
        self.assertEqual(holder.line(), "blocking")
        self.assertEqual(holder.line(), "in")
        waiter = self.spawn(link)
        self.assertEqual(waiter.line(), "blocking")
        self.assertTrue(waiter.silent(), "cross-directory symlink entered while the target is held")
        holder.send()
        self.assertEqual(holder.line(), "out")
        self.assertEqual(waiter.line(), "in")
        waiter.send()
        self.assertEqual(waiter.line(), "out")

    def test_hardlink_alias_in_same_directory_coordinates_with_target(self):
        # Directory lock: a hardlink in the SAME directory resolves to the same lock directory, so it is serialized.
        alias = os.path.join(self.d, "hardlink.db")
        os.link(self.target, alias)
        holder = self.spawn(self.target)
        self.assertEqual(holder.line(), "blocking")
        self.assertEqual(holder.line(), "in")
        other = self.spawn(alias)
        self.assertEqual(other.line(), "blocking")
        self.assertTrue(other.silent(), "same-directory hardlink entered while the target is held")
        holder.send()
        self.assertEqual(holder.line(), "out")
        self.assertEqual(other.line(), "in")
        other.send()
        self.assertEqual(other.line(), "out")

    def test_hardlink_alias_in_other_directory_is_not_coordinated_characterization(self):
        # CURRENT BEHAVIOR, NOT A GUARANTEE: a hardlink in a different directory has a different lock directory.
        other_dir = os.path.join(self.d, "elsewhere")
        os.mkdir(other_dir)
        alias = os.path.join(other_dir, "hardlink.db")
        os.link(self.target, alias)
        holder = self.spawn(self.target)
        self.assertEqual(holder.line(), "blocking")
        self.assertEqual(holder.line(), "in")
        other = self.spawn(alias)
        self.assertEqual(other.line(), "blocking")
        self.assertEqual(other.line(), "in")       # does not wait for the holder of the other name
        other.send()
        self.assertEqual(other.line(), "out")
        holder.send()
        self.assertEqual(holder.line(), "out")


class FirstOpenAcrossComponents(unittest.TestCase):
    """GENUINE concurrent first opens: separate processes start on a barrier and open the same file at once. The
    migration re-check path is NOT tested here; it is covered only by the independent-process migration-gap test in
    test_stage1054a_ledger.py, which does not prove normal concurrent opener behavior."""

    def setUp(self):
        self._td = tempfile.TemporaryDirectory()
        self.d = self._td.name
        self.children = []

    def tearDown(self):
        for c in self.children:
            c.kill_and_reap()
        self._td.cleanup()

    def race(self, path, kinds):
        """Start one child per kind; all wait at a barrier, then open the same path at the same time."""
        kids = [Child(START_CHILD, path, kind) for kind in kinds]
        self.children.extend(kids)
        for k in kids:
            self.assertEqual(k.line(), "ready")
        for k in kids:
            k.send()
        return [k.line() for k in kids]

    def test_ledger_and_usage_first_open_race_on_one_file(self):
        # Every Ledger open must succeed under the lock. A usage open either succeeds, or fails with the exact known
        # Ledger->usage schema conflict (characterized separately below; NOT fixed by Stage 3). No busy/lock error.
        path = os.path.join(self.d, "ledger_usage.db")
        kinds = ["ledger", "usage", "ledger", "usage"]
        results = self.race(path, kinds)
        for kind, res in zip(kinds, results):
            if kind == "ledger":
                self.assertEqual(res, "ok")
            else:
                self.assertTrue(res == "ok" or res.startswith("EXC LedgerStorageError"), res)
        with Ledger(path) as led:
            self.assertTrue(led.verify().ok)

    def test_ledger_and_sink_first_open_race_on_one_file(self):
        path = os.path.join(self.d, "ledger_sink.db")
        results = self.race(path, ["ledger", "sink", "ledger", "sink"])
        self.assertEqual(results, ["ok"] * 4)
        with Ledger(path) as led:
            self.assertTrue(led.verify().ok)


class KnownSchemaCollisionCharacterization(unittest.TestCase):
    """SEPARATE, KNOWN, NOT FIXED. Schema conflicts on one file, characterized by the exact failures reproduced on the
    unmodified Stage 2 copy: Ledger->usage (serial, one direction only), and Ledger<->governance (both orders). They
    are independent of the first-open lock and are NOT fixed by Stage 3. If one is ever fixed, its assertion fails on
    purpose and must be rewritten under that stage's own approval."""

    def setUp(self):
        self._td = tempfile.TemporaryDirectory()
        self.path = os.path.join(self._td.name, "shared.db")

    def tearDown(self):
        self._td.cleanup()

    def test_governance_first_then_ledger_raises_captured_collision(self):
        GovernanceStore(self.path).close()
        with self.assertRaises(LedgerStorageError) as cm:
            Ledger(self.path)
        self.assertEqual(str(cm.exception), "ledger storage failure")
        self.assertEqual(type(cm.exception.__context__).__name__, "OperationalError")
        self.assertEqual(str(cm.exception.__context__), "no such column: checksum")

    def test_ledger_first_then_usage_raises_serial_collision(self):
        # Deterministic and serial (no concurrency). Reproduced on the unmodified Stage 2 copy: same outcome.
        Ledger(self.path).close()
        with self.assertRaises(UsageStorageError) as cm:
            SqliteUsageRepository(self.path)
        self.assertEqual(str(cm.exception), "usage ledger storage unavailable")

    def test_usage_first_then_ledger_opens_cleanly(self):
        # The reverse order is fine on both trees: the conflict is one-directional.
        SqliteUsageRepository(self.path).close()
        Ledger(self.path).close()

    def test_ledger_first_then_governance_raises_captured_collision(self):
        Ledger(self.path).close()
        with self.assertRaises(GovernanceStorageError) as cm:
            GovernanceStore(self.path)
        self.assertEqual(str(cm.exception), "governance storage unavailable")
        self.assertEqual(type(cm.exception.__context__).__name__, "IntegrityError")
        self.assertEqual(str(cm.exception.__context__), "NOT NULL constraint failed: schema_migrations.name")


if __name__ == "__main__":
    unittest.main()
