"""Stage 10.57 Stage 3: the Ledger first-open lock is held for __init__ (initialization and migration) only, is released
on success and on failure, maps lock failures to LedgerStorageError, keeps the existing busy-wait retry, and refuses
nested acquisition in the same thread. Probes use a separate descriptor with LOCK_NB, so they never block. Every
descriptor opened by a probe is closed in `finally`."""

import fcntl
import os
import pathlib
import sqlite3
import subprocess
import sys
import tempfile
import textwrap
import unittest
from unittest import mock

from sanour_ai.persistence import first_open_lock as L
from sanour_ai.persistence import ledger as ledger_module
from sanour_ai.persistence.errors import LedgerStorageError
from sanour_ai.persistence.ledger import Ledger
from sanour_ai.persistence.first_open_lock import LockUnavailable, exclusive_open_lock

ROOT = pathlib.Path(__file__).resolve().parents[2]
ENV = {**os.environ, "PYTHONPATH": f"{ROOT / 'src'}{os.pathsep}{ROOT}", "PYTHONDONTWRITEBYTECODE": "1"}


def sidecar_is_free(path):
    """True if no descriptor holds the first-open lock on this file right now (non-blocking probe on the canonical
    parent directory, the lock target since Stage 3). Opens read-only: the probe creates nothing."""
    fd = os.open(os.path.dirname(os.path.realpath(path)), os.O_RDONLY)
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return False
        fcntl.flock(fd, fcntl.LOCK_UN)
        return True
    finally:
        os.close(fd)


class LedgerLockRelease(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory()
        self.path = os.path.join(self._td.name, "ledger.db")

    def tearDown(self):
        self._td.cleanup()

    def test_lock_is_held_during_open_and_migration_and_released_after(self):
        seen = {}
        real_open_writer = Ledger._open_writer
        real_migrate = Ledger._migrate

        def spy_open_writer(self):
            seen["open_writer_held"] = not sidecar_is_free(self._path)
            return real_open_writer(self)

        def spy_migrate(self):
            seen["migrate_held"] = not sidecar_is_free(self._path)
            return real_migrate(self)

        with mock.patch.object(Ledger, "_open_writer", spy_open_writer), \
                mock.patch.object(Ledger, "_migrate", spy_migrate):
            led = Ledger(self.path)
        self.assertEqual(seen, {"open_writer_held": True, "migrate_held": True})
        self.assertTrue(sidecar_is_free(self.path))
        led.close()

    def test_lock_is_not_held_by_normal_transactions(self):
        with Ledger(self.path) as led:
            self.assertTrue(sidecar_is_free(self.path))
            led.append("evidence", "rec-1", "EVIDENCE_ADDED", {"n": 1})
            self.assertTrue(sidecar_is_free(self.path))
            self.assertEqual(L._thread_held_paths(), set())

    def test_init_failure_releases_lock(self):
        with mock.patch.object(Ledger, "_migrate", side_effect=LedgerStorageError("injected migration failure")):
            with self.assertRaises(LedgerStorageError):
                Ledger(self.path)
        self.assertTrue(sidecar_is_free(self.path))
        self.assertEqual(L._thread_held_paths(), set())

    def test_lock_failure_maps_to_ledger_storage_error(self):
        with mock.patch.object(ledger_module, "exclusive_open_lock",
                               side_effect=LockUnavailable("injected lock failure")):
            with self.assertRaises(LedgerStorageError) as cm:
                Ledger(self.path)
        self.assertEqual(str(cm.exception), "ledger storage lock unavailable")
        self.assertTrue(isinstance(cm.exception.__context__, LockUnavailable) or cm.exception.__cause__ is None)

    def test_nested_ledger_open_in_same_thread_is_refused_child(self):
        # Child process: a broken check would block this thread on its own flock, so the child is always killed.
        code = textwrap.dedent("""
            import sys
            from sanour_ai.persistence.errors import LedgerStorageError
            from sanour_ai.persistence.ledger import Ledger
            from sanour_ai.storage_lock import exclusive_open_lock
            p = sys.argv[1]
            with exclusive_open_lock(p):
                try:
                    Ledger(p)
                    print("opened")
                except LedgerStorageError as exc:
                    print("refused: " + str(exc))
        """)
        path = os.path.join(self._td.name, "ledger.db")
        proc = subprocess.Popen([sys.executable, "-W", "ignore", "-c", code, path], env=ENV,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        try:
            out, err = proc.communicate(timeout=20)
        finally:
            if proc.poll() is None:
                proc.kill()
            proc.wait()
        self.assertEqual(proc.returncode, 0, err[-300:])
        self.assertEqual(out.strip(), "refused: ledger storage lock unavailable")

    def test_busy_retry_loop_is_preserved_inside_the_lock(self):
        real_connect = Ledger._connect
        calls = {"writer": 0}

        def flaky_connect(self, *, readonly):
            if not readonly:
                calls["writer"] += 1
                if calls["writer"] == 1:
                    raise sqlite3.OperationalError("database is locked")   # existing busy path: retried
            return real_connect(self, readonly=readonly)

        with mock.patch.object(Ledger, "_connect", flaky_connect):
            with Ledger(self.path) as led:
                self.assertTrue(led.verify().ok)
        self.assertEqual(calls["writer"], 2)
        self.assertTrue(sidecar_is_free(self.path))


class ImportBoundaryAndInitialization(unittest.TestCase):
    """The lock module is stdlib-only, persistence keeps its boundary, and each module imports cleanly as the FIRST
    import of a fresh interpreter (no circular-import dependence on import order)."""

    FIRST_IMPORTS = ("sanour_ai.persistence.first_open_lock", "sanour_ai.storage_lock",
                     "sanour_ai.persistence.ledger", "sanour_ai.persistence", "sanour_ai.ledger.sqlite_repository",
                     "sanour_ai.governance.store", "sanour_ai.governance.sink")

    def test_lock_module_imports_only_the_standard_library(self):
        import ast
        import sys
        src = pathlib.Path(L.__file__).read_text()
        stdlib = set(sys.stdlib_module_names)
        for node in ast.walk(ast.parse(src)):
            mods = []
            if isinstance(node, ast.Import):
                mods = [a.name for a in node.names]
            elif isinstance(node, ast.ImportFrom) and not node.level:
                mods = [node.module or ""]
            for mod in mods:
                self.assertIn(mod.split(".")[0], stdlib, mod)

    def test_each_module_imports_cleanly_as_first_import_in_a_fresh_interpreter(self):
        for mod in self.FIRST_IMPORTS:
            p = subprocess.run([sys.executable, "-W", "ignore", "-c", f"import {mod}"], env=ENV,
                               capture_output=True, text=True, timeout=60)
            self.assertEqual(p.returncode, 0, f"{mod}: {p.stderr[-300:]}")

    def test_storage_lock_shim_exposes_the_same_objects(self):
        from sanour_ai import storage_lock as shim
        self.assertIs(shim.exclusive_open_lock, L.exclusive_open_lock)
        self.assertIs(shim.LockUnavailable, L.LockUnavailable)



class DescriptorReleaseDeterministic(unittest.TestCase):
    """Deterministic release proof for the lock descriptor: no timeout is involved. The descriptor count returns to its
    value before the lock, and a non-blocking probe on the canonical directory succeeds right after the context exits,
    on both the normal path and an exception path. A leaked descriptor fails here immediately."""

    def setUp(self):
        self._td = tempfile.TemporaryDirectory()
        self.path = os.path.join(self._td.name, "d.db")

    def tearDown(self):
        self._td.cleanup()

    @staticmethod
    def fd_count():
        return len(os.listdir("/proc/self/fd"))

    def test_normal_exit_closes_descriptor_and_releases_kernel_lock(self):
        before = self.fd_count()
        with exclusive_open_lock(self.path):
            self.assertFalse(sidecar_is_free(self.path))      # held while inside (probe is a separate descriptor)
        self.assertEqual(self.fd_count(), before)               # the lock descriptor was closed
        self.assertTrue(sidecar_is_free(self.path))             # and the kernel lock is gone

    def test_exception_exit_closes_descriptor_and_releases_kernel_lock(self):
        before = self.fd_count()
        with self.assertRaises(ValueError):
            with exclusive_open_lock(self.path):
                raise ValueError("body")
        self.assertEqual(self.fd_count(), before)
        self.assertTrue(sidecar_is_free(self.path))


if __name__ == "__main__":
    unittest.main()
