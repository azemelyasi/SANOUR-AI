"""Stage 2 integration: owner backups taken while a writer commits. Each finalized backup must inspect clean and
hold a row count inside the writer's committed window [c0, c1 + 1]. Fixture-only. This does NOT prove every
production scenario (owner decision 2 caveat); it exercises the owner path under concurrent writes."""

import datetime as dt
import os
import shutil
import sqlite3
import tempfile
import threading
import unittest
from unittest import mock

from sanour_ai.storage import legacy_inventory as L
from sanour_ai.storage import owner_backup as OB
from sanour_ai.storage.identity import SubsystemId

NOW = dt.datetime(2026, 11, 9, 12, 0, tzinfo=dt.timezone.utc)


class BackupUnderConcurrentWrites(unittest.TestCase):
    def setUp(self):
        self.root = tempfile.mkdtemp(prefix="s1056c_")
        self.live = os.path.join(self.root, "live")
        self.stage = os.path.join(self.root, "stage")
        os.makedirs(self.live)
        os.makedirs(self.stage)

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def test_backups_during_writes_are_clean_and_within_window(self):
        db = os.path.join(self.live, "usage.db")
        committed = [0]
        ready = threading.Event()
        stop = threading.Event()
        errors = []

        def writer():
            try:
                w = sqlite3.connect(db, isolation_level=None, timeout=5)
                w.execute("PRAGMA journal_mode=WAL")
                w.execute("PRAGMA wal_autocheckpoint=0")
                w.execute("CREATE TABLE usage_records (x INTEGER PRIMARY KEY)")
                ready.set()
                k = 0
                while not stop.is_set():
                    k += 1
                    w.execute("INSERT INTO usage_records VALUES (?)", (k,))
                    committed[0] = k
                    if k % 9 == 0:
                        w.execute("PRAGMA wal_checkpoint(TRUNCATE)")
                w.close()
            except Exception as exc:
                errors.append(repr(exc))
                ready.set()

        clock = mock.patch.object(OB, "_utc_now", return_value=NOW)
        clock.start()
        self.addCleanup(clock.stop)
        th = threading.Thread(target=writer)
        th.start()
        ready.wait()
        self.assertEqual(errors, [])
        try:
            results = []
            for _ in range(8):
                c0 = committed[0]
                m = OB.create_owner_backup(db, self.stage, "usage")
                c1 = committed[0]
                path = os.path.join(self.stage, m["backup_file"])
                out = L.inspect_backup(path, expected=SubsystemId.USAGE, identities={
                    SubsystemId.LEDGER: 1, SubsystemId.USAGE: 2, SubsystemId.GOVERNANCE: 3, SubsystemId.SINK: 4})
                r = sqlite3.connect("file:%s?mode=ro" % path, uri=True)
                rows = r.execute("SELECT count(*) FROM usage_records").fetchone()[0]
                r.close()
                results.append((out.kind, c0 <= rows <= c1 + 1))
        finally:
            stop.set()
            th.join()
        self.assertTrue(all(kind == L.KIND_OK and inside for kind, inside in results), results)
        finals = [n for n in os.listdir(self.stage) if n.endswith(".sqlite")]
        self.assertEqual(len(finals), 8)
        self.assertFalse(any(n.endswith((".partial", "-wal", "-shm", "-journal")) for n in os.listdir(self.stage)))


if __name__ == "__main__":
    unittest.main()
