"""Single gate for SDK-dependent tests (Stage 10.49-R8-R2).

Default: a missing SDK skips the test, and the skip is counted and reported as a skip, never as a pass.
SANOUR_REQUIRE_SDK=1: a missing SDK is an error at import (decorators) or in the test (sdk_or_skip). An environment
that claims SDK conformance cannot pass silently without the packages.

The gate checks package presence only. It does not verify the SDK's behavior. Real-SDK behavior is verified only by
runs in an environment where these tests actually execute.
"""

import importlib.util
import os
import unittest

REQUIRE_ENV = "SANOUR_REQUIRE_SDK"
PACKAGES = ("openai", "httpx2")
SKIP_REASON = "openai and httpx2 not installed; skipped"


def sdk_available() -> bool:
    return all(importlib.util.find_spec(name) is not None for name in PACKAGES)


def sdk_required() -> bool:
    return os.environ.get(REQUIRE_ENV) == "1"


def _missing_message() -> str:
    return f"{REQUIRE_ENV}=1 but the SDK is missing: openai and httpx2 must be installed"


def sdk_marker(reason: str = SKIP_REASON):
    """Class or method decorator. Raises at import when the SDK is required and missing."""
    if sdk_available():
        return lambda obj: obj
    if sdk_required():
        raise ImportError(_missing_message())
    return unittest.skip(reason)


def sdk_or_skip(test: unittest.TestCase, reason: str = SKIP_REASON) -> None:
    """Call inside a test body. Returns when the SDK is present; otherwise fails when required, else skips."""
    if sdk_available():
        return
    if sdk_required():
        raise AssertionError(_missing_message())
    test.skipTest(reason)


def SDK_REQUIRED(obj):
    """Decorator for SDK-dependent classes and methods. The check runs when a test is decorated, not when this
    module is imported, so importing the gate never fails by itself."""
    return sdk_marker()(obj)
