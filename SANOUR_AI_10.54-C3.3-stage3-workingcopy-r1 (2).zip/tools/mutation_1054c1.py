"""Stage 10.54-C1 mutation testing. One textual change per mutant, applied to a PRIVATE COPY of the tree.
Runs the C1 test module and classifies each outcome:
  KILLED_ASSERTION  a test assertion failed (the intended way to kill a mutant)
  KILLED_ERROR      a test raised an unexpected exception (counts as detected, reported separately)
  CRASH             the test process died or could not start: NOT counted as a kill
  TIMEOUT           the run exceeded the limit: NOT counted as a kill
  SURVIVED          all tests passed: a gap in the tests, reported as such
  INVALID           the pattern was not found in the source
Usage: PYTHONPATH=src:. python tools/mutation_1054c1.py [--md OUT.md] [--workers N]"""
import concurrent.futures as cf
import os
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = pathlib.Path(__file__).resolve().parents[1]
TESTS = ["tests.unit.test_stage1054c1_backup"]
F = "archive.py"
M = [
 (F, 'if claimed != C.sha256_hex(C.dumps(obj)):', 'if False:'),
 (F, 'if not isinstance(obj, dict) or raw != C.dumps(obj):', 'if not isinstance(obj, dict):'),
 (F, 'if obj.get("v") != MANIFEST_VERSION or obj.get("kind") != KIND:', 'if False:'),
 (F, 'if m.get("migrations") != _code_migrations():', 'if False:'),
 (F, 'if snap["migrations"] != _code_migrations():', 'if False:'),
 (F, 'if snap["streams"] != manifest["streams"]:', 'if False:'),
 (F, 'if _digest(tmp) != (entry["sha256"], entry["size"]):', 'if False:'),
 (F, 'if os.path.getsize(src_db) != entry["size"] or _digest(src_db)[0] != entry["sha256"]:', 'if False:'),
 (F, 'if anchor["seq"] > head_seq:', 'if False:'),
 (F, 'if at is None or at[0] != anchor["head_hash"]:', 'if False:'),
 (F, '        if not report.ok:', '        if False:'),
 (F, '    if any(os.path.lexists(path + s) for s in _SIDECARS):', '    if False:'),
 (F, '    _refuse_existing(dest, RestoreError)\n    parent', '    parent'),
 (F, '            os.link(tmp, dest)', '            os.replace(tmp, dest)'),
 (F, '        _remove_db_files(tmp)      # removes', '        pass      # removes'),
 (F, 'raise RestoreError("destination was created during restore: nothing published") from None', 'pass'),
 (F, '        _finalize(tmp, RestoreError)\n', ''),
 (F, 'PRAGMA journal_mode=DELETE', 'PRAGMA journal_mode=WAL'),
 (F, '            os.fsync(fd_out)', '            pass'),
 (F, '    if os.path.islink(src):\n        raise RestoreError("backup file is a link")', '    pass'),
 (F, '    if os.path.islink(path) or not os.path.isfile(path):', '    if not os.path.isfile(path):'),
 (F, '    if os.path.getsize(path) > _MAX_MANIFEST_BYTES:', '    if False:'),
 (F, '        snap = _verify_db(db, anchor_d, None, BackupError)', '        snap = _verify_db(db, None, None, BackupError)'),
 (F, '"v": MANIFEST_VERSION, "kind": KIND,', '"v": 2, "kind": KIND,'),
 (F, '"files": [{"name": DB_NAME, "size": db_size, "sha256": db_sha}],', '"files": [{"name": DB_NAME, "size": 0, "sha256": db_sha}],'),
 (F, '        h.update(block)', '        pass'),
 (F, '        _refuse_existing(dest, BackupError)\n        os.rename(staging, dest)', '        os.rename(staging, dest)'),
 (F, '    if not isinstance(value, str) or not value or "\\x00" in value or len(value) > 1024:', '    if False:'),
]
IGN = shutil.ignore_patterns("__pycache__", "*.pyc", ".git")


def run_one(i, spec):
    fname, old, new = spec
    tmp = pathlib.Path(tempfile.mkdtemp(prefix="mutc1_"))
    try:
        work = tmp / "tree"
        shutil.copytree(ROOT, work, ignore=IGN)
        path = work / "src/sanour_ai/backup" / fname
        src = path.read_text()
        if old not in src:
            return i, "INVALID", 0.0
        path.write_text(src.replace(old, new, 1))
        env = {**os.environ, "PYTHONPATH": f"{work/'src'}{os.pathsep}{work}", "PYTHONDONTWRITEBYTECODE": "1"}
        t = time.time()
        try:
            p = subprocess.run([sys.executable, "-m", "unittest", "-f", *TESTS], cwd=work, env=env,
                               capture_output=True, text=True, timeout=300)
        except subprocess.TimeoutExpired:
            return i, "TIMEOUT", time.time() - t
        out = p.stderr
        m = re.search(r"FAILED \((.*?)\)", out)
        ran = re.search(r"^Ran \d+ tests?", out, re.M)
        if p.returncode == 0 and ran:
            return i, "SURVIVED", time.time() - t
        if p.returncode < 0 or not ran:
            return i, "CRASH", time.time() - t
        if m and "failures=" in m.group(1):
            return i, "KILLED_ASSERTION", time.time() - t
        if m and "errors=" in m.group(1):
            return i, "KILLED_ERROR", time.time() - t
        return i, "CRASH", time.time() - t
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main():
    md = sys.argv[sys.argv.index("--md") + 1] if "--md" in sys.argv else None
    workers = int(sys.argv[sys.argv.index("--workers") + 1]) if "--workers" in sys.argv else 3
    res = {}
    with cf.ThreadPoolExecutor(workers) as ex:
        futs = [ex.submit(run_one, i, s) for i, s in enumerate(M, 1)]
        for f in cf.as_completed(futs):
            i, st, dt = f.result()
            res[i] = st
            print(f"[{i:3}] {st:17} {M[i-1][1][:60]!r} -> {M[i-1][2][:30]!r} ({dt:.1f}s)", flush=True)
    from collections import Counter
    c = Counter(res.values())
    print("\nmutants:", len(M), dict(c))
    if md:
        with open(md, "w") as fh:
            fh.write("# Stage 10.54-C1 mutation testing (generated by tools/mutation_1054c1.py)\n\n")
            fh.write(f"Mutants: {len(M)}. " + ". ".join(f"{k}: {v}" for k, v in sorted(c.items())) + ".\n\n")
            fh.write("Only KILLED_ASSERTION and KILLED_ERROR count as detected. CRASH, TIMEOUT and SURVIVED do not.\n\n")
            fh.write("| # | original | mutant | result |\n|---|---|---|---|\n")
            esc = lambda x: x.replace("|", "\\|").replace("\n", "\\n")[:90]
            for i in sorted(res):
                fh.write(f"| {i} | `{esc(M[i-1][1])}` | `{esc(M[i-1][2])}` | {res[i]} |\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
