"""Stage 10.52 mutation testing. Mutates readiness sources one change at a time; each must be killed."""
import pathlib, subprocess, sys, os
ROOT = pathlib.Path(__file__).resolve().parents[1]
PK = ROOT / "src/sanour_ai/readiness"
M = [
 ("engine.py", "if contradicting:", "if False:"),
 ("engine.py", "if live:", "if mine:"),
 ("engine.py", "e.kind is EvidenceKind.LIVE and e.supports", "e.supports"),
 ("engine.py", "Status.FAIL: 3", "Status.FAIL: 1"),
 ("engine.py", "Status.UNVERIFIED: 2", "Status.UNVERIFIED: 0"),
 ("engine.py", "max((r.status", "min((r.status"),
 ("engine.py", "ready = overall is Status.PASS and not blockers", "ready = not blockers"),
 ("engine.py", "ready = overall is Status.PASS and not blockers", "ready = True"),
 ("engine.py", "if r.status in (Status.FAIL, Status.UNVERIFIED)", "if r.status is Status.FAIL"),
 ("engine.py", "if e.criterion is criterion", "if True"),
 ("engine.py", "if waived:", "if False:"),
 ("engine.py", "for c in Criterion)", "for c in list(Criterion)[:-1])"),
 ("engine.py", "if not provider_id.strip():", "if False:"),
 ("model.py", "WAIVABLE: frozenset[Criterion] = frozenset({Criterion.SDK_TRANSPORT_CONFORMANCE})", "WAIVABLE: frozenset[Criterion] = frozenset(Criterion)"),
 ("model.py", "if not self.reviewer.strip():", "if False:"),
 ("model.py", "if not _SHA256.match(self.artifact_sha256):", "if False:"),
 ("model.py", "if not self.ref.strip() or not self.note.strip():", "if False:"),
 ("model.py", "len(self.reason.strip()) < 10", "len(self.reason.strip()) < 0"),
 ("model.py", "[0-9a-f]{64}", "[0-9a-f]{1,64}"),
 ("registry.py", "if provider_id in self._evidence:", "if False:"),
 ("registry.py", "if provider_id not in self._evidence:", "if False:"),
 ("current_evidence.py", "K.LOCAL_TEST, \"tests/unit/test_redaction.py\"", "K.LIVE, \"tests/unit/test_redaction.py\""),
 ("current_evidence.py", "Evidence(crit, kind, True, ref, note)", "Evidence(crit, kind, False, ref, note)"),
 ("current_evidence.py", "\"grok_responses\": \"tests/unit/test_stage1037_conformance.py\"", "\"grok_responses\": \"tests/unit/nonexistent.py\""),
 ("report.py", "'yes' if a.production_ready else 'no'", "'yes'"),
]
# Known equivalent mutants (cannot change behaviour): `ready = not blockers` (only one criterion is waivable, so overall can never be
# NOT_APPLICABLE) and removing registry._known (a dict lookup raises the same KeyError).
tests = "tests.unit.test_stage1052_readiness"
env = dict(os.environ, PYTHONPATH=f"{ROOT/'src'}:{ROOT}", PYTHONDONTWRITEBYTECODE="1")
killed = survived = 0
for f, a, b in M:
    path = PK / f
    orig = path.read_text()
    assert a in orig, (f, a)
    path.write_text(orig.replace(a, b, 1))
    try:
        r = subprocess.run([sys.executable, "-m", "unittest", tests], cwd=ROOT, env=env, capture_output=True, text=True)
    finally:
        path.write_text(orig)
    ok = r.returncode != 0
    killed += ok; survived += (not ok)
    print(("KILLED  " if ok else "SURVIVED"), f, "|", a[:50], "->", b[:40])
print(f"total={len(M)} killed={killed} survived={survived}")
sys.exit(1 if survived else 0)
