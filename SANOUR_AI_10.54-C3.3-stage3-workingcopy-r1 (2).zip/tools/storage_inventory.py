"""Read-only inspection of ONE finalized owner-produced backup (Stage 2, restricted scope).

Exit codes (owner-approved): 0 inspected clean, 1 content refused, 2 input or configuration error,
3 UNVERIFIED, 4 NOT_INSPECTED. Precedence when a run has several results: 2, 1, 3, 4, 0.
Inspect-only: nothing is accepted, stamped, migrated, adopted, or written beside the input.
"""

from __future__ import annotations

import argparse
import json
import os
import sys

from sanour_ai.storage.identity import SubsystemId
from sanour_ai.storage.legacy_inventory import (
    DEFAULT_MAX_BYTES, EXIT_INPUT_ERROR, InputError, inspect_backup, load_identity_config, write_report,
)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="storage_inventory", description=__doc__.splitlines()[0])
    p.add_argument("backup", help="path to a finalized *.sqlite owner backup")
    p.add_argument("--expected", required=True, choices=[s.value for s in SubsystemId],
                   help="subsystem the caller intends to use this file for")
    p.add_argument("--identities", required=True, help="JSON file mapping subsystem name to identity integer")
    p.add_argument("--manifest", default=None, help="manifest path (default: beside the backup)")
    p.add_argument("--max-bytes", type=int, default=DEFAULT_MAX_BYTES,
                   help="maximum input size in bytes (default 1 GiB)")
    p.add_argument("--assurance", choices=["strict", "standard"], default="strict",
                   help="strict (default) reads twice; standard is reduced assurance and is labeled as such")
    p.add_argument("--report", default=None, help="write a JSON report here (must be outside the input directory)")
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        identities = load_identity_config(args.identities)
        if args.max_bytes <= 0:
            raise InputError("--max-bytes must be positive")
        outcome = inspect_backup(
            args.backup,
            expected=SubsystemId(args.expected),
            identities=identities,
            max_bytes=args.max_bytes,
            strict=(args.assurance == "strict"),
            manifest_path=args.manifest,
        )
        if args.report:
            write_report(args.report, args.backup, outcome)
    except InputError as exc:
        print(json.dumps({"exit_code": EXIT_INPUT_ERROR, "error": str(exc)}), file=sys.stderr)
        return EXIT_INPUT_ERROR
    except OSError as exc:
        print(json.dumps({"exit_code": EXIT_INPUT_ERROR, "error": f"io: {type(exc).__name__}"}), file=sys.stderr)
        return EXIT_INPUT_ERROR
    print(json.dumps(outcome.as_dict(), sort_keys=True))
    return outcome.exit_code


if __name__ == "__main__":
    sys.exit(main())
