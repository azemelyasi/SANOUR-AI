"""Stage 10.54-C3.2 mutation testing for the changed code (shared first-open lock and its callers).
One textual change per mutant on a PRIVATE COPY of the tree. Categories:
  Killed by Assertion | Killed by Exception | Equivalent (only with written proof; none declared) |
  Survived | Timeout | Tool Error. Survived and Timeout are reported as they are.
Usage: PYTHONPATH=src:. python tools/mutation_c32_storage.py [--md OUT.md] [--workers N]"""
import concurrent.futures as cf
import os
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile
import time
from collections import Counter

ROOT = pathlib.Path(__file__).resolve().parents[1]
# Scope: the regression modules that target the lock code. The whole stage-1048r1 module was tried first: a leaked lock
# (mutant 4) then blocks an unrelated later test in the same process, so the run hit the time limit (classified Timeout).
TESTS = ["tests.unit.test_stage1054c32_storage", "tests.unit.test_stage1048r1_wal_race",
         "tests.unit.test_stage1057_reentry", "tests.integration.test_stage1057_first_open",
         "tests.integration.test_stage1057_lock_release"]
M = [
 ("persistence/first_open_lock.py", "        fcntl.flock(fd, fcntl.LOCK_EX)\n", "        pass\n"),
 ("persistence/first_open_lock.py", "    if fcntl is None:\n        raise LockUnavailable", "    if False:\n        raise LockUnavailable"),
 ("persistence/first_open_lock.py", "        os.close(fd)          # closing the descriptor releases the lock", "        pass"),
 ("governance/store.py", "            with exclusive_open_lock(path):          # Stage 10.54-C3.2: serialize the first open (storage_lock)\n                self._open(path)",
     "            if True:\n                self._open(path)"),
 ("governance/sink.py", "            with exclusive_open_lock(path):          # Stage 10.54-C3.2: serialize the first open (storage_lock)",
     "            if True:"),
 ("ledger/sqlite_repository.py", "        with exclusive_open_lock(path):\n            yield", "        if True:\n            yield"),
 ("integrity/audit.py", "                if fcntl is None:\n                    raise AuditError", "                if False:\n                    raise AuditError"),
 ("persistence/first_open_lock.py", "    if held:                          # this thread already holds", "    if False:                          # this thread already holds"),
 ("persistence/first_open_lock.py", "        held.add(canon)               # registered BEFORE the blocking flock\n        registered = True\n\n        try:\n            fcntl.flock(fd, fcntl.LOCK_EX)\n        except OSError as exc:\n            raise LockUnavailable(\"file lock could not be taken\") from exc\n",
  "        try:\n            fcntl.flock(fd, fcntl.LOCK_EX)\n        except OSError as exc:\n            raise LockUnavailable(\"file lock could not be taken\") from exc\n        held.add(canon)\n        registered = True\n"),
 ("persistence/first_open_lock.py", "    lock_dir = os.path.dirname(canon)", "    lock_dir = os.path.dirname(os.path.abspath(path))"),
 ("persistence/ledger.py", "            with exclusive_open_lock(self._path):", "            if True:"),
]
IGN = shutil.ignore_patterns("__pycache__", "*.pyc", ".git")


def run_one(i, spec):
    fname, old, new = spec
    tmp = pathlib.Path(tempfile.mkdtemp(prefix="mutc31_"))
    try:
        work = tmp / "tree"
        shutil.copytree(ROOT, work, ignore=IGN)
        path = work / "src/sanour_ai" / fname
        src = path.read_text()
        if src.count(old) != 1:
            return i, "Tool Error", 0.0, "pattern not unique or not found"
        path.write_text(src.replace(old, new, 1))
        env = {**os.environ, "PYTHONPATH": f"{work/'src'}{os.pathsep}{work}", "PYTHONDONTWRITEBYTECODE": "1"}
        t = time.time()
        try:
            p = subprocess.run([sys.executable, "-W", "ignore", "-m", "unittest", "-f", *TESTS], cwd=work, env=env,
                               capture_output=True, text=True, timeout=240)
        except subprocess.TimeoutExpired:
            return i, "Timeout", time.time() - t, ""
        out = p.stderr
        m = re.search(r"FAILED \((.*?)\)", out)
        ran = re.search(r"^Ran \d+ tests?", out, re.M)
        if not ran or p.returncode < 0:
            return i, "Tool Error", time.time() - t, "test process did not finish normally"
        if p.returncode == 0:
            return i, "Survived", time.time() - t, ""
        if m and "failures=" in m.group(1):
            return i, "Killed by Assertion", time.time() - t, ""
        if m and "errors=" in m.group(1):
            return i, "Killed by Exception", time.time() - t, ""
        return i, "Tool Error", time.time() - t, "unclassified"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main():
    md = sys.argv[sys.argv.index("--md") + 1] if "--md" in sys.argv else None
    workers = int(sys.argv[sys.argv.index("--workers") + 1]) if "--workers" in sys.argv else 3
    res = {}
    with cf.ThreadPoolExecutor(workers) as ex:
        for f in cf.as_completed([ex.submit(run_one, i, s) for i, s in enumerate(M, 1)]):
            i, st, dt, note = f.result()
            res[i] = st
            print(f"[{i:3}] {st:20} {M[i-1][1][:50]!r} ({dt:.1f}s) {note}", flush=True)
    c = Counter(res.values())
    print("\nmutants:", len(M), dict(c))
    if md:
        with open(md, "w") as fh:
            fh.write("# Stage 10.54-C3.2 mutation testing (generated by tools/mutation_c32_storage.py)\n\n")
            fh.write(f"Mutants: {len(M)}. " + ". ".join(f"{k}: {v}" for k, v in sorted(c.items())) + ".\n\n")
            fh.write("| # | original | mutant | result |\n|---|---|---|---|\n")
            esc = lambda x: x.replace("|", "\\|").replace("\n", "\\n")[:90]
            for i in sorted(res):
                fh.write(f"| {i} | `{esc(M[i-1][1])}` | `{esc(M[i-1][2])}` | {res[i]} |\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
