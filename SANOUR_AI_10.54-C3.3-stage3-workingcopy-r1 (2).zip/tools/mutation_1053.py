"""Stage 10.53 mutation testing. One change at a time to the new modules; each must be killed by the 10.52 + 10.53 tests."""
import os, pathlib, subprocess, sys
ROOT = pathlib.Path(__file__).resolve().parents[1]
PK = ROOT / "src/sanour_ai/readiness"
M = [
 # chain
# Equivalent (not run): dropping `e.prev_hash != prev` or `e.seq != i` in chain.verify changes nothing, because
# both values are already inside the entry hash that verify() recomputes.
 ("chain.py", "e.hash != _entry_hash(e.seq, e.kind, e.payload, prev)", "False"),
 ("chain.py", 'f"{seq}|{kind}|{payload}|{prev}"', 'f"{seq}|{kind}|{prev}"'),
 # evidence store
 ("evidence_store.py", "if claimed is not None and claimed.lower() != sha:", "if False:"),
 ("evidence_store.py", "sha = hashlib.sha256(bytes(artifact)).hexdigest()", 'sha = claimed or "0"*64'),
 ("evidence_store.py", 'if not source.startswith("live://"):', "if False:"),
 ("evidence_store.py", "if method not in LIVE_METHODS:", "if False:"),
 ("evidence_store.py", "if reviewer not in self._reviewers:", "if False:"),
 ("evidence_store.py", "if reviewer == recorded_by:", "if False:"),
 ("evidence_store.py", "if _has_mock_marker(source, method, software, version, note, artifact.decode", "if False and _has_mock_marker(source, method, software, version, note, artifact.decode"),
 ("evidence_store.py", 'if _has_mock_marker(source, method, software, version, note, artifact.decode("utf-8", "ignore")):', 'if _has_mock_marker(source, method, software, version, note):'),
 ("evidence_store.py", "if verified_at > now:", "if False:"),
 ("evidence_store.py", "if dt.tzinfo is None:", "if False:"),
 ("evidence_store.py", "if any(redact(t) != t for t in text_fields):", "if False:"),
 ("evidence_store.py", "if redact(body) != body:", "if False:"),
 ("evidence_store.py", "if sup in self._superseded_by or sup in self._revoked:", "if False:"),
 ("evidence_store.py", "if (old.provider_id, old.criterion) != (provider_id, criterion):", "if False:"),
 ("evidence_store.py", "if old is None:", "if False:"),
 ("evidence_store.py", "if age > life:", "if age > life * 2:"),
 ("evidence_store.py", "if age > life * STALE_FRACTION:", "if False:"),
 ("evidence_store.py", "if evidence_id in self._revoked:\n                return Standing.REVOKED", "if False:\n                return Standing.REVOKED"),
 ("evidence_store.py", "if evidence_id in self._superseded_by:\n                return Standing.SUPERSEDED", "if False:\n                return Standing.SUPERSEDED"),
 ("evidence_store.py", "if not self._log.verify():\n                return False", "if False:\n                return False"),
 ("evidence_store.py", "self._records[i].digest() == d", "True"),
 ("evidence_store.py", "set(logged) == set(self._records) and ", ""),
 ("evidence_store.py", "len(seen) == 2" , "len(seen) == 2") if False else ("evidence_store.py", "if len(v) == 2]", "if len(v) == 3]"),
 ("evidence_store.py", "self._log.append(\"EVIDENCE_REJECTED\"", "(lambda *a, **k: None)(\"EVIDENCE_REJECTED\""),
 ("evidence_store.py", "if len(reason.strip()) < 5", "if False") if False else ("evidence_store.py", 'if not actor.strip() or len(reason.strip()) < 5:', "if False:"),
 ("evidence_store.py", "if evidence_id in self._revoked:\n                raise", "if False:\n                raise"),
 # governance
 ("governance.py", "if not self._store.verify_integrity():", "if False:"),
 ("governance.py", "if st in (Standing.VALID, Standing.STALE):", "if st is not Standing.REVOKED:"),
 ("governance.py", "usable += [r for r in expired if not r.supports]", "pass"),
 ("governance.py", "if data is None or not self._store.verify_artifact(r.evidence_id, data):", "if False:"),
 ("governance.py", "if prev is not r.status:", "if False:"),
 ("governance.py", "or logged[0][\"digest\"] != digest", ""),
 ("governance.py", "sha256_text(canonical(body)) != digest or ", ""),
 ("governance.py", "if not self._log.verify() or ", "if "),
 ("governance.py", "overall is Status.PASS and not blockers", "True"),
 ("governance.py", "key=sev.__getitem__", "key=lambda s: 0"),
 ("governance.py", '"evidence_log_head": self._store.head_hash', '"evidence_log_head": ""'),
 ("governance.py", "if spec.criteria != tuple(c.value for c in Criterion):", "if False:"),
 ("governance.py", '"1": CriteriaSpec(\n        "1",\n        tuple(c.value for c in Criterion),\n        ("sdk_transport_conformance",),', '"1": CriteriaSpec(\n        "1",\n        tuple(c.value for c in Criterion),\n        (),'),
 # lifecycle
 ("lifecycle.py", "if target not in ALLOWED[cur]:", "if False:"),
 ("lifecycle.py", "if not roles & REQUIRED_ROLES[target]:", "if False:"),
 ("lifecycle.py", "actor == self._configured_by.get(provider_id)", "False"),
 ("lifecycle.py", "len(reason.strip()) < 5", "len(reason.strip()) < 0"),
 ("lifecycle.py", "S.RETIRED: frozenset(),", "S.RETIRED: frozenset({S.REGISTERED}),"),
 ("lifecycle.py", "S.OPERATIONAL: frozenset({S.SUSPENDED, S.RETIRED}),", "S.OPERATIONAL: frozenset({S.SUSPENDED, S.RETIRED, S.REGISTERED}),"),
 ("lifecycle.py", "S.VALIDATED: frozenset({Role.REVIEWER}),", "S.VALIDATED: frozenset({Role.REVIEWER, Role.OPERATOR}),"),
 ("lifecycle.py", "S.RETIRED: frozenset({Role.ADMIN}),", "S.RETIRED: frozenset({Role.ADMIN, Role.OPERATOR}),"),
 ("lifecycle.py", "if cur is None:", "if False:"),
 ("lifecycle.py", '"reason": redact(str(reason))[:200]', '"reason": str(reason)[:200]'),
 ("lifecycle.py", 'self._record("DENIED", pid, cur, target, actor, why)', "pass"),
]
env = dict(os.environ, PYTHONPATH=f"{ROOT/'src'}:{ROOT}", PYTHONDONTWRITEBYTECODE="1")
mods = "tests.unit.test_stage1052_readiness tests.unit.test_stage1053_readiness".split()
killed = 0; survivors = []
for f, a, b in M:
    path = PK / f
    orig = path.read_text()
    assert orig.count(a) >= 1, (f, a)
    path.write_text(orig.replace(a, b, 1))
    try:
        r = subprocess.run([sys.executable, "-m", "unittest", *mods], cwd=ROOT, env=env, capture_output=True, text=True, timeout=120)
        dead = r.returncode != 0
    except subprocess.TimeoutExpired:
        dead = True
    finally:
        path.write_text(orig)
    if dead: killed += 1
    else: survivors.append((f, a[:60], b[:40]))
    print("KILLED  " if dead else "SURVIVED", f, "|", a[:60].replace("\n", " "), "->", b[:40].replace("\n", " "))
print(f"total={len(M)} killed={killed} survived={len(survivors)}")
sys.exit(1 if survivors else 0)
