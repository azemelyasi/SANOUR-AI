"""Stage 10.54-C3 mutation testing. One textual change per mutant, applied to a PRIVATE COPY of the tree.
Runs the C1, C2 and C3 test modules and classifies each outcome:
  Killed by Assertion | Killed by Exception | Equivalent (only with a written proof; none declared here)
  Survived | Timeout | Tool Error (pattern not found or tool failure)
Only Assertion and Exception count as detected. Survived and Timeout are reported, never relabelled.
Usage: PYTHONPATH=src:. python tools/mutation_1054c3.py [--md OUT.md] [--workers N]"""
import concurrent.futures as cf
import os
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile
import time
from collections import Counter

ROOT = pathlib.Path(__file__).resolve().parents[1]
TESTS = ["tests.unit.test_stage1054c1_backup", "tests.unit.test_stage1054c2_integration", "tests.unit.test_stage1054c3_final"]
P, I, B = "persistence", "integrity", "backup"
M = [
 (f"{P}/ledger.py", "if C.sha256_hex(r.canonical_bytes) != r.record_hash:", "if False:"),
 (f"{P}/ledger.py", "if r.seq != expect_seq:", "if False:"),
 (f"{P}/ledger.py", "if r.prev_hash != prev:", "if False:"),
 (f"{P}/ledger.py", "            for g in GUARDS:", "            for g in ():"),
 (f"{P}/ledger.py", "                for hook in self._commit_hooks:\n                    hook(conn)", "                for hook in ():\n                    hook(conn)"),
 (f"{P}/ledger.py", 'conn.execute("ROLLBACK")', "None"),
 (f"{P}/recovery.py", "            if at is None or at[0] != a.head_hash:", "            if False:"),
 (f"{P}/recovery.py", "            if at is None or at[0] != cp.head_hash:", "            if False:"),
 (f"{P}/recovery.py", "        if cp.record_seq > head_seq:", "        if False:"),
 (f"{P}/recovery.py", "                if anchor == top:\n                    if any(", "                if False:\n                    if any("),
 (f"{I}/composition.py", "    if expected is not None and {k: streams.get(k) for k in expected} != expected:", "    if False:"),
 (f"{I}/composition.py", "    report = verify_integrity(ledger, anchors)", "    report = verify_integrity(ledger, None)"),
 (f"{I}/hooks.py", "if g not in triggers:", "if False:"),
 (f"{I}/audit.py", "        with self._lock, self._file_lock():", "        with self._lock:"),
 (f"{I}/audit.py", "                        if time.monotonic() >= deadline:", "                        if False:"),
 (f"{I}/audit.py", "            if any(e[\"id\"] == event_id for e in self.events()):", "            if False:"),
 (f"{B}/archive.py", "    if any(os.path.lexists(path + s) for s in _SIDECARS):\n        raise exc(\"unexpected sidecar files next to the database\")\n    try:", "    try:"),
 (f"{B}/archive.py", "            os.fsync(fd_out)", "            pass"),
 (f"{B}/archive.py", "        os.fsync(fd)\n    finally:\n        os.close(fd)\n\n\ndef _digest", "        pass\n    finally:\n        os.close(fd)\n\n\ndef _digest"),
 (f"{B}/archive.py", "        _write_new(os.path.join(staging, MANIFEST_NAME), C.dumps({**body, \"manifest_sha256\": manifest_sha}))", "        pass"),
 (f"{B}/archive.py", "        _refuse_existing(dest, BackupError)\n        os.rename(staging, dest)", "        os.rename(staging, dest)"),
 (f"{B}/archive.py", "    _refuse_existing(dest, RestoreError)\n    parent", "    parent"),
 (f"{B}/archive.py", "            os.link(tmp, dest)", "            os.replace(tmp, dest)"),
 (f"{B}/archive.py", "        report = verify_integrity(led, anchors)", "        report = verify_integrity(led, None)"),
 (f"{B}/archive.py", "        if _digest(tmp) != (entry[\"sha256\"], entry[\"size\"]):", "        if False:"),
 (f"{B}/archive.py", "    if claimed != C.sha256_hex(C.dumps(obj)):", "    if False:"),
]
IGN = shutil.ignore_patterns("__pycache__", "*.pyc", ".git")
TIMEOUT_S = 90


def run_one(i, spec):
    fname, old, new = spec
    tmp = pathlib.Path(tempfile.mkdtemp(prefix="mutc3_"))
    try:
        work = tmp / "tree"
        shutil.copytree(ROOT, work, ignore=IGN)
        path = work / "src/sanour_ai" / fname
        src = path.read_text()
        if src.count(old) != 1:
            return i, "Tool Error", 0.0, "pattern not unique or not found"
        path.write_text(src.replace(old, new, 1))
        env = {**os.environ, "PYTHONPATH": f"{work/'src'}{os.pathsep}{work}", "PYTHONDONTWRITEBYTECODE": "1"}
        t = time.time()
        try:
            p = subprocess.run([sys.executable, "-W", "ignore", "-m", "unittest", *TESTS], cwd=work, env=env,
                               capture_output=True, text=True, timeout=TIMEOUT_S)
        except subprocess.TimeoutExpired:
            return i, "Timeout", time.time() - t, ""
        out = p.stderr
        m = re.search(r"FAILED \((.*?)\)", out)
        ran = re.search(r"^Ran \d+ tests?", out, re.M)
        if not ran or p.returncode < 0:
            return i, "Tool Error", time.time() - t, "test process did not finish normally"
        if p.returncode == 0:
            return i, "Survived", time.time() - t, ""
        if m and "failures=" in m.group(1):
            return i, "Killed by Assertion", time.time() - t, ""
        if m and "errors=" in m.group(1):
            return i, "Killed by Exception", time.time() - t, ""
        return i, "Tool Error", time.time() - t, "unclassified failure"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main():
    md = sys.argv[sys.argv.index("--md") + 1] if "--md" in sys.argv else None
    workers = int(sys.argv[sys.argv.index("--workers") + 1]) if "--workers" in sys.argv else 3
    res, notes = {}, {}
    with cf.ThreadPoolExecutor(workers) as ex:
        futs = [ex.submit(run_one, i, s) for i, s in enumerate(M, 1)]
        for f in cf.as_completed(futs):
            i, st, dt, note = f.result()
            res[i], notes[i] = st, note
            print(f"[{i:3}] {st:20} {M[i-1][0]}: {M[i-1][1][:50]!r} -> {M[i-1][2][:24]!r} ({dt:.1f}s) {note}", flush=True)
    c = Counter(res.values())
    print("\nmutants:", len(M), dict(c))
    if md:
        with open(md, "w") as fh:
            fh.write("# Stage 10.54-C3 mutation testing (generated by tools/mutation_1054c3.py)\n\n")
            fh.write(f"Mutants: {len(M)}. " + ". ".join(f"{k}: {v}" for k, v in sorted(c.items())) + ".\n\n")
            fh.write("Equivalent: none declared (an equivalence claim needs a written proof). Survived and Timeout are real results.\n\n")
            fh.write("| # | file | original | mutant | result |\n|---|---|---|---|---|\n")
            esc = lambda x: x.replace("|", "\\|").replace("\n", "\\n")[:80]
            for i in sorted(res):
                fh.write(f"| {i} | {M[i-1][0]} | `{esc(M[i-1][1])}` | `{esc(M[i-1][2])}` | {res[i]} |\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
