"""Stage 10.54-B mutation testing. One textual change per mutant, applied to a PRIVATE COPY of the tree, so the
real tree is never modified. Runs the 10.54-A and 10.54-B persistence test modules and classifies each outcome:
  KILLED_ASSERTION  a test assertion failed (the intended way to kill a mutant)
  KILLED_ERROR      a test raised an unexpected exception (counts as detected, reported separately)
  CRASH             the test process died or could not start (import/syntax error, signal): NOT counted as a kill
  TIMEOUT           the run exceeded the limit: NOT counted as a kill
  SURVIVED          all tests passed
  INVALID           the pattern was not found in the source
Usage: PYTHONPATH=src:. python tools/mutation_1054b.py [--md OUT.md] [--workers N]"""
import concurrent.futures as cf
import os
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = pathlib.Path(__file__).resolve().parents[1]
TESTS = ["tests.unit.test_stage1054b_recovery", "tests.unit.test_stage1054a_ledger"]
R, L, MG = "recovery.py", "ledger.py", "migrations.py"
M = [
 (R, "if last.record_seq and (at is None or at[0] != last.head_hash):", "if False:"),
 (R, "if seq == last.record_seq and hsh == last.head_hash:", "if False:"),
 (R, "if head and C.sha256_hex(head[2] if isinstance(head[2], bytes) else b\"\") != hsh:", "if False:"),
 (R, "prev, cp_seq = last.cp_hash, last.cp_seq + 1", "prev, cp_seq = last.cp_hash, last.cp_seq + 2"),
 (R, "prev, cp_seq = last.cp_hash, last.cp_seq + 1", "prev, cp_seq = C.GENESIS_HASH, last.cp_seq + 1"),
 (R, "created = ledger._now()", "created = \"1970-01-01T00:00:00+00:00\""),
 (R, "version = int(c.execute(\"SELECT MAX(version) FROM schema_migrations\").fetchone()[0])", "version = 1"),
 (R, "if an.seq < last_seq.get(an.stream, 0):", "if False:"),
 (R, "and obj[\"prev\"] == prev", "and True"),
 (R, "obj[\"line_hash\"] == C.sha256_hex(C.dumps(body))", "True"),
 (R, "and raw == C.dumps(obj)", "and True"),
 (R, "if tail:", "if False:"),
 (R, "if anchor.seq < top.seq:", "if False:"),
 (R, "anchor.head_hash != top.head_hash", "False"),
 (R, "if anchor == top:", "if False:"),
 (R, "os.fsync(fd)", "pass"),
 (R, "if issues:   # drop an unfinished tail", "if False:   # drop an unfinished tail"),
 (R, "or an.stream not in C.STREAMS", ""),
 (R, "if any(not i.startswith(\"anchor_partial_tail\") for i in issues):", "if False:"),
 (R, "return anchors, issues   # nothing after a broken link can be trusted", "pass"),
 (R, "if cp.record_seq > head_seq:", "if False:"),
 (R, "if at is None or at[0] != cp.head_hash:", "if False:"),
 (R, "if at is None or at[0] != a.head_hash:", "if False:"),
 (R, "if a.seq > head_seq:", "if False:"),
 (R, "if cp.record_seq < last_rseq:", "if False:"),
 (R, "if cp.prev_cp_hash != prev_hash:", "if False:"),
 (R, "if C.sha256_hex(cp.canonical_bytes) != cp.cp_hash:", "if False:"),
 (R, "if C.dumps(b) != cp.canonical_bytes:", "if False:"),
 (R, "out.append(Finding(s, cp.cp_seq, \"checkpoint_columns_differ_from_bytes\"))", "pass"),
 (R, "if cp.cp_seq != expect:", "if False:"),
 (R, "if res != \"ok\":", "if False:"),
 (R, "if c.execute(\"PRAGMA foreign_key_check\").fetchone():", "if False:"),
 (R, "if rel is None or rel[0] != want:", "if False:"),
 (R, "if r is None or r[0] >= seq:", "if False:"),
 (R, "if want == \"supersedes\":", "if False:"),
 (R, "found += [Finding(\"-\", 0, f\"guard_missing:{g}\") for g in CP_GUARDS if g not in have]", "pass"),
 (R, "        if seq == 0:                                  # structural: a guard trigger is gone", "        if False:"),
 (R, "            if seq:\n                found.append(Finding(s, seq, code))", "            if False:\n                found.append(Finding(s, seq, code))"),
 (R, "schema_version > ?", "schema_version > ? + 100000"),
 (R, "            with led._write() as _:\n                pass          # takes the write lock once: proves no dead writer still holds it", "            pass"),
 (R, "verify_integrity(led, anchors))", "verify_integrity(led))"),
 (R, "return RecoveryReport(True, led.schema_version(), moved,", "return RecoveryReport(False, led.schema_version(), moved,"),
 (R, "return [Finding(\"-\", 0, \"checkpoint_schema_version_ahead\")] if bad else []", "return []"),
 (R, "anchors, issues = log.read()\n    except AnchorError:", "anchors, issues = [], []\n    except AnchorError:"),
 (L, "if record_id.startswith(RESERVED_PREFIXES):", "if False:"),
 (MG, "    CHECK ((record_seq = 0) = (head_hash = '{ZERO}'))\n", "    CHECK (1)\n"),
 (MG, "    UNIQUE (cp_hash),\n", ""),
 (MG, "\"(stream = NEW.stream AND cp_seq = NEW.cp_seq) OR cp_hash = NEW.cp_hash\"", "\"(stream = NEW.stream AND cp_seq = NEW.cp_seq)\""),
 (MG, "    CHECK ((cp_seq = 1) = (prev_cp_hash = '{ZERO}')),\n", ""),
]
EQUIVALENT: list[tuple[str, str]] = [
    ("recovery.py: `if seq < last.record_seq:` -> `if False:`",
     "Redundant guard. When the ledger head is behind the last checkpoint, no record exists at last.record_seq, so the "
     "very next check (`at is None`) raises the same RecoveryError. Behaviour is identical; kept as an explicit, "
     "readable first line of defence."),
    ("recovery.py: raising RecoveryError('ledger is behind its last checkpoint') -> `pass`",
     "Same redundancy as above: the following `at is None` check raises RecoveryError for the same input."),
]
IGN = shutil.ignore_patterns("__pycache__", "*.pyc", ".git")


def run_one(i, spec):
    fname, old, new = spec
    tmp = pathlib.Path(tempfile.mkdtemp(prefix="mut1054b_"))
    try:
        work = tmp / "tree"
        shutil.copytree(ROOT, work, ignore=IGN)
        path = work / "src/sanour_ai/persistence" / fname
        src = path.read_text()
        if old not in src:
            return i, "INVALID", 0.0
        path.write_text(src.replace(old, new, 1))
        env = {**os.environ, "PYTHONPATH": f"{work/'src'}{os.pathsep}{work}", "PYTHONDONTWRITEBYTECODE": "1"}
        t = time.time()
        try:
            p = subprocess.run([sys.executable, "-m", "unittest", "-f", *TESTS], cwd=work, env=env,
                               capture_output=True, text=True, timeout=300)
        except subprocess.TimeoutExpired:
            return i, "TIMEOUT", time.time() - t
        out = p.stderr
        m = re.search(r"FAILED \((.*?)\)", out)
        ran = re.search(r"^Ran \d+ tests?", out, re.M)
        if p.returncode == 0 and ran:
            return i, "SURVIVED", time.time() - t
        if p.returncode < 0 or not ran:
            return i, "CRASH", time.time() - t
        if m and "failures=" in m.group(1):
            return i, "KILLED_ASSERTION", time.time() - t
        if m and "errors=" in m.group(1):
            return i, "KILLED_ERROR", time.time() - t
        return i, "CRASH", time.time() - t
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main():
    md = sys.argv[sys.argv.index("--md") + 1] if "--md" in sys.argv else None
    workers = int(sys.argv[sys.argv.index("--workers") + 1]) if "--workers" in sys.argv else 3
    res = {}
    with cf.ThreadPoolExecutor(workers) as ex:
        futs = [ex.submit(run_one, i, s) for i, s in enumerate(M, 1)]
        for f in cf.as_completed(futs):
            i, st, dt = f.result()
            res[i] = st
            print(f"[{i:3}] {st:17} {M[i-1][0]}: {M[i-1][1][:60]!r} -> {M[i-1][2][:28]!r} ({dt:.1f}s)", flush=True)
    from collections import Counter
    c = Counter(res.values())
    for name, why in EQUIVALENT:
        print(f"EQUIVALENT (not run): {name}: {why}")
    print("\nmutants:", len(M), dict(c), "equivalent:", len(EQUIVALENT))
    if md:
        with open(md, "w") as fh:
            fh.write("# Stage 10.54-B mutation testing (generated by tools/mutation_1054b.py)\n\n")
            fh.write(f"Mutants: {len(M)}. " + ". ".join(f"{k}: {v}" for k, v in sorted(c.items())) + f". Equivalent (not run): {len(EQUIVALENT)}.\n\n")
            for name, why in EQUIVALENT:
                fh.write(f"Equivalent, not run: **{name}**. {why}\n\n")
            fh.write("Only KILLED_ASSERTION and KILLED_ERROR count as detected. CRASH and TIMEOUT do not.\n\n")
            fh.write("| # | file | original | mutant | result |\n|---|---|---|---|---|\n")
            esc = lambda x: x.replace("|", "\\|").replace("\n", "\\n")[:90]
            for i in sorted(res):
                fh.write(f"| {i} | {M[i-1][0]} | `{esc(M[i-1][1])}` | `{esc(M[i-1][2])}` | {res[i]} |\n")
    bad = [k for k in c if k not in ("KILLED_ASSERTION", "KILLED_ERROR")]
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
