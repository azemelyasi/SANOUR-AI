"""Stage 10.54-A mutation testing. One textual change at a time to the persistence package; the 10.54-A test
module must fail (kill) each one. Files are restored after every mutant, even on error or Ctrl-C.
Usage: PYTHONPATH=src:. python tools/mutation_1054a.py [--md OUT.md]
A SURVIVED mutant is reported, never hidden. Mutants judged equivalent are listed with a reason in EQUIVALENT
and are not run."""
import os
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parents[1]
PK = ROOT / "src/sanour_ai/persistence"
TEST = "tests.unit.test_stage1054a_ledger"

M = [
 # canonical.py
 ("canonical.py", "if redact(text) != text or _PRIVATE_KEY_BLOCK.search(text):", "if False:"),
 ("canonical.py", "redact(text) != text or _PRIVATE_KEY_BLOCK.search(text)", "redact(text) != text"),
 ("canonical.py", "redact(text) != text or _PRIVATE_KEY_BLOCK.search(text)", "_PRIVATE_KEY_BLOCK.search(text)"),
 ("canonical.py", "if _SECRET_KEY.match(key) and item not in (None, \"\", False):", "if False:"),
 ("canonical.py", "if _SECRET_KEY.match(key) and item not in (None, \"\", False):", "if _SECRET_KEY.match(key):"),
 ("canonical.py", "_screen_text(key)", "pass"),
 ("canonical.py", "raise RecordRejected(\"payload contains an unsupported type\")", "return"),
 ("canonical.py", "sort_keys=True", "sort_keys=False"),
 ("canonical.py", "ensure_ascii=True", "ensure_ascii=False"),
 ("canonical.py", "if depth > MAX_DEPTH:", "if False:"),
 ("canonical.py", "if len(value) > MAX_STRING:", "if False:"),
 ("canonical.py", "if not -(2**63) <= value < 2**63:", "if False:"),
 ("canonical.py", "if not isinstance(key, str):", "if False:"),
 ("canonical.py", "if len(dumps(payload)) > MAX_PAYLOAD_BYTES:", "if False:"),
 ("canonical.py", "if not isinstance(payload, dict):", "if False:"),
 ("canonical.py", "not _ID.match(value)", "False"),
 ("canonical.py", "not _KIND.match(value)", "False"),
 ("canonical.py", "value not in STREAMS", "False"),
 ("canonical.py", "{\"kind\": kind, \"payload\": payload}", "{\"payload\": payload}"),
 ("canonical.py", "\"prev_hash\": prev_hash, \"payload\": payload,", "\"payload\": payload,"),
 ("canonical.py", "\"recorded_at\": recorded_at,", ""),
 # ledger.py
 ("ledger.py", "rec_hash = C.sha256_hex(raw)", "rec_hash = C.sha256_hex(raw[:-1])"),
 ("ledger.py", "if existing.content_sha256 != digest:", "if False:"),
 ("ledger.py", "            return AppendResult(existing, True)\n        head", "            return AppendResult(existing, False)\n        head"),
 ("ledger.py", "(head[0] + 1, head[1]) if head", "(head[0] + 1, C.GENESIS_HASH) if head"),
 ("ledger.py", "\"ORDER BY seq DESC LIMIT 1\", (stream,)).fetchone()\n        seq, prev", "\"ORDER BY seq ASC LIMIT 1\", (stream,)).fetchone()\n        seq, prev"),
 ("ledger.py", "conn.execute(\"BEGIN IMMEDIATE\")", "conn.execute(\"BEGIN\")"),
 ("ledger.py", "conn.execute(\"ROLLBACK\")", "pass"),
 ("ledger.py", "conn.execute(\"COMMIT\")", "pass"),
 ("ledger.py", "PRAGMA synchronous=FULL", "PRAGMA synchronous=NORMAL"),
 ("ledger.py", "PRAGMA journal_mode=WAL", "PRAGMA journal_mode=DELETE"),
 ("ledger.py", "PRAGMA foreign_keys=ON", "PRAGMA foreign_keys=OFF"),
 ("ledger.py", "conn.execute(\"PRAGMA query_only=ON\")", "pass"),
 ("ledger.py", "conn.execute(\"BEGIN\")        # one consistent", "pass        # one consistent"),
 ("ledger.py", "if mig.version in again:", "if False:"),
 ("ledger.py", "or path == \":memory:\"", ""),
 ("ledger.py", "if record_id == old_id:", "if False:"),
 ("ledger.py", "if self._link_exists(c, stream, old.seq, \"supersedes\") or self._link_exists(c, stream, old.seq, \"revokes\"):", "if False:"),
 ("ledger.py", "if self._link_exists(c, stream, old.seq, \"supersedes\") or self._link_exists(c, stream, old.seq, \"revokes\"):", "if self._link_exists(c, stream, old.seq, \"supersedes\"):"),
 ("ledger.py", "if old is None:\n                raise LinkRejected", "if False:\n                raise LinkRejected"),
 ("ledger.py", "new.content_sha256 != C.content_digest(kind, payload)", "False"),
 ("ledger.py", "if target is None:", "if False:"),
 ("ledger.py", "len(reason.strip()) < 5", "len(reason.strip()) < 0"),
 ("ledger.py", "if existing.content_sha256 != C.content_digest(event_kind, event_payload):", "if False:"),
 ("ledger.py", "if not isinstance(actor, str) or not actor.strip():", "if False:"),
 ("ledger.py", "self._insert_link(c, stream, ev.record.seq, \"supersedes\", old.seq)", "pass"),
 ("ledger.py", "self._insert_link(c, stream, ev.record.seq, \"revokes\", target.seq)", "pass"),
 ("ledger.py", "if self._link_exists(c, stream, rec.seq, \"revokes\"):\n                return \"revoked\"", "if False:\n                return \"revoked\""),
 ("ledger.py", "if C.sha256_hex(r.canonical_bytes) != r.record_hash:", "if False:"),
 ("ledger.py", "if r.prev_hash != prev:", "if False:"),
 ("ledger.py", "if r.seq != expect_seq:", "if False:"),
 ("ledger.py", "if C.dumps(body) != r.canonical_bytes:", "if False:"),
 ("ledger.py", "r.prev_hash):\n                out.append(\"columns_differ_from_bytes\")", "r.prev_hash) and False:\n                out.append(\"columns_differ_from_bytes\")"),
 ("ledger.py", "if C.content_digest(body[\"kind\"], body[\"payload\"]) != r.content_sha256:", "if False:"),
 ("ledger.py", "if g not in have:", "if False:"),
 ("ledger.py", "if not ok:", "if False:"),
 ("ledger.py", "return VerifyReport(not problems,", "return VerifyReport(True,"),
 ("ledger.py", "if str(mode).lower() != \"wal\":", "if False:"),
 ("ledger.py", "if conn.execute(\"PRAGMA quick_check\").fetchone()[0] != \"ok\":", "if False:"),
 ("ledger.py", "return LedgerBusyError(\"ledger is busy\")", "return LedgerStorageError(\"ledger is busy\")"),
 ("ledger.py", "r[8] if isinstance(r[8], bytes) else", "r[8] if True else"),
 # migrations.py
 ("migrations.py", "if not migrations or [m.version for m in migrations] != list(range(1, len(migrations) + 1)):", "if not migrations:"),
 ("migrations.py", "if known[version].checksum != checksum:", "if False:"),
 ("migrations.py", "if version not in known:", "if False:"),
 ("migrations.py", "if done != list(range(1, len(done) + 1)):", "if False:"),
 ("migrations.py", "CHECK ((seq = 1) = (prev_hash = '{ZERO}'))", "CHECK (1)"),
 ("migrations.py", "    UNIQUE (stream, record_id),\n", ""),
 ("migrations.py", "    UNIQUE (record_hash),\n", ""),
 ("migrations.py", "    CHECK (target_seq < event_seq),\n", ""),
 ("migrations.py", "    UNIQUE (stream, target_seq, relation),\n", ""),
 ("migrations.py", "    FOREIGN KEY (stream, target_seq) REFERENCES ledger_records (stream, seq)\n", "    CHECK (1)\n"),
 ("migrations.py", "BEFORE UPDATE ON {table} ", "BEFORE UPDATE ON {table} WHEN 0 "),
 ("migrations.py", "BEFORE DELETE ON {table} ", "BEFORE DELETE ON {table} WHEN 0 "),
 ("migrations.py", "BEFORE INSERT ON {table} WHEN EXISTS ", "BEFORE INSERT ON {table} WHEN 0 AND EXISTS "),
 ("migrations.py", "OR record_hash = NEW.record_hash", ""),
 # facades.py
 ("facades.py", "claimed.lower() != sha", "False"),
 ("facades.py", "sha = hashlib.sha256(bytes(artifact)).hexdigest()", "sha = a[\"claimed_sha256\"] or \"0\" * 64"),
 ("facades.py", "if len(artifact) > MAX_ARTIFACT_BYTES:", "if False:"),
 ("facades.py", "if old is not None and (old.payload[\"provider_id\"], old.payload[\"criterion\"]) != (provider_id, criterion):", "if False:"),
 ("facades.py", "p[\"supersedes\"] = old_id", "pass"),
 ("facades.py", "v.tzinfo is None", "False"),
 ("facades.py", "if not isinstance(a[\"supports\"], bool):", "if False:"),
 ("facades.py", "if not isinstance(a[name], str) or not a[name].strip():", "if False:"),
 ("facades.py", "return hashlib.sha256(bytes(data)).hexdigest() == rec.payload[\"artifact_sha256\"]", "return True"),
]

# Mutants judged equivalent are not run; each needs a reason. (Filled in only after inspection.)
EQUIVALENT: list[tuple[str, str]] = [
    ("canonical.py: allow_nan=False -> True",
     "Equivalent: floats (the only source of NaN/inf) are rejected by _walk before dumps() runs, so allow_nan is never "
     "exercised. Kept as defence in depth."),
]


def run_tests(timeout=240):
    stray = ROOT / ":memory:"   # a mutant that disables the :memory: refusal creates this file; never ship it
    env = {**os.environ, "PYTHONPATH": f"{ROOT/'src'}{os.pathsep}{ROOT}", "PYTHONDONTWRITEBYTECODE": "1"}
    try:
        p = subprocess.run([sys.executable, "-m", "unittest", "-f", TEST], cwd=ROOT, env=env, capture_output=True,
                           text=True, timeout=timeout)
        return p.returncode, p.stderr[-300:]
    except subprocess.TimeoutExpired:
        return 124, "timeout"
    finally:
        if stray.exists():
            stray.unlink()


def main():
    md = sys.argv[sys.argv.index("--md") + 1] if "--md" in sys.argv else None
    rc, err = run_tests()
    if rc != 0:
        print("baseline run is not green; refusing to mutate\n" + err)
        return 2
    killed, survived, invalid, rows = 0, [], [], []
    for i, (fname, old, new) in enumerate(M, 1):
        path = PK / fname
        src = path.read_text()
        if src.count(old) < 1:
            invalid.append((i, fname, old))
            rows.append((i, fname, old, new, "INVALID (pattern not found)"))
            print(f"[{i:3}] INVALID  {fname}: {old[:60]!r}", flush=True)
            continue
        try:
            path.write_text(src.replace(old, new, 1))
            t = time.time()
            rc, _ = run_tests()
        finally:
            path.write_text(src)
        status = "KILLED" if rc != 0 else "SURVIVED"
        if rc == 0:
            survived.append((i, fname, old, new))
        else:
            killed += 1
        rows.append((i, fname, old, new, status))
        print(f"[{i:3}] {status:8} {fname}: {old[:55]!r} -> {new[:30]!r} ({time.time()-t:.1f}s)", flush=True)
    total = len(M) - len(invalid)
    for name, why in EQUIVALENT:
        print(f"EQUIVALENT (not run): {name}: {why}")
    print(f"\nmutants run: {total}  killed: {killed}  survived: {len(survived)}  invalid patterns: {len(invalid)}")
    if md:
        with open(md, "w") as fh:
            fh.write("# Stage 10.54-A mutation testing (generated by tools/mutation_1054a.py)\n\n")
            fh.write(f"Run: {total}. Killed: {killed}. Survived: {len(survived)}. Invalid patterns: {len(invalid)}.\n\n")
            for name, why in EQUIVALENT:
                fh.write(f"Equivalent, not run: **{name}**. {why}\n\n")
            fh.write("| # | file | original | mutant | result |\n|---|---|---|---|---|\n")
            for i, f, o, n, s in rows:
                esc = lambda x: x.replace("|", "\\|").replace("\n", "\\n")[:90]
                fh.write(f"| {i} | {f} | `{esc(o)}` | `{esc(n)}` | {s} |\n")
    return 0 if not survived and not invalid else 1


if __name__ == "__main__":
    sys.exit(main())
