"""Stage 10.54-C2 mutation testing. One textual change per mutant, applied to a PRIVATE COPY of the tree.
Runs the C2 test module and classifies each outcome:
  KILLED_ASSERTION  a test assertion failed (the intended way to kill a mutant)
  KILLED_ERROR      a test raised an unexpected exception (counts as detected, reported separately)
  CRASH             the test process died or could not start: NOT counted as a kill
  TIMEOUT           the run exceeded the limit: NOT counted as a kill
  SURVIVED          all tests passed: a gap in the tests, reported as such (never relabelled)
  INVALID           the pattern was not found in the source (not counted)
No mutant is declared EQUIVALENT in this file: an equivalence claim needs a written proof, added by hand.
Usage: PYTHONPATH=src:. python tools/mutation_1054c2.py [--md OUT.md] [--workers N]"""
import concurrent.futures as cf
import os
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = pathlib.Path(__file__).resolve().parents[1]
TESTS = ["tests.unit.test_stage1054c2_integration"]
L, H, AU, PO, AR = "persistence/ledger.py", "integrity/hooks.py", "integrity/audit.py", "integrity/ports.py", "backup/archive.py"
M = [
 (L, "                for hook in self._commit_hooks:\n                    hook(conn)", "                for hook in ():\n                    hook(conn)"),
 (L, "        self._commit_hooks = hooks", "        self._commit_hooks = ()"),
 (H, "                    if g not in triggers:", "                    if False:"),
 (H, "                if expected.get(version) != checksum:", "                if False:"),
 (H, "if hashlib.sha256(bytes(raw)).hexdigest() != rh:", "if False:"),
 (H, "                if seq != rows[i - 1][0] + 1:", "                if False:"),
 (H, "                if prev != rows[i - 1][2]:", "                if False:"),
 (H, "        if last[0] > head:", "        if False:"),
 (H, "        return set() if at is not None and at[0] == last[1] else {\"checkpoint_mismatch\"}", "        return set()"),
 (H, "        if codes:\n            raise IntegrityHookError", "        if False:\n            raise IntegrityHookError"),
 (H, "        if \"ledger_records\" in tables:\n            for stream", "        if False:\n            for stream"),
 (H, "            if table in tables:", "            if False:"),
 (H, "                    codes.add(\"migration_mismatch\")", "                    pass"),
 (AU, "            if any(e[\"id\"] == event_id for e in self.events()):", "            if False:"),
 (AU, "                    os.ftruncate(fd, len(data))", "                    pass"),
 (AU, "        if operation not in OPERATIONS or outcome not in OUTCOMES:", "        if False:"),
 (AU, "            if not isinstance(obj, dict) or obj.get(\"v\") != AUDIT_VERSION or raw != C.dumps(obj):", "            if False:"),
 (PO, "        self._record(op, target, \"ok\", \"-\")", "        pass"),
 (PO, "            self._record(op, target, \"refused\", type(exc).__name__ if type(exc).__name__.isidentifier() else \"-\")\n            raise",
      "            raise"),
 (AR, "    if any(os.path.lexists(path + s) for s in _SIDECARS):\n        raise exc(\"unexpected sidecar files next to the database\")\n    try:",
      "    try:"),
 (AR, "        raise exc(\"unexpected sidecar files next to the database\")\n\n\ndef _online_copy",
      "        pass\n\n\ndef _online_copy"),
 (AR, "                _remove_quiet(p)\n                removed += 1", "                removed += 1"),
 (AR, "        if name.startswith(_RESTORE_TMP) and not os.path.isdir(p) and (", "        if name.startswith(\"~never\") and not os.path.isdir(p) and ("),
 (AR, "        return restore_backup(backup_dir, os.path.join(parent, \"verify.sqlite\"))", "        return restore_backup(backup_dir, os.path.join(backup_dir, \"verify.sqlite\"))"),
 (AR, "        shutil.rmtree(parent, ignore_errors=True)\n\n\ndef sweep", "        pass\n\n\ndef sweep"),
]
IGN = shutil.ignore_patterns("__pycache__", "*.pyc", ".git")


def run_one(i, spec):
    fname, old, new = spec
    tmp = pathlib.Path(tempfile.mkdtemp(prefix="mutc2_"))
    try:
        work = tmp / "tree"
        shutil.copytree(ROOT, work, ignore=IGN)
        path = work / "src/sanour_ai" / fname
        src = path.read_text()
        if src.count(old) != 1:
            return i, "INVALID", 0.0
        path.write_text(src.replace(old, new, 1))
        env = {**os.environ, "PYTHONPATH": f"{work/'src'}{os.pathsep}{work}", "PYTHONDONTWRITEBYTECODE": "1"}
        t = time.time()
        try:
            p = subprocess.run([sys.executable, "-m", "unittest", "-f", *TESTS], cwd=work, env=env,
                               capture_output=True, text=True, timeout=300)
        except subprocess.TimeoutExpired:
            return i, "TIMEOUT", time.time() - t
        out = p.stderr
        m = re.search(r"FAILED \((.*?)\)", out)
        ran = re.search(r"^Ran \d+ tests?", out, re.M)
        if p.returncode == 0 and ran:
            return i, "SURVIVED", time.time() - t
        if p.returncode < 0 or not ran:
            return i, "CRASH", time.time() - t
        if m and "failures=" in m.group(1):
            return i, "KILLED_ASSERTION", time.time() - t
        if m and "errors=" in m.group(1):
            return i, "KILLED_ERROR", time.time() - t
        return i, "CRASH", time.time() - t
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main():
    md = sys.argv[sys.argv.index("--md") + 1] if "--md" in sys.argv else None
    workers = int(sys.argv[sys.argv.index("--workers") + 1]) if "--workers" in sys.argv else 3
    res = {}
    with cf.ThreadPoolExecutor(workers) as ex:
        futs = [ex.submit(run_one, i, s) for i, s in enumerate(M, 1)]
        for f in cf.as_completed(futs):
            i, st, dt = f.result()
            res[i] = st
            print(f"[{i:3}] {st:17} {M[i-1][0]}: {M[i-1][1][:55]!r} -> {M[i-1][2][:25]!r} ({dt:.1f}s)", flush=True)
    from collections import Counter
    c = Counter(res.values())
    print("\nmutants:", len(M), dict(c))
    if md:
        with open(md, "w") as fh:
            fh.write("# Stage 10.54-C2 mutation testing (generated by tools/mutation_1054c2.py)\n\n")
            fh.write(f"Mutants: {len(M)}. " + ". ".join(f"{k}: {v}" for k, v in sorted(c.items())) + ".\n\n")
            fh.write("No mutant is declared equivalent in this run.\n\n")
            fh.write("| # | file | original | mutant | result |\n|---|---|---|---|---|\n")
            esc = lambda x: x.replace("|", "\\|").replace("\n", "\\n")[:90]
            for i in sorted(res):
                fh.write(f"| {i} | {M[i-1][0]} | `{esc(M[i-1][1])}` | `{esc(M[i-1][2])}` | {res[i]} |\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
