# SANOUR AI (Stage 10.54-B; recovery and integrity: docs/RECOVERY_INTEGRITY_10_54B.md; Stage 10.54-A; persistent ledger foundation: docs/PERSISTENT_EVIDENCE_LEDGER.md; previous Stage 10.53; see docs/PROVIDER_OPERATIONAL_READINESS.md and docs/READINESS_GOVERNANCE_10_53.md)

Orchestration core. The OpenAI adapter is implemented and tested with fakes. It is not verified for production, and production builds are refused by the model verification gate until a model is approved in reviewed code. Tests run offline: no network, no API keys, no paid services. See `docs/PROVIDER_STATUS.md` for the status of each adapter.

## Windows PowerShell (not yet run on Windows)

    py -3.11 -m venv .venv
    .\.venv\Scripts\Activate.ps1
    python -m pip install -e ".[dev]"
    python -m pytest -q
    python -m ruff check .

Standard library only (no pytest needed):

    $env:PYTHONPATH = "src;."
    python -m unittest discover -s tests -t . -v

## Request policy

- **One attempt per request.** The router selects exactly one model. There is no fallback list,
  and `allow_fallback` is rejected as an invalid field.
- **One total deadline.** `timeout_seconds` (default 10, max 60) starts when `handle()` starts.
  Validation, routing, and the provider call all count against it. An expired deadline fails
  before any provider call.
- **Tolerance.** The caller returns at about the deadline. Tests allow 0.25 s of scheduling
  overhead. Measured only in the sandbox, not on Windows.
- **No retries.** `retryable` in an error tells the client whether a later retry may succeed.
  The core never retries itself.

## Timeout and worker policy

- Provider calls run in daemon threads. Python cannot forcibly stop a thread.
- **A timed-out call is not stopped.** It keeps running until the provider returns, and its
  result is discarded. The code makes no claim that the thread was terminated.
- **Bounded accumulation.** A semaphore caps live worker threads, including abandoned ones, at
  `SANOUR_MAX_CONCURRENT_PROVIDER_CALLS` (default 4, valid range 1 to 16).
- **Overflow fails fast.** When the cap is reached, a new call returns `provider_overloaded`
  (retryable) and starts no thread.
- **Slots return only when workers return.** A provider call that never returns keeps its slot
  for the life of the process. Known limit: recovering it requires a restart.
- **No cancellation** is implemented.

## Configuration

`config/settings.py` holds one operational value: the worker cap. It is read from the environment
variable above. No `.env` file is read, so no secrets can enter through it. Invalid values raise
`ConfigError` at startup, and the message names the setting but never its value.

## Layout

- `core/`: SanourCore entry point and request acceptance.
- `models/`: request/response schemas, capabilities, router, gateway, provider protocol.
- `providers/`: provider adapters and the shared contract. The test fake is test-only.
- `config/`: typed runtime settings.
- `security/`: secret redaction.
- `persistence/`: SQLite append-only evidence and governance ledger (Stage 10.54-A). Standalone: not wired into the core yet.
- `observability/`: redacted audit events (no prompt text).
- `tests/`: unit tests, integration tests, and shared helpers in `support.py`.

## OpenAI provider (step 09, offline only)

`src/sanour_ai/providers/openai_provider.py` implements the OpenAI adapter. It is wired only into the
gated production composition root, and the gate refuses it today (see Stage 10.45). It has **not been
connected to OpenAI** in this repository. No test sends a real request.

- Setup (after approval only): `pip install -e ".[openai]"`, which pins `openai==3.45.0` and
  `httpx2==2.13.1`. Set `OPENAI_API_KEY` in the environment. The key is never read from files or
  logged.
- Responses API with `store=False` and `max_output_tokens` from the call. The SDK is created with
  `max_retries=0`. No retry, no fallback, no automatic model substitution.
- Deadline: only `ModelCall.deadline` is used. It is checked before I/O and again after the
  response. The four timeouts (connect, read, write, pool) are capped by the remaining budget.
- Model ID: the provider never rewrites it. A mismatch or a missing id is rejected by the gateway
  as `PROVIDER_INVALID_RESPONSE`.
- Errors: 401, 403, 404, 429, 5xx, connection, and timeout are mapped to fixed messages by typed
  internal kinds, never by message text. Raw SDK text never reaches the caller, the log, or the audit.
  Public `ErrorCode` values are unchanged. Each 429 is classified by its typed kind (see
  `docs/FAILURE_KIND_DECISIONS.md`), not by the code string.

**Known limit (Trickle):** the per-phase httpx timeouts do not guarantee an overall deadline when
data arrives slowly. Network work can continue after the deadline. The gateway returns on time and
discards the late result, but the worker thread and its semaphore slot stay occupied until the SDK
call returns. No cancellation is implemented or claimed.

Tests in `tests/unit/test_openai_provider.py` run offline. Without the SDK installed, the
real-SDK tests are skipped and the rest use a fake client and fake SDK error classes that exist
only in the tests. With `openai==3.45.0` and `httpx2==2.13.1` installed, the real-SDK tests also run
against a test-only mock transport. That is not a connection to OpenAI. No test in this repository
has contacted the OpenAI API.

## OpenAI adapter security boundary

The adapter is not connected to OpenAI, and nothing in this repository makes a real request.

- **Endpoint pinned:** the adapter always uses `https://api.openai.com/v1`. `OPENAI_BASE_URL` is
  not honored.
- **Fail closed on environment:** the adapter refuses to start if `OPENAI_BASE_URL`,
  `OPENAI_CUSTOM_HEADERS`, `OPENAI_ORG_ID`, or `OPENAI_PROJECT_ID` is set, even if empty. The error
  names the variable and never prints its value.
- **Validation, not a flag:** `validate_client()` runs directly in the constructor, so a subclass
  cannot skip it. It runs again before every request. A client changed after construction is
  refused with a non-retryable `ProviderError` before any request is sent.
- **What validation requires:** the adapter's key (`auth_headers` equals `Bearer <key>`), the
  pinned endpoint, no organization or project, retries disabled, no custom query parameters, and no
  alternate credential (`workload_identity`).
- **Header policy (exact allowlist, SDK 3.45.0):** the only accepted header names are `accept`,
  `content-type`, `user-agent`, `x-stainless-lang`, `x-stainless-package-version`, `x-stainless-os`,
  `x-stainless-arch`, `x-stainless-runtime`, `x-stainless-runtime-version`, `x-stainless-async`, plus
  `openai-organization` and `openai-project` while they are unset. There is no prefix rule.
  Rejected: `Authorization` (always the adapter's key), any organization or project value that is
  set, and any other name, for example `X-Stainless-Probe`, `X-Probe`, or `Host`. This applies to
  both the merged default headers and caller-supplied custom headers.
- **Transport policy:** the only accepted transport class is the httpx2 default transport.
  Rejected: an explicit proxy on the client (`_mounts`), an explicit proxy on the transport, TLS
  verification disabled, environment proxy or certificate trust enabled, and any unknown transport
  type. Unknown transports are refused until a reviewer adds them to the policy.
- **Environment transport:** `HTTP(S)_PROXY`, `ALL_PROXY`, `NO_PROXY`, `SSL_CERT_FILE`, and
  `SSL_CERT_DIR` are ignored (`trust_env=False`). Verified: with `HTTPS_PROXY` set, a plain httpx2
  client routes OpenAI traffic through the proxy, and the adapter's client does not.
- **Logging:** `OPENAI_LOG` is read by the SDK and only changes verbosity. The SDK redacts the
  authorization header. Debug logs on success and error paths were checked for the key. Keep
  `OPENAI_LOG` off in production anyway.

| Variable | Effect on this adapter | Action |
|---|---|---|
| `OPENAI_BASE_URL` | Redirects requests (key sent to host) | Blocked (fail closed) |
| `OPENAI_CUSTOM_HEADERS` | Injects or replaces headers | Blocked |
| `OPENAI_ORG_ID`, `OPENAI_PROJECT_ID` | Adds billing headers | Blocked |
| `OPENAI_ADMIN_KEY` | Populates `admin_api_key`; Responses auth unchanged (tested) | Not blocked |
| `OPENAI_WEBHOOK_SECRET` | Webhook verification only; auth unchanged (tested) | Not blocked |
| `OPENAI_API_TYPE`, `OPENAI_API_VERSION` | Module-level or Azure switches; client stays `openai.OpenAI` (tested) | Not blocked |
| `OPENAI_API_KEY` | Not used; the adapter always passes its own key | Not blocked |
| `OPENAI_LOG` | Log verbosity; authorization header redacted (tested) | Not blocked |
| `HTTP(S)_PROXY`, `ALL_PROXY`, `NO_PROXY`, `SSL_CERT_*` | Route traffic or change trust store | Ignored (`trust_env=False`) |

## Test suite and what it proves

- **SDK-free tests** always run: key handling, environment guard, header allowlist (pure policy),
  and constructor shape.
- **SDK-backed tests** need `openai==3.45.0` and `httpx2==2.13.1` installed. They build real
  `openai.OpenAI` clients on `httpx2.MockTransport`. The mock transport is allowed only inside the
  test suite, through a test-only override of the transport policy. The production policy accepts
  only the httpx2 default transport. These tests make no network connection and use no real key.
- **Real-network tests:** none. No test in this repository has contacted the OpenAI API.
- **Skips:** without the SDK installed, the SDK-backed tests are skipped and reported as skipped.
  They are not counted as passed.

## Stage 10.45: production model verification gate, audit completeness

**Gate.** `Runtime.build()` and the other production entry points call `models/production_gate.py`
before any adapter exists. A production runtime is built only if both hold:

1. every required capability is VERIFIED for the provider surface (`production_ready()`), and
2. the exact (provider, surface, model id) triple is in `APPROVED_PRODUCTION_MODELS`, a reviewed code list.

Today both are empty, so **every production build is refused by design**. The environment cannot
change either input. An operator-declared model id is never verified. A refusal names no provider,
model, or value. Tests and fakes use `Runtime.build_for_tests()`, which skips the gate and reports
`mode: "test"`.

**Audit.** Audit events use a whitelisted field set. Prompts, keys, and error text never reach them.
`AuditLogger.emit()` returns True only when the write returned without error, and failures are
counted. `audit` in the stats shows `emitted`, `failed`, and `health` (`ok` or `degraded`).

- A rejected request after shutdown emits `runtime.request_refused` with `refusal="runtime_not_ready"`.
  It stays a refusal even if that audit write fails.
- **Production (required audit):** if `request.received` cannot be recorded, the request is not
  processed (`INTERNAL_ERROR`, no provider call). If `request.completed` cannot be recorded, the
  successful output is withheld (`INTERNAL_ERROR`).
- **Test (tolerant):** audit failures are counted and the request continues.
- Audit errors are reported only as fixed codes or types, never as text.

Tests: `tests/unit/test_stage1045.py`. The earlier suites and the 10.41–10.43 mutation sets still run.

## Stage 10.2: opt-in production composition root

`src/sanour_ai/composition/production.py` adds `build_production_core(environ)`. It is the only
path that can reach the OpenAI adapter, and it is off unless you ask for it.

- **Opt-in:** `SANOUR_PROVIDER` must be exactly `openai`. Unset, blank, `mock`, or any other value
  raises `ConfigError`. There is no mock, fallback, or automatic model choice.
- **Required settings (no defaults):** `SANOUR_OPENAI_MODEL_ID`, `SANOUR_OPENAI_MAX_CONTEXT_TOKENS`,
  `SANOUR_OPENAI_MAX_OUTPUT_TOKENS` (positive whole numbers, output not above context), and
  `OPENAI_API_KEY`. Errors name the variable, never its value.
- **Endpoint:** the blocked variables (`OPENAI_BASE_URL`, `OPENAI_CUSTOM_HEADERS`, `OPENAI_ORG_ID`,
  `OPENAI_PROJECT_ID`) fail closed, even when empty.
- **No network at build time.** The first request happens only in `handle()`.
- **Routing:** the profile is `runs_locally=False`. `offline_only` requests are refused by the
  router's existing rule. That rule is the enforcement, not the flag alone.
- **Not done in this stage:** no live call to OpenAI, no real key. Live use needs a separate approval.

Tests: `tests/unit/test_production_composition.py` (SDK-free, always runs) and
`tests/integration/test_production_openai_path.py` (needs the `openai` extra, offline MockTransport).

## Stage 10.33-R1: runtime integration and configuration ownership

- **One production entry point:** `composition.runtime.Runtime.build()`. It calls
  `build_core_and_registry()`, the only function that assembles the production core.
  `build_production_core()` remains for existing callers and runs the same function.
- **One owner of settings:** `config/governance.py`. It owns the environment policy (blocked
  variables, key requirement, provider switch) and the loader. `providers/openai_provider.py` calls
  the same `check_environment()` and receives a validated `SecretStr`. It defines no second reader.
- **Sealed configuration:** `RuntimeConfig` can only be created by `load_runtime_config()`. Direct
  construction and `dataclasses.replace()` copies are checked again and refused when invalid.
- **Cleanup on failure:** if registration, initialization, or assembly fails after the adapter was
  created, the adapter is closed before `ConfigError` is raised. No Runtime exists.
- **Explicit shutdown interface:** the registry depends on `ShutdownTarget` (`shutdown`,
  `provider_state`), exposed by `SanourCore.shutdown_target()`. `Runtime` no longer reads private
  core or gateway fields.
- **Shutdown:** idempotent. Provider states match the registry. A provider with a live worker stays
  `closing` until its worker ends. One failing close does not stop the other providers.
- **Known limit:** the anthropic, gemini and grok adapters still have their own key loaders. They
  are not wired into any composition root, so they cannot affect a production Runtime. Their
  status is in `docs/PROVIDER_STATUS.md`.
- **Known limit:** the SDK-backed tests need `openai` and `httpx2`. They are skipped where those
  packages are not installed, and they are not counted as passed.

## Stage 10.34: multi-provider architecture and lifecycle readiness

- **Shared contract:** `providers/contract.py`. Each adapter declares `name`, `vendor`, `surface`,
  `auth_method`, `capabilities`, and optionally `close()`. `contract_violations()` names each broken
  rule. The shared send path (one attempt, remaining budget as timeout, no retry, post-deadline
  refusal) lives there, not in each adapter.
- **Registry:** the only registration point. Any identity an adapter declares must match the
  registration. Production additionally requires the full contract, and refuses any adapter that
  does not follow it.
- **Lifecycle:** `TRANSITIONS` in `providers/registry.py` is the only list of legal moves. Every
  state write goes through it. Closed is terminal. A refused move changes nothing.
- **Authentication:** `config/governance.py` is the only loader. `load_provider_secret()` reads the
  one variable each provider id declares. Adapters receive a `SecretStr` and never read the
  environment. The old per-adapter loader names remain as delegates.
- **Readiness matrix:** `providers/readiness.py` generates `docs/PROVIDER_READINESS_MATRIX.md`.
  VERIFIED means an official document confirms the capability. It is not live evidence. No adapter
  is marked production-ready, because nothing in this repository has contacted a provider API.
- **Adapters that stay out of production:** anthropic, gemini, grok, and grok_responses. Only
  openai is wired by production composition. xAI Responses stays disabled.
- **Known limits:** SDK-backed OpenAI tests are skipped where the SDK is absent. The non-OpenAI
  adapters' request and response shapes are NOT VERIFIED against current documentation.
- **Undeclared identity in generic tests:** the generic registry accepts a fake adapter that declares
  no identity, so existing fakes keep working. Production is strict.

## Stage 10.35: model catalog, capability intelligence, and profiles

- **Catalog:** `models/model_catalog.py`. Versioned, exact model ids, facts only with a source,
  freeze before requests, read and write separated. See `docs/MODEL_CATALOG.md`.
- **Capability levels:** `models/capability_intelligence.py`. Provider/API, adapter, and runtime
  verified are kept apart. Documentation maps to DOCUMENTED_ONLY, never VERIFIED.
  See `docs/MODEL_CAPABILITY_MATRIX.md` and `docs/MODEL_VERIFICATION_POLICY.md`.
- **Profiles:** `models/profile_management.py`. Each profile is linked to one provider, one model,
  and one surface, and is checked before use. Verification status is always `unverified`.
  See `docs/MODEL_PROFILE_GUIDE.md`.
- **Production:** the operator's model becomes one operator-declared, unverified catalog record.
  Its profile is validated, both registries freeze, and only then is the router-facing profile built.
- **Known limit:** `DeterministicRouter.select()` remains for existing tests. Production never calls
  it, and a test checks that.

## Stage 10.36: routing integrity and request identity

- **No automatic selection:** `DeterministicRouter.select()` is removed. Every request names its
  profile, and the router resolves exactly that profile or refuses. See `docs/ROUTING_INTEGRITY.md`.
- **One identity object:** `models/request_identity.py`. Frozen, created once per request by the
  Coordinator, checked by the gateway before any call. See `docs/REQUEST_IDENTITY_LIFECYCLE.md`.
- **Identity rules:** exact matching, no wildcards, fail closed. See `docs/MODEL_IDENTITY_POLICY.md`.
- **Renamed audit event:** `model.identity_mismatch` is now `model.identity.mismatch`.
