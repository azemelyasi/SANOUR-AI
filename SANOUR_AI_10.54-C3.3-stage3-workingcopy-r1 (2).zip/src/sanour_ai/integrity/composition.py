"""Composition boundary (Stage 10.54-C3). The ONLY module that may combine persistence, integrity, backup and readiness.

Policy (enforced by tests):
  - every production ledger is opened with `open_guarded_ledger`, which installs the ChainTailHook;
  - Core, Governance and Readiness never import this module, persistence writers, or backup;
  - the window hook is a fast guard, NOT a full check: `full_integrity` is the complete check and must be used for
    any claim of integrity.
Hooks cannot be bypassed by a caller that opens a Ledger directly; the repository-level scan test forbids such calls
outside the allowed packages. A process that imports persistence itself is outside what this code can prevent.
"""

from __future__ import annotations

import os
import sqlite3
from dataclasses import dataclass, field
from typing import Callable

from sanour_ai.backup import verify_backup
from sanour_ai.integrity.hooks import ChainTailHook
from sanour_ai.persistence import canonical as C
from sanour_ai.persistence import verify_integrity
from sanour_ai.persistence.ledger import Ledger
from sanour_ai.persistence.recovery import AnchorLog
from sanour_ai.readiness.backup_status import assess_backup_status

_TEMP_PREFIXES = (".sanour-restore-", ".sanour-backup-", ".sanour-verify-")


def open_guarded_ledger(path: str, *, clock: Callable | None = None, busy_timeout_ms: int = 5000,
                        tail: int = 16) -> Ledger:
    return Ledger(path, clock=clock, busy_timeout_ms=busy_timeout_ms, commit_hooks=(ChainTailHook(tail),))


@dataclass(frozen=True)
class FullIntegrity:
    ok: bool
    codes: tuple
    streams: dict = field(default_factory=dict)     # stream -> {head_seq, head_hash, records, checkpoints}


def _stream_facts(path: str) -> dict:
    out = {}
    c = sqlite3.connect(path, timeout=5)
    try:
        c.execute("BEGIN")
        for s in sorted(C.STREAMS):
            head = c.execute("SELECT seq, record_hash FROM ledger_records WHERE stream=? ORDER BY seq DESC LIMIT 1",
                             (s,)).fetchone()
            out[s] = {
                "head_seq": int(head[0]) if head else 0,
                "head_hash": head[1] if head else C.GENESIS_HASH,
                "records": int(c.execute("SELECT COUNT(*) FROM ledger_records WHERE stream=?", (s,)).fetchone()[0]),
                "checkpoints": int(c.execute("SELECT COUNT(*) FROM ledger_checkpoints WHERE stream=?",
                                             (s,)).fetchone()[0]),
            }
        c.execute("COMMIT")
    finally:
        c.close()
    return out


def full_integrity(ledger: Ledger, anchors: AnchorLog | None = None, expected: dict | None = None) -> FullIntegrity:
    """Complete check: every record of both chains, sequence, links, metadata against canonical bytes, guards,
    migrations, checkpoints, and external anchors when `anchors` is given. `expected` (for example from a backup
    manifest) is compared with the stream heads and counts. Read-only."""
    report = verify_integrity(ledger, anchors)
    codes = {f.code for f in report.findings}
    streams = _stream_facts(ledger._path)
    if expected is not None and {k: streams.get(k) for k in expected} != expected:
        codes.add("expected_streams_mismatch")
    return FullIntegrity(not codes, tuple(sorted(codes)), streams)


def backup_status(ledger: Ledger, backup_dir: str | None, anchors: AnchorLog | None = None) -> dict:
    """Collect facts (read-only) and hand them to readiness. Readiness decides; this function only gathers."""
    fi = full_integrity(ledger, anchors)
    base = ledger._path
    sidecars = sum(1 for s in ("-wal", "-shm", "-journal") if os.path.lexists(base + s))
    folder = os.path.dirname(base)
    temporaries = sum(1 for n in os.listdir(folder) if n.startswith(_TEMP_PREFIXES))
    verified = False
    if backup_dir is not None:
        try:
            verify_backup(backup_dir)
            verified = True
        except Exception:                      # any refusal means: not verified; the reason is not exposed here
            verified = False
    snapshot = {"integrity_verified": True, "integrity_ok": fi.ok, "sidecars": sidecars,
                "temporaries": temporaries, "verified_backup": verified}
    return assess_backup_status(snapshot)
