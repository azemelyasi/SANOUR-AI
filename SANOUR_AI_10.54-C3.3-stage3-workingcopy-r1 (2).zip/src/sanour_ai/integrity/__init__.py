"""Stage 10.54-C2: commit hooks, audit trail and the narrow backup port. Offline, stdlib only.

Core does not import this package. Readiness and Governance receive results through the port; they do not own backup
or restore operations. Hooks are read-only and fail closed. The audit trail is append-only and idempotent.
"""

from sanour_ai.integrity.audit import AuditError, AuditTrail
from sanour_ai.integrity.hooks import IntegrityHookError, ChainTailHook
from sanour_ai.integrity.ports import BackupPort, LocalBackupPort
from sanour_ai.integrity.composition import FullIntegrity, backup_status, full_integrity, open_guarded_ledger

__all__ = ["AuditError", "AuditTrail", "BackupPort", "ChainTailHook", "FullIntegrity", "IntegrityHookError",
           "LocalBackupPort", "backup_status", "full_integrity", "open_guarded_ledger"]
