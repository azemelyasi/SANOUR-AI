"""Append-only, idempotent audit trail for backup/restore operations (Stage 10.54-C2).

One JSON line per distinct event. The event id is a hash of (operation, target reference, outcome, code), so a
repeat of the same event is recorded once. Lines hold fixed vocabulary only: no paths, payloads, keys or messages.
Single writer per file (documented); a torn last line from a crash is dropped before the next append.
"""

from __future__ import annotations

import json
import os
import re
import threading
import time

try:
    import fcntl
except ImportError:          # Stage 10.54-C3.2: no fcntl means no lock: appends are refused (fail closed)
    fcntl = None
from sanour_ai.persistence import canonical as C
from sanour_ai.persistence.errors import LedgerError

AUDIT_VERSION = 1
OPERATIONS = frozenset({"backup", "restore", "verify"})
OUTCOMES = frozenset({"ok", "refused"})
_ID = re.compile(r"[0-9a-f]{64}\Z")
_CODE = re.compile(r"(?:-|[A-Za-z][A-Za-z0-9_]{0,63})\Z")


class AuditError(LedgerError):
    """The audit file is damaged or the event is malformed. Nothing was appended."""


class AuditTrail:
    def __init__(self, path: str, *, lock_timeout_s: float = 5.0) -> None:
        if not isinstance(path, str) or not path or "\x00" in path or len(path) > 1024:
            raise AuditError("invalid audit path")
        if not isinstance(lock_timeout_s, (int, float)) or not 0 <= lock_timeout_s <= 60:
            raise AuditError("invalid lock timeout")
        self._path = path
        self._lock_path = path + ".lock"       # a lock file, never an audit record; it is not a sidecar of the ledger
        self._lock_timeout = float(lock_timeout_s)
        self._lock = threading.Lock()

    def _data(self) -> bytes:
        try:
            with open(self._path, "rb") as fh:
                return fh.read()
        except FileNotFoundError:
            return b""
        except OSError:
            raise AuditError("audit file unreadable") from None

    def events(self) -> list[dict]:
        data = self._data()
        complete = data[: data.rfind(b"\n") + 1] if b"\n" in data else b""
        out = []
        for raw in complete.split(b"\n")[:-1]:
            try:
                obj = json.loads(raw)
            except ValueError:
                raise AuditError("audit file is damaged") from None
            if not isinstance(obj, dict) or obj.get("v") != AUDIT_VERSION or raw != C.dumps(obj):
                raise AuditError("audit file is damaged")
            out.append(obj)
        return out

    def _file_lock(self):
        """Exclusive advisory lock across processes. Waits up to lock_timeout_s, then refuses (never blocks forever)."""
        trail = self

        class _Held:
            def __enter__(self):
                if fcntl is None:
                    raise AuditError("audit locking is not available on this platform: append refused")
                self.fd = os.open(trail._lock_path, os.O_RDWR | os.O_CREAT, 0o600)
                deadline = time.monotonic() + trail._lock_timeout
                while True:
                    try:
                        fcntl.flock(self.fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                        return self
                    except BlockingIOError:
                        if time.monotonic() >= deadline:
                            os.close(self.fd)
                            raise AuditError("audit busy: another writer holds the lock") from None
                        time.sleep(0.01)

            def __exit__(self, *exc):
                os.close(self.fd)                # closing the descriptor releases the flock
                return False

        return _Held()

    def record(self, operation: str, target_ref: str, outcome: str, code: str = "-") -> bool:
        """Append the event unless the same event is already recorded. Returns True when a line was written."""
        if operation not in OPERATIONS or outcome not in OUTCOMES:
            raise AuditError("unknown audit operation or outcome")
        if not isinstance(target_ref, str) or not _ID.match(target_ref) or not isinstance(code, str) \
                or not _CODE.match(code):
            raise AuditError("malformed audit event")
        event_id = C.sha256_hex(C.dumps([operation, target_ref, outcome, code]))
        with self._lock, self._file_lock():
            data = self._data()
            if data and not data.endswith(b"\n"):          # torn tail from a crash: drop it
                data = data[: data.rfind(b"\n") + 1] if b"\n" in data else b""
                fd = os.open(self._path, os.O_WRONLY)
                try:
                    os.ftruncate(fd, len(data))
                    os.fsync(fd)
                finally:
                    os.close(fd)
            if any(e["id"] == event_id for e in self.events()):
                return False
            line = C.dumps({"v": AUDIT_VERSION, "id": event_id, "op": operation, "outcome": outcome,
                            "code": code}) + b"\n"
            fd = os.open(self._path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
            try:
                os.write(fd, line)
                os.fsync(fd)
            finally:
                os.close(fd)
            return True
