"""Read-only commit hook for the evidence ledger (Stage 10.54-C2).

Runs INSIDE the open write transaction, after the change and before COMMIT. Any failure raises, the transaction is
rolled back, and nothing is committed (fail closed). The hook never writes, repairs or deletes a row. A refusal carries
fixed codes only.

Checks, on the transaction's own view of the database:
  - append-only guard triggers exist for every table that exists
  - applied migration checksums equal this code's checksums
  - the newest `tail` records of each stream are contiguous, hash-correct and linked
  - the latest checkpoint of each stream is not ahead of the ledger and matches the record it names
Full-chain, anchor and restore checks stay in verify_integrity and restore_backup (on demand, not per commit).
"""

from __future__ import annotations

import hashlib
import sqlite3

from sanour_ai.persistence import canonical as C
from sanour_ai.persistence import migrations as M
from sanour_ai.persistence.errors import LedgerError

GUARDS = {
    "ledger_records": ("ledger_records_no_update", "ledger_records_no_delete", "ledger_records_no_replace"),
    "ledger_links": ("ledger_links_no_update", "ledger_links_no_delete", "ledger_links_no_replace"),
    "ledger_checkpoints": ("ledger_checkpoints_no_update", "ledger_checkpoints_no_delete",
                           "ledger_checkpoints_no_replace"),
    "schema_migrations": ("schema_migrations_no_update", "schema_migrations_no_delete",
                          "schema_migrations_no_replace"),
}
_MAX_CODES = 8


class IntegrityHookError(LedgerError):
    """A commit was refused by an integrity hook. Nothing was committed; the message carries fixed codes only."""


class ChainTailHook:
    def __init__(self, tail: int = 16) -> None:
        if not isinstance(tail, int) or not 1 <= tail <= 1024:
            raise ValueError("tail must be an integer from 1 to 1024")
        self._tail = tail

    def __call__(self, conn: sqlite3.Connection) -> None:
        codes: set[str] = set()
        tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        triggers = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='trigger'")}
        for table, guards in GUARDS.items():
            if table in tables:
                for g in guards:
                    if g not in triggers:
                        codes.add("guard_missing")
        if "schema_migrations" in tables:
            expected = {m.version: m.checksum for m in M.MIGRATIONS}
            for version, checksum in conn.execute("SELECT version, checksum FROM schema_migrations"):
                if expected.get(version) != checksum:
                    codes.add("migration_mismatch")
        if "ledger_records" in tables:
            for stream in sorted(C.STREAMS):
                codes |= self._tail_codes(conn, stream)
        if "ledger_checkpoints" in tables and "ledger_records" in tables:
            for stream in sorted(C.STREAMS):
                codes |= self._checkpoint_codes(conn, stream)
        if codes:
            raise IntegrityHookError("commit refused: " + ", ".join(sorted(codes)[:_MAX_CODES]))

    def _tail_codes(self, conn: sqlite3.Connection, stream: str) -> set[str]:
        rows = conn.execute("SELECT seq, prev_hash, record_hash, canonical_bytes FROM ledger_records "
                            "WHERE stream=? ORDER BY seq DESC LIMIT ?", (stream, self._tail + 1)).fetchall()
        rows.reverse()
        out: set[str] = set()
        for i, (seq, prev, rh, raw) in enumerate(rows):
            if hashlib.sha256(bytes(raw)).hexdigest() != rh:
                out.add("record_hash_mismatch")
            if i:
                if seq != rows[i - 1][0] + 1:
                    out.add("sequence_gap")
                if prev != rows[i - 1][2]:
                    out.add("chain_link_broken")
        return out

    @staticmethod
    def _checkpoint_codes(conn: sqlite3.Connection, stream: str) -> set[str]:
        last = conn.execute("SELECT record_seq, head_hash FROM ledger_checkpoints WHERE stream=? "
                            "ORDER BY cp_seq DESC LIMIT 1", (stream,)).fetchone()
        if last is None or last[0] == 0:
            return set()
        head = conn.execute("SELECT MAX(seq) FROM ledger_records WHERE stream=?", (stream,)).fetchone()[0] or 0
        if last[0] > head:
            return {"checkpoint_ahead"}
        at = conn.execute("SELECT record_hash FROM ledger_records WHERE stream=? AND seq=?",
                          (stream, last[0])).fetchone()
        return set() if at is not None and at[0] == last[1] else {"checkpoint_mismatch"}
