"""The only door between the integrity layer and backup/restore (Stage 10.54-C2).

Core does not import this module. Readiness and Governance may call the port for results; they never receive file
handles or paths to backup files, and they do not own backup or restore operations.
Audit events carry an operation, a hash of the target, an outcome and a fixed code. Never a path, message or payload.
"""

from __future__ import annotations

import hashlib
from typing import Protocol

from sanour_ai.backup import create_backup, restore_backup, verify_backup
from sanour_ai.integrity.audit import AuditTrail
from sanour_ai.persistence.errors import LedgerError


class BackupPort(Protocol):
    def backup(self, source: str, dest: str, *, anchor=None): ...
    def restore(self, backup_dir: str, dest: str, *, anchors=None): ...
    def verify(self, backup_dir: str): ...


def _ref(*parts: str) -> str:
    return hashlib.sha256("\x1f".join(parts).encode("utf-8")).hexdigest()


class LocalBackupPort:
    def __init__(self, audit: AuditTrail | None = None) -> None:
        self._audit = audit

    def _record(self, op: str, target: str, outcome: str, code: str) -> None:
        if self._audit is not None:
            self._audit.record(op, _ref(op, target), outcome, code)

    def _run(self, op: str, target: str, fn):
        try:
            result = fn()
        except LedgerError as exc:
            self._record(op, target, "refused", type(exc).__name__ if type(exc).__name__.isidentifier() else "-")
            raise
        self._record(op, target, "ok", "-")
        return result

    def backup(self, source: str, dest: str, *, anchor=None):
        return self._run("backup", dest, lambda: create_backup(source, dest, anchor=anchor))

    def restore(self, backup_dir: str, dest: str, *, anchors=None):
        return self._run("restore", dest, lambda: restore_backup(backup_dir, dest, anchors=anchors))

    def verify(self, backup_dir: str):
        return self._run("verify", backup_dir, lambda: verify_backup(backup_dir))
