"""Database identity classification (C3.3 Stage 1).

Identity metadata (PRAGMA application_id, PRAGMA user_version) is version and identity METADATA. It is NOT a
security control and NOT proof of integrity: anyone with write access can set it. Classification therefore
always combines the metadata with a structural inspection (table set, signature tables, quick_check).

This module is pure except `read_facts`, which only reads (read-only URI, no writes, no DDL, no stamping).
It imports the standard library only. No application_id value is chosen here: callers pass the identity
mapping explicitly (see `validate_identities`).
"""

from __future__ import annotations

import enum
import os
import sqlite3
from collections.abc import Mapping
from dataclasses import dataclass, field
from pathlib import Path


class SubsystemId(enum.Enum):
    LEDGER = "ledger"
    USAGE = "usage"
    GOVERNANCE = "governance"
    SINK = "sink"


class IdentityState(enum.Enum):
    NEW = "new"                          # absent or zero bytes
    OWNED = "owned"                      # own identity, own structure, version current
    OWNED_OLDER = "owned_older"          # own identity, version below current
    OWNED_NEWER = "owned_newer"          # own identity, version above what this code supports
    FOREIGN = "foreign"                  # stamped with another subsystem's identity (expected subsystem given)
    UNSTAMPED_KNOWN = "unstamped_known"  # identity 0, structure matches exactly one subsystem
    MIXED = "mixed"                      # structure matches two or more subsystems
    UNKNOWN = "unknown"                  # identity or structure not recognized, or metadata malformed/conflicting
    DAMAGED = "damaged"                  # not a database, unreadable, or fails quick_check


SHARED_TABLES = frozenset({"schema_migrations"})   # present in more than one subsystem; never proves ownership
SIGNED_INT_MIN = -(2**31)
SIGNED_INT_MAX = 2**31 - 1
_SQLITE_HEADER = b"SQLite format 3\x00"


@dataclass(frozen=True)
class StructureSpec:
    subsystem: SubsystemId
    tables: frozenset          # every table this subsystem's code creates (observed in current source)
    signature: frozenset       # tables that must all be present to claim the subsystem
    schema_version: int | None  # current user_version, or None when the subsystem does not use user_version


SPECS: Mapping[SubsystemId, StructureSpec] = {
    SubsystemId.LEDGER: StructureSpec(
        SubsystemId.LEDGER,
        frozenset({"ledger_records", "ledger_links", "ledger_checkpoints", "schema_migrations"}),
        frozenset({"ledger_records", "ledger_checkpoints"}),
        3,
    ),
    SubsystemId.USAGE: StructureSpec(
        SubsystemId.USAGE,
        frozenset({"usage_records"}),
        frozenset({"usage_records"}),
        1,
    ),
    SubsystemId.GOVERNANCE: StructureSpec(
        SubsystemId.GOVERNANCE,
        frozenset({
            "pricing_versions", "budgets", "budget_windows", "quota_limits", "quota_windows", "reservations",
            "reservation_lines", "cost_records", "exposure_resolutions", "governance_log", "audit_outbox",
            "conflict_resolutions", "schema_migrations",
        }),
        frozenset({"pricing_versions", "governance_log"}),
        None,
    ),
    SubsystemId.SINK: StructureSpec(
        SubsystemId.SINK,
        frozenset({"audit_receipts", "audit_inbox"}),
        frozenset({"audit_receipts", "audit_inbox"}),
        None,
    ),
}


@dataclass(frozen=True)
class FileFacts:
    exists: bool
    size: int
    readable: bool
    application_id: int | None = None
    user_version: int | None = None
    quick_check: str | None = None
    tables: frozenset = frozenset()
    error: str | None = None


@dataclass(frozen=True)
class Classification:
    state: IdentityState
    owner: SubsystemId | None
    reasons: tuple = field(default_factory=tuple)


def validate_identities(identities: Mapping[SubsystemId, int]) -> dict:
    """Refuse a malformed or conflicting identity configuration. Raises ValueError. Chooses no values itself."""
    if not isinstance(identities, Mapping):
        raise ValueError("identities must be a mapping")
    if set(identities.keys()) != set(SubsystemId):
        raise ValueError("identities must contain exactly one entry per subsystem")
    seen: dict = {}
    for sub, value in identities.items():
        if isinstance(value, bool) or not isinstance(value, int):
            raise ValueError("identity values must be integers")
        if value == 0:
            raise ValueError("identity value 0 is reserved for unstamped files")
        if not SIGNED_INT_MIN <= value <= SIGNED_INT_MAX:
            raise ValueError("identity value out of range")
        if value in seen:
            raise ValueError("identity values must be unique")
        seen[value] = sub
    return dict(identities)


class LiveWalRefused(RuntimeError):
    """read_facts refuses a WAL-mode database or one with WAL/SHM sidecars: opening it would create or touch
    sidecar files beside a live database. Not an ErrorCode. Raised before any SQLite connection is made."""


_WAL_SIDECARS = ("-wal", "-shm")


def _wal_refusal_reason(path: str, head: bytes) -> str | None:
    """Return a reason when the file must not be opened by read_facts, else None. Reads bytes only."""
    for suffix in _WAL_SIDECARS:
        if os.path.exists(path + suffix):
            return f"sidecar {suffix} present"
    if len(head) >= 20 and head[18] == 2 and head[19] == 2:
        return "database is in WAL mode (header bytes 18-19 are 2)"
    return None


def read_facts(path: str) -> FileFacts:
    """Read identity metadata and table names with a read-only connection. Never writes, never stamps.

    Stage 1 reader guard (C3.3, approved O5): refuses WAL-mode databases and databases with -wal or -shm
    sidecars by raising LiveWalRefused BEFORE any SQLite connection is opened. Rollback-mode files are read
    exactly as before. Still not safe for live databases that a writer may be modifying; Stage 2 must not use it
    on source paths."""
    p = Path(path)
    if not os.path.exists(path):
        return FileFacts(exists=False, size=0, readable=False)
    size = os.path.getsize(path)
    if size == 0:
        return FileFacts(exists=True, size=0, readable=False)
    try:
        with open(path, "rb") as fh:
            head = fh.read(100)
    except OSError as exc:
        return FileFacts(exists=True, size=size, readable=False, error=f"unreadable: {type(exc).__name__}")
    if head[: len(_SQLITE_HEADER)] != _SQLITE_HEADER:
        return FileFacts(exists=True, size=size, readable=False, error="not a SQLite database")
    reason = _wal_refusal_reason(path, head)
    if reason is not None:
        raise LiveWalRefused(f"refused: {reason}")
    uri = p.resolve().as_uri() + "?mode=ro"
    conn = None
    try:
        conn = sqlite3.connect(uri, uri=True, timeout=1.0)
        app_id = conn.execute("PRAGMA application_id").fetchone()[0]
        user_version = conn.execute("PRAGMA user_version").fetchone()[0]
        qc = conn.execute("PRAGMA quick_check").fetchone()[0]
        tables = frozenset(
            row[0] for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'")
        )
        return FileFacts(exists=True, size=size, readable=True, application_id=int(app_id),
                         user_version=int(user_version), quick_check=str(qc), tables=tables)
    except sqlite3.Error as exc:
        return FileFacts(exists=True, size=size, readable=False, error=f"read failed: {type(exc).__name__}")
    finally:
        if conn is not None:
            conn.close()


def classify_facts(facts: FileFacts, *, identities: Mapping[SubsystemId, int],
                   expected: SubsystemId | None = None, specs: Mapping = SPECS) -> Classification:
    """Pure structural classification. Identity metadata alone never yields OWNED or UNSTAMPED_KNOWN."""
    ids = validate_identities(identities)
    by_value = {v: k for k, v in ids.items()}

    if not facts.exists or facts.size == 0:
        return Classification(IdentityState.NEW, None, ("absent or zero bytes",))
    if not facts.readable or facts.quick_check is None:
        return Classification(IdentityState.DAMAGED, None, (facts.error or "unreadable",))
    if facts.quick_check != "ok":
        return Classification(IdentityState.DAMAGED, None, ("quick_check failed",))

    tables = facts.tables
    all_known = frozenset().union(*(s.tables for s in specs.values()))
    unknown = tables - all_known
    if unknown:
        return Classification(IdentityState.UNKNOWN, None,
                              ("unrecognized tables: " + ", ".join(sorted(unknown)),))

    touched = frozenset(
        sub for sub, spec in specs.items() if tables & (spec.tables - SHARED_TABLES)
    )
    if len(touched) >= 2:
        return Classification(IdentityState.MIXED, None,
                              ("structure matches subsystems: " + ", ".join(sorted(s.value for s in touched)),))

    app = facts.application_id
    uv = facts.user_version
    if app is None or uv is None:
        return Classification(IdentityState.UNKNOWN, None, ("identity metadata missing",))
    if app < SIGNED_INT_MIN or app > SIGNED_INT_MAX or uv < 0:
        return Classification(IdentityState.UNKNOWN, None, ("malformed identity metadata",))

    if app == 0:
        if len(touched) == 1:
            (owner,) = touched
            spec = specs[owner]
            if spec.signature <= tables:
                if spec.schema_version is not None and uv > spec.schema_version:
                    return Classification(IdentityState.UNKNOWN, owner,
                                          ("unstamped file has a version newer than this code",))
                return Classification(IdentityState.UNSTAMPED_KNOWN, owner,
                                      ("unstamped; structure matches " + owner.value,))
        return Classification(IdentityState.UNKNOWN, None, ("unstamped and structure not recognized",))

    stamped = by_value.get(app)
    if stamped is None:
        return Classification(IdentityState.UNKNOWN, None, ("unrecognized application_id",))
    if touched != frozenset({stamped}):
        return Classification(IdentityState.UNKNOWN, stamped,
                              ("application_id conflicts with structure",))
    spec = specs[stamped]
    if not spec.signature <= tables:
        return Classification(IdentityState.UNKNOWN, stamped,
                              ("application_id present but signature tables missing",))
    if expected is not None and stamped != expected:
        return Classification(IdentityState.FOREIGN, stamped,
                              (f"owned by {stamped.value}, expected {expected.value}",))
    if spec.schema_version is None:
        if uv != 0:
            return Classification(IdentityState.UNKNOWN, stamped,
                                  ("version metadata conflicts: subsystem does not use user_version",))
        return Classification(IdentityState.OWNED, stamped, ("identity and structure agree",))
    if uv > spec.schema_version:
        return Classification(IdentityState.OWNED_NEWER, stamped,
                              (f"user_version {uv} above supported {spec.schema_version}",))
    if uv < spec.schema_version:
        return Classification(IdentityState.OWNED_OLDER, stamped,
                              (f"user_version {uv} below current {spec.schema_version}",))
    return Classification(IdentityState.OWNED, stamped, ("identity and structure agree",))


def classify(path: str, *, identities: Mapping[SubsystemId, int],
             expected: SubsystemId | None = None) -> Classification:
    """Read-only classification of one file. Opens the file read-only; never writes."""
    return classify_facts(read_facts(path), identities=identities, expected=expected)
