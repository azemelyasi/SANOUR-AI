"""Owner-side production of a finalized backup. Runs in the database-owning process only.

Uses the SQLite Backup API, converts ONLY the backup copy to rollback-journal mode, verifies there are no
sidecars, validates the final bytes, fsyncs, renames atomically, and writes the manifest LAST. On failure nothing
final is left behind. The inventory tool never imports or calls this module.

Public surface: `create_owner_backup` and `OwnerBackupError`. Everything else is private.
"""

from __future__ import annotations

import datetime as _dt
import hashlib
import json
import os
import sqlite3
import uuid

from sanour_ai.storage.identity import SubsystemId
from sanour_ai.storage.legacy_inventory import (
    MANIFEST_VERSION,
    METHOD,
    SUFFIX,
    InputError,
    manifest_path_for,
    required_free_bytes,
    require_free_space,
)

_PAGES_PER_STEP = -1
_SIDECARS = ("-wal", "-shm", "-journal")


class OwnerBackupError(Exception):
    """Base failure of owner backup production. Nothing final is left behind when it is raised."""


class _RollbackConversionFailed(OwnerBackupError):
    pass


class _SidecarPresent(OwnerBackupError):
    pass


class _ValidationFailed(OwnerBackupError):
    pass


def _utc_now() -> _dt.datetime:
    return _dt.datetime.now(_dt.timezone.utc)


def _sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _fsync_dir(directory: str) -> None:
    fd = os.open(directory, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def _remove_quietly(path: str) -> None:
    try:
        os.remove(path)
    except FileNotFoundError:
        pass


def _check_locations(source: str, staging: str) -> None:
    src_real = os.path.realpath(source)
    src_dir = os.path.dirname(src_real)
    stg_real = os.path.realpath(staging)
    if stg_real == src_dir or stg_real.startswith(src_dir + os.sep) or src_real.startswith(stg_real + os.sep):
        raise InputError("staging directory must be separate from the live database directory")


def _build_manifest(final_path: str, subsystem: str, started: _dt.datetime, finished: _dt.datetime,
                    source_basename: str, meta: dict) -> dict:
    return {
        "manifest_version": MANIFEST_VERSION,
        "subsystem": subsystem,
        "backup_started_utc": started.isoformat(),
        "backup_finished_utc": finished.isoformat(),
        "method": METHOD,
        "backup_file": os.path.basename(final_path),
        "size_bytes": os.path.getsize(final_path),
        "sha256": _sha256(final_path),
        "sqlite_library_version": sqlite3.sqlite_version,
        "journal_mode": "delete",
        "header_bytes_18_19": "0101",
        "schema_user_version": meta["user_version"],
        "application_id": meta["application_id"],
        "page_size": meta["page_size"],
        "page_count": meta["page_count"],
        "integrity_check": "ok",
        "table_names": meta["tables"],
        "source_basename": source_basename,
    }


def _backup_api_copy(source_path: str, partial: str) -> None:
    src = sqlite3.connect(source_path, timeout=10.0, isolation_level=None)
    dst = sqlite3.connect(partial, isolation_level=None)
    try:
        src.backup(dst, pages=_PAGES_PER_STEP)
    finally:
        dst.close()
        src.close()


def _set_rollback_mode(conn: sqlite3.Connection) -> str:
    return str(conn.execute("PRAGMA journal_mode=DELETE").fetchone()[0]).lower()


def _convert_to_rollback(partial: str) -> dict:
    conn = sqlite3.connect(partial, isolation_level=None)
    try:
        if _set_rollback_mode(conn) != "delete":
            raise _RollbackConversionFailed("could not convert the backup copy to rollback-journal mode")
        return {
            "application_id": int(conn.execute("PRAGMA application_id").fetchone()[0]),
            "user_version": int(conn.execute("PRAGMA user_version").fetchone()[0]),
            "page_size": int(conn.execute("PRAGMA page_size").fetchone()[0]),
            "page_count": int(conn.execute("PRAGMA page_count").fetchone()[0]),
            "tables": sorted(r[0] for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'")),
        }
    finally:
        conn.close()


def _assert_no_sidecars(partial: str) -> None:
    for suffix in _SIDECARS:
        if os.path.exists(partial + suffix):
            raise _SidecarPresent(f"sidecar {suffix} present beside backup copy")


def _validate_final_bytes(partial: str) -> None:
    """Header must be rollback mode; integrity must be ok on a fresh read-only connection; no sidecars after."""
    with open(partial, "rb") as fh:
        head = fh.read(100)
    if head[18:20] != b"\x01\x01":
        raise _RollbackConversionFailed("backup copy header is not rollback-journal mode")
    check = sqlite3.connect("file:%s?mode=ro" % os.path.abspath(partial), uri=True)
    try:
        integrity = [r[0] for r in check.execute("PRAGMA integrity_check").fetchall()]
    except sqlite3.DatabaseError:
        raise _ValidationFailed("integrity_check could not run on the backup copy") from None
    finally:
        check.close()
    if integrity != ["ok"]:
        raise _ValidationFailed("integrity_check did not return ok")
    _assert_no_sidecars(partial)


def _finalize(partial: str, final: str, staging_dir: str) -> None:
    fd = os.open(partial, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
    os.replace(partial, final)
    _fsync_dir(staging_dir)


def _write_manifest(manifest: dict, manifest_file: str) -> None:
    tmp = manifest_file + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, indent=2, sort_keys=True)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, manifest_file)
    _fsync_dir(os.path.dirname(manifest_file) or ".")


def create_owner_backup(source_path: str, staging_dir: str, subsystem: str) -> dict:
    """Produce one finalized backup of `source_path` in `staging_dir` and return its manifest dict.

    Raises InputError for invalid arguments, InsufficientSpace before anything is created, and OwnerBackupError
    (or sqlite3 errors) on failure. On any failure, nothing final and no manifest is left behind."""
    if subsystem not in {s.value for s in SubsystemId}:
        raise InputError("unknown subsystem")
    if os.path.islink(source_path) or not os.path.isfile(source_path):
        raise InputError("source must be a regular file")
    if not os.path.isdir(staging_dir):
        raise InputError("staging directory does not exist")
    _check_locations(source_path, staging_dir)

    started = _utc_now()
    require_free_space(staging_dir, required_free_bytes(os.path.getsize(source_path)))

    stamp = started.strftime("%Y%m%dT%H%M%SZ")
    final = os.path.join(staging_dir, f"{subsystem}-{stamp}-{uuid.uuid4().hex[:12]}{SUFFIX}")
    partial = final + ".partial"
    manifest_file = manifest_path_for(final)
    if os.path.lexists(final) or os.path.lexists(partial):
        raise OwnerBackupError("name collision")
    finalized = False
    manifest_written = False
    try:
        _backup_api_copy(source_path, partial)
        meta = _convert_to_rollback(partial)
        _assert_no_sidecars(partial)
        _validate_final_bytes(partial)
        _finalize(partial, final, staging_dir)
        finalized = True
        manifest = _build_manifest(final, subsystem, started, _utc_now(),
                                   os.path.basename(source_path), meta)
        _write_manifest(manifest, manifest_file)
        manifest_written = True
        return manifest
    except BaseException:
        _remove_quietly(partial)
        for suffix in _SIDECARS:
            _remove_quietly(partial + suffix)
        if finalized and not manifest_written:
            _remove_quietly(final)               # never leave a final backup without its manifest
        _remove_quietly(manifest_file + ".tmp")
        raise
