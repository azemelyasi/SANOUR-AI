"""Stage 2 (restricted scope, owner decision 2026): read-only inspection of FINALIZED owner-produced SQLite
Backup API outputs. Inspect-only: never accepts, stamps, migrates, adopts, or writes beside the input.
Never creates a backup and never opens a live database. Stdlib plus sanour_ai.storage.identity only."""

from __future__ import annotations

import datetime as _dt
import hashlib
import json
import os
import re
import sqlite3
import stat as _stat
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from pathlib import Path

from sanour_ai.storage.identity import (
    SPECS,
    SubsystemId,
    FileFacts,
    classify_facts,
    validate_identities,
)

SUFFIX = ".sqlite"
MANIFEST_SUFFIX = ".manifest.json"
MANIFEST_VERSION = 1
METHOD = "sqlite_backup_api"
DEFAULT_MAX_BYTES = 1 << 30            # 1 GiB, owner decision 1 (configurable)
OVERHEAD_MIN = 64 << 20
OVERHEAD_FRACTION = 0.10
CHUNK = 1 << 20
_SQLITE_MAGIC = b"SQLite format 3\x00"
_SHA_RE = re.compile(r"^[0-9a-f]{64}$")

# Outcome kinds and their exit codes (owner decision 4; 2 is raised as InputError, never returned as Outcome).
KIND_OK = "CLASSIFIED_OK"
KIND_REFUSED = "CONTENT_REFUSED"
KIND_UNVERIFIED = "UNVERIFIED"
KIND_NOT_INSPECTED = "NOT_INSPECTED"
EXIT_CODE = {KIND_OK: 0, KIND_REFUSED: 1, KIND_UNVERIFIED: 3, KIND_NOT_INSPECTED: 4}
EXIT_INPUT_ERROR = 2

# UNVERIFIED reasons (not damage; re-run or re-produce the backup)
R_MANIFEST_MISSING = "MANIFEST_MISSING"
R_MANIFEST_INVALID = "MANIFEST_INVALID"
R_MANIFEST_MISMATCH = "MANIFEST_MISMATCH"
R_MANIFEST_INCONSISTENT = "MANIFEST_INCONSISTENT"
R_SNAPSHOT_UNSTABLE = "SNAPSHOT_UNSTABLE"
R_HOT_JOURNAL = "HOT_JOURNAL"
R_SOURCE_BUSY = "SOURCE_BUSY"
# NOT_INSPECTED reasons
R_SYMLINK_REFUSED = "SYMLINK_REFUSED"
R_NOT_REGULAR_FILE = "NOT_REGULAR_FILE"
R_SIZE_LIMIT_EXCEEDED = "SIZE_LIMIT_EXCEEDED"
# CONTENT_REFUSED reasons besides identity states
R_REFUSED_FOR_OWNER = "REFUSED_FOR_OWNER"
R_DAMAGED = "DAMAGED"

MANIFEST_FIELDS = {
    "manifest_version": int, "subsystem": str, "backup_started_utc": str, "backup_finished_utc": str,
    "method": str, "backup_file": str, "size_bytes": int, "sha256": str, "sqlite_library_version": str,
    "journal_mode": str, "header_bytes_18_19": str, "schema_user_version": int, "application_id": int,
    "page_size": int, "page_count": int, "integrity_check": str, "table_names": list, "source_basename": str,
}


class InputError(Exception):
    """Usage, configuration, or input problem. Maps to exit code 2. Nothing is inspected."""


class InsufficientSpace(Exception):
    """Required temporary space is not available. Raised before any byte is written."""


class ManifestProblem(Exception):
    def __init__(self, reason: str):
        super().__init__(reason)
        self.reason = reason


@dataclass(frozen=True)
class Outcome:
    kind: str
    reason: str | None
    state: str | None
    owner: str | None
    assurance: str
    detail: str = ""
    accepted: bool = False            # Stage 2 is inspect-only: always False

    @property
    def exit_code(self) -> int:
        return EXIT_CODE[self.kind]

    def as_dict(self) -> dict:
        return {"kind": self.kind, "reason": self.reason, "state": self.state, "owner": self.owner,
                "assurance": self.assurance, "detail": self.detail, "accepted": self.accepted,
                "exit_code": self.exit_code}


def combine_exit_codes(codes) -> int:
    """Precedence (owner-approved O4): 2 > 1 > 3 > 4 > 0. 2 comes from InputError, not from Outcome."""
    codes = set(codes)
    for c in (EXIT_INPUT_ERROR, 1, 3, 4, 0):
        if c in codes:
            return c
    return 0


# ---------------------------------------------------------------- free space (owner decision 1)
def required_free_bytes(size_bytes: int) -> int:
    """2x the item plus overhead. Applies to temporary storage used for copying or processing."""
    return 2 * int(size_bytes) + max(OVERHEAD_MIN, int(int(size_bytes) * OVERHEAD_FRACTION))


def free_bytes(directory: str) -> int:
    st = os.statvfs(directory)
    return st.f_bavail * st.f_frsize


def require_free_space(directory: str, needed: int) -> None:
    available = free_bytes(directory)
    if available < needed:
        raise InsufficientSpace(f"need {needed} bytes free, have {available}")


# ---------------------------------------------------------------- identity configuration
def load_identity_config(path: str) -> dict:
    """Owner-supplied identity values (U1 deferred: this code chooses no values)."""
    try:
        with open(path, "r", encoding="utf-8") as fh:
            raw = json.load(fh)
    except (OSError, ValueError) as exc:
        raise InputError("identity configuration is missing or not valid JSON") from None
    if not isinstance(raw, dict):
        raise InputError("identity configuration must be a JSON object")
    try:
        mapping = {SubsystemId(k): v for k, v in raw.items()}
    except ValueError:
        raise InputError("identity configuration has an unknown subsystem name") from None
    try:
        return validate_identities(mapping)
    except ValueError as exc:
        raise InputError(f"identity configuration invalid: {exc}") from None


# ---------------------------------------------------------------- manifest
def manifest_path_for(backup_path: str) -> str:
    return backup_path[: -len(SUFFIX)] + MANIFEST_SUFFIX


def _parse_utc(text: str) -> _dt.datetime:
    value = _dt.datetime.fromisoformat(text)
    if value.tzinfo is None:
        raise ManifestProblem(R_MANIFEST_INVALID)
    return value


def validate_manifest_fields(m: dict, backup_name: str, actual_size: int) -> None:
    """Structural checks. Raises ManifestProblem(MANIFEST_INVALID) or (MANIFEST_MISMATCH) for the size."""
    if not isinstance(m, dict):
        raise ManifestProblem(R_MANIFEST_INVALID)
    for key, typ in MANIFEST_FIELDS.items():
        if key not in m or not isinstance(m[key], typ) or isinstance(m[key], bool) and typ is int:
            raise ManifestProblem(R_MANIFEST_INVALID)
    if m["manifest_version"] != MANIFEST_VERSION or m["method"] != METHOD:
        raise ManifestProblem(R_MANIFEST_INVALID)
    if m["subsystem"] not in {s.value for s in SubsystemId}:
        raise ManifestProblem(R_MANIFEST_INVALID)
    if m["journal_mode"] != "delete" or m["header_bytes_18_19"] != "0101" or m["integrity_check"] != "ok":
        raise ManifestProblem(R_MANIFEST_INVALID)
    if m["backup_file"] != backup_name or not _SHA_RE.match(m["sha256"]):
        raise ManifestProblem(R_MANIFEST_INVALID)
    if not all(isinstance(t, str) for t in m["table_names"]):
        raise ManifestProblem(R_MANIFEST_INVALID)
    try:
        started = _parse_utc(m["backup_started_utc"])
        finished = _parse_utc(m["backup_finished_utc"])
    except ValueError:
        raise ManifestProblem(R_MANIFEST_INVALID) from None
    if finished < started:
        raise ManifestProblem(R_MANIFEST_INVALID)
    if m["size_bytes"] != actual_size:
        raise ManifestProblem(R_MANIFEST_MISMATCH)


def load_manifest(path: str) -> dict:
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except FileNotFoundError:
        raise ManifestProblem(R_MANIFEST_MISSING) from None
    except (OSError, ValueError, UnicodeDecodeError):
        raise ManifestProblem(R_MANIFEST_INVALID) from None


# ---------------------------------------------------------------- reading (no retry, no waiting)
def _hash_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(CHUNK), b""):
            h.update(chunk)
    return h.hexdigest()


def _read_backup_facts(path: str) -> dict:
    """Read-only SQLite access to a finalized rollback-mode backup. One attempt, short timeout, no retry."""
    uri = Path(path).resolve().as_uri() + "?mode=ro"
    conn = None
    try:
        conn = sqlite3.connect(uri, uri=True, timeout=0.5)
        integrity = [r[0] for r in conn.execute("PRAGMA integrity_check").fetchall()]
        app_id = conn.execute("PRAGMA application_id").fetchone()[0]
        user_version = conn.execute("PRAGMA user_version").fetchone()[0]
        page_size = conn.execute("PRAGMA page_size").fetchone()[0]
        page_count = conn.execute("PRAGMA page_count").fetchone()[0]
        tables = sorted(r[0] for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'"))
        return {"integrity": integrity, "application_id": int(app_id), "user_version": int(user_version),
                "page_size": int(page_size), "page_count": int(page_count), "tables": tables}
    except sqlite3.OperationalError as exc:
        text = str(exc).lower()
        if "locked" in text or "busy" in text:
            raise _SourceBusy() from None
        raise _Damaged(type(exc).__name__) from None
    except sqlite3.DatabaseError as exc:
        raise _Damaged(type(exc).__name__) from None
    finally:
        if conn is not None:
            conn.close()


class _SourceBusy(Exception):
    pass


class _Damaged(Exception):
    pass


# ---------------------------------------------------------------- inspection
def inspect_backup(path: str, *, expected: SubsystemId | None, identities: Mapping,
                   max_bytes: int = DEFAULT_MAX_BYTES, strict: bool = True,
                   manifest_path: str | None = None,
                   _between_reads: Callable[[str], None] | None = None) -> Outcome:
    """Inspect one finalized owner backup. Order: name, file type, sidecars, size, header, manifest, stable
    hash (strict: two reads), read-only SQLite checks, manifest consistency, Stage 1 classification."""
    assurance = "STRICT" if strict else "REDUCED"
    validate_identities(identities)
    if not isinstance(path, str) or not path.endswith(SUFFIX):
        raise InputError("input must be a finalized backup named *.sqlite")
    if not os.path.lexists(path):
        raise InputError("input file does not exist")
    if os.path.islink(path):
        return Outcome(KIND_NOT_INSPECTED, R_SYMLINK_REFUSED, None, None, assurance)
    st = os.stat(path)
    if not _stat.S_ISREG(st.st_mode):
        return Outcome(KIND_NOT_INSPECTED, R_NOT_REGULAR_FILE, None, None, assurance)
    for suffix in ("-wal", "-shm"):
        if os.path.exists(path + suffix):
            raise InputError(f"sidecar {suffix} present beside backup: refused")
    if os.path.exists(path + "-journal"):
        return Outcome(KIND_UNVERIFIED, R_HOT_JOURNAL, None, None, assurance)
    if st.st_size > max_bytes:
        return Outcome(KIND_NOT_INSPECTED, R_SIZE_LIMIT_EXCEEDED, None, None, assurance,
                       detail=f"{st.st_size} bytes > limit {max_bytes}")
    with open(path, "rb") as fh:
        head = fh.read(100)
    if head[: len(_SQLITE_MAGIC)] == _SQLITE_MAGIC and len(head) >= 20 and head[18] == 2 and head[19] == 2:
        raise InputError("WAL-mode file refused: only rollback-mode owner backups are inspected")

    name = os.path.basename(path)
    mpath = manifest_path or manifest_path_for(path)
    try:
        manifest = load_manifest(mpath)
        validate_manifest_fields(manifest, name, st.st_size)
    except ManifestProblem as exc:
        return Outcome(KIND_UNVERIFIED, exc.reason, None, None, assurance)

    # stable read: strict = two full reads that must agree (change detection; not a consistency proof)
    before = os.stat(path)
    first = _hash_file(path)
    if _between_reads is not None:
        _between_reads(path)
    second = _hash_file(path) if strict else first
    after = os.stat(path)
    same_identity = (before.st_size, before.st_ino, before.st_mtime_ns) == \
                    (after.st_size, after.st_ino, after.st_mtime_ns)
    if first != second or not same_identity:
        return Outcome(KIND_UNVERIFIED, R_SNAPSHOT_UNSTABLE, None, None, assurance)
    if first != manifest["sha256"]:
        return Outcome(KIND_UNVERIFIED, R_MANIFEST_MISMATCH, None, None, assurance)

    try:
        facts = _read_backup_facts(path)
    except _SourceBusy:
        return Outcome(KIND_UNVERIFIED, R_SOURCE_BUSY, None, None, assurance)
    except _Damaged as exc:
        return Outcome(KIND_REFUSED, R_DAMAGED, "DAMAGED", None, assurance, detail=str(exc))
    if facts["integrity"] != ["ok"]:
        return Outcome(KIND_REFUSED, R_DAMAGED, "DAMAGED", None, assurance, detail="integrity_check failed")

    consistent = (
        manifest["application_id"] == facts["application_id"]
        and manifest["schema_user_version"] == facts["user_version"]
        and manifest["page_size"] == facts["page_size"]
        and manifest["page_count"] == facts["page_count"]
        and manifest["table_names"] == facts["tables"]
    )
    if not consistent:
        return Outcome(KIND_UNVERIFIED, R_MANIFEST_INCONSISTENT, None, None, assurance)

    cls_facts = FileFacts(exists=True, size=st.st_size, readable=True, application_id=facts["application_id"],
                          user_version=facts["user_version"], quick_check="ok", tables=frozenset(facts["tables"]))
    cls = classify_facts(cls_facts, identities=identities, expected=expected)
    owner = cls.owner.value if cls.owner else None
    if cls.owner is not None and cls.owner.value != manifest["subsystem"]:
        return Outcome(KIND_UNVERIFIED, R_MANIFEST_INCONSISTENT, cls.state.name, owner, assurance,
                       detail="manifest subsystem differs from structure owner")
    state = cls.state.name
    if cls.state.name in ("DAMAGED", "MIXED", "UNKNOWN", "FOREIGN", "OWNED_OLDER", "OWNED_NEWER"):
        return Outcome(KIND_REFUSED, state, state, owner, assurance, detail="; ".join(cls.reasons))
    if expected is not None and cls.owner is not None and cls.owner != expected:
        return Outcome(KIND_REFUSED, R_REFUSED_FOR_OWNER, state, owner, assurance,
                       detail=f"structure belongs to {cls.owner.value}, requested {expected.value}")
    if expected is not None and cls.owner is None:
        return Outcome(KIND_REFUSED, R_REFUSED_FOR_OWNER, state, owner, assurance, detail="no owner established")
    return Outcome(KIND_OK, None, state, owner, assurance, detail="; ".join(cls.reasons))


def write_report(report_path: str, input_path: str, outcome: Outcome) -> None:
    """Report goes outside the input's directory (never beside the input)."""
    in_dir = os.path.realpath(os.path.dirname(input_path))
    out_dir = os.path.realpath(os.path.dirname(report_path) or ".")
    if out_dir == in_dir or out_dir.startswith(in_dir + os.sep):
        raise InputError("report must be written outside the input directory")
    data = {"input_basename": os.path.basename(input_path), "outcome": outcome.as_dict(),
            "source_label": "SQLITE_BACKUP_INPUT", "inspect_only": True}
    tmp = report_path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, sort_keys=True)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, report_path)
