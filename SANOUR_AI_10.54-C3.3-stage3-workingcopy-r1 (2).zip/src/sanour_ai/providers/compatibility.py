"""Stage 10.51: versioned compatibility contracts for provider adapters, and the SDK pin gate.

Stdlib only. Imports no SDK. Fail-closed: a missing or mismatched pinned package refuses construction of the
production client, before any request is accepted. Nothing here calls a provider or reads a secret.

Two separate decisions, never merged:
- verified_production: a reviewed fact about evidence. It is False for every provider in this repository.
- compatibility: whether the packages and attributes an adapter needs are present and match. Passing it does not
  make a provider production-ready.

Refusals name the failed rule. They never print installed versions, endpoints, or any secret value.
"""

from __future__ import annotations

import importlib.metadata as _metadata
from collections.abc import Callable
from dataclasses import dataclass

from sanour_ai.config.settings import ConfigError

# Layout version of the Contract record. Bump only when a field is added, removed, or changes meaning.
CONTRACT_SCHEMA = 1


@dataclass(frozen=True)
class Contract:
    provider: str                       # registry key, equal to the adapter's name attribute
    adapter: str                        # adapter class name
    contract_version: str               # adapter-level version: bump on any change to its behaviour
    surface: str                        # endpoint family, equal to the adapter's surface attribute
    auth_method: str                    # equal to the adapter's auth_method attribute
    endpoint: str                       # pinned endpoint or base, as coded in the adapter (checked by tests)
    sdk_pins: tuple[tuple[str, str], ...] = ()   # (package, exact version); empty: no SDK is used
    verified_production: bool = False   # reviewed evidence only. Always False in this repository.


CONTRACTS: dict[str, Contract] = {
    "openai": Contract(
        provider="openai", adapter="OpenAIProvider", contract_version="10.51.0",
        surface="openai_responses", auth_method="sdk_bearer_client",
        endpoint="https://api.openai.com/v1",
        sdk_pins=(("openai", "3.45.0"), ("httpx2", "2.13.1")),
    ),
    "anthropic": Contract(
        provider="anthropic", adapter="AnthropicProvider", contract_version="10.51.0",
        surface="anthropic_messages", auth_method="x_api_key_header",
        endpoint="https://api.anthropic.com/v1/messages",
    ),
    "gemini": Contract(
        provider="gemini", adapter="GeminiProvider", contract_version="10.51.0",
        surface="gemini_generate_content", auth_method="x_goog_api_key_header",
        endpoint="https://generativelanguage.googleapis.com/v1beta/models/",
    ),
    "grok": Contract(
        provider="grok", adapter="GrokProvider", contract_version="10.51.0",
        surface="grok_chat_completions", auth_method="bearer_header",
        endpoint="https://api.x.ai/v1/chat/completions",
    ),
    "grok_responses": Contract(
        provider="grok_responses", adapter="XaiResponsesProvider", contract_version="10.51.0",
        surface="grok_responses", auth_method="bearer_header",
        endpoint="https://api.x.ai/v1/responses",
    ),
}


def sdk_problems(contract: Contract,
                 lookup: Callable[[str], str] = _metadata.version) -> list[str]:
    """Rule names that fail for this contract's pinned packages. Empty means the pins are met (or none are needed).
    `lookup` returns an installed version or raises PackageNotFoundError. Values are never returned."""
    problems: list[str] = []
    for package, pin in contract.sdk_pins:
        try:
            installed = lookup(package)
        except _metadata.PackageNotFoundError:
            problems.append(f"{package} is not installed")
            continue
        if installed != pin:
            problems.append(f"{package} is not the pinned version")
    return problems


def require_sdk(provider: str, lookup: Callable[[str], str] = _metadata.version) -> None:
    """Fail-closed gate for a production client. Raises ConfigError naming the failed rules only."""
    contract = CONTRACTS.get(provider)
    if contract is None:
        raise ConfigError("provider has no compatibility contract")
    problems = sdk_problems(contract, lookup)
    if problems:
        raise ConfigError(f"compatibility contract not met for {provider}: " + "; ".join(problems))
