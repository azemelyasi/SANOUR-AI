"""Backup and restore of the ledger database (Stage 10.54-C1).

Backup: SQLite online backup API (one consistent snapshot), verified as a private copy, then published as a
directory holding `ledger.sqlite` and `manifest.json`. The manifest is canonical JSON: file names, sizes and
SHA-256, migration checksums, per-stream heads and counts, optional external anchor facts, and its own SHA-256.

Restore: refuses any existing destination (and its SQLite sidecars). Verifies the manifest, the file hash, the
migration checksums against this code, then copies to a private temporary file in the destination directory,
re-verifies it (migrations, both chains, anchor facts, heads and counts), and only then publishes it with
`os.link`, which fails instead of overwriting. Any failure removes the temporary file; the destination is never
created partially.

Reports carry fixed codes, counts and hashes only: never payloads, record ids, paths of secrets or SQL text.
Residual limit: directory publication in `create_backup` checks for absence and then renames; a directory created at
the same instant by another process could be replaced if it is empty. Restore publication has no such window.
"""

from __future__ import annotations

import json
import os
import pathlib
import secrets
import shutil
import sqlite3
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Callable

from sanour_ai.persistence import canonical as C
from sanour_ai.persistence import migrations as M
from sanour_ai.persistence.errors import LedgerError
from sanour_ai.persistence.ledger import Ledger
from sanour_ai.persistence.recovery import AnchorLog, verify_integrity

MANIFEST_VERSION = 1
KIND = "sanour-ledger-backup"
DB_NAME = "ledger.sqlite"
MANIFEST_NAME = "manifest.json"
_MAX_MANIFEST_BYTES = 1 << 20
_SIDECARS = ("-wal", "-shm", "-journal")
_BACKUP_TMP = ".sanour-backup-"
_RESTORE_TMP = ".sanour-restore-"
_MAX_CODES = 5


class BackupError(LedgerError):
    """Backup refused or failed. Nothing was published at the destination."""


class RestoreError(LedgerError):
    """Restore refused or failed. Nothing was published at the destination."""


@dataclass(frozen=True)
class BackupResult:
    path: str
    manifest_sha256: str
    db_sha256: str
    db_size: int
    streams: dict


@dataclass(frozen=True)
class RestoreResult:
    path: str
    manifest_sha256: str
    schema_version: int
    streams: dict


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _abs_path(value: object, exc: type[LedgerError]) -> str:
    if not isinstance(value, str) or not value or "\x00" in value or len(value) > 1024:
        raise exc("invalid path")
    return os.path.abspath(value)


def _check_parent(dest: str, exc: type[LedgerError]) -> str:
    parent = os.path.dirname(dest)
    if not os.path.isdir(parent) or os.path.islink(parent):
        raise exc("destination parent directory does not exist")
    return parent


def _refuse_existing(dest: str, exc: type[LedgerError]) -> None:
    for suffix in ("",) + _SIDECARS:
        if os.path.lexists(dest + suffix):
            raise exc("destination already exists: nothing written")


def _fsync_dir(path: str) -> None:
    fd = os.open(path, os.O_RDONLY)
    try:
        os.fsync(fd)
    except OSError:
        pass
    finally:
        os.close(fd)


def _write_new(path: str, data: bytes) -> None:
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        view = memoryview(data)
        while view:
            n = os.write(fd, view)
            view = view[n:]
        os.fsync(fd)
    finally:
        os.close(fd)


def _digest(path: str) -> tuple[str, int]:
    import hashlib
    h, size = hashlib.sha256(), 0
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
            size += len(block)
    return h.hexdigest(), size


def _remove_quiet(path: str) -> None:
    try:
        os.unlink(path)
    except FileNotFoundError:
        pass
    except OSError:
        pass


def _remove_db_files(path: str) -> None:
    for suffix in ("",) + _SIDECARS:
        _remove_quiet(path + suffix)


# ---------------------------------------------------------------- snapshot and verification
def _code_migrations() -> list[dict]:
    return [{"version": m.version, "name": m.name, "checksum": m.checksum} for m in M.MIGRATIONS]


def _snapshot(conn: sqlite3.Connection) -> dict:
    migrations = [{"version": int(v), "name": str(n), "checksum": str(c)} for v, n, c in conn.execute(
        "SELECT version, name, checksum FROM schema_migrations ORDER BY version")]
    streams = {}
    for s in sorted(C.STREAMS):
        head = conn.execute("SELECT seq, record_hash FROM ledger_records WHERE stream=? ORDER BY seq DESC LIMIT 1",
                            (s,)).fetchone()
        records = conn.execute("SELECT COUNT(*) FROM ledger_records WHERE stream=?", (s,)).fetchone()[0]
        cps = conn.execute("SELECT COUNT(*) FROM ledger_checkpoints WHERE stream=?", (s,)).fetchone()[0]
        streams[s] = {"head_seq": int(head[0]) if head else 0, "head_hash": head[1] if head else C.GENESIS_HASH,
                      "records": int(records), "checkpoints": int(cps)}
    return {"migrations": migrations, "streams": streams}


def _verify_db(path: str, anchor: dict | None, anchors: AnchorLog | None, exc: type[LedgerError]) -> dict:
    """Full check of one database file: migrations against this code, SQLite structure, both chains,
    checkpoints, optional external anchors, and the manifest's anchor facts. Returns the snapshot."""
    try:
        led = Ledger(path, busy_timeout_ms=5000)
    except LedgerError:
        raise exc("database failed to open or its migrations do not match this code") from None
    try:
        report = verify_integrity(led, anchors)
        if not report.ok:
            codes = sorted({f.code for f in report.findings})[:_MAX_CODES]
            raise exc("integrity check failed: " + ", ".join(codes))
        conn = sqlite3.connect(path, timeout=5)
        try:
            conn.execute("BEGIN")
            snap = _snapshot(conn)
            if anchor is not None:
                _check_anchor(conn, anchor, exc)
            conn.execute("COMMIT")
        finally:
            conn.close()
    except sqlite3.Error:
        raise exc("database could not be read") from None
    finally:
        led.close()
    if snap["migrations"] != _code_migrations():
        raise exc("migration checksums do not match this code")
    return snap


def _check_anchor(conn: sqlite3.Connection, anchor: dict, exc: type[LedgerError]) -> None:
    if anchor.get("stream") not in C.STREAMS or not isinstance(anchor.get("seq"), int) or anchor["seq"] < 0:
        raise exc("anchor facts are malformed")
    head = conn.execute("SELECT seq FROM ledger_records WHERE stream=? ORDER BY seq DESC LIMIT 1",
                        (anchor["stream"],)).fetchone()
    head_seq = int(head[0]) if head else 0
    if anchor["seq"] > head_seq:
        raise exc("ledger is behind its external anchor")
    if anchor["seq"]:
        at = conn.execute("SELECT record_hash FROM ledger_records WHERE stream=? AND seq=?",
                          (anchor["stream"], anchor["seq"])).fetchone()
        if at is None or at[0] != anchor["head_hash"]:
            raise exc("ledger does not match its external anchor")


def _finalize(path: str, exc: type[LedgerError]) -> None:
    """Fold the WAL into the single file and refuse any leftover sidecar, so the file alone is the backup.
    A sidecar present BEFORE this call is refused, not removed: SQLite would otherwise clean it up silently (a stale
    journal could roll the copy back). The check after the switch catches a sidecar that appears during it."""
    if any(os.path.lexists(path + s) for s in _SIDECARS):
        raise exc("unexpected sidecar files next to the database")
    try:
        conn = sqlite3.connect(path, timeout=5)
        try:
            mode = conn.execute("PRAGMA journal_mode=DELETE").fetchone()[0]
        finally:
            conn.close()
    except sqlite3.Error:
        raise exc("database could not be finalized") from None
    if str(mode).lower() != "delete":
        raise exc("database could not be finalized")
    if any(os.path.lexists(path + s) for s in _SIDECARS):
        raise exc("unexpected sidecar files next to the database")


def _online_copy(src: str, dst: str) -> None:
    uri = pathlib.Path(src).as_uri() + "?mode=ro"
    source = sqlite3.connect(uri, uri=True, timeout=5)
    target = sqlite3.connect(dst)
    try:
        source.backup(target)        # one call: one consistent snapshot of the whole database
    finally:
        target.close()
        source.close()


# ---------------------------------------------------------------- backup
def create_backup(source_path: str, dest_dir: str, *, anchor=None,
                  clock: Callable[[], str] | None = None) -> BackupResult:
    """Consistent online backup of `source_path` into the NEW directory `dest_dir`. `anchor` is an optional
    `Anchor` (from export_anchor) recorded in the manifest and checked against the copy."""
    src = _abs_path(source_path, BackupError)
    if not os.path.isfile(src) or os.path.islink(src):
        raise BackupError("source ledger not found")
    dest = _abs_path(dest_dir, BackupError)
    _refuse_existing(dest, BackupError)
    parent = _check_parent(dest, BackupError)
    anchor_d = None if anchor is None else dict(anchor.as_dict())
    staging = tempfile.mkdtemp(prefix=_BACKUP_TMP, dir=parent)
    try:
        db = os.path.join(staging, DB_NAME)
        _online_copy(src, db)
        snap = _verify_db(db, anchor_d, None, BackupError)
        _finalize(db, BackupError)
        db_sha, db_size = _digest(db)
        body = {
            "v": MANIFEST_VERSION, "kind": KIND,
            "created_at": (clock or _utc_now)(),
            "files": [{"name": DB_NAME, "size": db_size, "sha256": db_sha}],
            "migrations": _code_migrations(),
            "streams": snap["streams"],
            "anchor": anchor_d,
        }
        manifest_sha = C.sha256_hex(C.dumps(body))
        _write_new(os.path.join(staging, MANIFEST_NAME), C.dumps({**body, "manifest_sha256": manifest_sha}))
        _fsync_dir(staging)
        _refuse_existing(dest, BackupError)
        os.rename(staging, dest)
        _fsync_dir(parent)
        return BackupResult(dest, manifest_sha, db_sha, db_size, snap["streams"])
    except LedgerError:
        shutil.rmtree(staging, ignore_errors=True)
        raise
    except (sqlite3.Error, OSError):
        shutil.rmtree(staging, ignore_errors=True)
        raise BackupError("backup failed: nothing published") from None
    except BaseException:
        shutil.rmtree(staging, ignore_errors=True)
        raise


# ---------------------------------------------------------------- restore
def _read_manifest(bdir: str) -> tuple[dict, str]:
    path = os.path.join(bdir, MANIFEST_NAME)
    if os.path.islink(path) or not os.path.isfile(path):
        raise RestoreError("manifest missing")
    if os.path.getsize(path) > _MAX_MANIFEST_BYTES:
        raise RestoreError("manifest unreadable")
    with open(path, "rb") as fh:
        raw = fh.read()
    try:
        obj = json.loads(raw)
    except ValueError:
        raise RestoreError("manifest unreadable") from None
    if not isinstance(obj, dict) or raw != C.dumps(obj):
        raise RestoreError("manifest is not canonical")
    claimed = obj.pop("manifest_sha256", None)
    if claimed != C.sha256_hex(C.dumps(obj)):
        raise RestoreError("manifest integrity hash mismatch")
    if obj.get("v") != MANIFEST_VERSION or obj.get("kind") != KIND:
        raise RestoreError("manifest version or kind not supported")
    return obj, claimed


def _check_manifest_shape(m: dict) -> dict:
    files = m.get("files")
    if not isinstance(files, list) or len(files) != 1 or not isinstance(files[0], dict):
        raise RestoreError("manifest file list is wrong")
    f = files[0]
    if f.get("name") != DB_NAME or not isinstance(f.get("size"), int) or not isinstance(f.get("sha256"), str):
        raise RestoreError("manifest file entry is wrong")
    if m.get("migrations") != _code_migrations():
        raise RestoreError("migration checksums do not match this code")
    if not isinstance(m.get("streams"), dict) or set(m["streams"]) != set(C.STREAMS):
        raise RestoreError("manifest streams are wrong")
    return f


def _copy_exclusive(src: str, dst: str) -> None:
    if os.path.islink(src):
        raise RestoreError("backup file is a link")
    fd_in = os.open(src, os.O_RDONLY)
    try:
        fd_out = os.open(dst, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        try:
            while True:
                block = os.read(fd_in, 1 << 20)
                if not block:
                    break
                view = memoryview(block)
                while view:
                    view = view[os.write(fd_out, view):]
            os.fsync(fd_out)
        finally:
            os.close(fd_out)
    finally:
        os.close(fd_in)


def restore_backup(backup_dir: str, dest_path: str, *, anchors: AnchorLog | None = None) -> RestoreResult:
    """Restore a backup directory to a NEW database path. Refuses existing destinations; publishes only a
    fully verified copy, without overwriting."""
    bdir = _abs_path(backup_dir, RestoreError)
    if not os.path.isdir(bdir) or os.path.islink(bdir):
        raise RestoreError("backup directory not found")
    dest = _abs_path(dest_path, RestoreError)
    _refuse_existing(dest, RestoreError)
    parent = _check_parent(dest, RestoreError)
    manifest, manifest_sha = _read_manifest(bdir)
    entry = _check_manifest_shape(manifest)
    src_db = os.path.join(bdir, DB_NAME)
    if not os.path.isfile(src_db):
        raise RestoreError("backup file missing")
    if os.path.getsize(src_db) != entry["size"] or _digest(src_db)[0] != entry["sha256"]:
        raise RestoreError("backup file does not match the manifest")
    tmp = os.path.join(parent, f"{_RESTORE_TMP}{secrets.token_hex(8)}.tmp")
    try:
        _copy_exclusive(src_db, tmp)
        if _digest(tmp) != (entry["sha256"], entry["size"]):
            raise RestoreError("copy does not match the manifest")
        snap = _verify_db(tmp, manifest["anchor"], anchors, RestoreError)
        if snap["streams"] != manifest["streams"]:
            raise RestoreError("stream heads or counts do not match the manifest")
        _finalize(tmp, RestoreError)
        try:
            os.link(tmp, dest)
        except FileExistsError:
            raise RestoreError("destination was created during restore: nothing published") from None
        except OSError:
            raise RestoreError("publication without overwrite is not available on this filesystem") from None
        _fsync_dir(parent)
        return RestoreResult(dest, manifest_sha, M.LATEST_VERSION, snap["streams"])
    except LedgerError:
        raise
    except (sqlite3.Error, OSError):
        raise RestoreError("restore failed: nothing published") from None
    finally:
        _remove_db_files(tmp)      # removes only the temporary name: a published link is untouched


def verify_backup(backup_dir: str) -> RestoreResult:
    """Read-only check of a backup directory: the full restore verification into a private temporary directory that
    is removed afterwards. Nothing is published at a caller-visible path."""
    parent = tempfile.mkdtemp(prefix=".sanour-verify-")
    try:
        return restore_backup(backup_dir, os.path.join(parent, "verify.sqlite"))
    finally:
        shutil.rmtree(parent, ignore_errors=True)


def sweep_stale_temporaries(parent_dir: str) -> int:
    """Remove what a killed restore or backup left behind: `.sanour-restore-*.tmp` (with its sidecars) and
    `.sanour-backup-*` staging directories. Only these exact prefixes are touched. Run only when no backup or restore
    is active in that directory. Returns the number of entries removed."""
    parent = _abs_path(parent_dir, BackupError)
    if not os.path.isdir(parent) or os.path.islink(parent):
        raise BackupError("directory to sweep not found")
    removed = 0
    for name in sorted(os.listdir(parent)):
        p = os.path.join(parent, name)
        if name.startswith(_RESTORE_TMP) and not os.path.isdir(p) and (
                name.endswith(".tmp") or any(name.endswith(".tmp" + s) for s in _SIDECARS)):
            if not os.path.islink(p):
                _remove_quiet(p)
                removed += 1
        elif name.startswith(_BACKUP_TMP) and os.path.isdir(p) and not os.path.islink(p):
            shutil.rmtree(p, ignore_errors=True)
            removed += 1
    return removed
