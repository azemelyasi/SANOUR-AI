"""Stage 10.54-C1: consistent online backup and verified, non-overwriting restore of the evidence ledger.

Kept OUTSIDE sanour_ai.persistence on purpose: the 10.54-B boundary guard keeps persistence free of backup code.
Offline, stdlib only. Reads the source ledger; never writes to it.
"""

from sanour_ai.backup.archive import (
    BackupError, BackupResult, RestoreError, RestoreResult, create_backup, restore_backup, sweep_stale_temporaries,
    verify_backup,
)

__all__ = ["BackupError", "BackupResult", "RestoreError", "RestoreResult", "create_backup", "restore_backup",
           "sweep_stale_temporaries", "verify_backup"]
