"""Cross-process lock for FIRST OPENS of a SQLite file (Stage 10.54-C3.2, Stage 10.57 Stage 3).

Location of the lock (Stage 3 revised design): the lock target is the CANONICAL PARENT DIRECTORY of the database file,
not a sidecar file. No lock file is created, read, or deleted, so backup and restore directories are not polluted and
no lock file ever needs unlinking. `flock` is taken on a read-only descriptor of that directory.

Mechanism:
- canon = os.path.realpath(path); the lock target is os.path.dirname(canon). A symlink and its target resolve to the same
  directory, so they exclude each other. Hardlinks in the SAME directory share one lock (serialized). Hardlinks in
  DIFFERENT directories are NOT coordinated.
- A thread-local set holds canonical paths this thread currently holds. The path is added BEFORE the blocking flock, so an
  interrupt during the pending flock still finds it and cleans it up. A thread may hold at most one first-open lock at a
  time: any nested call fails immediately with LockUnavailable, for the same or a different path. Without this check, a
  same-thread nested flock on the same directory would block on itself forever.
- Each call opens its own descriptor. On Linux, flock locks belong to the open file description, so threads conflict with
  each other exactly as processes do. No FIFO or fairness order is promised.

Trade-offs (accepted): every first open in one directory is serialized, so unrelated databases in the same folder wait on
each other; the Ledger busy-wait runs under the lock, so a slow SQLite wait can delay other first opens in that folder.

Limitations (stated, not claimed beyond them):
- Linux is the exercised platform. macOS is NOT verified. Windows has no lock: callers REFUSE to open (fail closed).
- Network filesystems: `flock` is not reliable; not claimed.
- Symlink replacement race: realpath is evaluated before the directory is opened; an alias swapped in between is not covered.
- Hardlinks across directories are not coordinated.
- The blocking wait is unbounded. This is temporary Option A behavior: no timeout, polling, or cancellation.
- Only first opens are locked. In-memory paths are not locked.

This module imports only the standard library, so the persistence import boundary holds.
"""

from __future__ import annotations

import os
import threading
from collections.abc import Iterator
from contextlib import contextmanager

try:
    import fcntl
except ImportError:          # no fcntl on this platform: locking is unavailable, opening is refused
    fcntl = None


class LockUnavailable(RuntimeError):
    """The platform cannot take the open lock, the lock directory cannot be opened, or a nested acquisition was
    refused. Nothing was opened."""


_HELD = threading.local()


def _thread_held_paths() -> set[str]:
    """Canonical paths whose first-open lock this thread currently holds (registered before blocking flock)."""
    held = getattr(_HELD, "paths", None)
    if held is None:
        held = set()
        _HELD.paths = held
    return held


def _release(held: set[str], fd: int | None, canon: str, registered: bool, primary: BaseException | None) -> None:
    """Close the descriptor (releases the flock), then always discard the path. A close failure never replaces the
    original exception: with an exception in flight it is attached as a note; without one it fails closed."""
    close_err: OSError | None = None
    try:
        if fd is not None:
            try:
                os.close(fd)          # closing the descriptor releases the lock
            except OSError as exc:
                close_err = exc
    finally:
        if registered:
            held.discard(canon)       # runs even if os.close raised anything
    if close_err is not None:
        if primary is None:
            raise LockUnavailable("lock descriptor could not be closed") from close_err
        primary.add_note("lock descriptor close also failed: " + repr(close_err))


@contextmanager
def exclusive_open_lock(path: str) -> Iterator[None]:
    if path == ":memory:":
        yield
        return
    if fcntl is None:
        raise LockUnavailable("file locking is not available on this platform")

    held = _thread_held_paths()
    if held:                          # this thread already holds a first-open lock (same or other path): refuse
        raise LockUnavailable("nested first-open refused")

    canon = os.path.realpath(path)
    lock_dir = os.path.dirname(canon)
    fd: int | None = None
    registered = False
    primary: BaseException | None = None   # the exception that will propagate, if any
    try:
        try:
            fd = os.open(lock_dir, os.O_RDONLY)
        except OSError as exc:
            raise LockUnavailable("lock directory could not be opened") from exc

        held.add(canon)               # registered BEFORE the blocking flock
        registered = True

        try:
            fcntl.flock(fd, fcntl.LOCK_EX)
        except OSError as exc:
            raise LockUnavailable("file lock could not be taken") from exc
        # BaseException (e.g. KeyboardInterrupt) from flock propagates unchanged

        yield                         # with-body runs holding the lock
    except BaseException as exc:
        primary = exc
        raise
    finally:
        _release(held, fd, canon, registered, primary)
