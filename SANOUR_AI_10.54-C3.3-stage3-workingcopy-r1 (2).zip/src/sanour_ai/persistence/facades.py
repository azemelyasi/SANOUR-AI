"""Evidence and governance-event facades over the generic ledger (Stage 10.54-A).

Storage only. They know nothing about providers, readiness rules or the evidence store's live-acceptance
screening; those stay in the readiness package, which will call these in a later stage. Artifact bytes are
hashed here and never stored (same rule as the in-memory store).
"""

from __future__ import annotations

import hashlib
import re
from datetime import datetime, timezone

from sanour_ai.persistence.errors import RecordRejected
from sanour_ai.persistence.ledger import AppendResult, Ledger

EVIDENCE = "evidence"
GOVERNANCE = "governance"
MAX_ARTIFACT_BYTES = 10 * 1024 * 1024
_SHA = re.compile(r"[0-9a-f]{64}\Z")
_TEXT = ("provider_id", "criterion", "kind", "source", "recorded_by", "method", "software",
         "software_version", "note")


class EvidenceLedger:
    def __init__(self, ledger: Ledger) -> None:
        self._l = ledger

    def _payload(self, a: dict) -> dict:
        artifact = a["artifact"]
        if not isinstance(artifact, (bytes, bytearray)) or not artifact:
            raise RecordRejected("artifact bytes are required")
        if len(artifact) > MAX_ARTIFACT_BYTES:
            raise RecordRejected("artifact too large")
        for name in _TEXT:
            if not isinstance(a[name], str) or not a[name].strip():
                raise RecordRejected(f"{name} is required")
        if not isinstance(a["reviewer"], str):
            raise RecordRejected("reviewer must be text")
        if not isinstance(a["supports"], bool):
            raise RecordRejected("supports must be a bool")
        v = a["verified_at"]
        if not isinstance(v, datetime) or v.tzinfo is None:
            raise RecordRejected("verified_at must be timezone-aware")
        sha = hashlib.sha256(bytes(artifact)).hexdigest()   # computed, never accepted
        claimed = a["claimed_sha256"]
        if claimed is not None and (not isinstance(claimed, str) or claimed.lower() != sha):
            raise RecordRejected("claimed sha256 does not match the artifact")
        return {
            "evidence_id": a["evidence_id"], "provider_id": a["provider_id"], "criterion": a["criterion"],
            "kind": a["kind"], "supports": a["supports"], "artifact_sha256": sha, "source": a["source"],
            "reviewer": a["reviewer"], "recorded_by": a["recorded_by"],
            "verified_at": v.astimezone(timezone.utc).isoformat(),
            "method": a["method"], "software": a["software"], "software_version": a["software_version"],
            "note": a["note"],
        }

    def add(self, *, evidence_id: str, provider_id: str, criterion: str, kind: str, supports: bool,
            artifact: bytes, source: str, reviewer: str, recorded_by: str, verified_at: datetime,
            method: str, software: str, software_version: str, note: str,
            claimed_sha256: str | None = None) -> AppendResult:
        p = self._payload(locals())
        return self._l.append(EVIDENCE, evidence_id, "EVIDENCE_ADDED", p)

    def supersede(self, old_id: str, *, evidence_id: str, provider_id: str, criterion: str, kind: str,
                  supports: bool, artifact: bytes, source: str, reviewer: str, recorded_by: str,
                  verified_at: datetime, method: str, software: str, software_version: str, note: str,
                  actor: str, reason: str = "superseded", claimed_sha256: str | None = None):
        p = self._payload(locals())
        old = self._l.get(EVIDENCE, old_id)
        if old is not None and (old.payload["provider_id"], old.payload["criterion"]) != (provider_id, criterion):
            raise RecordRejected("can only supersede evidence of the same provider and criterion")
        p["supersedes"] = old_id
        return self._l.supersede(EVIDENCE, old_id, evidence_id, "EVIDENCE_ADDED", p,
                                 event_kind="EVIDENCE_SUPERSEDED", actor=actor, reason=reason)

    def revoke(self, evidence_id: str, actor: str, reason: str) -> AppendResult:
        return self._l.revoke(EVIDENCE, evidence_id, event_kind="EVIDENCE_REVOKED", actor=actor, reason=reason)

    def get(self, evidence_id: str):
        return self._l.get(EVIDENCE, evidence_id)

    def standing(self, evidence_id: str) -> str:
        return self._l.standing(EVIDENCE, evidence_id)

    def verify_artifact(self, evidence_id: str, data: bytes) -> bool:
        rec = self._l.get(EVIDENCE, evidence_id)
        if rec is None:
            raise KeyError(evidence_id)
        return hashlib.sha256(bytes(data)).hexdigest() == rec.payload["artifact_sha256"]

    def verify(self):
        return self._l.verify(EVIDENCE)


class GovernanceEventLedger:
    def __init__(self, ledger: Ledger) -> None:
        self._l = ledger

    def append(self, event_id: str, event_type: str, *, actor: str, subject: str, detail: dict | None = None) -> AppendResult:
        for name, v in (("actor", actor), ("subject", subject)):
            if not isinstance(v, str) or not v.strip():
                raise RecordRejected(f"{name} is required")
        return self._l.append(GOVERNANCE, event_id, event_type,
                              {"actor": actor, "subject": subject, "detail": detail or {}})

    def revoke(self, event_id: str, actor: str, reason: str) -> AppendResult:
        return self._l.revoke(GOVERNANCE, event_id, event_kind="GOVERNANCE_EVENT_REVOKED", actor=actor, reason=reason)

    def supersede(self, old_id: str, new_id: str, event_type: str, *, actor: str, subject: str,
                  detail: dict | None = None, reason: str = "superseded"):
        return self._l.supersede(GOVERNANCE, old_id, new_id, event_type,
                                 {"actor": actor, "subject": subject, "detail": detail or {}},
                                 event_kind="GOVERNANCE_EVENT_SUPERSEDED", actor=actor, reason=reason)

    def get(self, event_id: str):
        return self._l.get(GOVERNANCE, event_id)

    def standing(self, event_id: str) -> str:
        return self._l.standing(GOVERNANCE, event_id)

    def verify(self):
        return self._l.verify(GOVERNANCE)
