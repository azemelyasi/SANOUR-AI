"""SQLite append-only hash-chained ledger (Stage 10.54-A).

Durability: WAL journal, synchronous=FULL. A committed record survives a process crash or restart.
Atomicity: every write is one BEGIN IMMEDIATE transaction. A crash or error before COMMIT leaves nothing.
Concurrency: any number of readers (each read uses its own short connection and a consistent snapshot)
and one writer at a time (in-process lock plus SQLite's write lock, so several processes are safe too).
Append-only: UPDATE and DELETE on every ledger table are refused by triggers, and the public API has no
update or delete method. `verify()` re-hashes the stored bytes, so edits made by bypassing the triggers
(for example a process that drops them) are still detected.
Limit: someone who can rewrite the whole file can rebuild a consistent chain. Export `head()` and keep
it elsewhere for stronger guarantees. Backup, restore and recovery belong to stages 10.54-B and 10.54-C.
The module imports nothing from providers, models, core or readiness.
"""

from __future__ import annotations

import json
import os
import sqlite3
import threading
import time
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone

from sanour_ai.persistence import canonical as C
from sanour_ai.persistence import migrations as M
from sanour_ai.persistence.first_open_lock import LockUnavailable, exclusive_open_lock
from sanour_ai.persistence.errors import (
    IdempotencyConflict, LedgerBusyError, LedgerStorageError, LinkRejected, RecordRejected, SchemaError,
)

_MAX_PATH = 1024
RESERVED_PREFIXES = ("supersede:", "revoke:")
_COLUMNS = ("stream, seq, record_id, kind, recorded_at, prev_hash, record_hash, content_sha256, "
            "canonical_bytes")
GUARDS = tuple(f"{t}_no_{op}" for t in ("ledger_records", "ledger_links", "schema_migrations")
               for op in ("update", "delete", "replace"))


@dataclass(frozen=True)
class StoredRecord:
    stream: str
    seq: int
    record_id: str
    kind: str
    recorded_at: str
    prev_hash: str
    record_hash: str
    content_sha256: str
    canonical_bytes: bytes

    @property
    def payload(self) -> dict:
        return json.loads(self.canonical_bytes)["payload"]


@dataclass(frozen=True)
class AppendResult:
    record: StoredRecord
    replayed: bool   # True: the same record id and content already existed; nothing new was written


@dataclass(frozen=True)
class VerifyReport:
    ok: bool
    records: int
    head_seq: int
    head_hash: str
    problems: tuple[tuple[int, str], ...]   # (seq, code); seq 0 = not about one record


def _row(r: tuple) -> StoredRecord:
    return StoredRecord(r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8] if isinstance(r[8], bytes) else str(r[8]).encode("utf-8", "replace"))


def _map(exc: sqlite3.Error) -> Exception:
    text = str(exc).lower()
    if isinstance(exc, sqlite3.OperationalError) and ("locked" in text or "busy" in text):
        return LedgerBusyError("ledger is busy")
    return LedgerStorageError("ledger storage failure")


class Ledger:
    def __init__(
        self,
        path: str,
        *,
        clock: Callable[[], datetime] | None = None,
        busy_timeout_ms: int = 5000,
        migrations: tuple[M.Migration, ...] = M.MIGRATIONS,
        commit_hooks: tuple = (),
    ) -> None:
        if (not isinstance(path, str) or not path or path == ":memory:" or "\x00" in path
                or len(path) > _MAX_PATH):
            raise LedgerStorageError("invalid ledger path")  # :memory: is not durable: refused
        if not isinstance(busy_timeout_ms, int) or not 0 <= busy_timeout_ms <= 60_000:
            raise LedgerStorageError("invalid busy timeout")
        M.validate_migration_list(migrations)
        self._path = os.path.abspath(path)
        self._clock = clock or (lambda: datetime.now(timezone.utc))
        self._busy_ms = busy_timeout_ms
        self._migrations = migrations
        hooks = tuple(commit_hooks)
        if not all(callable(h) for h in hooks):
            raise LedgerStorageError("invalid commit hook")
        self._commit_hooks = hooks      # run inside each write transaction, before COMMIT; a failure rolls back
        self._wlock = threading.Lock()
        self._conn: sqlite3.Connection | None = None
        self._closed = False
        try:
            # Stage 10.57 (Stage 3): the first-open lock covers initialization and migration only. It is released
            # when __init__ returns or raises; normal transactions and the Ledger lifetime are not locked.
            with exclusive_open_lock(self._path):
                conn = self._open_writer()         # existing busy-wait loop, unchanged
                self._conn = conn
                try:
                    self._migrate()
                except BaseException:
                    self.close()
                    raise
        except LockUnavailable:
            raise LedgerStorageError("ledger storage lock unavailable") from None

    def _open_writer(self) -> sqlite3.Connection:
        """Open the writer connection and switch to WAL. SQLite does not always apply the busy timeout to
        the journal-mode switch of a brand-new file, so a short bounded wait loop covers simultaneous first opens."""
        deadline = time.monotonic() + self._busy_ms / 1000
        while True:
            conn = None
            try:
                conn = self._connect(readonly=False)
                mode = conn.execute("PRAGMA journal_mode=WAL").fetchone()[0]
                if str(mode).lower() != "wal":
                    conn.close()
                    raise LedgerStorageError("WAL journal mode is not available here")
                conn.execute("PRAGMA synchronous=FULL")
                if conn.execute("PRAGMA quick_check").fetchone()[0] != "ok":
                    conn.close()
                    raise LedgerStorageError("database failed its integrity check")
                return conn
            except sqlite3.Error as exc:
                if conn is not None:
                    conn.close()
                mapped = _map(exc)
                if isinstance(mapped, LedgerBusyError) and time.monotonic() < deadline:
                    time.sleep(0.02)
                    continue
                raise mapped from None

    # ---- connections ---------------------------------------------------------
    def _connect(self, *, readonly: bool) -> sqlite3.Connection:
        conn = sqlite3.connect(self._path, timeout=self._busy_ms / 1000, isolation_level=None,
                               check_same_thread=False)
        conn.execute(f"PRAGMA busy_timeout={int(self._busy_ms)}")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA trusted_schema=OFF")
        conn.execute("PRAGMA recursive_triggers=ON")
        if readonly:
            conn.execute("PRAGMA query_only=ON")
        return conn

    @contextmanager
    def _read(self) -> Iterator[sqlite3.Connection]:
        if self._closed:
            raise LedgerStorageError("ledger is closed")
        conn = None
        try:
            conn = self._connect(readonly=True)
            conn.execute("BEGIN")        # one consistent snapshot for the whole read
            yield conn
        except sqlite3.Error as exc:
            raise _map(exc) from None
        finally:
            if conn is not None:
                conn.close()

    @contextmanager
    def _write(self) -> Iterator[sqlite3.Connection]:
        if self._closed or self._conn is None:
            raise LedgerStorageError("ledger is closed")
        with self._wlock:
            conn = self._conn
            try:
                conn.execute("BEGIN IMMEDIATE")
            except sqlite3.Error as exc:
                raise _map(exc) from None
            try:
                yield conn
                for hook in self._commit_hooks:
                    hook(conn)
                conn.execute("COMMIT")
            except BaseException as exc:
                try:
                    conn.execute("ROLLBACK")
                except sqlite3.Error:
                    pass
                if isinstance(exc, sqlite3.Error):
                    raise _map(exc) from None
                raise

    def close(self) -> None:
        with self._wlock:
            self._closed = True
            if self._conn is not None:
                try:
                    self._conn.close()
                finally:
                    self._conn = None

    def __enter__(self) -> "Ledger":
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    # ---- migrations ----------------------------------------------------------
    def _migrate(self) -> None:
        conn = self._conn
        assert conn is not None
        try:
            conn.execute(M.BOOTSTRAP)
            applied = self._applied(conn)
            pending = M.check_applied(applied, self._migrations)
            for mig in pending:
                with self._write() as c:
                    # another process may have applied it between our read and our lock
                    again = self._applied(c)
                    if mig.version in again:
                        continue
                    for stmt in mig.statements + mig.sqlite_only:
                        c.execute(stmt)
                    c.execute("INSERT INTO schema_migrations (version, name, checksum, applied_at) "
                              "VALUES (?, ?, ?, ?)",
                              (mig.version, mig.name, mig.checksum, self._now()))
                    c.execute(f"PRAGMA user_version={int(mig.version)}")
            M.check_applied(self._applied(conn), self._migrations)
        except sqlite3.Error as exc:
            raise _map(exc) from None

    @staticmethod
    def _applied(conn: sqlite3.Connection) -> dict[int, str]:
        return {v: c for v, c in conn.execute("SELECT version, checksum FROM schema_migrations")}

    def schema_version(self) -> int:
        with self._read() as c:
            row = c.execute("SELECT MAX(version) FROM schema_migrations").fetchone()
            return int(row[0] or 0)

    def _now(self) -> str:
        t = self._clock()
        if not isinstance(t, datetime) or t.tzinfo is None:
            raise RecordRejected("clock must return a timezone-aware datetime")
        return t.astimezone(timezone.utc).isoformat(timespec="microseconds")

    # ---- writes --------------------------------------------------------------
    def append(self, stream: str, record_id: str, kind: str, payload: dict) -> AppendResult:
        """Append one record. Same id and same content again is a no-op replay; same id with different
        content raises IdempotencyConflict."""
        stream, record_id, kind = C.check_stream(stream), C.check_id(record_id, "record id"), C.check_kind(kind)
        if record_id.startswith(RESERVED_PREFIXES):
            raise RecordRejected("record id prefix is reserved for supersession and revocation events")
        payload = C.validate_payload(payload)
        with self._write() as c:
            return self._append_in(c, stream, record_id, kind, payload)

    def _append_in(self, c: sqlite3.Connection, stream: str, record_id: str, kind: str,
                   payload: dict) -> AppendResult:
        digest = C.content_digest(kind, payload)
        existing = self._by_id(c, stream, record_id)
        if existing is not None:
            if existing.content_sha256 != digest:
                raise IdempotencyConflict("record id exists with different content")
            return AppendResult(existing, True)
        head = c.execute("SELECT seq, record_hash FROM ledger_records WHERE stream=? "
                         "ORDER BY seq DESC LIMIT 1", (stream,)).fetchone()
        seq, prev = (head[0] + 1, head[1]) if head else (1, C.GENESIS_HASH)
        recorded_at = self._now()
        raw = C.record_bytes(stream=stream, seq=seq, record_id=record_id, kind=kind,
                             recorded_at=recorded_at, prev_hash=prev, payload=payload)
        rec_hash = C.sha256_hex(raw)   # hash of the exact bytes that are stored
        c.execute(f"INSERT INTO ledger_records ({_COLUMNS}) VALUES (?,?,?,?,?,?,?,?,?)",
                  (stream, seq, record_id, kind, recorded_at, prev, rec_hash, digest, raw))
        return AppendResult(StoredRecord(stream, seq, record_id, kind, recorded_at, prev, rec_hash,
                                         digest, raw), False)

    def supersede(self, stream: str, old_id: str, record_id: str, kind: str, payload: dict, *,
                  event_kind: str, actor: str, reason: str = "") -> tuple[AppendResult, AppendResult]:
        """Atomically append the replacement record and the supersession event. The old record is never
        touched. Returns (replacement, event)."""
        stream, old_id = C.check_stream(stream), C.check_id(old_id, "superseded id")
        record_id, kind, event_kind = C.check_id(record_id, "record id"), C.check_kind(kind), C.check_kind(event_kind)
        if record_id == old_id:
            raise LinkRejected("a record cannot supersede itself")
        payload = C.validate_payload(payload)
        event_payload = C.validate_payload(self._event(old_id, actor, reason, replacement=record_id))
        event_id = f"supersede:{old_id}"
        with self._write() as c:
            old = self._by_id(c, stream, old_id)
            if old is None:
                raise LinkRejected("superseded record does not exist")
            ev = self._by_id(c, stream, event_id)
            if ev is not None:   # replay of the same supersession
                new = self._by_id(c, stream, record_id)
                if (new is None or new.content_sha256 != C.content_digest(kind, payload)
                        or ev.content_sha256 != C.content_digest(event_kind, event_payload)):
                    raise LinkRejected("record already superseded")
                return AppendResult(new, True), AppendResult(ev, True)
            if self._link_exists(c, stream, old.seq, "supersedes") or self._link_exists(c, stream, old.seq, "revokes"):
                raise LinkRejected("record already superseded or revoked")
            new = self._append_in(c, stream, record_id, kind, payload)
            ev = self._append_in(c, stream, event_id, event_kind, event_payload)
            self._insert_link(c, stream, ev.record.seq, "supersedes", old.seq)
            return new, ev

    def revoke(self, stream: str, target_id: str, *, event_kind: str, actor: str, reason: str) -> AppendResult:
        stream, target_id = C.check_stream(stream), C.check_id(target_id, "revoked id")
        event_kind = C.check_kind(event_kind)
        if not isinstance(reason, str) or len(reason.strip()) < 5:
            raise RecordRejected("revocation needs a reason")
        event_payload = C.validate_payload(self._event(target_id, actor, reason))
        event_id = f"revoke:{target_id}"
        with self._write() as c:
            target = self._by_id(c, stream, target_id)
            if target is None:
                raise LinkRejected("revoked record does not exist")
            existing = self._by_id(c, stream, event_id)
            if existing is not None:
                if existing.content_sha256 != C.content_digest(event_kind, event_payload):
                    raise LinkRejected("record already revoked")
                return AppendResult(existing, True)
            ev = self._append_in(c, stream, event_id, event_kind, event_payload)
            self._insert_link(c, stream, ev.record.seq, "revokes", target.seq)
            return ev

    @staticmethod
    def _event(target: str, actor: object, reason: object, replacement: str | None = None) -> dict:
        if not isinstance(actor, str) or not actor.strip():
            raise RecordRejected("an actor is required")
        if not isinstance(reason, str):
            raise RecordRejected("reason must be text")
        out = {"target": target, "actor": actor, "reason": reason}
        if replacement is not None:
            out["replacement"] = replacement
        return out

    def _insert_link(self, c, stream: str, event_seq: int, relation: str, target_seq: int) -> None:
        c.execute("INSERT INTO ledger_links (stream, event_seq, relation, target_seq) VALUES (?,?,?,?)",
                  (stream, event_seq, relation, target_seq))

    @staticmethod
    def _link_exists(c, stream: str, target_seq: int, relation: str) -> bool:
        return c.execute("SELECT 1 FROM ledger_links WHERE stream=? AND target_seq=? AND relation=?",
                         (stream, target_seq, relation)).fetchone() is not None

    @staticmethod
    def _by_id(c, stream: str, record_id: str) -> StoredRecord | None:
        r = c.execute(f"SELECT {_COLUMNS} FROM ledger_records WHERE stream=? AND record_id=?",
                      (stream, record_id)).fetchone()
        return _row(r) if r else None

    # ---- reads ---------------------------------------------------------------
    def get(self, stream: str, record_id: str) -> StoredRecord | None:
        C.check_stream(stream)
        with self._read() as c:
            return self._by_id(c, stream, record_id)

    def records(self, stream: str, *, after_seq: int = 0, limit: int = 1000) -> tuple[StoredRecord, ...]:
        C.check_stream(stream)
        if not isinstance(after_seq, int) or after_seq < 0 or not isinstance(limit, int) or not 1 <= limit <= 10_000:
            raise RecordRejected("invalid range")
        with self._read() as c:
            rows = c.execute(f"SELECT {_COLUMNS} FROM ledger_records WHERE stream=? AND seq>? "
                             "ORDER BY seq LIMIT ?", (stream, after_seq, limit)).fetchall()
            return tuple(_row(r) for r in rows)

    def head(self, stream: str) -> tuple[int, str]:
        C.check_stream(stream)
        with self._read() as c:
            r = c.execute("SELECT seq, record_hash FROM ledger_records WHERE stream=? "
                          "ORDER BY seq DESC LIMIT 1", (stream,)).fetchone()
            return (r[0], r[1]) if r else (0, C.GENESIS_HASH)

    def standing(self, stream: str, record_id: str) -> str:
        """'active', 'superseded' or 'revoked' (revoked wins). Raises KeyError for an unknown id."""
        C.check_stream(stream)
        with self._read() as c:
            rec = self._by_id(c, stream, record_id)
            if rec is None:
                raise KeyError(record_id)
            if self._link_exists(c, stream, rec.seq, "revokes"):
                return "revoked"
            if self._link_exists(c, stream, rec.seq, "supersedes"):
                return "superseded"
            return "active"

    # ---- verification --------------------------------------------------------
    def verify(self, stream: str | None = None) -> VerifyReport:
        streams = [C.check_stream(stream)] if stream else sorted(C.STREAMS)
        problems: list[tuple[int, str]] = []
        total, head_seq, head_hash = 0, 0, C.GENESIS_HASH
        with self._read() as c:
            have = {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='trigger'")}
            for g in GUARDS:
                if g not in have:
                    problems.append((0, f"guard_missing:{g}"))
            for s in streams:
                prev, expect = C.GENESIS_HASH, 1
                for row in c.execute(f"SELECT {_COLUMNS} FROM ledger_records WHERE stream=? ORDER BY seq", (s,)):
                    r = _row(row)
                    total += 1
                    problems += [(r.seq, p) for p in self._check_row(r, expect, prev)]
                    prev, expect = r.record_hash, r.seq + 1
                    head_seq, head_hash = r.seq, r.record_hash
                for ev, rel, tgt, evid, tid in c.execute(
                        "SELECT l.event_seq, l.relation, l.target_seq, e.canonical_bytes, t.record_id "
                        "FROM ledger_links l JOIN ledger_records e ON e.stream=l.stream AND e.seq=l.event_seq "
                        "JOIN ledger_records t ON t.stream=l.stream AND t.seq=l.target_seq WHERE l.stream=?", (s,)):
                    try:
                        ok = json.loads(bytes(evid))["payload"]["target"] == tid
                    except (ValueError, KeyError, TypeError):
                        ok = False
                    if not ok:
                        problems.append((ev, "link_mismatch"))
            if len(streams) > 1:
                head_seq, head_hash = 0, C.GENESIS_HASH   # a combined head is not meaningful
        return VerifyReport(not problems, total, head_seq, head_hash, tuple(problems))

    @staticmethod
    def _check_row(r: StoredRecord, expect_seq: int, prev: str) -> list[str]:
        out = []
        if r.seq != expect_seq:
            out.append("sequence_gap")
        if r.prev_hash != prev:
            out.append("prev_hash_mismatch")
        if C.sha256_hex(r.canonical_bytes) != r.record_hash:
            out.append("record_hash_mismatch")
        try:
            body = json.loads(r.canonical_bytes)
            if C.dumps(body) != r.canonical_bytes:
                out.append("not_canonical")
            if (body["stream"], body["seq"], body["record_id"], body["kind"], body["recorded_at"],
                    body["prev_hash"]) != (r.stream, r.seq, r.record_id, r.kind, r.recorded_at, r.prev_hash):
                out.append("columns_differ_from_bytes")
            if C.content_digest(body["kind"], body["payload"]) != r.content_sha256:
                out.append("content_digest_mismatch")
        except (ValueError, KeyError, TypeError):
            out.append("unreadable_bytes")
        return out
