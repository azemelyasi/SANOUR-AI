"""Persistence errors (Stage 10.54-A).

These are storage-layer exceptions. They are not `ErrorCode` members and never reach the public API.
Messages are fixed text: they never include payload content, paths with secrets, or SQL text.
"""

from __future__ import annotations


class LedgerError(Exception):
    """Base class for every persistence error."""


class LedgerStorageError(LedgerError):
    """SQLite failed, the file is corrupt, or the environment cannot give the required durability."""


class LedgerBusyError(LedgerError):
    """The writer lock could not be obtained within the busy timeout. Nothing was written."""


class RecordRejected(LedgerError, ValueError):
    """The record failed validation. Nothing was written."""


class IdempotencyConflict(LedgerError):
    """The record id already exists with different content. Nothing was written."""


class LinkRejected(LedgerError):
    """Supersession or revocation refused (missing target, already superseded or revoked)."""


class SchemaError(LedgerError):
    """Schema or migration problem (database newer than code, checksum drift, bad migration list)."""


class RecoveryError(LedgerError):
    """A checkpoint or anchor operation was refused because it would accept stale or inconsistent state."""


class AnchorError(LedgerError):
    """The external anchor log is unreadable, tampered with, or an append would move it backwards."""
