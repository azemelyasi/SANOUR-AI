"""Chain verification, checkpoints, external anchors and crash-recovery inspection (Stage 10.54-B).

Scope: detect and report. Nothing here rewrites, repairs, deletes or re-inserts a historical record, and
nothing here is a backup or a restore (stage 10.54-C). Reports carry stream names, sequence numbers and fixed
codes only: never payloads, record ids, paths or SQL text.

Checkpoint = an append-only record (own hash chain per stream) of: stream, record sequence, head hash, schema
version, creation time. It is written inside the same kind of IMMEDIATE transaction as ledger writes, from the
head read inside that transaction, so it cannot be stale. A checkpoint that would move backwards is refused.
Anchor = the same facts exported to a file OUTSIDE the database (`AnchorLog`, a hash-chained JSON-lines file).
A checkpoint inside the database cannot reveal a rewrite of the whole file, because the attacker rewrites the
checkpoints too; the anchor can, provided it is kept somewhere the attacker cannot also rewrite.
"""

from __future__ import annotations

import json
import os
import sqlite3
import threading
from dataclasses import dataclass, field

from sanour_ai.persistence import canonical as C
from sanour_ai.persistence import migrations as M
from sanour_ai.persistence.errors import AnchorError, LedgerStorageError, RecoveryError
from sanour_ai.persistence.ledger import Ledger, _map

CP_GUARDS = tuple(f"ledger_checkpoints_no_{op}" for op in ("update", "delete", "replace"))
_CP_COLS = "stream, cp_seq, record_seq, head_hash, schema_version, created_at, prev_cp_hash, cp_hash, canonical_bytes"
ANCHOR_VERSION = 1


# ---------------------------------------------------------------- checkpoints
@dataclass(frozen=True)
class Checkpoint:
    stream: str
    cp_seq: int
    record_seq: int
    head_hash: str
    schema_version: int
    created_at: str
    prev_cp_hash: str
    cp_hash: str
    canonical_bytes: bytes


def _cp(r: tuple) -> Checkpoint:
    raw = r[8] if isinstance(r[8], bytes) else str(r[8]).encode("utf-8", "replace")
    return Checkpoint(r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], raw)


def _cp_bytes(stream, cp_seq, record_seq, head_hash, schema_version, created_at, prev) -> bytes:
    return C.dumps({"v": 1, "stream": stream, "cp_seq": cp_seq, "record_seq": record_seq, "head_hash": head_hash,
                    "schema_version": schema_version, "created_at": created_at, "prev_cp_hash": prev})


def create_checkpoint(ledger: Ledger, stream: str) -> tuple[Checkpoint, bool]:
    """Record the current head of `stream`. Returns (checkpoint, created). Same head again is a no-op."""
    stream = C.check_stream(stream)
    with ledger._write() as c:
        head = c.execute("SELECT seq, record_hash, canonical_bytes FROM ledger_records WHERE stream=? "
                         "ORDER BY seq DESC LIMIT 1", (stream,)).fetchone()
        seq, hsh = (head[0], head[1]) if head else (0, C.GENESIS_HASH)
        if head and C.sha256_hex(head[2] if isinstance(head[2], bytes) else b"") != hsh:
            raise RecoveryError("head record does not match its hash: checkpoint refused")
        last = c.execute(f"SELECT {_CP_COLS} FROM ledger_checkpoints WHERE stream=? ORDER BY cp_seq DESC LIMIT 1",
                         (stream,)).fetchone()
        prev, cp_seq = C.GENESIS_HASH, 1
        if last:
            last = _cp(last)
            if seq < last.record_seq:
                raise RecoveryError("ledger is behind its last checkpoint: stale state refused")
            at = c.execute("SELECT record_hash FROM ledger_records WHERE stream=? AND seq=?",
                           (stream, last.record_seq)).fetchone()
            if last.record_seq and (at is None or at[0] != last.head_hash):
                raise RecoveryError("ledger disagrees with its last checkpoint: checkpoint refused")
            if seq == last.record_seq and hsh == last.head_hash:
                return last, False
            prev, cp_seq = last.cp_hash, last.cp_seq + 1
        version = int(c.execute("SELECT MAX(version) FROM schema_migrations").fetchone()[0])
        created = ledger._now()
        raw = _cp_bytes(stream, cp_seq, seq, hsh, version, created, prev)
        cp = Checkpoint(stream, cp_seq, seq, hsh, version, created, prev, C.sha256_hex(raw), raw)
        c.execute(f"INSERT INTO ledger_checkpoints ({_CP_COLS}) VALUES (?,?,?,?,?,?,?,?,?)",
                  (cp.stream, cp.cp_seq, cp.record_seq, cp.head_hash, cp.schema_version, cp.created_at,
                   cp.prev_cp_hash, cp.cp_hash, cp.canonical_bytes))
        return cp, True


def latest_checkpoint(ledger: Ledger, stream: str) -> Checkpoint | None:
    stream = C.check_stream(stream)
    with ledger._read() as c:
        r = c.execute(f"SELECT {_CP_COLS} FROM ledger_checkpoints WHERE stream=? ORDER BY cp_seq DESC LIMIT 1",
                      (stream,)).fetchone()
        return _cp(r) if r else None


def checkpoints(ledger: Ledger, stream: str) -> tuple[Checkpoint, ...]:
    stream = C.check_stream(stream)
    with ledger._read() as c:
        return tuple(_cp(r) for r in c.execute(
            f"SELECT {_CP_COLS} FROM ledger_checkpoints WHERE stream=? ORDER BY cp_seq", (stream,)))


# ---------------------------------------------------------------- anchors (outside the database)
@dataclass(frozen=True)
class Anchor:
    stream: str
    seq: int
    head_hash: str
    schema_version: int
    created_at: str

    def as_dict(self) -> dict:
        return {"v": ANCHOR_VERSION, "stream": self.stream, "seq": self.seq, "head_hash": self.head_hash,
                "schema_version": self.schema_version, "created_at": self.created_at}


def export_anchor(ledger: Ledger, stream: str) -> Anchor:
    """Take (or reuse) a checkpoint and return its facts as an anchor to be stored OUTSIDE the database."""
    cp, _ = create_checkpoint(ledger, stream)
    return Anchor(cp.stream, cp.record_seq, cp.head_hash, cp.schema_version, cp.created_at)


def _line(anchor: dict, prev: str) -> str:
    body = {"anchor": anchor, "prev": prev}
    return C.dumps({**body, "line_hash": C.sha256_hex(C.dumps(body))}).decode("ascii")


class AnchorLog:
    """Append-only JSON-lines file; each line commits to the one before. Single writer assumed (documented)."""

    def __init__(self, path: str) -> None:
        if not isinstance(path, str) or not path or "\x00" in path or len(path) > 1024:
            raise AnchorError("invalid anchor path")
        self._path = path
        self._lock = threading.Lock()

    def read(self) -> tuple[list[Anchor], list[str]]:
        """Return (anchors, issues). Issues are fixed codes. An unfinished last line is reported, not trusted."""
        issues: list[str] = []
        anchors: list[Anchor] = []
        try:
            with open(self._path, "rb") as fh:
                data = fh.read()
        except FileNotFoundError:
            return [], []
        except OSError:
            raise AnchorError("anchor log unreadable") from None
        lines = data.split(b"\n")
        tail = lines.pop()               # text after the last newline: empty when the file ended cleanly
        if tail:
            issues.append("anchor_partial_tail")
        prev, last_seq = C.GENESIS_HASH, {}
        for n, raw in enumerate(lines, 1):
            try:
                obj = json.loads(raw)
                body = {"anchor": obj["anchor"], "prev": obj["prev"]}
                a = obj["anchor"]
                ok = (obj["line_hash"] == C.sha256_hex(C.dumps(body)) and obj["prev"] == prev
                      and a["v"] == ANCHOR_VERSION and raw == C.dumps(obj))
                an = Anchor(a["stream"], a["seq"], a["head_hash"], a["schema_version"], a["created_at"])
                if not ok or an.stream not in C.STREAMS or not isinstance(an.seq, int) or an.seq < 0:
                    raise ValueError
            except (ValueError, KeyError, TypeError):
                issues.append(f"anchor_line_{n}_tampered")
                return anchors, issues   # nothing after a broken link can be trusted
            if an.seq < last_seq.get(an.stream, 0):
                issues.append(f"anchor_line_{n}_regressed")
            last_seq[an.stream] = max(an.seq, last_seq.get(an.stream, 0))
            prev = obj["line_hash"]
            anchors.append(an)
        return anchors, issues

    def _drop_torn_tail(self) -> None:
        """Cut an unfinished last line (a crash mid-append). Only text after the last newline is removed."""
        with open(self._path, "rb") as fh:
            data = fh.read()
        cut = data.rfind(b"\n") + 1
        fd = os.open(self._path, os.O_WRONLY)
        try:
            os.ftruncate(fd, cut)
            os.fsync(fd)
        finally:
            os.close(fd)

    def append(self, anchor: Anchor) -> bool:
        """Append unless it would move backwards. Returns False for an identical repeat."""
        with self._lock:
            anchors, issues = self.read()
            if any(not i.startswith("anchor_partial_tail") for i in issues):
                raise AnchorError("anchor log is damaged: append refused")
            same = [a for a in anchors if a.stream == anchor.stream]
            if same:
                top = max(same, key=lambda a: a.seq)
                if anchor.seq < top.seq:
                    raise AnchorError("anchor would move backwards: refused")
                if anchor.seq == top.seq and anchor.head_hash != top.head_hash:
                    raise AnchorError("anchor conflicts with the recorded head: refused")
                if anchor == top:
                    if any(i.startswith("anchor_partial_tail") for i in issues):
                        self._drop_torn_tail()          # repair even when nothing new is appended (C3 fix)
                    return False
            prev = C.GENESIS_HASH
            if anchors or issues:
                with open(self._path, "rb") as fh:
                    good = [ln for ln in fh.read().split(b"\n")[:len(anchors)]]
                prev = json.loads(good[-1])["line_hash"] if good else C.GENESIS_HASH
            text = (_line(anchor.as_dict(), prev) + "\n").encode("ascii")
            fd = os.open(self._path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
            try:
                if issues:   # drop an unfinished tail so the new line starts cleanly
                    os.ftruncate(fd, sum(len(ln) + 1 for ln in good))
                os.write(fd, text)
                os.fsync(fd)
            finally:
                os.close(fd)
            return True


# ---------------------------------------------------------------- integrity report
@dataclass(frozen=True)
class Finding:
    stream: str          # stream name, or "-" when not about one stream
    seq: int             # record or checkpoint sequence; 0 when not about one record
    code: str            # fixed vocabulary, never content


@dataclass(frozen=True)
class IntegrityReport:
    ok: bool
    findings: tuple[Finding, ...]
    heads: dict = field(default_factory=dict)   # stream -> (head_seq, head_hash)

    def codes(self) -> set[str]:
        return {f.code for f in self.findings}


def verify_integrity(ledger: Ledger, anchors: AnchorLog | None = None) -> IntegrityReport:
    """Full read-only check: SQLite structure, both chains, links, checkpoints, and (optionally) the external anchors."""
    found: list[Finding] = []
    heads: dict = {}
    for seq, code in ledger.verify().problems:
        if seq == 0:                                  # structural: a guard trigger is gone
            found.append(Finding("-", 0, code))
    for s in sorted(C.STREAMS):
        for seq, code in ledger.verify(s).problems:
            if seq:
                found.append(Finding(s, seq, code))
    with ledger._read() as c:
        for (res,) in c.execute("PRAGMA integrity_check"):
            if res != "ok":
                found.append(Finding("-", 0, "sqlite_integrity_failed"))
                break
        if c.execute("PRAGMA foreign_key_check").fetchone():
            found.append(Finding("-", 0, "foreign_key_violation"))
        have = {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='trigger'")}
        found += [Finding("-", 0, f"guard_missing:{g}") for g in CP_GUARDS if g not in have]
        for s in sorted(C.STREAMS):
            h = c.execute("SELECT seq, record_hash FROM ledger_records WHERE stream=? ORDER BY seq DESC LIMIT 1",
                          (s,)).fetchone()
            head_seq, head_hash = (h[0], h[1]) if h else (0, C.GENESIS_HASH)
            heads[s] = (head_seq, head_hash)
            found += _check_checkpoints(c, s, head_seq)
            found += _check_groups(c, s)
        latest_version = int(c.execute("SELECT MAX(version) FROM schema_migrations").fetchone()[0] or 0)
        found += [f for f in _check_version(c, latest_version)]
        if anchors is not None:
            found += _check_anchors(c, anchors, heads)
    seen, uniq = set(), []
    for f in found:
        if f not in seen:
            seen.add(f)
            uniq.append(f)
    return IntegrityReport(not uniq, tuple(uniq), heads)


def _check_version(c, latest: int) -> list[Finding]:
    bad = c.execute("SELECT 1 FROM ledger_checkpoints WHERE schema_version > ? LIMIT 1", (latest,)).fetchone()
    return [Finding("-", 0, "checkpoint_schema_version_ahead")] if bad else []


def _check_checkpoints(c, s: str, head_seq: int) -> list[Finding]:
    out: list[Finding] = []
    prev_hash, expect, last_rseq = C.GENESIS_HASH, 1, 0
    for row in c.execute(f"SELECT {_CP_COLS} FROM ledger_checkpoints WHERE stream=? ORDER BY cp_seq", (s,)).fetchall():
        cp = _cp(row)
        if cp.cp_seq != expect:
            out.append(Finding(s, cp.cp_seq, "checkpoint_sequence_gap"))
        if cp.prev_cp_hash != prev_hash:
            out.append(Finding(s, cp.cp_seq, "checkpoint_prev_mismatch"))
        if C.sha256_hex(cp.canonical_bytes) != cp.cp_hash:
            out.append(Finding(s, cp.cp_seq, "checkpoint_hash_mismatch"))
        try:
            b = json.loads(cp.canonical_bytes)
            if C.dumps(b) != cp.canonical_bytes:
                out.append(Finding(s, cp.cp_seq, "checkpoint_not_canonical"))
            if (b["stream"], b["cp_seq"], b["record_seq"], b["head_hash"], b["schema_version"], b["created_at"],
                    b["prev_cp_hash"]) != (cp.stream, cp.cp_seq, cp.record_seq, cp.head_hash, cp.schema_version,
                                           cp.created_at, cp.prev_cp_hash):
                out.append(Finding(s, cp.cp_seq, "checkpoint_columns_differ_from_bytes"))
        except (ValueError, KeyError, TypeError):
            out.append(Finding(s, cp.cp_seq, "checkpoint_unreadable"))
        if cp.record_seq < last_rseq:
            out.append(Finding(s, cp.cp_seq, "checkpoint_regressed"))
        last_rseq = max(last_rseq, cp.record_seq)
        if cp.record_seq > head_seq:
            out.append(Finding(s, cp.cp_seq, "ledger_behind_checkpoint"))   # truncation below a checkpoint
        elif cp.record_seq:
            at = c.execute("SELECT record_hash FROM ledger_records WHERE stream=? AND seq=?",
                           (s, cp.record_seq)).fetchone()
            if at is None or at[0] != cp.head_hash:
                out.append(Finding(s, cp.cp_seq, "checkpoint_record_mismatch"))
        prev_hash, expect = cp.cp_hash, cp.cp_seq + 1
    return out


def _check_groups(c, s: str) -> list[Finding]:
    """Supersession / revocation events must be complete: event + link (+ replacement for a supersession)."""
    out: list[Finding] = []
    linked = {r[0]: (r[1], r[2]) for r in c.execute(
        "SELECT event_seq, relation, target_seq FROM ledger_links WHERE stream=?", (s,))}
    for seq, rid, raw in c.execute("SELECT seq, record_id, canonical_bytes FROM ledger_records WHERE stream=? "
                                   "AND (record_id LIKE 'supersede:%' OR record_id LIKE 'revoke:%') ORDER BY seq", (s,)).fetchall():
        rel = linked.get(seq)
        want = "supersedes" if rid.startswith("supersede:") else "revokes"
        if rel is None or rel[0] != want:
            out.append(Finding(s, seq, "event_without_link"))
            continue
        if want == "supersedes":
            try:
                repl = json.loads(bytes(raw))["payload"]["replacement"]
            except (ValueError, KeyError, TypeError):
                out.append(Finding(s, seq, "event_unreadable"))
                continue
            r = c.execute("SELECT seq FROM ledger_records WHERE stream=? AND record_id=?", (s, repl)).fetchone()
            if r is None or r[0] >= seq:
                out.append(Finding(s, seq, "supersession_replacement_missing"))
    return out


def _check_anchors(c, log: AnchorLog, heads: dict) -> list[Finding]:
    out: list[Finding] = []
    try:
        anchors, issues = log.read()
    except AnchorError:
        return [Finding("-", 0, "anchor_log_unreadable")]
    for i in issues:
        out.append(Finding("-", 0, "anchor_partial_tail" if i == "anchor_partial_tail" else
                           "anchor_log_regressed" if i.endswith("regressed") else "anchor_log_tampered"))
    for a in anchors:
        head_seq = heads.get(a.stream, (0, ""))[0]
        if a.seq > head_seq:
            out.append(Finding(a.stream, a.seq, "ledger_behind_anchor"))        # truncation
        elif a.seq:
            at = c.execute("SELECT record_hash FROM ledger_records WHERE stream=? AND seq=?", (a.stream, a.seq)).fetchone()
            if at is None or at[0] != a.head_hash:
                out.append(Finding(a.stream, a.seq, "anchor_mismatch"))         # rewritten or forked history
    return out


# ---------------------------------------------------------------- crash recovery
@dataclass(frozen=True)
class RecoveryReport:
    opened: bool
    schema_version: int
    wal_pages_checkpointed: int
    integrity: IntegrityReport | None

    @property
    def clean(self) -> bool:
        return self.opened and self.integrity is not None and self.integrity.ok


def recover(path: str, anchors: AnchorLog | None = None, *, busy_timeout_ms: int = 5000) -> RecoveryReport:
    """Open after an abrupt stop and report. SQLite itself discards uncommitted transactions and replays the
    committed WAL on open; this adds a passive WAL checkpoint and a full integrity report. It never writes,
    repairs or removes a ledger record: if the report is not clean, nothing was changed and the caller decides."""
    led = Ledger(path, busy_timeout_ms=busy_timeout_ms)
    try:
        moved = 0
        try:
            with led._write() as _:
                pass          # takes the write lock once: proves no dead writer still holds it
            r = led._conn.execute("PRAGMA wal_checkpoint(PASSIVE)").fetchone()
            moved = int(r[2]) if r and r[2] is not None and r[2] >= 0 else 0
        except sqlite3.Error as exc:
            raise _map(exc) from None
        return RecoveryReport(True, led.schema_version(), moved, verify_integrity(led, anchors))
    finally:
        led.close()
