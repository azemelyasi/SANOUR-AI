"""Versioned schema migrations (Stage 10.54-A).

Rules
- Append only: a released migration is never edited. Its checksum is stored when applied and compared on
  every open; a mismatch refuses the database.
- Each migration runs in one transaction, so it applies completely or not at all.
- A database that is newer than this code is refused (no silent downgrade).
- Plain portable SQL (TEXT, INTEGER, BLOB, CHECK, UNIQUE, FOREIGN KEY, `?` parameters) is kept apart from
  the SQLite-only parts (triggers), which are listed in `sqlite_only` so a PostgreSQL port knows what to
  translate: see docs/PERSISTENT_EVIDENCE_LEDGER.md.
"""

from __future__ import annotations

from dataclasses import dataclass

from sanour_ai.persistence.canonical import sha256_hex
from sanour_ai.persistence.errors import SchemaError

ZERO = "0" * 64


@dataclass(frozen=True)
class Migration:
    version: int
    name: str
    statements: tuple[str, ...]
    sqlite_only: tuple[str, ...] = ()

    @property
    def checksum(self) -> str:
        return sha256_hex("\n--\n".join(self.statements + self.sqlite_only).encode("utf-8"))


def _guards(table: str, clash: str) -> tuple[str, str, str]:
    """Update and delete refusals, plus a replace refusal: `INSERT OR REPLACE` deletes the clashing row
    without firing delete triggers, so a BEFORE INSERT trigger refuses any insert that would clash."""
    return (
        f"CREATE TRIGGER {table}_no_update BEFORE UPDATE ON {table} "
        f"BEGIN SELECT RAISE(ABORT, 'append-only: update refused'); END",
        f"CREATE TRIGGER {table}_no_delete BEFORE DELETE ON {table} "
        f"BEGIN SELECT RAISE(ABORT, 'append-only: delete refused'); END",
        f"CREATE TRIGGER {table}_no_replace BEFORE INSERT ON {table} WHEN EXISTS "
        f"(SELECT 1 FROM {table} WHERE {clash}) "
        f"BEGIN SELECT RAISE(ABORT, 'append-only: replace refused'); END",
    )


V1 = Migration(
    1, "ledger_records",
    (
        f"""CREATE TABLE ledger_records (
    stream TEXT NOT NULL CHECK (length(stream) BETWEEN 1 AND 32),
    seq INTEGER NOT NULL CHECK (seq >= 1),
    record_id TEXT NOT NULL CHECK (length(record_id) BETWEEN 1 AND 128),
    kind TEXT NOT NULL CHECK (length(kind) BETWEEN 1 AND 64),
    recorded_at TEXT NOT NULL,
    prev_hash TEXT NOT NULL CHECK (length(prev_hash) = 64),
    record_hash TEXT NOT NULL CHECK (length(record_hash) = 64),
    content_sha256 TEXT NOT NULL CHECK (length(content_sha256) = 64),
    canonical_bytes BLOB NOT NULL,
    PRIMARY KEY (stream, seq),
    UNIQUE (stream, record_id),
    UNIQUE (record_hash),
    CHECK ((seq = 1) = (prev_hash = '{ZERO}'))
)""",
    ),
    _guards("ledger_records", "(stream = NEW.stream AND (seq = NEW.seq OR record_id = NEW.record_id)) "
            "OR record_hash = NEW.record_hash")
    + _guards("schema_migrations", "version = NEW.version"),
)

V2 = Migration(
    2, "ledger_links",
    (
        """CREATE TABLE ledger_links (
    stream TEXT NOT NULL,
    event_seq INTEGER NOT NULL,
    relation TEXT NOT NULL CHECK (relation IN ('supersedes', 'revokes')),
    target_seq INTEGER NOT NULL,
    PRIMARY KEY (stream, event_seq),
    UNIQUE (stream, target_seq, relation),
    CHECK (target_seq < event_seq),
    FOREIGN KEY (stream, event_seq) REFERENCES ledger_records (stream, seq),
    FOREIGN KEY (stream, target_seq) REFERENCES ledger_records (stream, seq)
)""",
        "CREATE INDEX ledger_links_target ON ledger_links (stream, target_seq)",
        "CREATE INDEX ledger_records_kind ON ledger_records (stream, kind, seq)",
    ),
    _guards("ledger_links", "(stream = NEW.stream AND event_seq = NEW.event_seq) "
            "OR (stream = NEW.stream AND target_seq = NEW.target_seq AND relation = NEW.relation)"),
)

V3 = Migration(
    3, "ledger_checkpoints",
    (
        f"""CREATE TABLE ledger_checkpoints (
    stream TEXT NOT NULL CHECK (length(stream) BETWEEN 1 AND 32),
    cp_seq INTEGER NOT NULL CHECK (cp_seq >= 1),
    record_seq INTEGER NOT NULL CHECK (record_seq >= 0),
    head_hash TEXT NOT NULL CHECK (length(head_hash) = 64),
    schema_version INTEGER NOT NULL CHECK (schema_version >= 1),
    created_at TEXT NOT NULL,
    prev_cp_hash TEXT NOT NULL CHECK (length(prev_cp_hash) = 64),
    cp_hash TEXT NOT NULL CHECK (length(cp_hash) = 64),
    canonical_bytes BLOB NOT NULL,
    PRIMARY KEY (stream, cp_seq),
    UNIQUE (cp_hash),
    CHECK ((cp_seq = 1) = (prev_cp_hash = '{ZERO}')),
    CHECK ((record_seq = 0) = (head_hash = '{ZERO}'))
)""",
    ),
    _guards("ledger_checkpoints", "(stream = NEW.stream AND cp_seq = NEW.cp_seq) OR cp_hash = NEW.cp_hash"),
)

MIGRATIONS: tuple[Migration, ...] = (V1, V2, V3)
LATEST_VERSION = MIGRATIONS[-1].version

BOOTSTRAP = """CREATE TABLE IF NOT EXISTS schema_migrations (
    version INTEGER PRIMARY KEY CHECK (version >= 1),
    name TEXT NOT NULL,
    checksum TEXT NOT NULL CHECK (length(checksum) = 64),
    applied_at TEXT NOT NULL
)"""


def validate_migration_list(migrations: tuple[Migration, ...]) -> None:
    if not migrations or [m.version for m in migrations] != list(range(1, len(migrations) + 1)):
        raise SchemaError("migration versions must be 1..N with no gaps or duplicates")


def check_applied(applied: dict[int, str], migrations: tuple[Migration, ...]) -> list[Migration]:
    """Return the migrations still to apply, or raise if the database does not match this code."""
    known = {m.version: m for m in migrations}
    for version, checksum in applied.items():
        if version not in known:
            raise SchemaError("database schema is newer than this code")
        if known[version].checksum != checksum:
            raise SchemaError("applied migration checksum differs from the code")
    done = sorted(applied)
    if done != list(range(1, len(done) + 1)):
        raise SchemaError("applied migrations are not a contiguous prefix")
    return [m for m in migrations if m.version not in applied]
