"""Canonical record bytes (Stage 10.54-A).

One record = one byte string. The record hash is SHA-256 over exactly those bytes, and those same bytes
are what is stored. Verification re-hashes the stored bytes; it never trusts a stored hash column.

Canonical form: UTF-8 JSON, sorted keys, no whitespace, ASCII-escaped. Payloads may contain only
dict (str keys), list, str, int, bool and None. Floats are refused on purpose: their text form differs
between platforms and databases, which would break hashes after a migration.
"""

from __future__ import annotations

import hashlib
import json
import re

from sanour_ai.persistence.errors import RecordRejected
from sanour_ai.security.redaction import redact

GENESIS_HASH = "0" * 64
RECORD_FORMAT_VERSION = 1
MAX_PAYLOAD_BYTES = 1024 * 1024
MAX_DEPTH = 16
MAX_STRING = 64 * 1024

STREAMS = frozenset({"evidence", "governance"})
_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.:\-]{0,127}\Z")
_KIND = re.compile(r"[A-Z][A-Z0-9_]{0,63}\Z")
_SECRET_KEY = re.compile(
    r"(?i)(api[_-]?key|secret|token|password|passwd|authorization|private[_-]?key|access[_-]?key)\Z")
_PRIVATE_KEY_BLOCK = re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def dumps(obj: object) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True,
                      allow_nan=False).encode("ascii")


def check_id(value: object, what: str) -> str:
    if not isinstance(value, str) or not _ID.match(value):
        raise RecordRejected(f"{what} is invalid")
    return value


def check_kind(value: object) -> str:
    if not isinstance(value, str) or not _KIND.match(value):
        raise RecordRejected("kind is invalid")
    return value


def check_stream(value: object) -> str:
    if not isinstance(value, str) or value not in STREAMS:
        raise RecordRejected("stream is unknown")
    return value


def _screen_text(text: str) -> None:
    if redact(text) != text or _PRIVATE_KEY_BLOCK.search(text):
        raise RecordRejected("secret-like content refused")


def _walk(value: object, depth: int) -> None:
    if depth > MAX_DEPTH:
        raise RecordRejected("payload too deeply nested")
    if value is None or isinstance(value, bool):
        return
    if isinstance(value, int):
        if not -(2**63) <= value < 2**63:
            raise RecordRejected("integer out of range")
        return
    if isinstance(value, str):
        if len(value) > MAX_STRING:
            raise RecordRejected("string too long")
        _screen_text(value)
        return
    if isinstance(value, list):
        for item in value:
            _walk(item, depth + 1)
        return
    if isinstance(value, dict):
        for key, item in value.items():
            if not isinstance(key, str):
                raise RecordRejected("payload keys must be strings")
            _screen_text(key)
            if _SECRET_KEY.match(key) and item not in (None, "", False):
                raise RecordRejected("secret-like content refused")
            _walk(item, depth + 1)
        return
    raise RecordRejected("payload contains an unsupported type")  # float, bytes, tuple, set, objects


def validate_payload(payload: object) -> dict:
    if not isinstance(payload, dict):
        raise RecordRejected("payload must be a dict")
    _walk(payload, 0)
    if len(dumps(payload)) > MAX_PAYLOAD_BYTES:
        raise RecordRejected("payload too large")
    return payload


def content_digest(kind: str, payload: dict) -> str:
    """Identity of the content alone (no seq, no time, no chain). Used for idempotent replay."""
    return sha256_hex(dumps({"kind": kind, "payload": payload}))


def record_bytes(*, stream: str, seq: int, record_id: str, kind: str, recorded_at: str,
                 prev_hash: str, payload: dict) -> bytes:
    return dumps({
        "v": RECORD_FORMAT_VERSION, "stream": stream, "seq": seq, "record_id": record_id,
        "kind": kind, "recorded_at": recorded_at, "prev_hash": prev_hash, "payload": payload,
    })
