"""Append-only, hash-chained event log (Stage 10.53). Shared by evidence, governance and lifecycle.

There is no delete, update or truncate method. Each entry commits to the previous entry's hash, so
`verify()` detects edits, removals and reordering made after the fact. Limit: a process that can rewrite
this object's memory can also rewrite the chain; the chain detects accidents and naive tampering, and the
head hash should be exported and kept elsewhere for stronger guarantees (see docs).
"""

from __future__ import annotations

import hashlib
import json
import threading
from dataclasses import dataclass

GENESIS = "0" * 64


def canonical(obj: object) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class Entry:
    seq: int
    kind: str
    payload: str      # canonical JSON
    prev_hash: str
    hash: str


def _entry_hash(seq: int, kind: str, payload: str, prev: str) -> str:
    return sha256_text(f"{seq}|{kind}|{payload}|{prev}")


class AppendOnlyLog:
    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._entries: list[Entry] = []

    def append(self, kind: str, payload: dict) -> Entry:
        body = canonical(payload)
        with self._lock:
            prev = self._entries[-1].hash if self._entries else GENESIS
            seq = len(self._entries) + 1
            e = Entry(seq, kind, body, prev, _entry_hash(seq, kind, body, prev))
            self._entries.append(e)
            return e

    def entries(self) -> tuple[Entry, ...]:
        with self._lock:
            return tuple(self._entries)

    @property
    def head(self) -> str:
        with self._lock:
            return self._entries[-1].hash if self._entries else GENESIS

    def verify(self) -> bool:
        with self._lock:
            prev = GENESIS
            for i, e in enumerate(self._entries, start=1):
                if e.seq != i or e.prev_hash != prev or e.hash != _entry_hash(e.seq, e.kind, e.payload, prev):
                    return False
                prev = e.hash
            return True
