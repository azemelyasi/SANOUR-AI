"""Pure status assessment for backup/restore readiness (Stage 10.54-C3).

No I/O and no imports from sanour_ai: readiness only evaluates a plain snapshot that the composition layer collects.
It never owns, creates, restores or deletes backups. Output carries fixed reason codes only.
"""

from __future__ import annotations

from typing import Mapping

REASONS = ("integrity_not_verified", "integrity_failed", "sidecar_present", "temporary_present", "no_verified_backup")


def assess_backup_status(snapshot: Mapping) -> dict:
    reasons: list[str] = []
    if snapshot.get("integrity_verified") is not True:
        reasons.append("integrity_not_verified")
    elif snapshot.get("integrity_ok") is not True:
        reasons.append("integrity_failed")
    if snapshot.get("sidecars", 0):
        reasons.append("sidecar_present")
    if snapshot.get("temporaries", 0):
        reasons.append("temporary_present")
    if snapshot.get("verified_backup") is not True:
        reasons.append("no_verified_backup")
    return {"status": "ready" if not reasons else "blocked", "reasons": reasons}
