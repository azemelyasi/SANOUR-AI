"""Stage 10.52: Provider Operational Readiness Framework.

Pure, offline, deterministic. No network, no keys, no retry, no fallback, no auto-select.
"""

from sanour_ai.readiness.engine import assess, assess_all
from sanour_ai.readiness.model import (
    Criterion,
    Evidence,
    EvidenceKind,
    NotApplicable,
    ProviderAssessment,
    Status,
)
from sanour_ai.readiness.registry import ReadinessRegistry, default_registry
from sanour_ai.readiness.report import render_json, render_markdown

__all__ = [
    "Criterion", "Evidence", "EvidenceKind", "NotApplicable", "ProviderAssessment", "Status",
    "ReadinessRegistry", "default_registry", "assess", "assess_all", "render_json", "render_markdown",
]

from sanour_ai.readiness.chain import AppendOnlyLog  # noqa: E402
from sanour_ai.readiness.evidence_store import EvidenceRejected, EvidenceStore, Standing  # noqa: E402
from sanour_ai.readiness.governance import GovernedReadiness, render_report_markdown  # noqa: E402
from sanour_ai.readiness.lifecycle import LifecycleError, LifecycleState, ProviderLifecycle, Role  # noqa: E402
