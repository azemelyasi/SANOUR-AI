"""Provider operational lifecycle (Stage 10.53, part 3).

Deliberately independent of readiness: this module never imports it and never reads a readiness status.
OPERATIONAL is an operations state, not a production-ready claim. Every attempt, allowed or denied, is
logged. Anything not explicitly allowed is refused and the state stays where it was (fail closed).
"""

from __future__ import annotations

import json
import threading
from collections.abc import Mapping
from enum import Enum

from sanour_ai.readiness.chain import AppendOnlyLog
from sanour_ai.security.redaction import redact


class LifecycleState(str, Enum):
    REGISTERED = "REGISTERED"
    CONFIGURED = "CONFIGURED"
    VALIDATED = "VALIDATED"
    OPERATIONAL = "OPERATIONAL"
    SUSPENDED = "SUSPENDED"
    RETIRED = "RETIRED"


class Role(str, Enum):
    OPERATOR = "operator"
    REVIEWER = "reviewer"
    ADMIN = "admin"


S = LifecycleState
ALLOWED: Mapping[LifecycleState, frozenset[LifecycleState]] = {
    S.REGISTERED: frozenset({S.CONFIGURED, S.RETIRED}),
    S.CONFIGURED: frozenset({S.VALIDATED, S.RETIRED}),
    S.VALIDATED: frozenset({S.OPERATIONAL, S.CONFIGURED, S.RETIRED}),
    S.OPERATIONAL: frozenset({S.SUSPENDED, S.RETIRED}),
    S.SUSPENDED: frozenset({S.VALIDATED, S.RETIRED}),
    S.RETIRED: frozenset(),
}
# Roles allowed to PERFORM a transition into the target state.
REQUIRED_ROLES: Mapping[LifecycleState, frozenset[Role]] = {
    S.CONFIGURED: frozenset({Role.OPERATOR, Role.ADMIN}),
    S.VALIDATED: frozenset({Role.REVIEWER}),
    S.OPERATIONAL: frozenset({Role.OPERATOR, Role.ADMIN}),
    S.SUSPENDED: frozenset({Role.OPERATOR, Role.REVIEWER, Role.ADMIN}),
    S.RETIRED: frozenset({Role.ADMIN}),
}


class LifecycleError(Exception):
    """Transition refused. State is unchanged."""


class ProviderLifecycle:
    def __init__(self, actors: Mapping[str, frozenset[Role]]) -> None:
        self._actors = {k: frozenset(v) for k, v in actors.items()}
        self._lock = threading.RLock()
        self._log = AppendOnlyLog()
        self._state: dict[str, LifecycleState] = {}
        self._configured_by: dict[str, str] = {}

    @property
    def log(self) -> AppendOnlyLog:
        return self._log

    def register(self, provider_id: str, actor: str, reason: str) -> None:
        with self._lock:
            if not provider_id.strip() or provider_id in self._state:
                self._deny(provider_id, None, S.REGISTERED, actor, "invalid or duplicate provider")
            if not self._actors.get(actor):
                self._deny(provider_id, None, S.REGISTERED, actor, "unknown actor")
            self._need_reason(provider_id, None, S.REGISTERED, actor, reason)
            self._state[provider_id] = S.REGISTERED
            self._record("TRANSITION", provider_id, None, S.REGISTERED, actor, reason)

    def state(self, provider_id: str) -> LifecycleState:
        with self._lock:
            try:
                return self._state[provider_id]
            except KeyError:
                raise LifecycleError(f"unknown provider: {provider_id}") from None

    def transition(self, provider_id: str, to: object, actor: str, reason: str) -> LifecycleState:
        with self._lock:
            cur = self._state.get(provider_id)
            if cur is None:
                self._deny(provider_id, None, to, actor, "unknown provider")
            try:
                target = LifecycleState(to)
            except ValueError:
                self._deny(provider_id, cur, to, actor, "unknown target state")
            if target not in ALLOWED[cur]:
                self._deny(provider_id, cur, target, actor, "transition not allowed")
            roles = self._actors.get(actor, frozenset())
            if not roles & REQUIRED_ROLES[target]:
                self._deny(provider_id, cur, target, actor, "actor not authorized for this transition")
            self._need_reason(provider_id, cur, target, actor, reason)
            if target is S.VALIDATED and cur is S.CONFIGURED and actor == self._configured_by.get(provider_id):
                self._deny(provider_id, cur, target, actor, "validator must differ from configurer")
            if target is S.CONFIGURED:
                self._configured_by[provider_id] = actor
            self._state[provider_id] = target
            self._record("TRANSITION", provider_id, cur, target, actor, reason)
            return target

    def history(self, provider_id: str) -> list[dict]:
        return [json.loads(e.payload) for e in self._log.entries()
                if json.loads(e.payload).get("provider") == provider_id]

    # internals
    def _need_reason(self, pid, cur, target, actor, reason) -> None:
        if not isinstance(reason, str) or len(reason.strip()) < 5:
            self._deny(pid, cur, target, actor, "a reason is required")

    def _record(self, kind, pid, cur, target, actor, reason) -> None:
        self._log.append(kind, {
            "provider": str(pid)[:80], "from": cur.value if isinstance(cur, LifecycleState) else None,
            "to": target.value if isinstance(target, LifecycleState) else str(target)[:40],
            "actor": str(actor)[:80], "reason": redact(str(reason))[:200],
        })

    def _deny(self, pid, cur, target, actor, why) -> None:
        self._record("DENIED", pid, cur, target, actor, why)
        raise LifecycleError(why)
