"""Data model. Frozen value objects; invalid evidence is refused at construction."""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum


class Status(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    UNVERIFIED = "UNVERIFIED"
    NOT_APPLICABLE = "NOT_APPLICABLE"


class Criterion(str, Enum):
    SDK_TRANSPORT_CONFORMANCE = "sdk_transport_conformance"
    AUTHENTICATION_SECURITY = "authentication_security"
    MODEL_IDENTITY_VERIFICATION = "model_identity_verification"
    DEADLINE_COMPLIANCE = "deadline_compliance"
    WORKER_LIFECYCLE_SETTLEMENT = "worker_lifecycle_settlement"
    CONCURRENCY_CAPACITY = "concurrency_capacity"
    ERROR_CLASSIFICATION = "error_classification"
    USAGE_ACCOUNTING = "usage_accounting"
    AUDIT_INTEGRITY = "audit_integrity"
    RESPONSE_SIZE_LIMITS = "response_size_limits"
    FAILURE_ISOLATION = "failure_isolation"
    OPERATIONAL_EVIDENCE = "operational_evidence"


# Criteria that may be declared NOT_APPLICABLE (with a written reason). Everything else is mandatory.
WAIVABLE: frozenset[Criterion] = frozenset({Criterion.SDK_TRANSPORT_CONFORMANCE})


class EvidenceKind(str, Enum):
    """Kept strictly apart. Only LIVE can ever produce PASS."""

    LIVE = "live"            # real operation against the real provider, independently reviewed
    LOCAL_TEST = "local"     # offline test of real repository code, no provider contact
    MOCK_TEST = "mock"       # test against a fake client or fake transport
    DOCUMENTATION = "doc"    # a document says so


_SHA256 = re.compile(r"^[0-9a-f]{64}$")


@dataclass(frozen=True)
class Evidence:
    criterion: Criterion
    kind: EvidenceKind
    supports: bool            # True: supports the criterion. False: contradicts it.
    ref: str                  # test id, document path, or live artifact name
    note: str
    reviewer: str = ""        # required for LIVE
    artifact_sha256: str = ""  # required for LIVE

    def __post_init__(self) -> None:
        if not isinstance(self.criterion, Criterion) or not isinstance(self.kind, EvidenceKind):
            raise TypeError("criterion and kind must be enum members")
        if not self.ref.strip() or not self.note.strip():
            raise ValueError("evidence needs a ref and a note")
        if self.kind is EvidenceKind.LIVE:
            if not self.reviewer.strip():
                raise ValueError("live evidence needs an independent reviewer")
            if not _SHA256.match(self.artifact_sha256):
                raise ValueError("live evidence needs the sha256 of its artifact")


@dataclass(frozen=True)
class NotApplicable:
    criterion: Criterion
    reason: str

    def __post_init__(self) -> None:
        if self.criterion not in WAIVABLE:
            raise ValueError(f"{self.criterion.value} cannot be declared NOT_APPLICABLE")
        if len(self.reason.strip()) < 10:
            raise ValueError("NOT_APPLICABLE needs a real reason")


@dataclass(frozen=True)
class CriterionResult:
    criterion: Criterion
    status: Status
    reason: str
    evidence: tuple[Evidence, ...]


@dataclass(frozen=True)
class ProviderAssessment:
    provider_id: str
    results: tuple[CriterionResult, ...]
    overall: Status
    production_ready: bool
    blockers: tuple[str, ...]
