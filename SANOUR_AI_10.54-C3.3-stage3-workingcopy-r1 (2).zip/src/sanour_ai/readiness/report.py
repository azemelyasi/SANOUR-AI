"""Readiness report. Deterministic text from assessments."""

from __future__ import annotations

import json

from sanour_ai.readiness.model import EvidenceKind, ProviderAssessment


def _counts(a: ProviderAssessment) -> dict[str, int]:
    out = {k.value: 0 for k in EvidenceKind}
    for r in a.results:
        for e in r.evidence:
            out[e.kind.value] += 1
    return out


def render_json(assessments: list[ProviderAssessment]) -> str:
    data = [
        {
            "provider": a.provider_id,
            "overall": a.overall.value,
            "production_ready": a.production_ready,
            "criteria": {r.criterion.value: {"status": r.status.value, "reason": r.reason} for r in a.results},
            "evidence_counts": _counts(a),
            "blockers": list(a.blockers),
        }
        for a in assessments
    ]
    return json.dumps(data, indent=2, sort_keys=True) + "\n"


def render_markdown(assessments: list[ProviderAssessment]) -> str:
    lines = [
        "# Provider Readiness Report (Stage 10.52)",
        "",
        "Only independently reviewed LIVE evidence can produce PASS. Documentation, local tests and mock tests",
        "never do. A provider's overall status is its strictest criterion. Production ready requires every",
        "criterion to be PASS or NOT_APPLICABLE.",
        "",
        "| Provider | Overall | Production ready | PASS | FAIL | UNVERIFIED | N/A |",
        "|---|---|---|---|---|---|---|",
    ]
    for a in assessments:
        n = {s: sum(1 for r in a.results if r.status.value == s) for s in ("PASS", "FAIL", "UNVERIFIED", "NOT_APPLICABLE")}
        lines.append(
            f"| `{a.provider_id}` | {a.overall.value} | {'yes' if a.production_ready else 'no'} | "
            f"{n['PASS']} | {n['FAIL']} | {n['UNVERIFIED']} | {n['NOT_APPLICABLE']} |"
        )
    for a in assessments:
        c = _counts(a)
        lines += ["", f"## `{a.provider_id}`", "",
                  f"Evidence: live {c['live']}, local {c['local']}, mock {c['mock']}, doc {c['doc']}.", "",
                  "| Criterion | Status | Reason |", "|---|---|---|"]
        for r in a.results:
            lines.append(f"| {r.criterion.value} | {r.status.value} | {r.reason} |")
    return "\n".join(lines) + "\n"
