"""Readiness governance (Stage 10.53, part 2).

Statuses stay per-criterion. PASS is issued only from current, intact, LIVE evidence in the store.
Every status change is logged with its reason. Issued reports are frozen, digested and never rewritten.
Pure and offline: it reads evidence, it never runs a request, selects a provider, retries or falls back.
"""

from __future__ import annotations

import json
import threading
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime, timezone

from sanour_ai.readiness.chain import AppendOnlyLog, canonical, sha256_text
from sanour_ai.readiness.engine import assess_criterion
from sanour_ai.readiness.evidence_store import EvidenceStore, Standing
from sanour_ai.readiness.model import Criterion, EvidenceKind, ProviderAssessment, Status, CriterionResult
from sanour_ai.security.redaction import redact

STAGE = "10.53"


@dataclass(frozen=True)
class CriteriaSpec:
    version: str
    criteria: tuple[str, ...]
    waivable: tuple[str, ...]
    note: str

    def digest(self) -> str:
        return sha256_text(canonical({"v": self.version, "c": list(self.criteria), "w": list(self.waivable)}))


# Append only. A change to the criteria set needs a NEW entry here; editing an old entry changes its digest,
# and tests pin the digest of every released version.
SPECS: dict[str, CriteriaSpec] = {
    "1": CriteriaSpec(
        "1",
        tuple(c.value for c in Criterion),
        ("sdk_transport_conformance",),
        "Stage 10.52 criteria, unchanged in 10.53.",
    ),
}
CURRENT_SPEC_VERSION = "1"


class SpecMismatch(RuntimeError):
    pass


def current_spec() -> CriteriaSpec:
    spec = SPECS[CURRENT_SPEC_VERSION]
    if spec.criteria != tuple(c.value for c in Criterion):
        raise SpecMismatch("Criterion enum differs from the current criteria spec: add a new spec version")
    return spec


class ReportError(Exception):
    pass


class GovernedReadiness:
    def __init__(
        self,
        store: EvidenceStore,
        *,
        clock: Callable[[], datetime] | None = None,
        artifact_resolver: Callable[[str], bytes | None] | None = None,
        providers: tuple[str, ...] = (),
    ) -> None:
        self._store = store
        self._clock = clock or (lambda: datetime.now(timezone.utc))
        self._resolver = artifact_resolver
        self._providers = tuple(providers)
        self._spec = current_spec()
        self._lock = threading.RLock()
        self._log = AppendOnlyLog()          # status changes and issued reports
        self._last: dict[tuple[str, str], Status] = {}
        self._reports: dict[str, str] = {}   # report_id -> canonical json (frozen)

    @property
    def log(self) -> AppendOnlyLog:
        return self._log

    # ---- evaluation ----------------------------------------------------------
    def evaluate(self, provider_id: str, now: datetime | None = None) -> ProviderAssessment:
        now = now or self._clock()
        with self._lock:
            if not self._store.verify_integrity():
                results = tuple(CriterionResult(c, Status.UNVERIFIED, "evidence store integrity failure", ())
                                for c in Criterion)
                return self._finish(provider_id, results, now)
            recs = self._store.records(provider_id)
            results = []
            for crit in Criterion:
                results.append(self._criterion(crit, recs, now))
            return self._finish(provider_id, tuple(results), now)

    def _criterion(self, crit: Criterion, recs, now) -> CriterionResult:
        usable, expired = [], []
        for r in recs:
            if r.criterion is not crit:
                continue
            st = self._store.standing(r.evidence_id, now)
            if st in (Standing.VALID, Standing.STALE):
                usable.append(r)
            elif st is Standing.EXPIRED:
                expired.append(r)
        # Expired contradicting evidence still blocks (fail-closed) until superseded or revoked.
        usable += [r for r in expired if not r.supports]
        res = assess_criterion(crit, [self._store.to_engine_evidence(r) for r in usable])
        if res.status is Status.PASS and self._resolver is not None:
            for r in usable:
                if r.kind is EvidenceKind.LIVE and r.supports:
                    data = self._resolver(r.evidence_id)
                    if data is None or not self._store.verify_artifact(r.evidence_id, data):
                        return CriterionResult(crit, Status.FAIL, f"artifact hash mismatch for {r.evidence_id}", res.evidence)
        if res.status is Status.FAIL and any(r.supports for r in usable) and any(not r.supports for r in usable):
            return CriterionResult(crit, Status.FAIL, "conflicting evidence: " + res.reason, res.evidence)
        if res.status is Status.UNVERIFIED and any(r.supports for r in expired):
            ids = ",".join(r.evidence_id for r in expired if r.supports)
            return CriterionResult(crit, Status.UNVERIFIED, f"evidence expired ({ids})", res.evidence)
        return res

    def _finish(self, provider_id, results, now) -> ProviderAssessment:
        sev = {Status.NOT_APPLICABLE: 0, Status.PASS: 1, Status.UNVERIFIED: 2, Status.FAIL: 3}
        overall = max((r.status for r in results), key=sev.__getitem__)
        blockers = tuple(f"{r.criterion.value}: {r.status.value} ({r.reason})" for r in results
                         if r.status in (Status.FAIL, Status.UNVERIFIED))
        for r in results:
            key = (provider_id, r.criterion.value)
            prev = self._last.get(key)
            if prev is not r.status:
                self._last[key] = r.status
                self._log.append("STATUS_CHANGE", {
                    "provider": provider_id, "criterion": r.criterion.value,
                    "from": prev.value if prev else "NONE", "to": r.status.value,
                    "reason": redact(r.reason), "at": now.astimezone(timezone.utc).isoformat(),
                    "evidence": [e.ref for e in r.evidence],
                })
        return ProviderAssessment(provider_id, results, overall, overall is Status.PASS and not blockers, blockers)

    def status_history(self, provider_id: str, criterion: Criterion) -> list[dict]:
        out = []
        for e in self._log.entries():
            if e.kind == "STATUS_CHANGE":
                p = json.loads(e.payload)
                if p["provider"] == provider_id and p["criterion"] == criterion.value:
                    out.append(p)
        return out

    # ---- reports -------------------------------------------------------------
    def issue_report(self, provider_ids: tuple[str, ...] | None = None, now: datetime | None = None) -> str:
        """Evaluate, freeze and store a report. Returns its id. The stored text never changes."""
        now = now or self._clock()
        ids = tuple(provider_ids) if provider_ids is not None else (self._providers or tuple(self._store.providers()))
        with self._lock:
            provs = []
            for pid in ids:
                a = self.evaluate(pid, now)
                recs = {r.evidence_id: r for r in self._store.records(pid)}
                provs.append({
                    "provider": pid, "overall": a.overall.value, "production_ready": a.production_ready,
                    "criteria": [{
                        "criterion": r.criterion.value, "status": r.status.value, "reason": redact(r.reason),
                        "evidence": [{"id": e.ref, "kind": e.kind.value, "supports": e.supports,
                                      "sha256": recs[e.ref].artifact_sha256 if e.ref in recs else "",
                                      "standing": self._store.standing(e.ref, now).value if e.ref in recs else ""}
                                     for e in r.evidence],
                    } for r in a.results],
                    "blockers": [redact(b) for b in a.blockers],
                })
            rid = f"RR-{len([e for e in self._log.entries() if e.kind == 'REPORT_ISSUED']) + 1:05d}"
            body = {
                "report_id": rid, "stage": STAGE, "generated_at": now.astimezone(timezone.utc).isoformat(),
                "criteria_spec_version": self._spec.version, "criteria_spec_digest": self._spec.digest(),
                "evidence_log_head": self._store.head_hash, "providers": provs,
            }
            body["digest"] = sha256_text(canonical(body))
            text = canonical(body)
            self._reports[rid] = text
            self._log.append("REPORT_ISSUED", {"report_id": rid, "digest": body["digest"]})
            return rid

    def get_report(self, report_id: str) -> dict:
        """The frozen report, re-verified against its logged digest."""
        with self._lock:
            text = self._reports[report_id]
            body = json.loads(text)
            digest = body.pop("digest")
            logged = [json.loads(e.payload) for e in self._log.entries()
                      if e.kind == "REPORT_ISSUED" and json.loads(e.payload)["report_id"] == report_id]
            if not self._log.verify() or sha256_text(canonical(body)) != digest or not logged \
                    or logged[0]["digest"] != digest:
                raise ReportError("report integrity check failed")
            body["digest"] = digest
            return body


def render_report_markdown(report: dict) -> str:
    lines = [
        f"# Provider Readiness Report {report['report_id']} (Stage {report['stage']})", "",
        f"Generated: {report['generated_at']}  ",
        f"Criteria spec: v{report['criteria_spec_version']} ({report['criteria_spec_digest'][:16]})  ",
        f"Evidence log head: {report['evidence_log_head'][:16]}  ",
        f"Report digest: {report['digest']}", "",
        "Only independently reviewed, current LIVE evidence gives PASS. A provider's status is its strictest criterion.",
        "Readiness is separate from the operational lifecycle: OPERATIONAL does not mean production ready.", "",
        "| Provider | Overall | Production ready |", "|---|---|---|",
    ]
    for p in report["providers"]:
        lines.append(f"| `{p['provider']}` | {p['overall']} | {'yes' if p['production_ready'] else 'no'} |")
    for p in report["providers"]:
        lines += ["", f"## `{p['provider']}`", "", "| Criterion | Status | Reason | Evidence (id:kind:sha256) |", "|---|---|---|---|"]
        for c in p["criteria"]:
            ev = ", ".join(f"{e['id']}:{e['kind']}:{e['sha256'][:12] or '-'}" for e in c["evidence"]) or "none"
            lines.append(f"| {c['criterion']} | {c['status']} | {c['reason']} | {ev} |")
    return redact("\n".join(lines)) + "\n"
