"""Versioned, append-only evidence store (Stage 10.53, part 1).

Hashes are computed here from real bytes. A caller-claimed hash is only compared, never trusted.
Nothing is deleted or overwritten: replacement is `supersede`, withdrawal is `revoke`, both are logged.

Authenticity limits (also in docs): the store proves that THESE bytes had THIS hash when recorded and who
was named as reviewer. It cannot prove the artifact came from a real provider call, nor that the named
reviewer is the real person. LIVE acceptance is a set of fail-closed screening rules, not proof.
"""

from __future__ import annotations

import hashlib
import json
import os
import threading
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from enum import Enum

from sanour_ai.readiness.chain import AppendOnlyLog, canonical
from sanour_ai.readiness.model import Criterion, Evidence, EvidenceKind
from sanour_ai.security.redaction import redact

EVIDENCE_SCHEMA_VERSION = "1"
MAX_ARTIFACT_BYTES = 10 * 1024 * 1024
LIVE_METHODS = frozenset({"live_api_probe", "operator_witnessed_run", "independent_audit"})
MOCK_MARKERS = ("mock", "fake", "stub", "fixture", "simulated", "synthetic", "dummy")
MAX_AGE = {
    EvidenceKind.LIVE: timedelta(days=90),
    EvidenceKind.LOCAL_TEST: timedelta(days=180),
    EvidenceKind.MOCK_TEST: timedelta(days=180),
    EvidenceKind.DOCUMENTATION: timedelta(days=365),
}
STALE_FRACTION = 2 / 3


class EvidenceRejected(ValueError):
    """The record was refused. Nothing was stored."""


class Standing(str, Enum):
    VALID = "valid"
    STALE = "stale"          # past two thirds of its life: still counts, but renew soon
    EXPIRED = "expired"      # past its life: never supports PASS
    SUPERSEDED = "superseded"
    REVOKED = "revoked"


@dataclass(frozen=True)
class EvidenceRecord:
    schema_version: str
    evidence_id: str
    provider_id: str
    criterion: Criterion
    kind: EvidenceKind
    supports: bool
    artifact_sha256: str
    source: str
    reviewer: str
    recorded_by: str
    verified_at: datetime
    method: str
    software: str
    software_version: str
    note: str
    supersedes: str = ""

    def to_dict(self) -> dict:
        return {
            "schema_version": self.schema_version, "evidence_id": self.evidence_id,
            "provider_id": self.provider_id, "criterion": self.criterion.value, "kind": self.kind.value,
            "supports": self.supports, "artifact_sha256": self.artifact_sha256, "source": self.source,
            "reviewer": self.reviewer, "recorded_by": self.recorded_by,
            "verified_at": self.verified_at.isoformat(), "method": self.method,
            "software": self.software, "software_version": self.software_version,
            "note": self.note, "supersedes": self.supersedes,
        }

    def digest(self) -> str:
        return hashlib.sha256(canonical(self.to_dict()).encode()).hexdigest()


def _utc(dt: datetime, what: str) -> datetime:
    if dt.tzinfo is None:
        raise EvidenceRejected(f"{what} must be timezone-aware")
    return dt.astimezone(timezone.utc)


def _has_mock_marker(*texts: str) -> bool:
    joined = " ".join(texts).lower()
    return any(m in joined for m in MOCK_MARKERS)


class EvidenceStore:
    def __init__(
        self,
        *,
        authorized_reviewers: Iterable[str] = (),
        clock: Callable[[], datetime] | None = None,
    ) -> None:
        self._reviewers = frozenset(authorized_reviewers)
        self._clock = clock or (lambda: datetime.now(timezone.utc))
        self._lock = threading.RLock()
        self._log = AppendOnlyLog()
        self._records: dict[str, EvidenceRecord] = {}
        self._order: list[str] = []
        self._superseded_by: dict[str, str] = {}
        self._revoked: dict[str, str] = {}

    # ---- writes (all logged) -------------------------------------------------
    def add(
        self,
        *,
        provider_id: str,
        criterion: Criterion,
        kind: EvidenceKind,
        supports: bool,
        artifact: bytes,
        source: str,
        reviewer: str,
        recorded_by: str,
        verified_at: datetime,
        method: str,
        software: str,
        software_version: str,
        note: str,
        claimed_sha256: str | None = None,
        supersedes: str = "",
    ) -> EvidenceRecord:
        try:
            return self._add(locals())
        except EvidenceRejected as exc:
            with self._lock:
                self._log.append("EVIDENCE_REJECTED", {
                    "provider_id": str(provider_id)[:80], "criterion": getattr(criterion, "value", str(criterion)),
                    "kind": getattr(kind, "value", str(kind)), "reason": redact(str(exc))[:200],
                })
            raise

    def _add(self, a: dict) -> EvidenceRecord:
        provider_id, criterion, kind = a["provider_id"], a["criterion"], a["kind"]
        artifact, source, reviewer, recorded_by = a["artifact"], a["source"], a["reviewer"], a["recorded_by"]
        method, software, version, note = a["method"], a["software"], a["software_version"], a["note"]
        if not isinstance(criterion, Criterion) or not isinstance(kind, EvidenceKind):
            raise EvidenceRejected("criterion and kind must be enum members")
        if not isinstance(artifact, (bytes, bytearray)) or not artifact:
            raise EvidenceRejected("artifact bytes are required")
        if len(artifact) > MAX_ARTIFACT_BYTES:
            raise EvidenceRejected("artifact too large")
        for name, value in (("provider_id", provider_id), ("source", source), ("recorded_by", recorded_by),
                            ("method", method), ("software", software), ("software_version", version),
                            ("note", note)):
            if not isinstance(value, str) or not value.strip():
                raise EvidenceRejected(f"{name} is required")
        verified_at = _utc(a["verified_at"], "verified_at")
        now = _utc(self._clock(), "clock")
        if verified_at > now:
            raise EvidenceRejected("verified_at is in the future")
        sha = hashlib.sha256(bytes(artifact)).hexdigest()  # computed, never accepted
        claimed = a["claimed_sha256"]
        if claimed is not None and claimed.lower() != sha:
            raise EvidenceRejected("claimed sha256 does not match the artifact")
        text_fields = (source, reviewer, recorded_by, method, software, version, note)
        if any(redact(t) != t for t in text_fields):
            raise EvidenceRejected("secret-like content refused")
        if kind is EvidenceKind.LIVE:
            body = bytes(artifact).decode("utf-8", "ignore")
            if redact(body) != body:  # artifact bytes are hashed, never stored; a secret in one is still refused
                raise EvidenceRejected("secret-like content refused")
        if kind is EvidenceKind.LIVE:
            self._screen_live(source, reviewer, recorded_by, method, software, version, note, bytes(artifact))
        with self._lock:
            sup = a["supersedes"]
            if sup:
                old = self._records.get(sup)
                if old is None:
                    raise EvidenceRejected("superseded evidence does not exist")
                if (old.provider_id, old.criterion) != (provider_id, criterion):
                    raise EvidenceRejected("can only supersede evidence of the same provider and criterion")
                if sup in self._superseded_by or sup in self._revoked:
                    raise EvidenceRejected("evidence already superseded or revoked")
            eid = f"EV-{len(self._order) + 1:06d}"
            rec = EvidenceRecord(EVIDENCE_SCHEMA_VERSION, eid, provider_id, criterion, kind, bool(a["supports"]),
                                 sha, source, reviewer, recorded_by, verified_at, method, software, version,
                                 note, sup)
            self._records[eid] = rec
            self._order.append(eid)
            if sup:
                self._superseded_by[sup] = eid
            self._log.append("EVIDENCE_ADDED", {"record": rec.to_dict(), "record_digest": rec.digest()})
            if sup:
                self._log.append("EVIDENCE_SUPERSEDED", {"old": sup, "new": eid})
            return rec

    def _screen_live(self, source, reviewer, recorded_by, method, software, version, note, artifact) -> None:
        if not source.startswith("live://"):
            raise EvidenceRejected("live evidence source must start with live://")
        if method not in LIVE_METHODS:
            raise EvidenceRejected("verification method is not an accepted live method")
        if reviewer not in self._reviewers:
            raise EvidenceRejected("reviewer is not authorized")
        if reviewer == recorded_by:
            raise EvidenceRejected("reviewer must be independent of the recorder")
        if _has_mock_marker(source, method, software, version, note, artifact.decode("utf-8", "ignore")):
            raise EvidenceRejected("mock or fake marker found: not accepted as live")

    def revoke(self, evidence_id: str, actor: str, reason: str) -> None:
        with self._lock:
            if evidence_id not in self._records:
                raise KeyError(evidence_id)
            if not actor.strip() or len(reason.strip()) < 5:
                raise EvidenceRejected("revocation needs an actor and a reason")
            if evidence_id in self._revoked:
                raise EvidenceRejected("already revoked")
            self._revoked[evidence_id] = reason
            self._log.append("EVIDENCE_REVOKED", {"id": evidence_id, "actor": actor, "reason": redact(reason)})

    # ---- reads ---------------------------------------------------------------
    def get(self, evidence_id: str) -> EvidenceRecord:
        with self._lock:
            return self._records[evidence_id]

    def records(self, provider_id: str | None = None) -> tuple[EvidenceRecord, ...]:
        with self._lock:
            return tuple(self._records[i] for i in self._order
                         if provider_id is None or self._records[i].provider_id == provider_id)

    def providers(self) -> list[str]:
        with self._lock:
            return sorted({r.provider_id for r in self._records.values()})

    def standing(self, evidence_id: str, now: datetime | None = None) -> Standing:
        with self._lock:
            rec = self._records[evidence_id]
            if evidence_id in self._revoked:
                return Standing.REVOKED
            if evidence_id in self._superseded_by:
                return Standing.SUPERSEDED
        now = _utc(now or self._clock(), "now")
        life = MAX_AGE[rec.kind]
        age = now - rec.verified_at
        if age > life:
            return Standing.EXPIRED
        if age > life * STALE_FRACTION:
            return Standing.STALE
        return Standing.VALID

    def conflicts(self, provider_id: str, now: datetime | None = None) -> list[Criterion]:
        """Criteria where live, current records both support and contradict."""
        seen: dict[Criterion, set[bool]] = {}
        for r in self.records(provider_id):
            if r.kind is EvidenceKind.LIVE and self.standing(r.evidence_id, now) in (Standing.VALID, Standing.STALE):
                seen.setdefault(r.criterion, set()).add(r.supports)
        return [c for c, v in seen.items() if len(v) == 2]

    def verify_artifact(self, evidence_id: str, data: bytes) -> bool:
        return hashlib.sha256(bytes(data)).hexdigest() == self.get(evidence_id).artifact_sha256

    def verify_integrity(self) -> bool:
        """Chain intact AND every stored record still matches the digest logged when it was added."""
        with self._lock:
            if not self._log.verify():
                return False
            logged = {}
            for e in self._log.entries():
                if e.kind == "EVIDENCE_ADDED":
                    p = json.loads(e.payload)
                    logged[p["record"]["evidence_id"]] = p["record_digest"]
            return set(logged) == set(self._records) and all(
                self._records[i].digest() == d for i, d in logged.items())

    @property
    def log(self) -> AppendOnlyLog:
        return self._log

    @property
    def head_hash(self) -> str:
        return self._log.head

    def to_engine_evidence(self, rec: EvidenceRecord) -> Evidence:
        return Evidence(rec.criterion, rec.kind, rec.supports, rec.evidence_id, rec.note,
                        reviewer=rec.reviewer if rec.kind is EvidenceKind.LIVE else "",
                        artifact_sha256=rec.artifact_sha256 if rec.kind is EvidenceKind.LIVE else "")


def read_artifact(path: str) -> bytes:
    """Read a file for hashing, bounded. The store still hashes the bytes itself."""
    if os.path.getsize(path) > MAX_ARTIFACT_BYTES:
        raise EvidenceRejected("artifact too large")
    with open(path, "rb") as fh:
        return fh.read()
