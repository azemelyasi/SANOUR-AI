"""Builds the governed 10.53 view of today's evidence from the 10.52 entries (Stage 10.53).

Each 10.52 entry becomes a real store record whose artifact is the actual referenced repository file,
hashed here. Nothing is LIVE, so nothing can PASS. Used by the report and by tests.
"""

from __future__ import annotations

import os
from collections.abc import Callable
from datetime import datetime, timezone

from sanour_ai.readiness.current_evidence import populate
from sanour_ai.readiness.evidence_store import EvidenceStore, read_artifact
from sanour_ai.readiness.governance import GovernedReadiness
from sanour_ai.readiness.registry import ReadinessRegistry

BOOTSTRAP_ACTOR = "stage-10.53-bootstrap"
SOFTWARE = "sanour_ai"
SOFTWARE_VERSION = "10.53"


def build_current(root: str, clock: Callable[[], datetime] | None = None):
    """Return (store, governed) for the five providers. `root` is the project root."""
    clock = clock or (lambda: datetime.now(timezone.utc))
    reg = ReadinessRegistry()
    populate(reg)
    store = EvidenceStore(clock=clock)
    for pid in reg.provider_ids():
        for ev in reg.evidence(pid):
            store.add(
                provider_id=pid, criterion=ev.criterion, kind=ev.kind, supports=ev.supports,
                artifact=read_artifact(os.path.join(root, ev.ref)), source=f"repo://{ev.ref}",
                reviewer="", recorded_by=BOOTSTRAP_ACTOR, verified_at=clock(),
                method="repository_file_hash", software=SOFTWARE, software_version=SOFTWARE_VERSION,
                note=ev.note,
            )
    return store, GovernedReadiness(store, clock=clock, providers=tuple(reg.provider_ids()))
