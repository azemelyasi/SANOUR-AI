"""Honest current evidence for the five providers (Stage 10.52).

Nothing here is LIVE: no provider API has ever been contacted from this repository, so no criterion
can be PASS. Each entry names a real file (checked by tests). Mock and local tests are recorded as
what they are and never counted as operational proof.
"""

from __future__ import annotations

from sanour_ai.readiness.model import Criterion as C
from sanour_ai.readiness.model import Evidence, EvidenceKind as K
from sanour_ai.readiness.registry import ReadinessRegistry

_MOCK_TEST = {
    "openai": "tests/unit/test_openai_provider.py",
    "anthropic": "tests/unit/test_claude_provider.py",
    "gemini": "tests/unit/test_gemini_provider.py",
    "grok": "tests/unit/test_grok_provider.py",
    "grok_responses": "tests/unit/test_stage1037_conformance.py",
}

# (criterion, kind, ref, note) shared by every provider: core behaviour tested offline.
_COMMON = (
    (C.DEADLINE_COMPLIANCE, K.LOCAL_TEST, "tests/unit/test_gateway.py", "central deadline tested offline; hung provider threads are not stopped (known limit)"),
    (C.WORKER_LIFECYCLE_SETTLEMENT, K.LOCAL_TEST, "tests/unit/test_stage1049r8r1_bounded.py", "worker settlement tested offline; no recovery for a call that never returns"),
    (C.CONCURRENCY_CAPACITY, K.LOCAL_TEST, "tests/unit/test_gateway.py", "semaphore cap and provider_overloaded tested offline"),
    (C.USAGE_ACCOUNTING, K.LOCAL_TEST, "tests/unit/test_stage1047_usage.py", "usage extraction tested against fakes; provider usage fields never checked live"),
    (C.AUDIT_INTEGRITY, K.LOCAL_TEST, "tests/unit/test_cross_provider_audit.py", "audit records tested offline"),
    (C.RESPONSE_SIZE_LIMITS, K.LOCAL_TEST, "tests/unit/test_stage1049r8r1_bounded.py", "bounded reads tested offline; not exercised against a real network body"),
    (C.FAILURE_ISOLATION, K.LOCAL_TEST, "tests/unit/test_stage1041.py", "failure isolation tested offline"),
    (C.AUTHENTICATION_SECURITY, K.LOCAL_TEST, "tests/unit/test_redaction.py", "secret redaction tested offline; no real credential flow exercised"),
    (C.MODEL_IDENTITY_VERIFICATION, K.LOCAL_TEST, "docs/MODEL_IDENTITY_POLICY.md", "identity check implemented in the gateway; policy only, no live model id observed"),
    (C.ERROR_CLASSIFICATION, K.DOCUMENTATION, "docs/ERROR_TAXONOMY.md", "provider error and quota meanings are documented as unverified"),
    (C.OPERATIONAL_EVIDENCE, K.DOCUMENTATION, "docs/PROVIDER_STATUS.md", "no live-verified status exists for any provider"),
)


def populate(reg: ReadinessRegistry) -> None:
    for pid, test in _MOCK_TEST.items():
        reg.register_provider(pid)
        reg.add_evidence(pid, Evidence(C.SDK_TRANSPORT_CONFORMANCE, K.MOCK_TEST, True, test,
                                       "adapter logic tested against a fake client or transport, not the real API"))
        reg.add_evidence(pid, Evidence(C.ERROR_CLASSIFICATION, K.MOCK_TEST, True, test,
                                       "status mapping tested against fake errors"))
        for crit, kind, ref, note in _COMMON:
            reg.add_evidence(pid, Evidence(crit, kind, True, ref, note))
