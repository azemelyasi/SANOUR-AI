"""Extensible registry. A new provider is added by data, never by editing the engine."""

from __future__ import annotations

from sanour_ai.readiness.model import Evidence, NotApplicable


class ReadinessRegistry:
    def __init__(self) -> None:
        self._evidence: dict[str, list[Evidence]] = {}
        self._waivers: dict[str, list[NotApplicable]] = {}

    def register_provider(self, provider_id: str) -> None:
        if not provider_id.strip():
            raise ValueError("provider_id is required")
        if provider_id in self._evidence:
            raise ValueError(f"provider already registered: {provider_id}")
        self._evidence[provider_id] = []
        self._waivers[provider_id] = []

    def add_evidence(self, provider_id: str, ev: Evidence) -> None:
        self._known(provider_id)
        self._evidence[provider_id].append(ev)

    def add_waiver(self, provider_id: str, w: NotApplicable) -> None:
        self._known(provider_id)
        self._waivers[provider_id].append(w)

    def provider_ids(self) -> list[str]:
        return list(self._evidence)

    def evidence(self, provider_id: str) -> tuple[Evidence, ...]:
        self._known(provider_id)
        return tuple(self._evidence[provider_id])

    def waivers(self, provider_id: str) -> tuple[NotApplicable, ...]:
        self._known(provider_id)
        return tuple(self._waivers[provider_id])

    def _known(self, provider_id: str) -> None:
        if provider_id not in self._evidence:
            raise KeyError(f"unknown provider: {provider_id}")


def default_registry() -> ReadinessRegistry:
    from sanour_ai.readiness.current_evidence import populate

    reg = ReadinessRegistry()
    populate(reg)
    return reg
