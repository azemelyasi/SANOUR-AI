"""Pure assessment rules. Strictest criterion wins. No I/O, no retry, no fallback."""

from __future__ import annotations

from collections.abc import Iterable

from sanour_ai.readiness.model import (
    Criterion,
    CriterionResult,
    Evidence,
    EvidenceKind,
    NotApplicable,
    ProviderAssessment,
    Status,
)

# Severity order. Higher is stricter.
_SEVERITY = {Status.NOT_APPLICABLE: 0, Status.PASS: 1, Status.UNVERIFIED: 2, Status.FAIL: 3}


def assess_criterion(
    criterion: Criterion,
    evidence: Iterable[Evidence],
    waivers: Iterable[NotApplicable] = (),
) -> CriterionResult:
    mine = tuple(e for e in evidence if e.criterion is criterion)
    contradicting = [e for e in mine if not e.supports]
    if contradicting:  # any contradiction of any kind fails the criterion
        return CriterionResult(criterion, Status.FAIL, f"contradicted by {contradicting[0].ref}", mine)
    waived = [w for w in waivers if w.criterion is criterion]
    if waived:
        return CriterionResult(criterion, Status.NOT_APPLICABLE, waived[0].reason, mine)
    live = [e for e in mine if e.kind is EvidenceKind.LIVE and e.supports]
    if live:
        return CriterionResult(criterion, Status.PASS, f"live evidence {live[0].ref}", mine)
    kinds = sorted({e.kind.value for e in mine})
    why = ("no live evidence; only " + ", ".join(kinds)) if kinds else "no evidence"
    return CriterionResult(criterion, Status.UNVERIFIED, why, mine)


def assess(
    provider_id: str,
    evidence: Iterable[Evidence],
    waivers: Iterable[NotApplicable] = (),
) -> ProviderAssessment:
    if not provider_id.strip():
        raise ValueError("provider_id is required")
    ev = tuple(evidence)
    wv = tuple(waivers)
    results = tuple(assess_criterion(c, ev, wv) for c in Criterion)
    overall = max((r.status for r in results), key=_SEVERITY.__getitem__)
    blockers = tuple(
        f"{r.criterion.value}: {r.status.value} ({r.reason})"
        for r in results
        if r.status in (Status.FAIL, Status.UNVERIFIED)
    )
    ready = overall is Status.PASS and not blockers
    return ProviderAssessment(provider_id, results, overall, ready, blockers)


def assess_all(registry) -> list[ProviderAssessment]:
    return [assess(p, registry.evidence(p), registry.waivers(p)) for p in registry.provider_ids()]
