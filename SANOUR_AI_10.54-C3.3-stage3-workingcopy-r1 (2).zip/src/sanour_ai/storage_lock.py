"""Compatibility import path for the first-open lock (Stage 10.54-C3.2; Stage 10.57 Stage 3).

The implementation lives in `sanour_ai.persistence.first_open_lock`, so the persistence package keeps its import boundary.
This module only re-exports the same names; callers and exception identity are unchanged. See that module for the
directory-lock mechanism, its limitations, and the platform scope (Linux exercised; macOS unverified; Windows refused).
"""

from sanour_ai.persistence.first_open_lock import (  # noqa: F401  (re-exported names)
    LockUnavailable,
    _thread_held_paths,
    exclusive_open_lock,
    fcntl,
)

__all__ = ["LockUnavailable", "exclusive_open_lock", "fcntl"]
