#!/bin/sh
# Reproducible SDK run. NOT executed in the R8-R2 sandbox (no network, SDK not installed there).
# Creates an isolated venv, installs the two pinned packages, records the frozen environment, then runs the
# full suite with SANOUR_REQUIRE_SDK=1 so a missing SDK is a failure, not a skip.
set -eu
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
python3 -m venv .venv-sdk
. .venv-sdk/bin/activate
pip install --no-cache-dir -r sdk-env/requirements-sdk.txt
mkdir -p logs
python -V > logs/sdk-python-version.txt
pip freeze > logs/sdk-freeze.txt
SANOUR_REQUIRE_SDK=1 PYTHONPATH=src:. PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s tests -t . 2>&1 | tee logs/sdk-suite.log
