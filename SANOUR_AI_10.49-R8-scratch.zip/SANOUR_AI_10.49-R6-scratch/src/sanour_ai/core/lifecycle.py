"""Request lifecycle state machine (Stage 10.32). Pure: no I/O, no request content.

Transitions are acyclic, so a request visits each state at most once. History is bounded by the
number of states. Terminal states are frozen. `rejected` is only reachable before `executing`, so a
rejected request never reaches a provider. A timeout is recorded as `timed_out`; it does not mean
the provider worker has ended.
"""

from __future__ import annotations

import time
from collections.abc import Callable
from enum import StrEnum


class RequestState(StrEnum):
    RECEIVED = "received"
    VALIDATING = "validating"
    RESOLVED = "resolved"
    WAITING_CAPACITY = "waiting_capacity"  # admission pending: gateway checks run here; there is no queue
    EXECUTING = "executing"
    VALIDATING_RESPONSE = "validating_response"
    COMPLETED = "completed"
    FAILED = "failed"
    TIMED_OUT = "timed_out"
    REJECTED = "rejected"


R = RequestState
TERMINAL_STATES = frozenset({R.COMPLETED, R.FAILED, R.TIMED_OUT, R.REJECTED})

ALLOWED: dict[RequestState, frozenset[RequestState]] = {
    R.RECEIVED: frozenset({R.VALIDATING, R.REJECTED, R.FAILED}),
    R.VALIDATING: frozenset({R.RESOLVED, R.REJECTED, R.FAILED}),
    R.RESOLVED: frozenset({R.WAITING_CAPACITY, R.REJECTED, R.FAILED}),
    R.WAITING_CAPACITY: frozenset({R.EXECUTING, R.REJECTED, R.TIMED_OUT, R.FAILED}),
    R.EXECUTING: frozenset({R.VALIDATING_RESPONSE, R.TIMED_OUT, R.FAILED}),
    R.VALIDATING_RESPONSE: frozenset({R.COMPLETED, R.FAILED}),
}


class InvalidTransition(Exception):
    """A transition that the state machine does not allow. Fixed message; no state data."""


class RequestLifecycle:
    def __init__(self, clock: Callable[[], float] = time.monotonic) -> None:
        self._clock = clock
        self._state = R.RECEIVED
        self._entered: dict[RequestState, float] = {R.RECEIVED: clock()}
        self._validation: str | None = None

    @property
    def state(self) -> RequestState:
        return self._state

    @property
    def history(self) -> tuple[RequestState, ...]:
        return tuple(self._entered)

    @property
    def validation_outcome(self) -> str | None:
        return self._validation

    def record_validation(self, outcome: str) -> None:
        """Record how response validation ended. Allowed only while in validating_response."""
        if self._state is not R.VALIDATING_RESPONSE:
            raise InvalidTransition("validation outcome outside validating_response")
        self._validation = outcome

    def entered_at(self, state: RequestState) -> float | None:
        return self._entered.get(state)

    def move(self, to: RequestState) -> None:
        if self._state in TERMINAL_STATES:
            raise InvalidTransition("request is already in a final state")
        if to not in ALLOWED[self._state]:
            raise InvalidTransition("transition not allowed")
        self._state = to
        self._entered[to] = self._clock()

    def finish(self, to: RequestState) -> None:
        """Move to a terminal state if not already there. Safe to call once on any error path."""
        if self._state in TERMINAL_STATES:
            return
        self.move(to)
