"""Usage accounting over the usage ledger.

Records come only from ExecutionResult of an accepted provider completion (see the coordinator). The
service turns one result into one LedgerRecord and appends it to a repository. Reports are computed from
the stored records, so a report after a restart is the same as before it.

The report shape and its rules live in ledger/report.py. Re-exported here for existing callers.
For every bucket and every token field:
- sum is None when no record in the bucket reported that field. Unknown is never summed as zero.
- known_count / unknown_count say how many records did and did not report it.
- tokens_complete says whether the sum covers every request in the bucket.
Request counts, delivery status and audit status are kept apart from token counts.
"""

from __future__ import annotations

import threading
import time
from collections.abc import Callable, Mapping

from sanour_ai.ledger.record import LedgerRecord
from sanour_ai.ledger.report import DIMENSIONS, Bucket, FieldTotal, build_report
from sanour_ai.ledger.repository import InMemoryUsageRepository, LedgerConflictError, LedgerStorageError, UsageRepository
from sanour_ai.models.execution import ExecutionResult

__all__ = ["DIMENSIONS", "Bucket", "FieldTotal", "UsageAccountingService", "build_report"]


class UsageAccountingService:
    """Records accepted usage into a repository and reports from it.

    Default repository is in memory (no persistence, tests and development only). Production passes a
    durable repository, which survives restarts.
    """

    def __init__(self, clock: Callable[[], float] = time.time, repository: UsageRepository | None = None) -> None:
        self._clock = clock
        self._repo: UsageRepository = repository if repository is not None else InMemoryUsageRepository()
        self._counter_lock = threading.Lock()
        self._appended = 0
        self._duplicates = 0
        self._storage_failures = 0
        self._conflicts = 0

    @staticmethod
    def period_of(timestamp: float) -> str:
        from datetime import datetime, timezone
        return datetime.fromtimestamp(timestamp, tz=timezone.utc).strftime("%Y-%m-%d")

    def record(self, result: ExecutionResult, *, recorded_at: float | None = None) -> bool:
        """Store one accepted completion. True if newly stored, False for an identical duplicate.

        Raises ValueError for an invalid result (nothing is stored), LedgerStorageError when the write
        could not be made durable (never reported as success), LedgerConflictError for a different record
        under an existing request id.
        """
        when = self._clock() if recorded_at is None else recorded_at
        record = LedgerRecord.from_execution(result, when)
        try:
            stored = self._repo.append(record)
        except LedgerStorageError:
            with self._counter_lock:
                self._storage_failures += 1
            raise
        except LedgerConflictError:
            with self._counter_lock:
                self._conflicts += 1
            raise
        with self._counter_lock:
            if stored:
                self._appended += 1
            else:
                self._duplicates += 1
        return stored

    def records(self) -> list[LedgerRecord]:
        return self._repo.records()

    def report(self, filters: Mapping[str, object] | None = None,
               dimensions: tuple[str, ...] = DIMENSIONS) -> dict[str, object]:
        """Filtered report (exact matches on provider, profile, model, period, delivery, audit)."""
        return self._repo.report(filters, dimensions)

    def aggregate(self, by: str) -> dict[str, dict[str, object]]:
        if by not in DIMENSIONS:
            raise ValueError("unknown aggregation dimension")
        return self._repo.report(None, (by,))[by]  # type: ignore[return-value]

    def total(self) -> dict[str, object]:
        return self._repo.report(None, ())["total"]  # type: ignore[return-value]

    def duplicates_ignored(self) -> int:
        with self._counter_lock:
            return self._duplicates

    def health(self) -> dict[str, int]:
        """Counts for this process only. Failures are visible here, never hidden as success."""
        with self._counter_lock:
            return {
                "appended": self._appended,
                "duplicates_ignored": self._duplicates,
                "storage_failures": self._storage_failures,
                "conflicts": self._conflicts,
            }

    def summary(self) -> dict[str, object]:
        """Everything above in one bounded view. Identifiers, counts and integers only."""
        report = self._repo.report(None)
        report["health"] = self.health()
        return report

    def close(self) -> None:
        self._repo.close()
