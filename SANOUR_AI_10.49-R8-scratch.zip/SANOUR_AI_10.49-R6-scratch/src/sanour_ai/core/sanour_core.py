"""SanourCore: single entry point. One provider attempt per request, under one total deadline.

The pipeline lives in ExecutionCoordinator (Stage 10.32). The Core keeps the public surface.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping

from sanour_ai.core.coordinator import CoordinatorStats, ExecutionCoordinator
from sanour_ai.models.capabilities import ModelProfile
from sanour_ai.models.gateway import ModelGateway
from sanour_ai.models.requests import SanourRequest
from sanour_ai.models.responses import SanourResponse
from sanour_ai.models.router import DeterministicRouter
from sanour_ai.observability.audit import AuditLogger
from sanour_ai.providers.registry import ShutdownTarget


class SanourCore:
    def __init__(
        self,
        router: DeterministicRouter,
        gateway: ModelGateway,
        audit: AuditLogger | None = None,
        provider_states: Callable[[], Mapping[str, str]] | None = None,
        required_audit: bool = True,
        governance: object | None = None,
    ) -> None:
        self._router = router
        self._gateway = gateway
        self._audit = audit or AuditLogger()
        self._coordinator = ExecutionCoordinator(
            self._resolve_profile, gateway, self._audit, provider_states=provider_states,
            required_audit=required_audit,
            governance=governance,
        )

    def _resolve_profile(self, request: SanourRequest) -> ModelProfile:
        # Explicit profile only: the caller named it; the Router never chooses among others.
        return self._router.resolve(request)

    def handle(self, raw: object) -> SanourResponse:
        return self._coordinator.execute(raw)

    def handle_with_result(self, raw: object):
        """Same pipeline as handle(). Returns (response, ExecutionResult or None) (Stage 10.37)."""
        return self._coordinator.execute_with_result(raw)

    def shutdown(self, timeout: float = 5.0) -> int:
        """Stop accepting new requests and close providers whose workers have finished."""
        return self._gateway.shutdown(timeout)

    def coordinator_stats(self) -> CoordinatorStats:
        return self._coordinator.stats()

    @property
    def audit(self) -> AuditLogger:
        return self._audit

    def audit_counters(self) -> dict:
        """Read-only audit health (counts and a fixed word)."""
        return self._audit.counters()

    def settlement_stats(self) -> dict:
        """Read-only settlement view of the gateway (counts and phase names)."""
        return self._gateway.settlement_snapshot()

    def gateway_stats(self):
        """Gateway counters snapshot (read-only)."""
        return self._gateway.stats()

    def shutdown_target(self) -> ShutdownTarget:
        """The explicit shutdown interface of the gateway, for the registry. No other internals."""
        return self._gateway
