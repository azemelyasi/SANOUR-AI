"""Execution Coordinator (Stage 10.32).

Orders the request pipeline and hands each step to the component that owns it:
validation to request_manager, profile choice to the Router, admission and execution to the
Gateway, and provider calls to adapters. It holds no provider logic.

Deadline: created once, here, from handle() start. It is passed unchanged to the gateway.
Audit: the same events and fields as before 10.32. Metrics: fixed-size counters only.
"""

from __future__ import annotations

import threading
import time
from dataclasses import replace
import uuid
from collections.abc import Callable, Mapping
from dataclasses import dataclass

from sanour_ai.core.lifecycle import RequestLifecycle, RequestState
from sanour_ai.core.request_manager import accept
from sanour_ai.errors import ErrorCode, SanourError
from sanour_ai.models.base import ModelCall
from sanour_ai.models.capabilities import ModelProfile
from sanour_ai.governance.types import Settlement
from sanour_ai.models.usage import usage_audit_fields
from sanour_ai.models.gateway import IDENTITY_MISMATCH_SCOPE, VALIDATION_OUTCOMES, CallObserver, ModelGateway
from sanour_ai.models.error_taxonomy import classify
from sanour_ai.models.execution import ExecutionResult
from sanour_ai.models.request_identity import REQUEST_IDENTITY_SCOPE, RequestIdentity
from sanour_ai.models.router import RoutingRefusal
from sanour_ai.models.requests import SanourRequest
from sanour_ai.models.responses import SanourResponse
from sanour_ai.observability.audit import AuditLogger

INTERNAL_ERROR_MESSAGE = "internal error while processing request"

R = RequestState
PRE_ADMISSION = frozenset({R.RECEIVED, R.VALIDATING, R.RESOLVED, R.WAITING_CAPACITY})
# Codes that mean "never admitted". Provider failure is included for an unregistered provider and
# for a shut-down gateway; both are refused before any worker is started.
REJECT_CODES = frozenset(
    {ErrorCode.INVALID_REQUEST, ErrorCode.NO_ELIGIBLE_MODEL, ErrorCode.PROVIDER_OVERLOADED,
     ErrorCode.PROVIDER_FAILED,
     # Stage 10.49: budget and quota refusals are raised before capacity or provider work.
     ErrorCode.PROVIDER_RATE_LIMITED}
)
_ERROR_KEYS = tuple(c.value for c in ErrorCode) + ("none",)
_VALIDATION_KEYS = tuple(sorted(VALIDATION_OUTCOMES)) + ("unclassified", "not_reached")
# Provider lifecycle states as the registry reports them. Anything else is dropped, never copied.
PROVIDER_STATE_VALUES = frozenset({"registered", "initializing", "ready", "closing", "closed", "failed"})
MAX_PROVIDER_ENTRIES = 64  # bounded metrics: the list cannot grow with traffic


class _LifecycleObserver(CallObserver):
    """Turns the gateway's two hooks into lifecycle moves. Holds no validation logic of its own."""

    def __init__(self, lifecycle: RequestLifecycle) -> None:
        self._lifecycle = lifecycle

    def on_admitted(self) -> None:
        self._lifecycle.move(R.EXECUTING)

    def on_validating(self) -> None:
        self._lifecycle.move(R.VALIDATING_RESPONSE)


def terminal_for(state: RequestState, code: ErrorCode | None) -> RequestState:
    """Map where a request was and the error it raised to one terminal state. Fail closed to failed."""
    if code is ErrorCode.PROVIDER_TIMEOUT:
        return R.TIMED_OUT if state in (R.WAITING_CAPACITY, R.EXECUTING) else R.FAILED
    if state in PRE_ADMISSION and code in REJECT_CODES:
        return R.REJECTED
    return R.FAILED


def _elapsed_ms(started: float) -> int:
    return int(round((time.monotonic() - started) * 1000))


@dataclass(frozen=True)
class CoordinatorStats:
    requests: int
    terminal_counts: dict[str, int]
    error_counts: dict[str, int]
    capacity_wait_ms_total: int
    capacity_wait_ms_max: int
    execution_ms_total: int
    execution_ms_max: int
    active_workers: int
    abandoned_workers: int
    validation_counts: dict[str, int]
    validation_ms_total: int
    validation_ms_max: int
    provider_states: dict[str, str]


AUDIT_UNAVAILABLE_MESSAGE = "audit unavailable; request not processed"
RESPONSE_WITHHELD_MESSAGE = "audit unavailable; response withheld"


class ExecutionCoordinator:
    def __init__(
        self,
        resolve: Callable[[SanourRequest], ModelProfile],
        gateway: ModelGateway,
        audit: AuditLogger | None = None,
        provider_states: Callable[[], Mapping[str, str]] | None = None,
        required_audit: bool = True,
        governance: object | None = None,
    ) -> None:
        # Stage 10.49: optional admission hook (admit / settle). None keeps the previous behaviour.
        self._governance = governance
        # Stage 10.45: when True (production), a failed write of a required event fails the request closed.
        self._required_audit = required_audit
        # `provider_states` is a live reader of the registry. It is never cached here.
        self._provider_states = provider_states
        # `resolve` is the Core's explicit-profile lookup (Router). The coordinator never selects.
        self._resolve = resolve
        self._gateway = gateway
        self._audit = audit or AuditLogger()
        self._lock = threading.Lock()
        self._requests = 0
        self._terminal = {s.value: 0 for s in (R.COMPLETED, R.FAILED, R.TIMED_OUT, R.REJECTED)}
        self._errors = {k: 0 for k in _ERROR_KEYS}
        self._wait_total = 0
        self._wait_max = 0
        self._exec_total = 0
        self._exec_max = 0
        self._validation = {k: 0 for k in _VALIDATION_KEYS}
        self._val_total = 0
        self._val_max = 0

    # ------------------------------------------------------------ pipeline
    def execute(self, raw: object) -> SanourResponse:
        response, _result = self.execute_with_result(raw)
        return response

    def execute_with_result(self, raw: object) -> tuple[SanourResponse, ExecutionResult | None]:
        """The same pipeline as execute(). Also returns the typed result on success, else None."""
        started = time.monotonic()
        request_id = uuid.uuid4().hex
        lifecycle = RequestLifecycle()
        holder: list[ExecutionResult] = []
        response = self._pipeline(raw, request_id, started, lifecycle, holder)
        completed = self._audit.emit(
            "request.completed",
            request_id=request_id,
            status=response.status,
            error_code=response.error.code.value if response.error else None,
            latency_ms=response.latency_ms,
        )
        if not completed and self._required_audit and response.status == "success":
            # Fail closed: the output is withheld when its completion cannot be recorded. Usage that
            # was received is kept with delivery "withheld". Failure to write the event below is only
            # counted by the audit health counters; there is no retry.
            if holder:
                holder[0] = replace(holder[0], delivery="withheld")
            self._audit.emit("response.withheld", request_id=request_id,
                             withheld_reason="completion_audit_unavailable")
            response = SanourResponse.failure(
                request_id=request_id,
                error=SanourError(ErrorCode.INTERNAL_ERROR, RESPONSE_WITHHELD_MESSAGE),
                latency_ms=_elapsed_ms(started),
            )
        self._record(lifecycle, response)
        return response, (holder[0] if holder else None)

    def _pipeline(
        self,
        raw: object,
        request_id: str,
        started: float,
        lifecycle: RequestLifecycle,
        holder: list[ExecutionResult],
    ) -> SanourResponse:
        try:
            lifecycle.move(R.VALIDATING)
            request = accept(raw, request_id)
            # The one deadline for this request. Created here and never recomputed downstream.
            deadline = started + request.timeout_seconds
            received = self._audit.emit("request.received", request_id=request_id, task_type=request.task_type)
            if not received and self._required_audit:
                # Fail closed: no provider call without a recorded admission.
                raise SanourError(ErrorCode.INTERNAL_ERROR, AUDIT_UNAVAILABLE_MESSAGE)
            return self._admit_and_execute(request, started, deadline, lifecycle, holder)
        except SanourError as exc:
            lifecycle.finish(terminal_for(lifecycle.state, exc.code))
            return SanourResponse.failure(
                request_id=request_id, error=exc, latency_ms=_elapsed_ms(started)
            )
        except Exception as exc:
            lifecycle.finish(R.FAILED)
            self._audit.emit(
                "request.internal_error", request_id=request_id, exc_type=type(exc).__name__
            )
            internal = SanourError(ErrorCode.INTERNAL_ERROR, INTERNAL_ERROR_MESSAGE)
            return SanourResponse.failure(
                request_id=request_id, error=internal, latency_ms=_elapsed_ms(started)
            )

    def _admit_and_execute(
        self,
        request: SanourRequest,
        started: float,
        deadline: float,
        lifecycle: RequestLifecycle,
        holder: list[ExecutionResult],
    ) -> SanourResponse:
        # Explicit profile only: the Router resolves the one profile the caller named, or refuses.
        try:
            profile = self._resolve(request)
        except RoutingRefusal as refusal:
            self._audit.emit("routing.auto_select_blocked", request_id=request.request_id,
                             reason=refusal.reason)
            raise
        lifecycle.move(R.RESOLVED)
        # One identity object for the rest of the request. Built after the profile was checked.
        identity = RequestIdentity.for_profile(request.request_id, profile)
        self._audit.emit("request.profile.resolved", **identity.log_fields())
        self._audit.emit("request.identity.created", **identity.log_fields())
        # Stage 10.49: budgets and quotas are reserved before capacity admission and before the provider.
        # A refusal raises here, so no capacity, worker or provider call is ever started for it.
        ticket = self._governance.admit(request, profile) if self._governance is not None else None
        call = ModelCall(
            model_id=profile.model_id,
            prompt=request.prompt,
            max_output_tokens=request.max_output_tokens,
            deadline=deadline,  # the same value the gateway receives
        )
        lifecycle.move(R.WAITING_CAPACITY)
        try:
            # The gateway checks shutdown, provider, capability, deadline and capacity, in that order.
            # on_admitted fires only after capacity is held, so EXECUTING means a worker is starting.
            result = self._gateway.generate(
                profile, call, deadline, observer=_LifecycleObserver(lifecycle), identity=identity
            )
        except SanourError as exc:
            self._settle_governed(ticket, lifecycle, exc)
            if lifecycle.state is R.VALIDATING_RESPONSE:
                # The gateway tagged the validation outcome. Record it; do not re-decide it.
                tagged = getattr(exc, "validation_outcome", None)
                lifecycle.record_validation(tagged if tagged in VALIDATION_OUTCOMES else "unclassified")
            if exc.scope == REQUEST_IDENTITY_SCOPE:
                self._audit.emit("request.identity.rejected", reason="identity_conflict",
                                 **identity.log_fields())
            if exc.scope == IDENTITY_MISMATCH_SCOPE:
                # Identifiers only. The provider's reported value is never logged.
                self._audit.emit("model.identity.mismatch", **identity.log_fields())
            self._audit.emit(
                "model.failed",
                request_id=request.request_id,
                model_alias=profile.alias,
                model_id=profile.model_id,
                error_code=exc.code.value,
                retryable=exc.retryable,
                capacity_scope=exc.scope,
                provider=profile.provider,
                status_code=exc.status_code,
                failure_reason=exc.failure_reason,
                error_kind=classify(exc).value,
            )
            raise
        except BaseException:
            # Not a SanourError: still settle the reservation, then let the error continue unchanged.
            self._settle_governed(ticket, lifecycle, None)
            raise
        # The gateway has checked the response and the identity. Refused outside validating_response.
        self._settle_governed(ticket, lifecycle, None, result=result)
        lifecycle.record_validation("passed")
        self._audit.emit("model.identity.validated", **identity.log_fields())
        self._audit.emit(
            "model.succeeded",
            request_id=request.request_id,
            model_alias=profile.alias,
            model_id=profile.model_id,
        )
        # Stage 10.47-R1: exactly one usage record per accepted completion. Counters only, never content.
        usage_audited = self._audit.emit(
            "usage.recorded",
            request_id=request.request_id,
            model_alias=profile.alias,
            model_id=profile.model_id,
            provider=profile.provider,
            api_surface=identity.api_surface,
            **usage_audit_fields(result.usage),
        )
        if not usage_audited and self._required_audit:
            # Fail closed: the output is withheld. The provider's usage is still kept for accounting
            # (status "withheld"), but the usage audit is reported as failed, never as recorded.
            holder.append(ExecutionResult(
                request_id=request.request_id,
                profile_id=profile.alias,
                provider_id=profile.provider,
                api_surface=identity.api_surface,
                requested_model_id=profile.model_id,
                provider_reported_model_id=result.reported_model_id,
                output=result.text,
                finish_status="completed",
                execution_ms=_elapsed_ms(started),
                usage=result.usage,
                usage_audit="failed",
                delivery="withheld",
            ))
            self._audit.emit("response.withheld", request_id=request.request_id,
                             withheld_reason="usage_audit_unavailable")
            raise SanourError(ErrorCode.INTERNAL_ERROR, RESPONSE_WITHHELD_MESSAGE)
        # Typed result: requested and reported identities stay separate; usage is not invented.
        holder.append(ExecutionResult(
            request_id=request.request_id,
            profile_id=profile.alias,
            provider_id=profile.provider,
            api_surface=identity.api_surface,
            requested_model_id=profile.model_id,
            provider_reported_model_id=result.reported_model_id,
            output=result.text,
            finish_status="completed",
            execution_ms=_elapsed_ms(started),
            usage=result.usage,
            usage_audit="recorded" if usage_audited else "failed",
            delivery="delivered",
        ))
        lifecycle.move(R.COMPLETED)
        return SanourResponse.success(
            request_id=request.request_id,
            output=result.text,
            model_alias=profile.alias,
            model_id=profile.model_id,
            latency_ms=_elapsed_ms(started),
        )

    def _settle_governed(self, ticket, lifecycle: RequestLifecycle, exc: SanourError | None, result=None) -> None:
        """Stage 10.49: settle the reservation exactly once. A request that never reached the provider releases it."""
        if ticket is None or self._governance is None:
            return
        started = lifecycle.entered_at(R.EXECUTING) is not None
        if result is not None:
            settlement = Settlement("completed", provider_started=True, usage=result.usage)
        elif exc is not None and exc.code is ErrorCode.PROVIDER_TIMEOUT:
            settlement = Settlement("timed_out", provider_started=started)
        else:
            settlement = Settlement("failed", provider_started=started)
        self._governance.settle(ticket, settlement)

    # ------------------------------------------------------------ metrics (bounded)
    def _record(self, lifecycle: RequestLifecycle, response: SanourResponse) -> None:
        end = lifecycle.entered_at(lifecycle.state) or time.monotonic()
        waiting = lifecycle.entered_at(R.WAITING_CAPACITY)
        executing = lifecycle.entered_at(R.EXECUTING)
        wait_ms = 0
        exec_ms = 0
        if waiting is not None:
            wait_end = executing if executing is not None else end
            wait_ms = max(0, int(round((wait_end - waiting) * 1000)))
        if executing is not None:
            exec_ms = max(0, int(round((end - executing) * 1000)))
        code = response.error.code.value if response.error else "none"
        validating = lifecycle.entered_at(R.VALIDATING_RESPONSE)
        val_ms = 0
        if validating is not None:
            val_ms = max(0, int(round((end - validating) * 1000)))
            outcome = lifecycle.validation_outcome or "unclassified"
        else:
            outcome = "not_reached"
        with self._lock:
            self._validation[outcome] += 1
            self._val_total += val_ms
            self._val_max = max(self._val_max, val_ms)
            self._requests += 1
            if lifecycle.state in self._terminal:
                self._terminal[lifecycle.state.value] += 1
            self._errors[code] += 1
            self._wait_total += wait_ms
            self._wait_max = max(self._wait_max, wait_ms)
            self._exec_total += exec_ms
            self._exec_max = max(self._exec_max, exec_ms)

    def _read_provider_states(self) -> dict[str, str]:
        if self._provider_states is None:
            return {}
        raw = self._provider_states()
        out: dict[str, str] = {}
        for name in sorted(raw)[:MAX_PROVIDER_ENTRIES]:
            value = raw[name]
            if isinstance(name, str) and value in PROVIDER_STATE_VALUES:
                out[name] = value
        return out

    def stats(self) -> CoordinatorStats:
        gw = self._gateway.stats()
        states = self._read_provider_states()
        with self._lock:
            return CoordinatorStats(
                requests=self._requests,
                terminal_counts=dict(self._terminal),
                error_counts=dict(self._errors),
                capacity_wait_ms_total=self._wait_total,
                capacity_wait_ms_max=self._wait_max,
                execution_ms_total=self._exec_total,
                execution_ms_max=self._exec_max,
                active_workers=gw.active_workers,
                abandoned_workers=gw.abandoned_in_flight,
                validation_counts=dict(self._validation),
                validation_ms_total=self._val_total,
                validation_ms_max=self._val_max,
                provider_states=states,
            )
