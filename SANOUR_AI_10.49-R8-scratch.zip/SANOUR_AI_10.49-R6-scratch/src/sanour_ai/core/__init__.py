"""Central orchestration core."""
