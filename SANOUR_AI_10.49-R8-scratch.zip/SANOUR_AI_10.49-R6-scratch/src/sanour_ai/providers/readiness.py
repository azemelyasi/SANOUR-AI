"""Provider readiness matrix (Stage 10.34). Generated from code, never typed in by hand.

Rules this file enforces:
- A capability is listed as VERIFIED only when models/provider_matrix.py marks its cell VERIFIED,
  which means an official document says so. That is documentation evidence, not live evidence.
- No test in this repository has contacted any provider API. So no adapter is production-ready.
  `production_ready` is False for every adapter until a live, reviewed verification exists.
- Fake transports prove the adapter's own logic only. They do not prove API compatibility.
- Unknown or undocumented behaviour is written as NOT VERIFIED. It is never guessed.
"""

from __future__ import annotations

from dataclasses import dataclass

from sanour_ai.models import provider_matrix as pm
from sanour_ai.providers.anthropic_provider import AnthropicProvider
from sanour_ai.providers.contract import contract_violations, identity_of
from sanour_ai.providers.gemini_provider import GeminiProvider
from sanour_ai.providers.grok_provider import GrokProvider
from sanour_ai.providers.openai_provider import OpenAIProvider
from sanour_ai.providers.xai_responses_provider import XaiResponsesProvider

# Registry key -> adapter class. This is the full list of adapters in the codebase.
ADAPTERS: dict[str, type] = {
    "openai": OpenAIProvider,
    "anthropic": AnthropicProvider,
    "gemini": GeminiProvider,
    "grok": GrokProvider,
    "grok_responses": XaiResponsesProvider,
}

# Written by hand, reviewed against the adapter source. Each claim names what the code does.
NOTES: dict[str, dict[str, str]] = {
    "openai": {
        "production_wiring": "Only provider that production composition can register. Needs SANOUR_PROVIDER=openai, the openai and httpx2 packages, and OPENAI_API_KEY.",
        "error_mapping": "SDK exceptions mapped to fixed messages. 429 is transient only for the documented code slow_down; billing and quota codes are allowlisted; raw SDK text never leaves.",
        "timeout": "ModelCall.deadline only. SDK per-phase timeouts are capped by the remaining budget. Trickled bodies can outlive the deadline (known limit).",
        "response_validation": "Only status completed is accepted. Empty or unknown model ids are refused by the gateway identity check.",
        "unverified": "Live Responses API behaviour. SDK-backed tests are skipped where the SDK is absent.",
    },
    "anthropic": {
        "production_wiring": "Adapter only. Not registered by production composition.",
        "error_mapping": "Status mapping with a 429 spend-cap allowlist (enforced_spend_limit_reached). Other 429s are not retryable.",
        "timeout": "Remaining budget per call through the shared send path. No retry.",
        "response_validation": "Parser of documented Messages fields. Gateway identity and non-empty text checks apply.",
        "unverified": "Adapter docstring: request and response details are NOT VERIFIED against current documentation in this environment.",
    },
    "gemini": {
        "production_wiring": "Adapter only. Not registered by production composition.",
        "error_mapping": "Status mapping. No 429 code is allowlisted; RESOURCE_EXHAUSTED is ambiguous and stays unknown.",
        "timeout": "Remaining budget per call through the shared send path. No retry.",
        "response_validation": "Blocked prompts and candidates raise a separate content-blocked error. Missing or unknown finish states are refused.",
        "unverified": "Adapter docstring: request and response details are NOT VERIFIED against current documentation in this environment.",
    },
    "grok": {
        "production_wiring": "Adapter only. Not registered by production composition.",
        "error_mapping": "Status mapping. No 429 code is allowlisted, so every 429 is unknown and not retryable.",
        "timeout": "Remaining budget per call through the shared send path. No retry.",
        "response_validation": "Only finish_reason stop is accepted. length is truncation. Other values are refused.",
        "unverified": "Adapter docstring: Chat Completions field names and finish values are NOT VERIFIED against current documentation.",
    },
    "grok_responses": {
        "production_wiring": "Adapter only. Never registered in production (Stage 10.34 keeps it disabled).",
        "error_mapping": "Status mapping. Only 400, 401, 403, 404 and 429 are documented. Other statuses fail closed, not retryable.",
        "timeout": "Remaining budget per call through the shared send path. No retry.",
        "response_validation": "Only status completed is accepted. Incomplete responses are treated as truncated. Refusal parts are invalid.",
        "unverified": "incomplete_details reasons, refusal parts and 5xx behaviour are NOT VERIFIED.",
    },
}

LIFECYCLE = "registered, initializing, ready, closing, closed, failed (registry-owned; close() is optional)"


@dataclass(frozen=True)
class Row:
    provider_id: str
    vendor: str
    surface: str
    auth_method: str
    declared: tuple[str, ...]
    verified: tuple[str, ...]
    unverified: tuple[str, ...]
    unsupported: tuple[str, ...]
    contract_ok: bool
    production_ready: bool
    notes: dict[str, str]


def _cells(surface: str, status: str) -> tuple[str, ...]:
    return tuple(c for c in pm.CAPABILITIES if pm.status(surface, c) == status)


def rows() -> list[Row]:
    out: list[Row] = []
    for pid, cls in ADAPTERS.items():
        ident = identity_of(cls)
        declared_caps = cls.capabilities.model_dump()
        declared = tuple(flag for flag, on in declared_caps.items() if on)
        out.append(
            Row(
                provider_id=pid,
                vendor=ident.vendor,
                surface=ident.surface,
                auth_method=ident.auth_method,
                declared=declared,
                verified=_cells(ident.surface, pm.VERIFIED),
                unverified=_cells(ident.surface, pm.UNVERIFIED),
                unsupported=_cells(ident.surface, pm.UNSUPPORTED),
                contract_ok=not contract_violations(cls),
                production_ready=False,  # no live verification exists; see module docstring
                notes=NOTES[pid],
            )
        )
    return out


def render_markdown() -> str:
    """The readiness document. Deterministic: the same code always gives the same text."""
    lines = [
        "# Provider Readiness Matrix",
        "",
        "Generated by `sanour_ai.providers.readiness.render_markdown()` (Stage 10.34). Do not edit by hand.",
        "",
        "**Read this first.** VERIFIED means an official document confirms the capability on that API",
        "surface. It does not mean a live call succeeded. No test in this repository has contacted any",
        "provider API, and fake transports prove only the adapter's own logic. So **no adapter is",
        "production-ready** in this stage, and every row says so.",
        "",
        f"Lifecycle support: {LIFECYCLE}.",
        "",
        "## Adapters",
        "",
        "| Provider ID | Vendor | API surface | Auth method | Declared | Contract | Production ready |",
        "|---|---|---|---|---|---|---|",
    ]
    for r in rows():
        lines.append(
            f"| `{r.provider_id}` | {r.vendor} | `{r.surface}` | `{r.auth_method}` | "
            f"{', '.join(r.declared) or 'none'} | {'conforms' if r.contract_ok else 'FAILS'} | "
            f"{'yes' if r.production_ready else 'no'} |"
        )
    lines += ["", "## Capabilities per API surface", "",
              "| API surface | Verified (documented) | Unverified | Unsupported |", "|---|---|---|---|"]
    for surface in pm.MATRIX:
        lines.append(
            f"| `{surface}` | {', '.join(_cells(surface, pm.VERIFIED)) or 'none'} | "
            f"{', '.join(_cells(surface, pm.UNVERIFIED)) or 'none'} | "
            f"{', '.join(_cells(surface, pm.UNSUPPORTED)) or 'none'} |"
        )
    lines += ["", "## Per-adapter notes", ""]
    for r in rows():
        lines += [f"### `{r.provider_id}`", ""]
        labels = [
            ("production_wiring", "Production wiring"),
            ("error_mapping", "Error mapping"),
            ("timeout", "Timeout support"),
            ("response_validation", "Response validation"),
            ("unverified", "Unverified"),
        ]
        for key, label in labels:
            lines.append(f"- **{label}:** {r.notes[key]}")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def render_capability_matrix_markdown() -> str:
    """MODEL_CAPABILITY_MATRIX.md, generated from the three capability levels (Stage 10.35)."""
    from sanour_ai.models import capability_intelligence as ci
    from sanour_ai.models.model_catalog import CATEGORIES

    lines = [
        "# Model Capability Matrix",
        "",
        "Generated by `sanour_ai.providers.readiness.render_capability_matrix_markdown()`. Do not edit by hand.",
        "",
        "Three levels, never merged:",
        "",
        "- **Provider/API (level 1):** the official documentation. A documented capability shows as DOCUMENTED_ONLY.",
        "- **Adapter (level 2):** what this repository's adapter declares. Shows as IMPLEMENTED_UNVERIFIED.",
        "- **Runtime verified (level 3):** a reviewed runtime test with a test reference. None exists here.",
        "",
        "Status values: VERIFIED, IMPLEMENTED_UNVERIFIED, DOCUMENTED_ONLY, UNSUPPORTED, UNKNOWN.",
        "A category with no matrix row is UNKNOWN. It is never inferred from a similar one.",
        "",
    ]
    for r in rows():
        lines += [f"## `{r.provider_id}` on `{r.surface}`", "",
                  "| Category | Provider/API | Adapter | Runtime verified |", "|---|---|---|---|"]
        caps = ADAPTERS[r.provider_id].capabilities
        table = ci.levels(r.provider_id, r.surface, caps)
        for category in CATEGORIES:
            cells = table[category]
            lines.append(
                f"| {category} | {cells[ci.Level.PROVIDER_API].value} | "
                f"{cells[ci.Level.ADAPTER].value} | {cells[ci.Level.RUNTIME_VERIFIED].value} |"
            )
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"
