"""Shared provider contract (Stage 10.34).

Every provider adapter follows this contract. The contract separates these responsibilities, and
each one has one owner:

- Provider identity (provider_id, registry key): the adapter's `name`, checked by the registry.
- Vendor identity (vendor): the company, from a fixed set in the registry.
- API surface (surface): the endpoint family, from models/provider_matrix.py.
- Authentication (auth_method): how the secret is attached. The secret itself comes only from
  config/governance.load_provider_secret. The adapter never reads the environment.
- Request mapping: the adapter's own `_build_request`, plus `prepare_call` and `send` below.
- Response mapping: the adapter's own parser, which returns a ModelResult or raises.
- Error classification: fixed messages and retry flags. Provider text never reaches callers.
- Lifecycle: close() and the registry. The registry owns the state, not the adapter.
- Capability declaration: `capabilities` (ProviderCapabilities). Only VERIFIED cells may be declared.

Shared logic lives here, not in each adapter: the call prologue (deadline and model-id checks), the
single send path (timeout budget, OS error mapping, post-deadline check), and conformance checks.

This module performs no I/O of its own and reads no environment.
"""

from __future__ import annotations

import re
import time
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from pydantic import SecretStr

from sanour_ai.errors import FailureKind
from sanour_ai.config.settings import ConfigError
from sanour_ai.models.base import ModelCall, ProviderError
from sanour_ai.models.capabilities import ProviderCapabilities
from sanour_ai.providers.common import DeadlineExpired, RequestTimeout

CONTRACT_VERSION = 1

# How a secret is attached to a request. A fixed set: a new method needs a reviewed change here.
AUTH_METHODS = frozenset({
    "sdk_bearer_client",      # OpenAI SDK client built from the adapter's key (validated per call)
    "bearer_header",          # Authorization: Bearer <key>
    "x_api_key_header",       # x-api-key: <key>
    "x_goog_api_key_header",  # x-goog-api-key: <key>
})

# Attributes every adapter class must declare. Checked by contract_violations and the registry.
REQUIRED_ATTRIBUTES = ("name", "vendor", "surface", "auth_method", "capabilities")


@dataclass(frozen=True)
class ProviderIdentity:
    provider_id: str
    vendor: str
    surface: str
    auth_method: str


def identity_of(adapter_cls: type) -> ProviderIdentity:
    """Identity as declared on the adapter class. Raises ValueError if a field is missing."""
    values = {f: getattr(adapter_cls, f, None) for f in ("name", "vendor", "surface", "auth_method")}
    if not all(isinstance(v, str) and v for v in values.values()):
        raise ValueError("adapter does not declare its identity")
    return ProviderIdentity(values["name"], values["vendor"], values["surface"], values["auth_method"])


def contract_violations(adapter: Any) -> list[str]:
    """Names of the contract rules the adapter breaks. Empty means it conforms. Never shows values."""
    problems: list[str] = []
    for attr in REQUIRED_ATTRIBUTES:
        if not hasattr(adapter, attr):
            problems.append(f"missing {attr}")
    if problems:
        return problems
    if not isinstance(getattr(adapter, "name", None), str) or not adapter.name:
        problems.append("name must be a non-empty string")
    if not callable(getattr(adapter, "generate", None)):
        problems.append("generate() is not callable")
    if not isinstance(getattr(adapter, "capabilities", None), ProviderCapabilities):
        problems.append("capabilities must be ProviderCapabilities")
    if getattr(adapter, "auth_method", None) not in AUTH_METHODS:
        problems.append("auth_method is not in the fixed set")
    close = getattr(adapter, "close", None)
    if close is not None and not callable(close):
        problems.append("close must be callable when present")
    return problems


def ensure_secret(api_key: object, env_name: str) -> SecretStr:
    """The only accepted credential type. The message names the setting, never the value."""
    if not isinstance(api_key, SecretStr) or not api_key.get_secret_value().strip():
        raise ConfigError(f"{env_name} must be set to a non-empty value")
    return api_key


def prepare_call(call: ModelCall, model_pattern: re.Pattern[str]) -> float:
    """Shared prologue for every HTTP adapter. Returns the remaining budget in seconds."""
    if call.deadline is None:
        raise ProviderError("request has no deadline", kind=FailureKind.DEADLINE_MISSING, retryable=False)
    if not model_pattern.match(call.model_id):
        raise ProviderError("model id is not a valid identifier", kind=FailureKind.INVALID_MODEL_ID, retryable=False)
    remaining = call.deadline - time.monotonic()
    if remaining <= 0:
        raise ProviderError("deadline expired before provider call", kind=FailureKind.DEADLINE_EXPIRED, retryable=True)
    return remaining


Transport = Callable[..., Any]


def send(
    transport: Transport,
    url: str,
    headers: dict[str, str],
    body: bytes,
    call: ModelCall,
    remaining: float,
) -> tuple[int, bytes, Any]:
    """Shared send path: one attempt, the remaining budget as timeout, no retry.

    Returns (status, raw body, response headers). Transport failures become a retryable connection
    error with no detail kept. A response that arrives after the deadline is refused.
    """
    try:
        result = transport(url, headers, body, RequestTimeout(remaining, call.deadline))
        status, raw = result
    except OSError as exc:  # URLError, socket timeouts and DeadlineExpired are OSError subclasses
        # The central request deadline decides, not the per-call timeout (Stage 10.38).
        # A failure observed at or after the deadline is a deadline failure; before it, a connection failure.
        if isinstance(exc, DeadlineExpired) or time.monotonic() >= call.deadline:
            raise ProviderError("deadline expired during provider call", kind=FailureKind.DEADLINE_IN_CALL,
                                retryable=True) from None
        raise ProviderError("provider connection failed", kind=FailureKind.CONNECTION, retryable=True) from None
    if time.monotonic() >= call.deadline:
        raise ProviderError("response arrived after deadline", kind=FailureKind.DEADLINE_LATE, retryable=True)
    return status, raw, getattr(result, "headers", {})
