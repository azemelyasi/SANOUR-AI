"""Google Gemini (Generative Language API) adapter. Text generation only.

- Endpoint host and path prefix are pinned. The model id is validated before it enters the path.
- Redirects are refused and environment proxies are ignored.
- Authentication: key read only from GEMINI_API_KEY (or an explicit SecretStr); sent in a header,
  never in the URL. It is never logged or copied into exception text.
- Deadline: ModelCall.deadline only; per-operation timeout is the remaining budget (no separate cap; see common.default_transport).
- No retry, no fallback, no auto-select.
- Response classification follows the official Gemini API reference (checked 2026-11-07):
  promptFeedback.blockReason, candidate finishReason values, and the x-goog-api-key header.
  Request fields generationConfig.maxOutputTokens are still NOT VERIFIED in this environment.
"""

from __future__ import annotations

import json
import re
from collections.abc import Mapping

from pydantic import SecretStr

from sanour_ai.errors import FailureKind
from sanour_ai.config.governance import ENV_GEMINI_API_KEY, load_provider_secret
from sanour_ai.providers.contract import ensure_secret, prepare_call, send
from sanour_ai.models.usage import usage_from_gemini
from sanour_ai.models.base import ModelCall, ModelResult, ProviderError
from sanour_ai.models.capabilities import ProviderCapabilities
from sanour_ai.providers.common import (
    fields_from_body,
    payment_error,
    rate_limit_error,
    MAX_RESPONSE_BYTES,
    OPENER,
    ContentBlockedError,
    IncompleteResponseError,
    RefuseRedirects,
    Transport,
)
from sanour_ai.providers.common import default_transport as common_default_transport

GEMINI_PROVIDER_NAME = "gemini"
PINNED_BASE = "https://generativelanguage.googleapis.com/v1beta/models/"
# Model ids become a URL path segment, so only plain identifiers are accepted.
_MODEL_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")



# Shared plumbing lives in providers/common.py. Aliases keep this module's names stable.
_RefuseRedirects = RefuseRedirects
_OPENER = OPENER
default_transport = common_default_transport


def load_gemini_api_key(environ: Mapping[str, str] | None = None) -> SecretStr:
    """Kept for existing callers. The loader is governance.load_provider_secret."""
    return load_provider_secret('gemini', environ)


# Allowlist: empty. No structural 429 code is confirmed for this provider, so every 429 is unknown
# (non-retryable). Gemini RESOURCE_EXHAUSTED is ambiguous by design and is never allowlisted.


def _map_status(status: int, raw: bytes | None = None, headers: dict[str, str] | None = None) -> ProviderError:
    if status == 429:
        # No structural 429 code is confirmed for this provider: unknown, not retryable.
        return rate_limit_error(fields_from_body(raw), {})
    if status == 402:
        return payment_error(fields_from_body(raw), {})
    if status == 401:
        return ProviderError("provider rejected credentials", kind=FailureKind.AUTHENTICATION, retryable=False)
    if status == 403:
        return ProviderError("provider denied permission", kind=FailureKind.PERMISSION, retryable=False)
    if status == 404:
        return ProviderError("provider model or endpoint not found", kind=FailureKind.MODEL_NOT_FOUND, retryable=False)
    if status == 400:
        return ProviderError("provider rejected request", kind=FailureKind.REQUEST_REJECTED, retryable=False)
    if status >= 500:
        return ProviderError("provider server error", kind=FailureKind.SERVER_ERROR, retryable=True)
    return ProviderError("provider call failed", kind=FailureKind.CALL_FAILED, retryable=False)


# Official block reasons for promptFeedback.blockReason (no candidates are returned).
# BLOCK_REASON_UNSPECIFIED is documented as unused, so it is treated as unknown (fail closed).
_PROMPT_BLOCK_REASONS = frozenset({"SAFETY", "OTHER", "BLOCKLIST", "PROHIBITED_CONTENT", "IMAGE_SAFETY"})
# Official candidate finish reasons that mean the content was withheld.
_CANDIDATE_BLOCK_REASONS = frozenset({"SAFETY", "BLOCKLIST", "PROHIBITED_CONTENT", "SPII", "IMAGE_SAFETY"})


def _parse_result(raw: bytes, requested_model: str) -> ModelResult:
    """Classify one generateContent body. Fails closed: only a complete, valid STOP is a success.

    Order: promptFeedback first (a blocked prompt returns no candidates), then the first candidate.
    Content blocked -> ContentBlockedError. Truncated -> IncompleteResponseError. Anything missing,
    malformed, or unknown -> IncompleteResponseError, which the gateway reports as invalid response.
    Block reasons and safety data are never copied into any error or log.
    """
    if len(raw) > MAX_RESPONSE_BYTES:
        raise ProviderError("provider response too large", kind=FailureKind.RESPONSE_TOO_LARGE, retryable=False)
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise IncompleteResponseError("response malformed", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False) from None
    if not isinstance(payload, dict):
        raise IncompleteResponseError("response malformed", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False)

    feedback = payload.get("promptFeedback")
    if feedback is not None:
        if not isinstance(feedback, dict):
            raise IncompleteResponseError("response malformed", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False)
        reason = feedback.get("blockReason")
        if reason:  # a non-empty value means the prompt was blocked
            if not isinstance(reason, str) or reason not in _PROMPT_BLOCK_REASONS:
                raise IncompleteResponseError("prompt feedback status unknown", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False)
            raise ContentBlockedError("provider blocked content", kind=FailureKind.CONTENT_BLOCKED, retryable=False)

    candidates = payload.get("candidates")
    if not isinstance(candidates, list) or not candidates or not isinstance(candidates[0], dict):
        raise IncompleteResponseError("response has no candidate", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False)
    candidate = candidates[0]

    finish = candidate.get("finishReason")
    if not isinstance(finish, str) or not finish:
        raise IncompleteResponseError("response status missing", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False)
    if finish == "MAX_TOKENS":
        raise IncompleteResponseError("response truncated by token limit", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False)
    if finish in _CANDIDATE_BLOCK_REASONS:
        raise ContentBlockedError("provider blocked content", kind=FailureKind.CONTENT_BLOCKED, retryable=False)
    if finish != "STOP":
        raise IncompleteResponseError("response status unknown", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False)

    content = candidate.get("content")
    parts = content.get("parts") if isinstance(content, dict) else None
    if not isinstance(parts, list) or not parts:
        raise IncompleteResponseError("response has no content", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False)
    pieces = []
    for part in parts:
        if not isinstance(part, dict):
            raise IncompleteResponseError("response content unexpected", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False)
        if "text" in part:
            if not isinstance(part["text"], str):
                raise IncompleteResponseError("response content unexpected", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False)
            pieces.append(part["text"])
        elif set(part) != {"thoughtSignature"}:
            # Any other part (function call, inline data, ...) is unexpected for this text-only
            # adapter. A bare thoughtSignature carries no answer text and is ignored.
            raise IncompleteResponseError("response content unexpected", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False)
    text = "".join(pieces)
    if not text.strip():
        raise IncompleteResponseError("response text empty", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False)

    model = payload.get("modelVersion")
    return ModelResult(text=text, reported_model_id=model if isinstance(model, str) else "",
                       usage=usage_from_gemini(payload.get("usageMetadata")))


class GeminiProvider:
    name = GEMINI_PROVIDER_NAME
    vendor = 'google'
    surface = 'gemini_generate_content'
    auth_method = 'x_goog_api_key_header'
    # Only text generation is implemented here. Tools, streaming and multimodal input are not.
    capabilities = ProviderCapabilities(text_generation=True)

    def __init__(self, api_key: SecretStr, *, transport: Transport | None = None) -> None:
        self._api_key = ensure_secret(api_key, ENV_GEMINI_API_KEY)
        self._transport: Transport = transport or default_transport

    def generate(self, call: ModelCall) -> ModelResult:
        remaining = prepare_call(call, _MODEL_ID)
        url = f"{PINNED_BASE}{call.model_id}:generateContent"
        headers = {
            "content-type": "application/json",
            "x-goog-api-key": self._api_key.get_secret_value(),
        }
        body = json.dumps(
            {
                "contents": [{"role": "user", "parts": [{"text": call.prompt}]}],
                "generationConfig": {"maxOutputTokens": call.max_output_tokens},
            }
        ).encode("utf-8")
        status, raw, resp_headers = send(self._transport, url, headers, body, call, remaining)
        if status != 200:
            raise _map_status(status, raw, resp_headers)
        return _parse_result(raw, call.model_id)

    def close(self) -> None:
        """No persistent client is held, so there is nothing to release."""
