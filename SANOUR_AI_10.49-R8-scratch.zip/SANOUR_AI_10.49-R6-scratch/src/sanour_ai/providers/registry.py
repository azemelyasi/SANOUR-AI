"""Unified Provider Registry (Stage 10.31). Registration, lifecycle, and capability gating.

Identity
- provider_id is the registry key and must equal the adapter's `name` (the gateway keys on it).
  It is NOT assumed to equal the API surface: xAI has two registrations (grok, grok_responses).
- vendor (openai | anthropic | google | xai) and surface (an API surface in provider_matrix) are
  explicit at registration. A vendor may only register surfaces that belong to it.

Capabilities
- An adapter may declare a capability only if provider_matrix marks it VERIFIED on its surface.
  Unverified and Unsupported flags are refused at registration. Nothing is enabled by name or by a
  setting. See provider_matrix.py for the source of every cell.

Lifecycle (per provider)
  registered -> initializing -> ready -> closing -> closed
                    \\-> failed     (initialization or close error)
  registered/failed providers that never reached the gateway are closed directly by shutdown().
  A closed provider is never ready again. A provider with a live worker stays "closing" until the
  worker really ends (the gateway decides), so its resources are not closed under the worker.

Contract summary (what every adapter provides; enforced by tests, not by inheritance)
- name, capabilities (ProviderCapabilities), generate(ModelCall) -> ModelResult, optional close().
- Deadline: ModelCall.deadline only. Timeouts: remaining budget. No retry, no fallback.
- Errors: ProviderError subclasses with fixed messages, plus internal failure_reason/status_code.
- Model identity: ModelResult.reported_model_id is checked by the gateway against the profile.
- Health: the registry state above. Nothing here reads provider health from the network.

This module performs no I/O and holds no secrets. Error messages name the provider id or the
setting, never a value.
"""

from __future__ import annotations

import re
import threading
from collections.abc import Mapping
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any, Protocol

from sanour_ai.models import provider_matrix as pm
from sanour_ai.models.capabilities import ProviderCapabilities
from sanour_ai.providers.contract import AUTH_METHODS

PROVIDER_ID = re.compile(r"^[a-z][a-z0-9_]{1,63}$")

VENDOR_SURFACES: Mapping[str, frozenset[str]] = {
    "openai": frozenset({"openai_responses"}),
    "anthropic": frozenset({"anthropic_messages"}),
    "google": frozenset({"gemini_generate_content"}),
    "xai": frozenset({"grok_chat_completions", "grok_responses"}),
}


class SettlementObserver(Protocol):
    def __call__(self, provider_id: str, outcome: str) -> None: ...


class SettlementObserver(Protocol):
    def __call__(self, provider_id: str, outcome: str) -> None: ...


class ShutdownTarget(Protocol):
    """The explicit interface the registry needs from the gateway to coordinate shutdown.

    It is the only thing the registry reads from the request path. Nothing else is shared.
    """

    def shutdown(self, timeout: float = 5.0) -> int: ...

    def provider_state(self, name: str) -> str: ...

    def add_settlement_observer(self, observer: SettlementObserver) -> None: ...


class RegistryError(Exception):
    """Registry refusal. Messages are fixed or name a provider id; never a secret or a value."""


class ProviderState(StrEnum):
    REGISTERED = "registered"
    INITIALIZING = "initializing"
    READY = "ready"
    CLOSING = "closing"
    CLOSED = "closed"
    FAILED = "failed"


# The only legal lifecycle moves. Any other move is refused. Closed is terminal.
TRANSITIONS: Mapping[ProviderState, frozenset[ProviderState]] = {
    ProviderState.REGISTERED: frozenset({ProviderState.INITIALIZING, ProviderState.CLOSING}),
    ProviderState.INITIALIZING: frozenset({ProviderState.READY, ProviderState.FAILED}),
    ProviderState.READY: frozenset({ProviderState.CLOSING}),
    ProviderState.CLOSING: frozenset({ProviderState.CLOSED, ProviderState.FAILED}),
    ProviderState.FAILED: frozenset({ProviderState.CLOSING}),
    ProviderState.CLOSED: frozenset(),
}


@dataclass
class _Entry:
    provider_id: str
    vendor: str
    surface: str
    adapter: Any
    state: ProviderState = ProviderState.REGISTERED
    close_attempted: bool = False  # set once; a close is never repeated
    notes: list[str] = field(default_factory=list)


def _check_adapter(provider_id: str, vendor: str, surface: str, adapter: Any) -> None:
    if not PROVIDER_ID.match(provider_id):
        raise RegistryError("provider id has an invalid format")
    if vendor not in VENDOR_SURFACES:
        raise RegistryError("unknown provider vendor")
    if surface not in pm.MATRIX:
        raise RegistryError("unknown API surface")
    if surface not in VENDOR_SURFACES[vendor]:
        raise RegistryError("API surface does not belong to this vendor")
    if getattr(adapter, "name", None) != provider_id:
        raise RegistryError("adapter name must equal the provider id")
    # Any identity the adapter declares must agree with the registration. Production adapters must
    # declare all of it (composition.production checks that with contract.contract_violations).
    if hasattr(adapter, "vendor"):
        if getattr(adapter, "vendor", None) != vendor:
            raise RegistryError("adapter vendor does not match the registration")
    if hasattr(adapter, "surface") and getattr(adapter, "surface") != surface:
        raise RegistryError("adapter API surface does not match the registration")
    if hasattr(adapter, "auth_method") and getattr(adapter, "auth_method") not in AUTH_METHODS:
        raise RegistryError("adapter authentication method is not in the fixed set")
    if not callable(getattr(adapter, "generate", None)):
        raise RegistryError("adapter must implement generate()")
    caps = getattr(adapter, "capabilities", None)
    if not isinstance(caps, ProviderCapabilities):
        raise RegistryError("adapter must declare ProviderCapabilities")
    declared = caps.model_dump()
    refused = pm.provider_flags_are_verified(surface, declared)
    if refused:
        # Name the flags: they are fixed capability names, not provider data.
        raise RegistryError("capabilities not verified on this API surface: " + ", ".join(refused))


class ProviderRegistry:
    def __init__(self) -> None:
        self._entries: dict[str, _Entry] = {}
        self._lock = threading.Lock()
        self._listeners: list = []  # callables () run once the registry is fully settled
        self._listener_errors: list[str] = []  # exception type names only
        self._announced = False

    # ------------------------------------------------------------ registration
    def register(self, provider_id: str, *, vendor: str, surface: str, adapter: Any) -> None:
        _check_adapter(provider_id, vendor, surface, adapter)
        with self._lock:
            if provider_id in self._entries:
                raise RegistryError("provider id is already registered")
            self._entries[provider_id] = _Entry(provider_id, vendor, surface, adapter)

    def remove(self, provider_id: str) -> None:
        """Remove a provider that is not serving traffic (registered, failed or closed)."""
        with self._lock:
            entry = self._require(provider_id)
            if entry.state in (ProviderState.READY, ProviderState.INITIALIZING, ProviderState.CLOSING):
                raise RegistryError("provider is active; shut it down before removing it")
            del self._entries[provider_id]

    # ------------------------------------------------------------ lifecycle
    @staticmethod
    def _move(entry: _Entry, to: ProviderState) -> None:
        """Every state write goes through here. Caller holds the lock."""
        if to not in TRANSITIONS[entry.state]:
            raise RegistryError("provider state transition is not allowed")
        entry.state = to

    def initialize(self, provider_id: str) -> ProviderState:
        with self._lock:
            entry = self._require(provider_id)
            if entry.state is not ProviderState.REGISTERED:
                raise RegistryError("provider is not in the registered state")
            self._move(entry, ProviderState.INITIALIZING)
        try:
            init = getattr(entry.adapter, "initialize", None)
            if callable(init):
                init()
        except Exception:
            with self._lock:
                self._move(entry, ProviderState.FAILED)
            raise RegistryError("provider initialization failed") from None
        with self._lock:
            self._move(entry, ProviderState.READY)
        return ProviderState.READY

    def shutdown(self, gateway: ShutdownTarget, timeout: float = 5.0) -> dict[str, str]:
        """Central shutdown. Idempotent: closed providers are never closed again.

        Ready providers are handed to the gateway's shutdown, which waits for live workers and
        closes idle providers once each. Providers that never reached the gateway are closed here.
        A failing close is isolated to its provider. Returns the visible state of every provider.
        """
        with self._lock:
            in_gateway = []
            direct = []
            for entry in self._entries.values():
                if entry.state is ProviderState.READY:
                    self._move(entry, ProviderState.CLOSING)
                    entry.close_attempted = True
                    in_gateway.append(entry)
                elif entry.state is ProviderState.CLOSING:
                    in_gateway.append(entry)  # still open from an earlier shutdown: resolve it
                elif entry.state in (ProviderState.REGISTERED, ProviderState.FAILED) and not entry.close_attempted:
                    self._move(entry, ProviderState.CLOSING)
                    entry.close_attempted = True
                    direct.append(entry)
        gateway.shutdown(timeout)
        for entry in direct:
            self._close_direct(entry)
        with self._lock:
            for entry in in_gateway:
                if entry.state is not ProviderState.CLOSING:
                    continue
                status = gateway.provider_state(entry.provider_id)
                if status == "closed":
                    self._move(entry, ProviderState.CLOSED)
                elif status == "failed":
                    self._move(entry, ProviderState.FAILED)
                # "open": the gateway still has a live worker; stays CLOSING until a later shutdown.
            result = {pid: e.state.value for pid, e in self._entries.items()}
        self._notify_if_settled()
        return result

    def on_provider_settled(self, provider_id: str, outcome: str) -> None:
        """Event from the gateway: a provider's close finished. Idempotent: only CLOSING moves."""
        target = {"closed": ProviderState.CLOSED, "failed": ProviderState.FAILED}.get(outcome)
        if target is None:
            return
        with self._lock:
            entry = self._entries.get(provider_id)
            if entry is None or entry.state is not ProviderState.CLOSING:
                return
            self._move(entry, target)
        self._notify_if_settled()

    def add_settlement_listener(self, listener) -> None:
        with self._lock:
            self._listeners.append(listener)

    def _notify_if_settled(self) -> None:
        """Announce "everything settled" once per episode. Repeated shutdown() calls do not re-announce."""
        with self._lock:
            settled = all(e.state in (ProviderState.CLOSED, ProviderState.FAILED) for e in self._entries.values())
            if not settled:
                self._announced = False
                listeners = []
            elif self._announced:
                listeners = []
            else:
                self._announced = True
                listeners = list(self._listeners)
        for listener in listeners:
            try:
                listener()
            except Exception as exc:
                with self._lock:
                    self._listener_errors.append(type(exc).__name__)

    def _close_direct(self, entry: _Entry) -> None:
        close = getattr(entry.adapter, "close", None)
        ok = True
        if callable(close):
            try:
                close()
            except Exception as exc:
                ok = False
                entry.notes.append(type(exc).__name__)
        with self._lock:
            self._move(entry, ProviderState.CLOSED if ok else ProviderState.FAILED)

    # ------------------------------------------------------------ reads
    def state(self, provider_id: str) -> ProviderState:
        with self._lock:
            return self._require(provider_id).state

    def states(self) -> dict[str, str]:
        with self._lock:
            return {pid: e.state.value for pid, e in self._entries.items()}

    def describe(self, provider_id: str) -> dict[str, str]:
        with self._lock:
            e = self._require(provider_id)
            return {"provider_id": e.provider_id, "vendor": e.vendor, "surface": e.surface,
                    "state": e.state.value}

    def ready_providers(self) -> dict[str, Any]:
        """Adapters that may serve requests, keyed by provider id. Only READY entries."""
        with self._lock:
            return {pid: e.adapter for pid, e in self._entries.items() if e.state is ProviderState.READY}

    def validate_profile(self, provider_id: str, flags: Mapping[str, bool]) -> None:
        """A profile may only use provider capabilities that are READY and VERIFIED on its surface."""
        with self._lock:
            entry = self._require(provider_id)
            if entry.state is not ProviderState.READY:
                raise RegistryError("provider is not ready")
            surface = entry.surface
        refused = pm.provider_flags_are_verified(surface, dict(flags))
        if refused:
            raise RegistryError("profile requests capabilities not verified on this API surface: "
                                + ", ".join(refused))

    def _require(self, provider_id: str) -> _Entry:
        entry = self._entries.get(provider_id)
        if entry is None:
            raise RegistryError("provider is not registered")
        return entry
