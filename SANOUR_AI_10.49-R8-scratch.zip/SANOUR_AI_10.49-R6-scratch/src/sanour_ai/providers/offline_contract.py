"""Stage 10.46-R3: the test-provider contract for the test factories.

Two rules decide what a test factory may build with:

1. Identity denylist. Every concrete production adapter that can reach the network is listed here
   by its imported class object. An instance of any of them is refused, whatever its name, whatever
   the SDK state, and whatever the environment says.
2. Explicit allowlist. The only permitted providers are instances of OfflineTestProvider (or a
   subclass a test defines). Anything else, including a plain duck-typed object, is refused.

No decision here uses a class name string. The offline fake makes no network call and reads no
credential.
"""

from __future__ import annotations

from sanour_ai.config.settings import ConfigError
from sanour_ai.models.base import ModelResult
from sanour_ai.models.capabilities import ProviderCapabilities
from sanour_ai.providers.anthropic_provider import AnthropicProvider
from sanour_ai.providers.gemini_provider import GeminiProvider
from sanour_ai.providers.grok_provider import GrokProvider
from sanour_ai.providers.openai_provider import OPENAI_PROVIDER_NAME, OpenAIProvider
from sanour_ai.providers.xai_responses_provider import XaiResponsesProvider

# Every network-capable production adapter in the codebase (matches providers.readiness.ADAPTERS).
PRODUCTION_ADAPTERS: tuple[type, ...] = (
    OpenAIProvider,
    AnthropicProvider,
    GeminiProvider,
    GrokProvider,
    XaiResponsesProvider,
)


class OfflineTestProvider:
    """The explicit test-provider contract. Offline only: no network, no credential, no SDK.

    Subclass it to inject a test double. Override generate() for custom behaviour. The default
    answer is fixed text, so a request through it can never leave the process.
    """

    name = OPENAI_PROVIDER_NAME
    vendor = "openai"
    surface = "openai_responses"
    auth_method = "sdk_bearer_client"
    capabilities = ProviderCapabilities(text_generation=True)

    def initialize(self) -> None:
        pass

    def generate(self, call) -> ModelResult:
        return ModelResult(text="offline test response", reported_model_id=call.model_id)

    def close(self) -> None:
        pass


def check_test_provider(adapter: object) -> None:
    """Raise ConfigError unless the adapter is a permitted offline test provider. Fixed messages."""
    if isinstance(adapter, PRODUCTION_ADAPTERS):
        raise ConfigError("test factories never accept a production adapter")
    if not isinstance(adapter, OfflineTestProvider):
        raise ConfigError("test factories accept only offline test providers")
