"""Shared HTTP plumbing for the urllib-based adapters (Anthropic, Gemini, Grok) and shared error types.

Independent of any SDK. The OpenAI adapter re-exports RateLimitedError from here.
- Redirects are refused. Environment proxies are ignored (ProxyHandler with an empty mapping).
- Error response bodies are never read, so they cannot leak into exception text.
- Response size is capped; oversized responses are refused by the caller.
"""

from __future__ import annotations

import http.client
import json
import re
import socket
import time
import urllib.error
import urllib.request
from collections.abc import Callable, Mapping

from sanour_ai.errors import FailureKind
from sanour_ai.models.base import ProviderError

MAX_RESPONSE_BYTES = 2_000_000
# Error bodies are inspected only up to this size. Larger bodies are classified as unknown.
MAX_ERROR_BODY_BYTES = 4096
MAX_RETRY_AFTER_SECONDS = 3600
_RETRY_AFTER = re.compile(r"[0-9]{1,6}")

# Categories an allowlist entry may assign. Anything not listed is unknown.
CATEGORY_TRANSIENT = "transient"
CATEGORY_QUOTA = "quota"
CATEGORY_BILLING = "billing"
# Structural fields that may be used for classification. message is never read.
# details_code is error.details.error_code (Anthropic documents it for spend-cap 429s).
ALLOWED_ERROR_FIELDS = ("code", "status", "type", "details_code")
# Response headers the adapters may read. Everything else is dropped at the transport.
ALLOWED_RESPONSE_HEADERS = ("retry-after", "content-type")
_HEADER_MAX_CHARS = 256

Transport = Callable[[str, dict[str, str], bytes, float], tuple[int, bytes]]


class RateLimitedError(ProviderError):
    """Transient rate limit only. Produced when a documented structural code says so.

    The gateway keeps its provider_rate_limited code. Quota, billing and unknown 429s are not this
    class: they are ProviderError with a failure_reason and retryable=False.
    """

    error_code = "provider_rate_limited"


class IncompleteResponseError(ProviderError):
    """The provider's end-of-response status is not a complete, known success.

    Covers both a response cut off by a token limit and a missing or unrecognised status.
    Such a response is never returned as a successful result. The gateway reports it as
    PROVIDER_INVALID_RESPONSE, which is not retryable.
    """

    error_code = "provider_invalid_response"


class ContentBlockedError(ProviderError):
    """The provider withheld its answer because the prompt or the candidate was blocked.

    Not an incomplete or invalid response, and never retryable: the same input is blocked again.
    It deliberately does not derive from IncompleteResponseError, so the two never merge.
    Its text is fixed. Provider block reasons and safety data are never copied into it.
    """

    error_code = "provider_content_blocked"


class RefuseRedirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise urllib.error.HTTPError(req.full_url, code, "redirect refused", headers, None)


OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}), RefuseRedirects())


class HttpResult(tuple):
    """(status, body) that also carries the allowlisted response headers.

    It unpacks exactly like the plain tuple every transport used to return, so existing callers and
    fake transports keep working. Adapters read `.headers` only through the allowlist above.
    """

    headers: dict

    def __new__(cls, status: int, body: bytes, headers: dict | None = None) -> "HttpResult":
        obj = tuple.__new__(cls, (status, body))
        obj.headers = dict(headers or {})
        return obj


def _allowed_headers(message: object) -> dict[str, str]:
    """Copy only the allowlisted headers, as short strings. Never the whole header set."""
    out: dict[str, str] = {}
    if message is None:
        return out
    for name in ALLOWED_RESPONSE_HEADERS:
        try:
            value = message.get(name)  # type: ignore[attr-defined]
        except Exception:
            value = None
        if isinstance(value, str) and value.strip() and len(value) <= _HEADER_MAX_CHARS:
            out[name] = value.strip()
    return out


class DeadlineExpired(OSError):
    """The request deadline passed during connect or read. Subclasses OSError, so adapters map it
    to a connection failure. It is never retried inside the transport."""


class RequestTimeout(float):
    """Per-operation timeout in seconds that also carries the absolute deadline it came from.

    A float, so existing transports and tests that only read a number keep working. The default
    transport reads `deadline` to check the shared budget between reads.
    """

    deadline: float

    def __new__(cls, seconds: float, deadline: float) -> "RequestTimeout":
        obj = float.__new__(cls, seconds)
        obj.deadline = deadline
        return obj


# Injectable clock for tests. Production uses the monotonic clock only.
_now = time.monotonic
# Largest single read. Keeps each recv small so the deadline is checked often.
READ_CHUNK_BYTES = 8192


def _socket_of(stream: object) -> object | None:
    """Underlying socket of an http.client response, if reachable. CPython detail, optional."""
    try:
        return stream.fp.raw._sock  # type: ignore[attr-defined]
    except AttributeError:
        return None


def _set_socket_timeout(sock: object | None, seconds: float) -> None:
    if sock is not None:
        try:
            sock.settimeout(max(seconds, 0.001))  # type: ignore[attr-defined]
        except OSError:
            pass


def _read_bounded(stream: object, limit: int, deadline: float, expected: int | None) -> bytes:
    """Read at most `limit` bytes in small pieces, checking the shared deadline before each read.

    read1 returns as soon as any bytes arrive, so a trickling server cannot hold a call past the
    deadline. A short body that is shorter than Content-Length, or cut off by http.client, is an
    incomplete response and is never returned as a success.
    """
    chunks: list[bytes] = []
    received = 0
    sock = _socket_of(stream)
    while received < limit:
        remaining = deadline - _now()
        if remaining <= 0:
            raise DeadlineExpired("deadline expired while reading the response")
        _set_socket_timeout(sock, remaining)
        try:
            piece = stream.read1(min(READ_CHUNK_BYTES, limit - received))  # type: ignore[attr-defined]
        except socket.timeout:
            raise DeadlineExpired("deadline expired while reading the response") from None
        except (http.client.HTTPException, ValueError):
            raise IncompleteResponseError("response incomplete", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False) from None
        if not piece:
            break
        chunks.append(piece)
        received += len(piece)
    body = b"".join(chunks)
    if expected is not None and received < min(expected, limit):
        raise IncompleteResponseError("response incomplete", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False)
    return body


def _expected_length(response: object) -> int | None:
    try:
        raw = response.headers.get("Content-Length")  # type: ignore[attr-defined]
    except AttributeError:
        return None
    if isinstance(raw, str) and raw.strip().isdigit():
        return int(raw.strip())
    return None


def default_transport(url: str, headers: dict[str, str], body: bytes, timeout: float) -> HttpResult:
    """Single HTTPS POST under one shared deadline.

    - Connect and each socket read use min(timeout, remaining). The deadline is never extended.
    - The body is read in bounded pieces with a deadline check before each piece.
    - Success bodies are capped at MAX_RESPONSE_BYTES + 1; error bodies at MAX_ERROR_BODY_BYTES + 1.
      Oversized bodies are detectable by length and never parsed in full.
    - Truncated bodies raise IncompleteResponseError. Deadline expiry raises DeadlineExpired.
    - Redirects are refused and environment proxies are ignored (OPENER, unchanged).
    """
    deadline = getattr(timeout, "deadline", None)
    if deadline is None:
        deadline = _now() + float(timeout)
    remaining = deadline - _now()
    if remaining <= 0:
        raise DeadlineExpired("deadline expired before the request was sent")
    request = urllib.request.Request(url, data=body, headers=headers, method="POST")
    try:
        response = OPENER.open(request, timeout=min(float(timeout), remaining))
    except urllib.error.HTTPError as err:
        raw = b""
        if err.fp is not None:
            try:
                with err.fp:
                    raw = _read_bounded(err.fp, MAX_ERROR_BODY_BYTES + 1, deadline,
                                        _expected_length(err))
            except (DeadlineExpired, IncompleteResponseError, OSError):
                raw = b""  # the status code is still known; an unusable body stays unknown
        return HttpResult(err.code, raw, _allowed_headers(err.headers))
    with response:
        raw = _read_bounded(response, MAX_RESPONSE_BYTES + 1, deadline, _expected_length(response))
        return HttpResult(response.status, raw, _allowed_headers(response.headers))



def fields_from_error_object(obj: object) -> dict[str, str] | None:
    """Structural string fields of one error object. Values are kept only as allowlist keys."""
    if not isinstance(obj, dict):
        return None
    fields: dict[str, str] = {}
    for key in ("code", "status", "type"):
        value = obj.get(key)
        if isinstance(value, str):
            fields[key] = value
    details = obj.get("details")
    if isinstance(details, dict) and isinstance(details.get("error_code"), str):
        fields["details_code"] = details["error_code"]
    return fields


def fields_from_body(raw: bytes | None) -> dict[str, str] | None:
    """Parse an error body fail-closed. None means unusable: oversized, empty, not JSON, no error."""
    if not isinstance(raw, (bytes, bytearray)) or not raw or len(raw) > MAX_ERROR_BODY_BYTES:
        return None
    try:
        doc = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError, RecursionError):
        return None
    if not isinstance(doc, dict):
        return None
    return fields_from_error_object(doc.get("error"))


def resolve_category(fields: Mapping[str, str] | None, allow: Mapping[str, Mapping[str, str]]) -> str | None:
    """Category when exactly one allowlisted value matches. Missing, unknown or conflicting: None."""
    if not fields:
        return None
    found: set[str] = set()
    for key in ALLOWED_ERROR_FIELDS:
        value = fields.get(key)
        if value is None:
            continue
        category = allow.get(key, {}).get(value)
        if category is not None:
            found.add(category)
    return found.pop() if len(found) == 1 else None


def rate_limit_error(
    fields: Mapping[str, str] | None,
    allow: Mapping[str, Mapping[str, str]],
    *,
    retry_after: int | None = None,
) -> ProviderError:
    """Classify an HTTP 429. Only an allowlisted transient code is retryable."""
    category = resolve_category(fields, allow)
    if category == CATEGORY_TRANSIENT:
        return RateLimitedError("provider rate limited", kind=FailureKind.RATE_LIMIT, retryable=True, status_code=429, retry_after_seconds=retry_after
        )
    reason = category if category in (CATEGORY_QUOTA, CATEGORY_BILLING) else "unknown"
    return ProviderError("provider limit reached", kind=FailureKind.LIMIT_REACHED, retryable=False, status_code=429, failure_reason=reason)


def payment_error(fields: Mapping[str, str] | None, allow: Mapping[str, Mapping[str, str]]) -> ProviderError:
    """Classify an HTTP 402. Billing only when allowlisted; otherwise unknown. Never retryable."""
    reason = "billing" if resolve_category(fields, allow) == CATEGORY_BILLING else "unknown"
    return ProviderError("provider payment required", kind=FailureKind.PAYMENT_REQUIRED, retryable=False, status_code=402, failure_reason=reason)


def parse_retry_after(value: object) -> int | None:
    """Retry-After as a bounded hint in seconds. Only plain digits are accepted. Never sleeps."""
    if not isinstance(value, str):
        return None
    text = value.strip()
    if not _RETRY_AFTER.fullmatch(text):
        return None
    return min(int(text), MAX_RETRY_AFTER_SECONDS)
