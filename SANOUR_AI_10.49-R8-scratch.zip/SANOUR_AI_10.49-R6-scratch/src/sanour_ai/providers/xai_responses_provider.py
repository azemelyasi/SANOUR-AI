"""xAI Responses API adapter (POST /v1/responses). Text generation only. Not wired to production.

Official contract used (docs.x.ai, checked 2026-11-07):
- Endpoint https://api.x.ai/v1/responses, JSON body, Authorization: Bearer <key> header.
- Request: model, input (string), max_output_tokens. store is sent explicitly as false, because the
  documented default is true.
- Response: model (may differ from the requested alias, so the gateway allowlist applies),
  status (completed | in_progress | incomplete), output[] items. A message item holds
  content[] parts of type output_text. reasoning items carry no answer text and are skipped.
- Errors: 400, 401, 403, 404, 429 are documented in the debugging page. Other statuses are NOT
  VERIFIED, so they fail closed (not retryable).

NOT VERIFIED here: incomplete_details.reason values (the official reference page does not list them,
so every incomplete response is treated as truncated), refusal content parts (treated as invalid),
and any 5xx behaviour.

Deadline: ModelCall.deadline only. No retry, no fallback, no auto-select. The Chat Completions
adapter (grok_provider.py) is kept unchanged and is still the only registered xAI adapter.
"""

from __future__ import annotations

import json
import re
from collections.abc import Mapping

from pydantic import SecretStr

from sanour_ai.errors import FailureKind
from sanour_ai.config.governance import ENV_XAI_API_KEY
from sanour_ai.providers.contract import ensure_secret, prepare_call, send
from sanour_ai.models.usage import usage_from_openai_style
from sanour_ai.models.base import ModelCall, ModelResult, ProviderError
from sanour_ai.models.capabilities import ProviderCapabilities
from sanour_ai.providers.common import (
    MAX_RESPONSE_BYTES,
    IncompleteResponseError,
    Transport,
    fields_from_body,
    parse_retry_after,
    payment_error,
    rate_limit_error,
)
from sanour_ai.providers.common import default_transport as common_default_transport

XAI_RESPONSES_PROVIDER_NAME = "grok_responses"
PINNED_URL = "https://api.x.ai/v1/responses"
# Same identifier shape as the other adapters. Model ids are sent in the body only.
_MODEL_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")

default_transport = common_default_transport


def _map_status(status: int, raw: bytes | None = None, headers: Mapping[str, str] | None = None) -> ProviderError:
    if status == 429:
        # Documented as the rate limit, with no structural code: unknown, so not retryable.
        return rate_limit_error(fields_from_body(raw), {},
                                retry_after=parse_retry_after((headers or {}).get("retry-after")))
    if status == 402:
        return payment_error(fields_from_body(raw), {})
    if status == 401:
        return ProviderError("provider rejected credentials", kind=FailureKind.AUTHENTICATION, retryable=False)
    if status == 403:
        return ProviderError("provider denied permission", kind=FailureKind.PERMISSION, retryable=False)
    if status == 404:
        return ProviderError("provider model or endpoint not found", kind=FailureKind.MODEL_NOT_FOUND, retryable=False)
    if status == 400:
        return ProviderError("provider rejected request", kind=FailureKind.REQUEST_REJECTED, retryable=False)
    # 5xx and other statuses are not documented for this endpoint: fail closed.
    return ProviderError("provider call failed", kind=FailureKind.CALL_FAILED, retryable=False)


def _parse_result(raw: bytes) -> ModelResult:
    """Only a completed response with a message of output_text parts is a success."""
    if len(raw) > MAX_RESPONSE_BYTES:
        raise ProviderError("provider response too large", kind=FailureKind.RESPONSE_TOO_LARGE, retryable=False)
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError, RecursionError):
        raise IncompleteResponseError("response malformed", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False) from None
    if not isinstance(payload, dict):
        raise IncompleteResponseError("response malformed", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False)
    if payload.get("error") is not None:
        raise IncompleteResponseError("response reported an error", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False)
    status = payload.get("status")
    if status == "incomplete":
        raise IncompleteResponseError("response incomplete", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False)
    if status != "completed":
        raise IncompleteResponseError("response status unknown", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False)
    output = payload.get("output")
    if not isinstance(output, list) or not output:
        raise IncompleteResponseError("response has no output", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False)
    pieces: list[str] = []
    for item in output:
        if not isinstance(item, dict):
            raise IncompleteResponseError("response output unexpected", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False)
        kind = item.get("type")
        if kind == "reasoning":
            continue  # reasoning items carry no answer text
        if kind != "message" or item.get("status", "completed") != "completed":
            raise IncompleteResponseError("response output unexpected", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False)
        content = item.get("content")
        if not isinstance(content, list):
            raise IncompleteResponseError("response output unexpected", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False)
        for part in content:
            if (not isinstance(part, dict) or part.get("type") != "output_text"
                    or not isinstance(part.get("text"), str)):
                raise IncompleteResponseError("response content unexpected", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False)
            pieces.append(part["text"])
    text = "".join(pieces)
    if not text.strip():
        raise IncompleteResponseError("response text empty", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False)
    model = payload.get("model")
    return ModelResult(text=text, reported_model_id=model if isinstance(model, str) else "",
                       usage=usage_from_openai_style(payload.get("usage")))


class XaiResponsesProvider:
    name = XAI_RESPONSES_PROVIDER_NAME
    vendor = "xai"
    surface = "grok_responses"
    auth_method = "bearer_header"
    capabilities = ProviderCapabilities(text_generation=True)

    def __init__(self, api_key: SecretStr, *, transport: Transport | None = None) -> None:
        self._api_key = ensure_secret(api_key, ENV_XAI_API_KEY)
        self._transport: Transport = transport or default_transport

    def generate(self, call: ModelCall) -> ModelResult:
        remaining = prepare_call(call, _MODEL_ID)
        headers = {
            "content-type": "application/json",
            "authorization": f"Bearer {self._api_key.get_secret_value()}",
        }
        body = json.dumps({
            "model": call.model_id,
            "input": call.prompt,
            "max_output_tokens": call.max_output_tokens,
            "store": False,
        }).encode("utf-8")
        status, raw, resp_headers = send(self._transport, PINNED_URL, headers, body, call, remaining)
        if status != 200:
            raise _map_status(status, raw, resp_headers)
        return _parse_result(raw)

    def close(self) -> None:
        """No persistent client is held, so there is nothing to release."""
