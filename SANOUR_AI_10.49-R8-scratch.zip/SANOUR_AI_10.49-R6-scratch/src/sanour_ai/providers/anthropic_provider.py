"""Anthropic Messages API adapter. Text generation only. No retries, no fallback, no auto-select.

- Endpoint is pinned in code. Redirects are refused. Environment proxies are ignored.
- Authentication: the key is read only from ANTHROPIC_API_KEY (or an explicit SecretStr) and is
  never logged, stored in a plain string, or copied into an exception message.
- Deadline: the only deadline is ModelCall.deadline. The per-operation timeout is the remaining budget (no separate cap; see common.default_transport).
- Transport is injectable. Tests use a fake transport; no network is used in this repository.
- Live behaviour of the API is NOT VERIFIED here (no network, no key, no SDK).
"""

from __future__ import annotations

import json
import re
from collections.abc import Mapping

from pydantic import SecretStr

from sanour_ai.errors import FailureKind
from sanour_ai.config.governance import ENV_ANTHROPIC_API_KEY, load_provider_secret
from sanour_ai.providers.contract import ensure_secret, prepare_call, send
from sanour_ai.models.usage import usage_from_anthropic
from sanour_ai.models.base import ModelCall, ModelResult, ProviderError
from sanour_ai.models.capabilities import ProviderCapabilities
from sanour_ai.providers.common import (
    CATEGORY_BILLING,
    MAX_RESPONSE_BYTES,
    OPENER,
    IncompleteResponseError,
    RateLimitedError,
    RefuseRedirects,
    Transport,
    fields_from_body,
    parse_retry_after,
    payment_error,
    rate_limit_error,
    resolve_category,
)
from sanour_ai.providers.common import default_transport as common_default_transport

ANTHROPIC_PROVIDER_NAME = "anthropic"
# Same identifier rule as the other adapters, so model ids behave identically everywhere.
_MODEL_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
PINNED_URL = "https://api.anthropic.com/v1/messages"
# Current version per Anthropic versioning and migration guides (checked 2026-11-07). The changes it
# removes (document blocks in assistant turns, citations in user turns, temperature/top_p/top_k) are
# not sent by this adapter.
ANTHROPIC_VERSION = "2026-10-21"



# Shared plumbing lives in providers/common.py. Aliases keep this module's names stable.
_RefuseRedirects = RefuseRedirects
_OPENER = OPENER
default_transport = common_default_transport


def load_anthropic_api_key(environ: Mapping[str, str] | None = None) -> SecretStr:
    """Kept for existing callers. The loader is governance.load_provider_secret."""
    return load_provider_secret('anthropic', environ)


# Spend cap: error.details.error_code == enforced_spend_limit_reached (rate-limits page). Non-retryable.
ANTHROPIC_SPEND_CAP = {"details_code": {"enforced_spend_limit_reached": "billing"}}
ANTHROPIC_402 = {"type": {"billing_error": "billing"}}
RATE_LIMIT_TYPE = "rate_limit_error"


def _anthropic_429(fields: dict[str, str] | None, headers: dict[str, str]) -> ProviderError:
    """Anthropic 429. Documented: a spend-cap 429 has no retry-after header and carries the
    enforced_spend_limit_reached details code. A transient rate limit is rate_limit_error with a
    retry-after header and without that details code. Anything else is unknown (non-retryable).
    """
    if resolve_category(fields, ANTHROPIC_SPEND_CAP) == CATEGORY_BILLING:
        return ProviderError("provider limit reached", kind=FailureKind.LIMIT_REACHED, retryable=False, status_code=429,
                             failure_reason="billing")
    retry_after = parse_retry_after(headers.get("retry-after"))
    if (fields and fields.get("type") == RATE_LIMIT_TYPE and "details_code" not in fields
            and retry_after is not None):
        return RateLimitedError("provider rate limited", kind=FailureKind.RATE_LIMIT, retryable=True, status_code=429,
                                retry_after_seconds=retry_after)
    return rate_limit_error(fields, {})


def _map_status(status: int, raw: bytes | None = None, headers: dict[str, str] | None = None) -> ProviderError:
    if status == 429:
        return _anthropic_429(fields_from_body(raw), headers or {})
    if status == 402:
        return payment_error(fields_from_body(raw), ANTHROPIC_402)
    if status == 401:
        return ProviderError("provider rejected credentials", kind=FailureKind.AUTHENTICATION, retryable=False)
    if status == 403:
        return ProviderError("provider denied permission", kind=FailureKind.PERMISSION, retryable=False)
    if status == 404:
        return ProviderError("provider model or endpoint not found", kind=FailureKind.MODEL_NOT_FOUND, retryable=False)
    if status == 400:
        return ProviderError("provider rejected request", kind=FailureKind.REQUEST_REJECTED, retryable=False)
    if status == 529 or status >= 500:
        return ProviderError("provider server error", kind=FailureKind.SERVER_ERROR, retryable=True)
    return ProviderError("provider call failed", kind=FailureKind.CALL_FAILED, retryable=False)


def _parse_result(raw: bytes) -> ModelResult:
    """Anything unexpected yields an empty result, which the gateway rejects as invalid."""
    if len(raw) > MAX_RESPONSE_BYTES:
        raise ProviderError("provider response too large", kind=FailureKind.RESPONSE_TOO_LARGE, retryable=False)
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return ModelResult(text="", reported_model_id="")
    if not isinstance(payload, dict):
        return ModelResult(text="", reported_model_id="")
    # NOT VERIFIED field name and values: "end_turn" and "stop_sequence" count as complete.
    stop = payload.get("stop_reason")
    if stop == "max_tokens":
        raise IncompleteResponseError("response truncated by token limit", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False)
    if stop not in ("end_turn", "stop_sequence"):
        raise IncompleteResponseError("response status unknown", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False)
    blocks = payload.get("content")
    text = ""
    if isinstance(blocks, list):
        text = "".join(
            block.get("text", "")
            for block in blocks
            if isinstance(block, dict) and block.get("type") == "text" and isinstance(block.get("text"), str)
        )
    model = payload.get("model")
    return ModelResult(text=text, reported_model_id=model if isinstance(model, str) else "",
                       usage=usage_from_anthropic(payload.get("usage")))


class AnthropicProvider:
    name = ANTHROPIC_PROVIDER_NAME
    vendor = 'anthropic'
    surface = 'anthropic_messages'
    auth_method = 'x_api_key_header'
    # Only text generation is implemented. Tools, streaming and multimodal input are not.
    capabilities = ProviderCapabilities(text_generation=True)

    def __init__(self, api_key: SecretStr, *, transport: Transport | None = None) -> None:
        self._api_key = ensure_secret(api_key, ENV_ANTHROPIC_API_KEY)
        self._transport: Transport = transport or default_transport

    def generate(self, call: ModelCall) -> ModelResult:
        remaining = prepare_call(call, _MODEL_ID)
        headers = {
            "content-type": "application/json",
            "x-api-key": self._api_key.get_secret_value(),
            "anthropic-version": ANTHROPIC_VERSION,
        }
        body = json.dumps(
            {
                "model": call.model_id,
                "max_tokens": call.max_output_tokens,
                "messages": [{"role": "user", "content": call.prompt}],
            }
        ).encode("utf-8")
        status, raw, resp_headers = send(self._transport, PINNED_URL, headers, body, call, remaining)
        if status != 200:
            raise _map_status(status, raw, resp_headers)
        return _parse_result(raw)

    def close(self) -> None:
        """No persistent client is held, so there is nothing to release."""
