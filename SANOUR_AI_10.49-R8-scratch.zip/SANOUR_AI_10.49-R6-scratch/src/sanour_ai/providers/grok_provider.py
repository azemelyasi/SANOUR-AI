"""xAI Grok adapter. Text generation only.

- Endpoint is pinned to one HTTPS URL. The model id is validated and sent in the JSON body, never in the URL.
- Redirects are refused and environment proxies are ignored.
- Authentication: key read only from XAI_API_KEY (or an explicit SecretStr); sent as a bearer header,
  never in the URL. It is never logged or copied into exception text.
- Deadline: ModelCall.deadline only; per-operation timeout is the remaining budget (no separate cap; see common.default_transport).
- No retry, no fallback, no auto-select.
- Request and response field names follow the OpenAI-compatible chat shape as understood at
  implementation time. They are NOT VERIFIED against current xAI documentation in this environment (no network).
"""

from __future__ import annotations

import json
import re

from pydantic import SecretStr

from sanour_ai.errors import FailureKind
from sanour_ai.config.governance import ENV_XAI_API_KEY, load_provider_secret
from sanour_ai.providers.contract import ensure_secret, prepare_call, send
from sanour_ai.models.usage import usage_from_chat_completions
from sanour_ai.models.base import ModelCall, ModelResult, ProviderError
from sanour_ai.models.capabilities import ProviderCapabilities
from sanour_ai.providers.common import (
    fields_from_body,
    payment_error,
    rate_limit_error,
    MAX_RESPONSE_BYTES,
    OPENER,
    IncompleteResponseError,
    RefuseRedirects,
    Transport,
)
from sanour_ai.providers.common import default_transport as common_default_transport

GROK_PROVIDER_NAME = "grok"
PINNED_URL = "https://api.x.ai/v1/chat/completions"
# Model ids are sent in the body only, but are still restricted to plain identifiers.
_MODEL_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")



# Shared plumbing lives in providers/common.py. Aliases keep this module's names stable.
_RefuseRedirects = RefuseRedirects
_OPENER = OPENER
default_transport = common_default_transport


def load_xai_api_key(environ: Mapping[str, str] | None = None) -> SecretStr:
    """Kept for existing callers. The loader is governance.load_provider_secret."""
    return load_provider_secret('grok', environ)


# Allowlist: empty. No structural 429 code is confirmed for this provider, so every 429 is unknown
# (non-retryable). Gemini RESOURCE_EXHAUSTED is ambiguous by design and is never allowlisted.


def _map_status(status: int, raw: bytes | None = None, headers: dict[str, str] | None = None) -> ProviderError:
    if status == 429:
        # No structural 429 code is confirmed for this provider: unknown, not retryable.
        return rate_limit_error(fields_from_body(raw), {})
    if status == 402:
        return payment_error(fields_from_body(raw), {})
    if status == 401:
        return ProviderError("provider rejected credentials", kind=FailureKind.AUTHENTICATION, retryable=False)
    if status == 403:
        return ProviderError("provider denied permission", kind=FailureKind.PERMISSION, retryable=False)
    if status == 404:
        return ProviderError("provider model or endpoint not found", kind=FailureKind.MODEL_NOT_FOUND, retryable=False)
    if status == 400:
        return ProviderError("provider rejected request", kind=FailureKind.REQUEST_REJECTED, retryable=False)
    if status >= 500:
        return ProviderError("provider server error", kind=FailureKind.SERVER_ERROR, retryable=True)
    return ProviderError("provider call failed", kind=FailureKind.CALL_FAILED, retryable=False)


def _parse_result(raw: bytes) -> ModelResult:
    """Unexpected shapes yield an empty result, which the gateway rejects as invalid."""
    if len(raw) > MAX_RESPONSE_BYTES:
        raise ProviderError("provider response too large", kind=FailureKind.RESPONSE_TOO_LARGE, retryable=False)
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return ModelResult(text="", reported_model_id="")
    if not isinstance(payload, dict):
        return ModelResult(text="", reported_model_id="")
    text = ""
    choices = payload.get("choices")
    if isinstance(choices, list) and choices and isinstance(choices[0], dict):
        # NOT VERIFIED field name and values: "stop" is complete, "length" is truncated.
        finish = choices[0].get("finish_reason")
        if finish == "length":
            raise IncompleteResponseError("response truncated by token limit", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False)
        if finish != "stop":
            raise IncompleteResponseError("response status unknown", kind=FailureKind.INCOMPLETE_RESPONSE, retryable=False)
        message = choices[0].get("message")
        content = message.get("content") if isinstance(message, dict) else None
        if isinstance(content, str):
            text = content
    model = payload.get("model")
    return ModelResult(text=text, reported_model_id=model if isinstance(model, str) else "",
                       usage=usage_from_chat_completions(payload.get("usage")))


class GrokProvider:
    name = GROK_PROVIDER_NAME
    vendor = 'xai'
    surface = 'grok_chat_completions'
    auth_method = 'bearer_header'
    # Only text generation is implemented here. Tools, streaming and multimodal input are not.
    capabilities = ProviderCapabilities(text_generation=True)

    def __init__(self, api_key: SecretStr, *, transport: Transport | None = None) -> None:
        self._api_key = ensure_secret(api_key, ENV_XAI_API_KEY)
        self._transport: Transport = transport or default_transport

    def generate(self, call: ModelCall) -> ModelResult:
        remaining = prepare_call(call, _MODEL_ID)
        headers = {
            "content-type": "application/json",
            "authorization": f"Bearer {self._api_key.get_secret_value()}",
        }
        body = json.dumps(
            {
                "model": call.model_id,
                "messages": [{"role": "user", "content": call.prompt}],
                "max_tokens": call.max_output_tokens,
                "stream": False,
            }
        ).encode("utf-8")
        status, raw, resp_headers = send(self._transport, PINNED_URL, headers, body, call, remaining)
        if status != 200:
            raise _map_status(status, raw, resp_headers)
        return _parse_result(raw)

    def close(self) -> None:
        """No persistent client is held, so there is nothing to release."""
