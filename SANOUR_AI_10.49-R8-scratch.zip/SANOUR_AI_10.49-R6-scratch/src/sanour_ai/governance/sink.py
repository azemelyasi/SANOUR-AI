"""Audit sink contract and the durable SQLite sink (Stage 10.49-R4).

Contract
--------
deliver(outbox_key, event, fields) returns an AuditReceipt only after the sink's own durable commit has returned.
Every other outcome raises one of three classified exceptions:

- SinkFailed: the sink definitively did NOT record the event (failure before the commit started, or the commit
  was rolled back). Safe to retry; the event is not on record.
- SinkOutcomeUnknown: the sink cannot tell whether it recorded the event (failure while the commit itself was in
  flight). Retrying is safe only because the sink de-duplicates on outbox_key.
- SinkPayloadConflict: the same outbox_key was already recorded with a different payload. Fail closed: nothing is
  recorded, the original record stands, and the event is never retried automatically.

A standard Python logging handler is NOT a sink under this contract: it has no durable commit and it swallows its
own write errors. This module is the only sink implementation the outbox trusts.

Durable deduplication
---------------------
The receipt row and the inbox row (outbox_key -> digest, receipt_id) are written in ONE BEGIN IMMEDIATE transaction.
A duplicate key with the same digest returns the original receipt (duplicate=True) and writes nothing. A duplicate
key with a different digest raises SinkPayloadConflict. Writers are serialized by SQLite's write lock, so two
processes cannot both insert the same key. The database is WAL with synchronous=FULL, so a returned receipt has
been fsynced.

Limits: this is exactly-once at the sink's storage level only. End-to-end exactly-once delivery is not claimed.
The sink is a separate database file from the governance database, so the governance commit and the sink commit
cannot be one transaction. The outbox (governance side) closes that gap with at-least-once delivery plus this
deduplication.
"""

from __future__ import annotations

import contextlib
import json
import sqlite3
import threading
import time
from collections.abc import Callable

from sanour_ai.governance.sink_contract import (
    OUTBOX_KEY_MAX, AuditReceipt, SinkFailed, SinkOutcomeUnknown, SinkPayloadConflict, payload_digest,
)

_SCHEMA = """
CREATE TABLE IF NOT EXISTS audit_receipts (
    receipt_id INTEGER PRIMARY KEY AUTOINCREMENT,
    outbox_key TEXT NOT NULL UNIQUE CHECK (length(outbox_key) BETWEEN 1 AND 96),
    event TEXT NOT NULL,
    fields TEXT NOT NULL,
    recorded_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS audit_inbox (
    outbox_key TEXT PRIMARY KEY CHECK (length(outbox_key) BETWEEN 1 AND 96),
    digest TEXT NOT NULL CHECK (length(digest) = 64),
    receipt_id INTEGER NOT NULL REFERENCES audit_receipts (receipt_id)
);
"""


class DurableSqliteSink:
    """A durable audit sink in its own SQLite file. Thread-safe within a process; safe across processes."""

    def __init__(self, path: str, clock: Callable[[], float] = time.time) -> None:
        self._lock = threading.Lock()
        self._clock = clock
        self._conn = sqlite3.connect(path, timeout=10.0, isolation_level=None, check_same_thread=False)
        self._conn.execute("PRAGMA busy_timeout=10000")
        if path != ":memory:":
            mode = self._conn.execute("PRAGMA journal_mode=WAL").fetchone()
            if mode is None or str(mode[0]).lower() != "wal":
                raise SinkFailed("sink storage refused WAL mode")
        self._conn.execute("PRAGMA synchronous=FULL")
        self._conn.executescript(_SCHEMA)

    def close(self) -> None:
        with self._lock:
            with contextlib.suppress(sqlite3.Error):
                self._conn.close()

    def deliver(self, outbox_key: str, event: str, fields: dict) -> AuditReceipt:
        if not isinstance(outbox_key, str) or not (1 <= len(outbox_key) <= OUTBOX_KEY_MAX):
            raise SinkFailed("invalid outbox key")
        digest = payload_digest(event, fields)
        with self._lock:
            try:
                self._conn.execute("BEGIN IMMEDIATE")
            except sqlite3.Error:
                raise SinkFailed("sink unavailable") from None
            try:
                row = self._conn.execute("SELECT receipt_id, digest FROM audit_inbox WHERE outbox_key = ?",
                                         (outbox_key,)).fetchone()
                if row is not None:
                    self._conn.execute("ROLLBACK")
                    if row[1] != digest:
                        raise SinkPayloadConflict("outbox key already recorded with a different payload")
                    return AuditReceipt(int(row[0]), outbox_key, True)
                cursor = self._conn.execute(
                    "INSERT INTO audit_receipts (outbox_key, event, fields, recorded_at) VALUES (?, ?, ?, ?)",
                    (outbox_key, event, json.dumps(fields, sort_keys=True, default=str), int(self._clock())))
                receipt_id = int(cursor.lastrowid)
                self._conn.execute("INSERT INTO audit_inbox (outbox_key, digest, receipt_id) VALUES (?, ?, ?)",
                                   (outbox_key, digest, receipt_id))
            except SinkPayloadConflict:
                raise
            except sqlite3.Error:
                with contextlib.suppress(sqlite3.Error):
                    self._conn.execute("ROLLBACK")
                raise SinkFailed("sink write failed; nothing recorded") from None
            try:
                self._conn.execute("COMMIT")
            except sqlite3.Error:
                # The commit was in flight. The sink cannot prove the record is absent.
                with contextlib.suppress(sqlite3.Error):
                    self._conn.execute("ROLLBACK")
                raise SinkOutcomeUnknown("sink commit outcome not known") from None
            return AuditReceipt(receipt_id, outbox_key, False)

    def record_count(self) -> int:
        with self._lock:
            return int(self._conn.execute("SELECT COUNT(*) FROM audit_receipts").fetchone()[0])
