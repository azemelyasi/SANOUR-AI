"""Budget Manager (Stage 10.49-R1). Three separate money figures per budget and UTC window:

- spent:    ACTUAL cost. Only valid provider usage priced by a pricing version creates it.
- reserved: in-flight worst case. Held only while a request is being admitted or executed.
- exposed:  UNCERTAIN provider exposure. The request reached the provider, but its usage is unknown or
            invalid. The amount stays reserved against the budget, and it is never reported as spending.

Availability = limit - spent - reserved - exposed. Every applicable budget must have room (the strictest governs).
A budget applies only to pricing in its own currency. Unknown cost against an applicable budget is refused.
Runs inside the caller's transaction. Money is Decimal text. All arithmetic happens in Python.
"""

from __future__ import annotations

import sqlite3
from decimal import Decimal

from sanour_ai.governance.cost import PricingVersion, format_money
from sanour_ai.governance.types import BudgetLine, Refusal

OUTCOME_ACTUAL = "actual"
OUTCOME_EXPOSED = "exposed"
OUTCOME_RELEASED = "released"


def window_for(period: str, utc_day: str) -> str:
    return utc_day if period == "daily" else utc_day[:7]


def applicable(conn: sqlite3.Connection, provider_id: str, model_id: str, profile_id: str) -> list[tuple]:
    return conn.execute(
        "SELECT budget_id, scope_type, period, currency, limit_amount FROM budgets "
        "WHERE scope_type = 'global' OR (scope_type = 'provider' AND scope_value = ?) "
        "OR (scope_type = 'model' AND scope_value = ?) OR (scope_type = 'profile' AND scope_value = ?) "
        "ORDER BY budget_id",
        (provider_id, model_id, profile_id),
    ).fetchall()


def totals(conn: sqlite3.Connection, budget_id: int, window: str) -> tuple[Decimal, Decimal, Decimal]:
    """(reserved, spent, exposed) for one budget window. Missing row means zero."""
    row = conn.execute("SELECT reserved, spent, exposed FROM budget_windows WHERE budget_id = ? AND window_start = ?",
                       (budget_id, window)).fetchone()
    if row is None:
        return Decimal(0), Decimal(0), Decimal(0)
    return Decimal(row[0]), Decimal(row[1]), Decimal(row[2])


def _store(conn: sqlite3.Connection, budget_id: int, window: str, reserved: Decimal, spent: Decimal,
           exposed: Decimal) -> None:
    if reserved < 0 or exposed < 0 or spent < 0:
        raise ValueError("budget window invariant violated")
    conn.execute(
        "INSERT INTO budget_windows (budget_id, window_start, reserved, spent, exposed) VALUES (?, ?, ?, ?, ?) "
        "ON CONFLICT (budget_id, window_start) DO UPDATE SET reserved = excluded.reserved, "
        "spent = excluded.spent, exposed = excluded.exposed",
        (budget_id, window, format_money(reserved), format_money(spent), format_money(exposed)),
    )


def check_and_reserve(conn: sqlite3.Connection, rows: list[tuple], pricing: PricingVersion | None,
                      worst_case: Decimal | None, utc_day: str) -> list[BudgetLine]:
    lines: list[BudgetLine] = []
    for budget_id, scope_type, period, currency, limit_text in rows:
        if pricing is None or worst_case is None or pricing.currency != currency:
            raise Refusal("budget", "cost_unknown", scope_type, period)
        window = window_for(period, utc_day)
        reserved, spent, exposed = totals(conn, budget_id, window)
        if reserved + spent + exposed + worst_case > Decimal(limit_text):
            raise Refusal("budget", "budget_exceeded", scope_type, period)
        lines.append(BudgetLine(budget_id, scope_type, period, currency, window, worst_case))
    return lines


def write_reservation(conn: sqlite3.Connection, request_id: str, lines: list[BudgetLine]) -> None:
    for line in lines:
        conn.execute(
            "INSERT INTO reservation_lines (request_id, line_kind, line_id, window_start, amount, outcome) "
            "VALUES (?, 'budget', ?, ?, ?, 'open')",
            (request_id, line.budget_id, line.window_start, format_money(line.amount)),
        )
        reserved, spent, exposed = totals(conn, line.budget_id, line.window_start)
        _store(conn, line.budget_id, line.window_start, reserved + line.amount, spent, exposed)


def open_lines(conn: sqlite3.Connection, request_id: str) -> list[tuple[int, str, Decimal]]:
    return [(int(r[0]), r[1], Decimal(r[2])) for r in conn.execute(
        "SELECT line_id, window_start, amount FROM reservation_lines WHERE request_id = ? AND line_kind = 'budget' "
        "AND outcome = 'open' ORDER BY line_id", (request_id,))]


def apply(conn: sqlite3.Connection, request_id: str, actual: Decimal | None, release: bool) -> list[str]:
    """Move each open reserved line to its outcome. release: nothing charged or exposed. actual: charge
    spent. None (and not release): the amount becomes exposure. The reserved amount always leaves reserved."""
    outcomes = []
    for budget_id, window, amount in open_lines(conn, request_id):
        reserved, spent, exposed = totals(conn, budget_id, window)
        new_reserved = reserved - amount
        if release:
            outcome = OUTCOME_RELEASED
        elif actual is not None:
            outcome, spent = OUTCOME_ACTUAL, spent + actual
        else:
            outcome, exposed = OUTCOME_EXPOSED, exposed + amount
        _store(conn, budget_id, window, new_reserved, spent, exposed)
        conn.execute("UPDATE reservation_lines SET outcome = ? WHERE request_id = ? AND line_kind = 'budget' "
                     "AND line_id = ? AND window_start = ?", (outcome, request_id, budget_id, window))
        outcomes.append(outcome)
    return outcomes


def exposed_lines(conn: sqlite3.Connection, request_id: str) -> list[tuple[int, str, Decimal]]:
    return [(int(r[0]), r[1], Decimal(r[2])) for r in conn.execute(
        "SELECT line_id, window_start, amount FROM reservation_lines WHERE request_id = ? AND line_kind = 'budget' "
        "AND outcome = 'exposed' ORDER BY line_id", (request_id,))]


def resolve_exposed(conn: sqlite3.Connection, request_id: str, actual: Decimal) -> None:
    """Replace uncertain exposure with a verified actual cost. Only the exposed lines move."""
    for budget_id, window, amount in exposed_lines(conn, request_id):
        reserved, spent, exposed = totals(conn, budget_id, window)
        _store(conn, budget_id, window, reserved, spent + actual, exposed - amount)
        conn.execute("UPDATE reservation_lines SET outcome = ? WHERE request_id = ? AND line_kind = 'budget' "
                     "AND line_id = ? AND window_start = ?", (OUTCOME_ACTUAL, request_id, budget_id, window))


def written_off_amount(conn: sqlite3.Connection, budget_id: int, window: str) -> Decimal:
    row = conn.execute("SELECT written_off FROM budget_windows WHERE budget_id = ? AND window_start = ?",
                       (budget_id, window)).fetchone()
    return Decimal(0) if row is None else Decimal(row[0])


def write_off(conn: sqlite3.Connection, request_id: str) -> int:
    """Explicit operator write-off of exposed budget lines. Exposure leaves availability and moves to written_off.
    It is never added to spent: a write-off is not an actual cost. Returns how many lines were written off."""
    count = 0
    for budget_id, window, amount in exposed_lines(conn, request_id):
        reserved, spent, exposed = totals(conn, budget_id, window)
        _store(conn, budget_id, window, reserved, spent, exposed - amount)
        conn.execute("UPDATE budget_windows SET written_off = ? WHERE budget_id = ? AND window_start = ?",
                     (format_money(written_off_amount(conn, budget_id, window) + amount), budget_id, window))
        conn.execute("UPDATE reservation_lines SET outcome = 'written_off' WHERE request_id = ? AND "
                     "line_kind = 'budget' AND line_id = ? AND window_start = ?", (request_id, budget_id, window))
        count += 1
    return count
