"""Read-only governance reconciliation (Stage 10.49-R6).

Opens every database with SQLite's read-only URI mode. It never runs migrations, never writes, never repairs, and
never calls a governance transaction. It reports what it finds and leaves every decision to an operator.

Sections of the report:
- reservations and their lifecycle states (pending, uncertain exposure, pending settlement);
- budget and quota windows, recomputed from reservation lines and compared with the stored totals;
- the audit outbox (failed, unknown, pending, conflicts) and, optionally, the sink's receipts;
- optionally, the usage ledger, compared with the governance outcome of each request;
- findings: orphaned and inconsistent records, each with a code, severity and subject.

Limits: budget `spent` and quota `used` are not recomputed from lines (their actual amounts come from priced usage,
which lines do not store). They are reported as not recomputable, never as verified.
"""

from __future__ import annotations

import argparse
import json
import os
import sqlite3
import time
from decimal import Decimal
from pathlib import Path

TERMINAL_STATES = ("settled", "exposed", "released", "written_off")
GOVERNANCE_OPERATIONS_NEEDING_REQUEST = (
    "settle_intent", "settle_apply", "recovery_apply", "recovery_expire", "recovery_release",
    "verified_usage", "write_off", "retain",
)


class ReconcileError(RuntimeError):
    """The inputs cannot be opened read-only. The message names the input role, never its content."""


def _open_ro(path: str, role: str) -> sqlite3.Connection:
    if not isinstance(path, str) or path == ":memory:" or not os.path.isfile(path):
        raise ReconcileError(f"{role} database is not an existing file")
    uri = Path(path).resolve().as_uri() + "?mode=ro"
    try:
        return sqlite3.connect(uri, uri=True, timeout=10)
    except sqlite3.Error:
        raise ReconcileError(f"{role} database cannot be opened read-only") from None


def _tables(conn: sqlite3.Connection) -> set[str]:
    return {row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}


class _Findings:
    def __init__(self, sample_limit: int) -> None:
        self.items: list[dict] = []
        self.sample_limit = sample_limit

    def add(self, code: str, severity: str, subject: str, detail: str) -> None:
        self.items.append({"code": code, "severity": severity, "subject": subject, "detail": detail})

    def counts(self) -> dict[str, int]:
        out: dict[str, int] = {"error": 0, "warning": 0, "info": 0}
        for item in self.items:
            out[item["severity"]] += 1
        return out

    def sample(self) -> list[dict]:
        return self.items[: self.sample_limit]


def reconcile(governance_path: str, *, sink_path: str | None = None, ledger_path: str | None = None,
              now: float | None = None, sample_limit: int = 50) -> dict:
    now = time.time() if now is None else float(now)
    findings = _Findings(sample_limit)
    gov = _open_ro(governance_path, "governance")
    try:
        tables = _tables(gov)
        report: dict = {"generated_at": int(now), "read_only": True, "schema": {}}
        report["integrity_ok"] = gov.execute("PRAGMA integrity_check").fetchall() == [("ok",)]
        if not report["integrity_ok"]:
            findings.add("INTEGRITY_FAILED", "error", "governance", "integrity_check did not return ok")
        version = max((r[0] for r in gov.execute("SELECT version FROM schema_migrations")), default=0) \
            if "schema_migrations" in tables else 0
        report["schema"]["version"] = version
        required = {"reservations", "reservation_lines", "budget_windows", "quota_windows", "cost_records",
                    "governance_log", "audit_outbox", "conflict_resolutions", "budgets", "quota_limits"}
        if not required <= tables or version < 6:
            missing = sorted(required - tables)
            findings.add("SCHEMA_BEHIND", "warning", "governance",
                         f"schema version {version}; missing tables {missing or 'none'}; some checks skipped")
            report["findings"] = {"counts": findings.counts(), "items": findings.sample(),
                                  "total": len(findings.items)}
            report["ok"] = False
            return report

        _reservations(gov, now, findings, report)
        _lines_and_windows(gov, findings, report)
        _recompute_spend_and_usage(gov, findings, report)
        _outbox(gov, findings, report)
        receipts = _sink(sink_path, findings, report)
        _sink_cross_check(gov, receipts, findings, report)
        _ledger(gov, ledger_path, findings, report)
    finally:
        gov.close()
    report["findings"] = {"counts": findings.counts(), "items": findings.sample(), "total": len(findings.items)}
    report["ok"] = findings.counts()["error"] == 0
    return report


def _reservations(gov, now, findings, report) -> None:
    rows = gov.execute("SELECT request_id, state, admission_gate, expires_at, reserved_cost, currency, "
                       "pricing_version_id FROM reservations ORDER BY request_id").fetchall()
    by_state: dict[str, int] = {}
    pending, uncertain, settling = [], [], []
    for request_id, state, gate, expires_at, reserved_cost, currency, _pricing in rows:
        by_state[state] = by_state.get(state, 0) + 1
        if state == "reserved":
            pending.append({"request_id": request_id, "gate": gate, "expires_at": expires_at})
            if gate == "closed":
                findings.add("RESERVATION_GATE_CLOSED", "warning", request_id,
                             "reserved with admission gate closed: released by the next sweep after expiry")
            if gate == "open" and expires_at is not None and expires_at < now:
                findings.add("RESERVATION_STUCK_OPEN", "warning", request_id,
                             "reserved, gate open, past expiry: sweep has not run")
        if state == "settlement_pending":
            settling.append(request_id)
            findings.add("SETTLEMENT_PENDING", "warning", request_id,
                         "intent recorded, apply not committed: recovery must apply it")
        if state == "exposed":
            uncertain.append(request_id)
        if state in TERMINAL_STATES:
            if not gov.execute("SELECT 1 FROM cost_records WHERE request_id = ?", (request_id,)).fetchone():
                findings.add("COST_RECORD_MISSING", "error", request_id, f"terminal state {state} has no cost record")
        if state == "settlement_pending" and gov.execute(
                "SELECT intent_digest FROM reservations WHERE request_id = ?", (request_id,)).fetchone()[0] is None:
            findings.add("SETTLEMENT_NO_INTENT", "error", request_id, "settlement_pending without a stored intent")
    exposed_lines = dict(gov.execute("SELECT request_id, COUNT(*) FROM reservation_lines WHERE outcome = 'exposed' "
                                     "GROUP BY request_id").fetchall())
    open_lines = dict(gov.execute("SELECT request_id, COUNT(*) FROM reservation_lines WHERE outcome = 'open' "
                                  "GROUP BY request_id").fetchall())
    for request_id, state, *_ in rows:
        if state == "exposed" and not exposed_lines.get(request_id):
            findings.add("EXPOSED_WITHOUT_LINES", "error", request_id, "state exposed but no exposed line")
        if state in ("settled", "released", "written_off") and exposed_lines.get(request_id):
            findings.add("EXPOSED_LINE_ON_TERMINAL", "error", request_id,
                         f"state {state} still holds an exposed line")
        if state in TERMINAL_STATES and open_lines.get(request_id):
            findings.add("OPEN_LINE_ON_TERMINAL", "error", request_id, f"state {state} still holds an open line")
    admitted = {r[0] for r in gov.execute("SELECT request_id FROM governance_log WHERE operation = 'admit' "
                                          "AND outcome = 'ok'")}
    for request_id, *_ in rows:
        if request_id not in admitted:
            findings.add("ADMIT_LOG_MISSING", "error", request_id, "reservation without an admit ok log row")
    cost_orphans = gov.execute("SELECT c.request_id FROM cost_records c LEFT JOIN reservations r "
                               "ON r.request_id = c.request_id WHERE r.request_id IS NULL").fetchall()
    for (request_id,) in cost_orphans:
        findings.add("COST_ORPHAN", "error", request_id, "cost record without a reservation")
    for request_id, status, actual in gov.execute(
            "SELECT request_id, cost_status, actual_cost FROM cost_records WHERE cost_status = 'priced' "
            "AND actual_cost IS NULL").fetchall():
        findings.add("COST_PRICED_NO_AMOUNT", "error", request_id, "priced cost without an actual amount")
    log_orphans = gov.execute(
        "SELECT g.log_id, g.request_id, g.operation FROM governance_log g LEFT JOIN reservations r "
        "ON r.request_id = g.request_id WHERE g.request_id IS NOT NULL AND r.request_id IS NULL "
        f"AND g.operation IN ({','.join('?' * len(GOVERNANCE_OPERATIONS_NEEDING_REQUEST))})",
        GOVERNANCE_OPERATIONS_NEEDING_REQUEST).fetchall()
    for log_id, request_id, operation in log_orphans:
        findings.add("LOG_ORPHAN", "warning", str(log_id), f"{operation} log row for an unknown request")
    report["reservations"] = {
        "total": len(rows), "by_state": by_state,
        "pending": pending[:50], "pending_count": len(pending),
        "uncertain_exposures": uncertain[:50], "uncertain_exposure_count": len(uncertain),
        "pending_settlements": settling[:50], "pending_settlement_count": len(settling),
    }


def _lines_and_windows(gov, findings, report) -> None:
    orphans = gov.execute("SELECT rl.request_id, rl.line_kind FROM reservation_lines rl LEFT JOIN reservations r "
                          "ON r.request_id = rl.request_id WHERE r.request_id IS NULL").fetchall()
    for request_id, kind in orphans:
        findings.add("LINE_ORPHAN", "error", request_id, f"{kind} reservation line without a reservation")

    budget_expected: dict[tuple, dict[str, Decimal]] = {}
    for line_id, window, amount, outcome in gov.execute(
            "SELECT line_id, window_start, amount, outcome FROM reservation_lines WHERE line_kind = 'budget'"):
        bucket = budget_expected.setdefault((line_id, window), {"open": Decimal(0), "exposed": Decimal(0),
                                                                "written_off": Decimal(0)})
        if outcome in bucket:
            bucket[outcome] += Decimal(amount)
    checked = 0
    for budget_id, window, reserved, spent, exposed, written_off in gov.execute(
            "SELECT budget_id, window_start, reserved, spent, exposed, written_off FROM budget_windows"):
        checked += 1
        expected = budget_expected.pop((budget_id, window), {"open": Decimal(0), "exposed": Decimal(0),
                                                             "written_off": Decimal(0)})
        for column, stored, want in (("reserved", reserved, expected["open"]),
                                     ("exposed", exposed, expected["exposed"]),
                                     ("written_off", written_off, expected["written_off"])):
            if Decimal(stored) != want:
                findings.add("BUDGET_WINDOW_MISMATCH", "error", f"budget {budget_id} {window}",
                             f"{column}: stored {stored}, recomputed from lines {want}")
        for column, stored in (("reserved", reserved), ("spent", spent), ("exposed", exposed),
                               ("written_off", written_off)):
            if Decimal(stored) < 0:
                findings.add("BUDGET_NEGATIVE", "error", f"budget {budget_id} {window}", f"{column} is negative")
    for (budget_id, window), expected in budget_expected.items():
        if any(v != 0 for v in expected.values()):
            findings.add("BUDGET_WINDOW_MISSING", "error", f"budget {budget_id} {window}",
                         "lines exist for a window with no stored totals")

    quota_expected: dict[tuple, dict[str, int]] = {}
    for line_id, window, amount, outcome in gov.execute(
            "SELECT line_id, window_start, amount, outcome FROM reservation_lines WHERE line_kind = 'quota'"):
        bucket = quota_expected.setdefault((line_id, window), {"open": 0, "exposed": 0, "written_off": 0})
        if outcome in bucket:
            bucket[outcome] += int(amount)
    for quota_id, window, reserved, exposed, written_off in gov.execute(
            "SELECT quota_id, window_start, reserved, exposed, written_off FROM quota_windows"):
        checked += 1
        expected = quota_expected.pop((quota_id, window), {"open": 0, "exposed": 0, "written_off": 0})
        for column, stored, want in (("reserved", reserved, expected["open"]),
                                     ("exposed", exposed, expected["exposed"]),
                                     ("written_off", written_off, expected["written_off"])):
            if int(stored) != want:
                findings.add("QUOTA_WINDOW_MISMATCH", "error", f"quota {quota_id} {window}",
                             f"{column}: stored {stored}, recomputed from lines {want}")
    for (quota_id, window), expected in quota_expected.items():
        if any(expected.values()):
            findings.add("QUOTA_WINDOW_MISSING", "error", f"quota {quota_id} {window}",
                         "lines exist for a window with no stored totals")
    report["windows"] = {
        "windows_checked": checked,
        "recomputed": ["budget.reserved", "budget.exposed", "budget.written_off",
                       "quota.reserved", "quota.exposed", "quota.written_off"],
        "not_recomputable_from_lines_alone": ["budget.spent (needs cost_records.actual_cost)",
                                              "quota.used (needs persisted usage on reservations)"],
    }


_TOKEN_METRICS = ("input_tokens", "output_tokens", "total_tokens")


def _recompute_spend_and_usage(gov, findings, report) -> None:
    """Stage 10.49-R6-R1: read-only recomputation of budget.spent and quota.used from authoritative records.

    budget.spent(budget, window) = sum of cost_records.actual_cost over requests whose budget line is 'actual'.
      Every 'actual' budget line was written with a priced cost in the same transaction, so a missing or unpriced
      cost behind an 'actual' line is an error, never a zero.
    quota.used(requests) = count of 'actual' request lines (one per request, always counted).
    quota.used(token metrics) = recomputed from reservations.intent_* ONLY when the request's usage was persisted at
      settlement. Verified-usage resolutions (resolve_exposure) never persist their token counts, so those buckets are
      reported as unverifiable: skipped, never guessed.
    Nothing here writes. The connection is read-only (see _open_ro)."""
    spend: dict[tuple, Decimal] = {}
    spend_missing = 0
    for line_id, window, actual, status in gov.execute(
            "SELECT rl.line_id, rl.window_start, cr.actual_cost, cr.cost_status FROM reservation_lines rl "
            "LEFT JOIN cost_records cr ON cr.request_id = rl.request_id "
            "WHERE rl.line_kind = 'budget' AND rl.outcome = 'actual'"):
        if actual is None or status != "priced":
            spend_missing += 1
            continue
        spend[(line_id, window)] = spend.get((line_id, window), Decimal(0)) + Decimal(actual)
    if spend_missing:
        findings.add("SPEND_WITHOUT_PRICED_COST", "error", "budget lines",
                     f"{spend_missing} actual budget line(s) have no priced cost record")
    checked_spend = 0
    for budget_id, window, stored in gov.execute("SELECT budget_id, window_start, spent FROM budget_windows"):
        checked_spend += 1
        want = spend.pop((budget_id, window), Decimal(0))
        if Decimal(stored) != want:
            findings.add("BUDGET_SPENT_MISMATCH", "error", f"budget {budget_id} {window}",
                         f"spent: stored {stored}, recomputed from priced costs {want}")
    for (budget_id, window), want in spend.items():
        if want != 0:
            findings.add("BUDGET_SPENT_MISSING", "error", f"budget {budget_id} {window}",
                         "priced costs exist for a window with no stored totals")

    verified = {r[0] for r in gov.execute(
        "SELECT request_id FROM exposure_resolutions WHERE resolution = 'verified_usage'")}
    used: dict[tuple, int] = {}
    unverifiable: dict[tuple, int] = {}
    metric_of = dict(gov.execute("SELECT quota_id, metric FROM quota_limits"))
    for request_id, quota_id, window, amount in gov.execute(
            "SELECT rl.request_id, rl.line_id, rl.window_start, rl.amount FROM reservation_lines rl "
            "WHERE rl.line_kind = 'quota' AND rl.outcome = 'actual'"):
        metric = metric_of.get(quota_id)
        if metric == "requests":
            value = 1
        elif metric in _TOKEN_METRICS:
            if request_id in verified:
                unverifiable[(quota_id, window)] = unverifiable.get((quota_id, window), 0) + 1
                continue
            value = _persisted_metric(gov, request_id, metric)
            if value is None:
                findings.add("QUOTA_VALUE_UNRECOVERABLE", "error", f"quota {quota_id} {window}",
                             "an actual token count has no persisted usage behind it")
                continue
        else:
            continue
        used[(quota_id, window)] = used.get((quota_id, window), 0) + value
    checked_quota = 0
    for quota_id, window, stored in gov.execute("SELECT quota_id, window_start, used FROM quota_windows"):
        checked_quota += 1
        key = (quota_id, window)
        if unverifiable.pop(key, 0):
            used.pop(key, None)  # cannot prove equality for this bucket: skip it, never guess
            report.setdefault("spend_usage", {}).setdefault("unverifiable_buckets", []).append(
                f"quota {quota_id} {window}")
            continue
        want = used.pop(key, 0)
        if int(stored) != want:
            findings.add("QUOTA_USED_MISMATCH", "error", f"quota {quota_id} {window}",
                         f"used: stored {stored}, recomputed from persisted usage {want}")
    for key, want in used.items():
        if want:
            findings.add("QUOTA_USED_MISSING", "error", f"quota {key[0]} {key[1]}",
                         "usage exists for a window with no stored totals")
    report.setdefault("spend_usage", {}).update({
        "budget_windows_checked": checked_spend, "quota_windows_checked": checked_quota,
        "recomputed": ["budget.spent (from priced cost records)", "quota.used (requests)",
                       "quota.used (token metrics, where usage was persisted)"],
        "unverifiable": ["quota.used (token metrics) for requests settled by verified usage: counts not persisted"],
    })


def _persisted_metric(gov, request_id: str, metric: str) -> int | None:
    row = gov.execute("SELECT intent_input, intent_output, intent_total FROM reservations WHERE request_id = ?",
                      (request_id,)).fetchone()
    if row is None:
        return None
    inp, out, total = row
    if metric == "input_tokens":
        return int(inp) if inp is not None else None
    if metric == "output_tokens":
        return int(out) if out is not None else None
    if total is None and inp is not None and out is not None:
        total = inp + out  # same derivation as admission._quota_values
    return int(total) if total is not None else None


def _outbox(gov, findings, report) -> None:
    rows = gov.execute("SELECT o.outbox_id, o.event_key, o.event, o.log_id, o.status, o.attempts, o.lease_token, "
                       "o.lease_expires_at, o.receipt_id, (SELECT COUNT(*) FROM conflict_resolutions c "
                       "WHERE c.outbox_id = o.outbox_id) FROM audit_outbox o ORDER BY o.outbox_id").fetchall()
    by_status: dict[str, int] = {}
    unresolved, failed, unknown = [], [], []
    now_expired = 0
    for outbox_id, key, event, log_id, status, attempts, token, expires, receipt_id, resolved in rows:
        by_status[status] = by_status.get(status, 0) + 1
        if status == "failed":
            failed.append(key)
            findings.add("AUDIT_FAILED", "warning", key, f"{event}: sink refused; retried by recovery")
        elif status == "unknown":
            unknown.append(key)
            findings.add("AUDIT_UNKNOWN", "warning", key, f"{event}: sink outcome not known; retried with dedupe")
        elif status == "pending" and attempts > 0:
            unknown.append(key)
            findings.add("AUDIT_UNKNOWN", "warning", key, f"{event}: attempt recorded, outcome never recorded")
        elif status == "conflict" and not resolved:
            unresolved.append(key)
            findings.add("AUDIT_CONFLICT_UNRESOLVED", "error", key,
                         f"{event}: same key recorded with a different payload; needs operator resolution")
        elif status == "delivered" and receipt_id is None:
            findings.add("AUDIT_DELIVERED_NO_RECEIPT", "warning", key,
                         "delivered without a receipt id (legacy row or inconsistent update)")
        if token is not None and expires is not None and expires < int(report["generated_at"]):
            now_expired += 1
    for outbox_id, key, event, log_id, *_ in rows:
        if gov.execute("SELECT 1 FROM governance_log WHERE log_id = ?", (log_id,)).fetchone() is None:
            findings.add("OUTBOX_ORPHAN", "error", key, "outbox event without its governance log row")
    for outbox_id, decided_by in gov.execute("SELECT c.outbox_id, c.actor FROM conflict_resolutions c "
                                             "LEFT JOIN audit_outbox o ON o.outbox_id = c.outbox_id "
                                             "WHERE o.outbox_id IS NULL").fetchall():
        findings.add("RESOLUTION_ORPHAN", "error", str(outbox_id), "conflict resolution without its outbox row")
    conflicts_resolved = gov.execute("SELECT COUNT(*) FROM conflict_resolutions").fetchone()[0]
    report["audit"] = {
        "events": len(rows), "by_status": by_status,
        "failed_keys": failed[:50], "unknown_keys": unknown[:50],
        "unresolved_conflicts": unresolved[:50], "unresolved_conflict_count": len(unresolved),
        "resolved_conflicts": conflicts_resolved, "leases_past_expiry": now_expired,
    }


def _sink(sink_path, findings, report):
    if sink_path is None:
        report["sink"] = {"checked": False}
        return None
    try:
        conn = _open_ro(sink_path, "sink")
    except ReconcileError as exc:
        findings.add("SINK_UNAVAILABLE", "warning", "sink", str(exc))
        report["sink"] = {"checked": False, "reason": "unavailable"}
        return None
    try:
        if "audit_receipts" not in _tables(conn):
            findings.add("SINK_UNAVAILABLE", "warning", "sink", "sink has no receipt table")
            report["sink"] = {"checked": False, "reason": "no_table"}
            return None
        receipts = {key: (rid, fields) for rid, key, fields in conn.execute(
            "SELECT receipt_id, outbox_key, fields FROM audit_receipts")}
        report["sink"] = {"checked": True, "receipts": len(receipts)}
        return receipts
    finally:
        conn.close()


def _sink_cross_check(gov, receipts, findings, report) -> None:
    if receipts is None:
        return
    delivered = gov.execute("SELECT event_key, receipt_id FROM audit_outbox WHERE status = 'delivered'").fetchall()
    for key, receipt_id in delivered:
        held = receipts.get(key)
        if held is None or (receipt_id is not None and held[0] != receipt_id):
            findings.add("SINK_RECEIPT_MISSING", "error", key,
                         "governance marks delivered but the sink holds no matching receipt")
    known = {key for key, _ in delivered} | {r[0] for r in gov.execute(
        "SELECT event_key FROM audit_outbox WHERE status != 'delivered'")}
    for key in receipts:
        if key not in known:
            findings.add("SINK_RECEIPT_ORPHAN", "warning", key, "sink receipt with no outbox event")


def _ledger(gov, ledger_path, findings, report) -> None:
    if ledger_path is None:
        report["ledger"] = {"checked": False}
        return
    try:
        conn = _open_ro(ledger_path, "ledger")
    except ReconcileError as exc:
        findings.add("LEDGER_UNAVAILABLE", "warning", "ledger", str(exc))
        report["ledger"] = {"checked": False, "reason": "unavailable"}
        return
    try:
        if "usage_records" not in _tables(conn):
            findings.add("LEDGER_UNAVAILABLE", "warning", "ledger", "ledger has no usage table")
            report["ledger"] = {"checked": False, "reason": "no_table"}
            return
        ledger = {rid: (delivery, usage_status) for rid, delivery, usage_status in conn.execute(
            "SELECT request_id, delivery, usage_status FROM usage_records")}
    finally:
        conn.close()
    priced = {r[0]: r[1] for r in gov.execute(
        "SELECT r.request_id, r.state FROM reservations r JOIN cost_records c ON c.request_id = r.request_id "
        "WHERE c.cost_status = 'priced'")}
    states = dict(gov.execute("SELECT request_id, state FROM reservations").fetchall())
    for request_id, state in priced.items():
        if request_id not in ledger:
            findings.add("LEDGER_MISSING_FOR_COMPLETION", "warning", request_id,
                         f"governance has a priced {state} outcome; the ledger holds no record")
    for request_id, (delivery, usage_status) in ledger.items():
        state = states.get(request_id)
        if state is None:
            findings.add("LEDGER_ORPHAN", "warning", request_id, "ledger record with no reservation")
            continue
        if usage_status == "reported" and state in ("exposed", "written_off"):
            findings.add("LEDGER_EXPOSURE_DISAGREE", "warning", request_id,
                         f"ledger reports usage but governance holds {state}: needs operator reconciliation")
        if delivery == "withheld" and request_id in priced:
            findings.add("WITHHELD_WITH_ACTUAL_COST", "info", request_id,
                         "output withheld after a priced completion (documented: usage kept, cost charged)")
    report["ledger"] = {"checked": True, "records": len(ledger)}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Read-only governance reconciliation (never repairs).")
    parser.add_argument("--governance", required=True)
    parser.add_argument("--sink")
    parser.add_argument("--ledger")
    args = parser.parse_args(argv)
    try:
        report = reconcile(args.governance, sink_path=args.sink, ledger_path=args.ledger)
    except ReconcileError as exc:
        print(json.dumps({"ok": False, "error": str(exc)}))
        return 2
    print(json.dumps(report, indent=2, sort_keys=True, default=str))
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
