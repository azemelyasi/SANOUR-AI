"""Quota Manager (Stage 10.49-R1). Integer counters per scope, metric and UTC window. Independent of cost.

Per window: used (actual, certain counts), reserved (in-flight worst case), exposed (uncertain counts).
Availability = limit - used - reserved - exposed. A count is unknown when the provider did not report it.
Unknown counts are never recorded as zero: their reserved amount becomes exposure.
Runs inside the caller's transaction.
"""

from __future__ import annotations

import sqlite3

from sanour_ai.governance.budget import window_for
from sanour_ai.governance.types import QuotaLine, Refusal

METRICS = ("requests", "input_tokens", "output_tokens", "total_tokens")
OUTCOME_ACTUAL = "actual"
OUTCOME_EXPOSED = "exposed"
OUTCOME_RELEASED = "released"


def applicable(conn: sqlite3.Connection, provider_id: str, model_id: str, profile_id: str) -> list[tuple]:
    return conn.execute(
        "SELECT quota_id, scope_type, period, metric, limit_value FROM quota_limits "
        "WHERE scope_type = 'global' OR (scope_type = 'provider' AND scope_value = ?) "
        "OR (scope_type = 'model' AND scope_value = ?) OR (scope_type = 'profile' AND scope_value = ?) "
        "ORDER BY quota_id",
        (provider_id, model_id, profile_id),
    ).fetchall()


def totals(conn: sqlite3.Connection, quota_id: int, window: str) -> tuple[int, int, int]:
    """(used, reserved, exposed). Missing row means zero."""
    row = conn.execute("SELECT used, reserved, exposed FROM quota_windows WHERE quota_id = ? AND window_start = ?",
                       (quota_id, window)).fetchone()
    return (0, 0, 0) if row is None else (int(row[0]), int(row[1]), int(row[2]))


def _store(conn: sqlite3.Connection, quota_id: int, window: str, used: int, reserved: int, exposed: int) -> None:
    if min(used, reserved, exposed) < 0:
        raise ValueError("quota window invariant violated")
    conn.execute(
        "INSERT INTO quota_windows (quota_id, window_start, used, reserved, exposed) VALUES (?, ?, ?, ?, ?) "
        "ON CONFLICT (quota_id, window_start) DO UPDATE SET used = excluded.used, reserved = excluded.reserved, "
        "exposed = excluded.exposed",
        (quota_id, window, used, reserved, exposed),
    )


def amounts_for(max_input_tokens: int, max_output_tokens: int) -> dict[str, int]:
    return {
        "requests": 1,
        "input_tokens": max_input_tokens,
        "output_tokens": max_output_tokens,
        "total_tokens": max_input_tokens + max_output_tokens,
    }


def check_and_reserve(conn: sqlite3.Connection, rows: list[tuple], amounts: dict[str, int] | None,
                      utc_day: str) -> list[QuotaLine]:
    lines: list[QuotaLine] = []
    for quota_id, scope_type, period, metric, limit in rows:
        if amounts is None:
            raise Refusal("quota", "bounds_unknown", scope_type, period, metric)
        window = window_for(period, utc_day)
        used, reserved, exposed = totals(conn, quota_id, window)
        amount = amounts[metric]
        if used + reserved + exposed + amount > limit:
            raise Refusal("quota", "quota_exceeded", scope_type, period, metric)
        lines.append(QuotaLine(quota_id, scope_type, period, metric, window, amount))
    return lines


def write_reservation(conn: sqlite3.Connection, request_id: str, lines: list[QuotaLine]) -> None:
    for line in lines:
        conn.execute(
            "INSERT INTO reservation_lines (request_id, line_kind, line_id, window_start, amount, outcome) "
            "VALUES (?, 'quota', ?, ?, ?, 'open')",
            (request_id, line.quota_id, line.window_start, str(line.amount)),
        )
        used, reserved, exposed = totals(conn, line.quota_id, line.window_start)
        _store(conn, line.quota_id, line.window_start, used, reserved + line.amount, exposed)


def open_lines(conn: sqlite3.Connection, request_id: str) -> list[tuple[int, str, str, int]]:
    """(quota_id, window_start, metric, reserved amount) for lines still open."""
    return [(int(r[0]), r[1], r[2], int(r[3])) for r in conn.execute(
        "SELECT rl.line_id, rl.window_start, q.metric, rl.amount FROM reservation_lines rl "
        "JOIN quota_limits q ON q.quota_id = rl.line_id "
        "WHERE rl.request_id = ? AND rl.line_kind = 'quota' AND rl.outcome = 'open' ORDER BY rl.line_id",
        (request_id,))]


def apply(conn: sqlite3.Connection, request_id: str, values: dict[str, int | None], release: bool) -> None:
    """release: every open line returns to nothing. Otherwise a known value goes to used, and an unknown
    value (None or missing) goes to exposed. The reserved amount always leaves reserved."""
    for quota_id, window, metric, amount in open_lines(conn, request_id):
        used, reserved, exposed = totals(conn, quota_id, window)
        new_reserved = reserved - amount
        if release:
            outcome = OUTCOME_RELEASED
        else:
            value = values.get(metric)
            if value is not None:
                outcome, used = OUTCOME_ACTUAL, used + value
            else:
                outcome, exposed = OUTCOME_EXPOSED, exposed + amount
        _store(conn, quota_id, window, used, new_reserved, exposed)
        conn.execute("UPDATE reservation_lines SET outcome = ? WHERE request_id = ? AND line_kind = 'quota' "
                     "AND line_id = ? AND window_start = ?", (outcome, request_id, quota_id, window))


def exposed_lines(conn: sqlite3.Connection, request_id: str) -> list[tuple[int, str, str, int]]:
    return [(int(r[0]), r[1], r[2], int(r[3])) for r in conn.execute(
        "SELECT rl.line_id, rl.window_start, q.metric, rl.amount FROM reservation_lines rl "
        "JOIN quota_limits q ON q.quota_id = rl.line_id "
        "WHERE rl.request_id = ? AND rl.line_kind = 'quota' AND rl.outcome = 'exposed' ORDER BY rl.line_id",
        (request_id,))]


def resolve_exposed(conn: sqlite3.Connection, request_id: str, values: dict[str, int]) -> None:
    """Replace uncertain exposure with verified counts. Every exposed metric must have a value here."""
    for quota_id, window, metric, amount in exposed_lines(conn, request_id):
        if metric not in values:
            raise ValueError("verified usage is missing a metric that is still exposed")
        used, reserved, exposed = totals(conn, quota_id, window)
        _store(conn, quota_id, window, used + values[metric], reserved, exposed - amount)
        conn.execute("UPDATE reservation_lines SET outcome = ? WHERE request_id = ? AND line_kind = 'quota' "
                     "AND line_id = ? AND window_start = ?", (OUTCOME_ACTUAL, request_id, quota_id, window))


def write_off(conn: sqlite3.Connection, request_id: str) -> int:
    """Explicit write-off of exposed quota lines. Leaves availability; never counted as used."""
    count = 0
    for quota_id, window, metric, amount in exposed_lines(conn, request_id):
        used, reserved, exposed = totals(conn, quota_id, window)
        _store(conn, quota_id, window, used, reserved, exposed - amount)
        row = conn.execute("SELECT written_off FROM quota_windows WHERE quota_id = ? AND window_start = ?",
                           (quota_id, window)).fetchone()
        conn.execute("UPDATE quota_windows SET written_off = ? WHERE quota_id = ? AND window_start = ?",
                     (int(row[0]) + amount, quota_id, window))
        conn.execute("UPDATE reservation_lines SET outcome = 'written_off' WHERE request_id = ? AND "
                     "line_kind = 'quota' AND line_id = ? AND window_start = ?", (request_id, quota_id, window))
        count += 1
    return count
