"""AuditSink contract (Stage 10.49-R5). Independent of any storage technology: no SQLite import here.

The outbox depends only on this module. A durable implementation (today: DurableSqliteSink, a single-host SQLite file)
lives in sink.py. A future external multi-host audit service would implement the same AuditSink protocol.

deliver(outbox_key, event, fields) returns an AuditReceipt only after the sink's own durable commit has returned.
Other outcomes raise one of three classified exceptions:
- SinkFailed: definitively NOT recorded. Safe to retry.
- SinkOutcomeUnknown: may or may not be recorded. Retry is safe only because the sink de-duplicates on outbox_key.
- SinkPayloadConflict: same outbox_key already recorded with a different payload. Fail closed, never retried automatically.
A standard Python logging handler is not a sink.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Protocol, runtime_checkable


OUTBOX_KEY_MAX = 96


class SinkFailed(Exception):
    """The sink definitively did not record the event."""


class SinkOutcomeUnknown(Exception):
    """The sink may or may not have recorded the event."""


class SinkPayloadConflict(Exception):
    """Same outbox_key, different payload. Nothing recorded, original kept."""


@dataclass(frozen=True)
class AuditReceipt:
    receipt_id: int
    outbox_key: str
    duplicate: bool


def payload_digest(event: str, fields: dict) -> str:
    return hashlib.sha256(json.dumps([event, fields], sort_keys=True, default=str).encode("utf-8")).hexdigest()



@runtime_checkable
class AuditSink(Protocol):
    """What the outbox requires of any sink. Implementations must honour the classified-failure rules above."""

    def deliver(self, outbox_key: str, event: str, fields: dict) -> AuditReceipt: ...

    def close(self) -> None: ...
