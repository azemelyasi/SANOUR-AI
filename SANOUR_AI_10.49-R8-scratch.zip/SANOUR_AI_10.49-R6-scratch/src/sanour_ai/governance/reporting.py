"""Read-only governance reporting (Stage 10.49-R2).

Built from the per-request tables (reservations, cost_records, reservation_lines, exposure_resolutions,
governance_log), so every filter is exact and every figure is traceable to requests. No write is ever made.

Rules:
- One bucket per currency. Totals are never mixed across currencies. Requests without pricing are in the
  "unpriced" bucket, and their amounts are not summed anywhere else.
- actual_cost is priced usage only. Reserved, exposed, written-off and unknown amounts are reported under their
  own names and never as spending.
- NULL stays NULL. A reservation without a worst-case amount is counted in *_amount_unknown, not as zero.
- Filters: provider, model, profile, currency, utc_day. Values are validated and bound as parameters.
"""

from __future__ import annotations

import re
from datetime import date
from decimal import Decimal

from sanour_ai.governance.cost import format_money
from sanour_ai.governance.store import GovernanceStore

UNPRICED = "unpriced"
_IDENT = re.compile(r"[a-z][a-z0-9_]{0,63}")
_MODEL = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}")
_CURRENCY = re.compile(r"[A-Z]{3}")
_BAD = "report filter is not allowed"


def _validate(filters: dict[str, object]) -> dict[str, str]:
    clean: dict[str, str] = {}
    for key, value in filters.items():
        if value is None:
            continue
        if not isinstance(value, str):
            raise ValueError(_BAD)
        if key in ("provider", "profile") and _IDENT.fullmatch(value):
            clean[key] = value
        elif key == "model" and _MODEL.fullmatch(value):
            clean[key] = value
        elif key == "currency" and (value == UNPRICED or _CURRENCY.fullmatch(value)):
            clean[key] = value
        elif key == "utc_day":
            try:
                date.fromisoformat(value)
            except ValueError:
                raise ValueError(_BAD) from None
            clean[key] = value
        else:
            raise ValueError(_BAD)
    return clean


def _money_sum(values: list[str | None]) -> tuple[str | None, int]:
    """(sum or None when nothing is known, count of unknown values). A missing value is never zero."""
    known = [Decimal(v) for v in values if v is not None]
    unknown = len(values) - len(known)
    return (format_money(sum(known, Decimal(0))) if known else None), unknown


def _bucket() -> dict:
    return {"requests": 0, "actual_cost": None, "actual_cost_requests": 0, "unknown_cost_requests": 0,
            "active_reservations": 0, "active_reservation_amount": None, "active_amount_unknown": 0,
            "pending_settlement_intents": 0, "pending_settlement_amount": None,
            "uncertain_exposure": 0, "uncertain_exposure_amount": None, "uncertain_amount_unknown": 0,
            "written_off": 0, "written_off_amount": None,
            "resolved_by_verified_usage": 0, "resolved_by_write_off": 0,
            "retained_exposure": 0, "unresolved_exposure": 0,
            "failed_settlement_operations": 0}


def governance_report(store: GovernanceStore, *, provider: str | None = None, model: str | None = None,
                      profile: str | None = None, currency: str | None = None,
                      utc_day: str | None = None) -> dict[str, object]:
    flt = _validate({"provider": provider, "model": model, "profile": profile, "currency": currency,
                     "utc_day": utc_day})
    where, params = [], []
    for key, column in (("provider", "r.provider_id"), ("model", "r.model_id"), ("profile", "r.profile_id"),
                        ("utc_day", "r.utc_day")):
        if key in flt:
            where.append(f"{column} = ?")
            params.append(flt[key])
    if "currency" in flt:
        if flt["currency"] == UNPRICED:
            where.append("r.currency IS NULL")
        else:
            where.append("r.currency = ?")
            params.append(flt["currency"])
    clause = (" WHERE " + " AND ".join(where)) if where else ""

    def fetch(conn):
        rows = conn.execute(
            "SELECT r.request_id, r.state, r.currency, r.reserved_cost, c.cost_status, c.actual_cost "
            "FROM reservations r LEFT JOIN cost_records c ON c.request_id = r.request_id" + clause +
            " ORDER BY r.request_id", params).fetchall()
        ids = {row[0] for row in rows}
        resolutions = conn.execute("SELECT request_id, resolution FROM exposure_resolutions").fetchall()
        failed = conn.execute("SELECT request_id FROM governance_log WHERE outcome = 'failed' "
                              "AND request_id IS NOT NULL").fetchall()
        return rows, ids, resolutions, failed

    rows, ids, resolutions, failed = store.read(fetch)
    by_resolution: dict[str, set[str]] = {}
    for request_id, resolution in resolutions:
        by_resolution.setdefault(resolution, set()).add(request_id)
    failed_by_request: dict[str, int] = {}
    for (request_id,) in failed:
        if request_id in ids:
            failed_by_request[request_id] = failed_by_request.get(request_id, 0) + 1

    groups: dict[str, list] = {}
    for row in rows:
        groups.setdefault(row[2] if row[2] is not None else UNPRICED, []).append(row)

    report: dict[str, object] = {}
    for code in sorted(groups):
        members = groups[code]
        b = _bucket()
        b["requests"] = len(members)
        actual_values = [m[5] for m in members if m[4] == "priced" and m[5] is not None]
        b["actual_cost"], _ = _money_sum(actual_values)
        b["actual_cost_requests"] = len(actual_values)
        b["unknown_cost_requests"] = sum(1 for m in members if m[4] is not None and m[4].startswith("unknown_"))
        for state, prefix, amount_key, unknown_key in (
                ("reserved", "active_reservation", "active_reservation_amount", "active_amount_unknown"),
                ("settlement_pending", "pending_settlement", "pending_settlement_amount", None),
                ("exposed", "uncertain_exposure", "uncertain_exposure_amount", "uncertain_amount_unknown"),
                ("written_off", "written_off", "written_off_amount", None)):
            selected = [m for m in members if m[1] == state]
            if prefix == "active_reservation":
                b["active_reservations"] = len(selected)
            elif prefix == "pending_settlement":
                b["pending_settlement_intents"] = len(selected)
            elif prefix == "uncertain_exposure":
                b["uncertain_exposure"] = len(selected)
            else:
                b["written_off"] = len(selected)
            total, unknown = _money_sum([m[3] for m in selected])
            b[amount_key] = total
            if unknown_key:
                b[unknown_key] = unknown
        exposed_ids = [m[0] for m in members if m[1] == "exposed"]
        b["retained_exposure"] = sum(1 for i in exposed_ids if i in by_resolution.get("retain", set()))
        b["unresolved_exposure"] = len(exposed_ids)
        b["resolved_by_verified_usage"] = sum(1 for m in members if m[0] in by_resolution.get("verified_usage", set()))
        b["resolved_by_write_off"] = sum(1 for m in members if m[0] in by_resolution.get("write_off", set()))
        b["failed_settlement_operations"] = sum(failed_by_request.get(m[0], 0) for m in members)
        report[code] = b
    return {"filters": flt, "currencies": report}
