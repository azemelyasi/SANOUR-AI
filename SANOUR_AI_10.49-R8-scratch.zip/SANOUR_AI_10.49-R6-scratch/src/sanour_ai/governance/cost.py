"""Cost Engine (Stage 10.49). Pure functions over Decimal. No storage, no clock, no network.

Pricing is configured explicitly, per provider and model, from its effective date (UTC day) onward. Nothing
is inferred from a model name, and no default price exists. Every money value is a Decimal built from a
string. Floats are refused, so no binary rounding can enter a total.

Rules:
- Prices are per one million tokens, in one currency per pricing version.
- input cost:  (input - cached) x input_price + cached x cached_input_price
- output cost: (output - reasoning) x output_price + reasoning x reasoning_price
- Reasoning tokens are part of output tokens. If no reasoning price is configured, output_price covers
  all output tokens. Reasoning is therefore never charged twice.
- If cached tokens are reported and no cached price is configured, the cost is unknown (never guessed).
- A missing input or output count makes the cost unknown. A missing count is never read as zero.
- The worst-case cost uses the highest configured price per side, so it is never below the real cost.
"""

from __future__ import annotations

import re
from collections.abc import Iterable
from dataclasses import dataclass
from datetime import date
from decimal import Decimal, InvalidOperation, localcontext

from sanour_ai.models.usage import Usage

MILLION = Decimal(1_000_000)
MAX_PRICE_PER_MILLION = Decimal(1_000_000)
MAX_PRICE_DECIMALS = 12
_CURRENCY = re.compile(r"[A-Z]{3}")
_IDENT = re.compile(r"[a-z][a-z0-9_]{0,63}")
_MODEL = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}")

STATUS_PRICED = "priced"
STATUS_UNKNOWN_PRICING = "unknown_pricing"
STATUS_UNKNOWN_USAGE = "unknown_usage"


class PricingConfigError(ValueError):
    """Pricing configuration refused. Fixed message: it never echoes the value."""


def parse_price(value: object) -> Decimal:
    """A price per million tokens. Strings only. Finite, not negative, bounded precision."""
    if isinstance(value, bool) or not isinstance(value, (str, Decimal)):
        raise PricingConfigError("price must be given as a decimal string")
    try:
        number = Decimal(str(value).strip()) if isinstance(value, str) else value
    except InvalidOperation:
        raise PricingConfigError("price is not a decimal number") from None
    if not number.is_finite() or number < 0 or number > MAX_PRICE_PER_MILLION:
        raise PricingConfigError("price is out of range")
    if -number.as_tuple().exponent > MAX_PRICE_DECIMALS:
        raise PricingConfigError("price has too many decimal places")
    return number


def parse_optional_price(value: object) -> Decimal | None:
    return None if value is None else parse_price(value)


def format_money(value: Decimal) -> str:
    """Canonical text for storage. Never scientific notation. Zero is always '0'."""
    if value == 0:
        return "0"
    return format(value, "f")


def check_day(value: object) -> str:
    if not isinstance(value, str) or len(value) != 10:
        raise PricingConfigError("effective date must be YYYY-MM-DD")
    try:
        date.fromisoformat(value)
    except ValueError:
        raise PricingConfigError("effective date must be a real UTC day") from None
    return value


@dataclass(frozen=True)
class PricingVersion:
    pricing_version_id: int | None
    provider_id: str
    model_id: str
    currency: str
    effective_from: str  # UTC day, inclusive
    input_per_million: Decimal
    output_per_million: Decimal
    cached_input_per_million: Decimal | None = None
    reasoning_per_million: Decimal | None = None

    @classmethod
    def build(cls, *, provider_id: str, model_id: str, currency: str, effective_from: str,
              input_per_million: object, output_per_million: object,
              cached_input_per_million: object = None, reasoning_per_million: object = None,
              pricing_version_id: int | None = None) -> PricingVersion:
        if not isinstance(provider_id, str) or not _IDENT.fullmatch(provider_id):
            raise PricingConfigError("provider identifier is not allowed")
        if not isinstance(model_id, str) or not _MODEL.fullmatch(model_id):
            raise PricingConfigError("model identifier is not allowed")
        if not isinstance(currency, str) or not _CURRENCY.fullmatch(currency):
            raise PricingConfigError("currency must be a three-letter ISO code")
        return cls(
            pricing_version_id=pricing_version_id,
            provider_id=provider_id,
            model_id=model_id,
            currency=currency,
            effective_from=check_day(effective_from),
            input_per_million=parse_price(input_per_million),
            output_per_million=parse_price(output_per_million),
            cached_input_per_million=parse_optional_price(cached_input_per_million),
            reasoning_per_million=parse_optional_price(reasoning_per_million),
        )


@dataclass(frozen=True)
class CostResult:
    status: str  # priced | unknown_pricing | unknown_usage
    amount: Decimal | None
    currency: str | None


def select_pricing(versions: Iterable[PricingVersion], provider_id: str, model_id: str,
                   utc_day: str) -> PricingVersion | None:
    """The version in force on utc_day: the latest effective_from that is not after it. Never a guess."""
    best: PricingVersion | None = None
    for version in versions:
        if version.provider_id != provider_id or version.model_id != model_id:
            continue
        if version.effective_from > utc_day:
            continue
        if best is None or version.effective_from > best.effective_from:
            best = version
    return best


def actual_cost(pricing: PricingVersion | None, usage: Usage | None) -> CostResult:
    if pricing is None:
        return CostResult(STATUS_UNKNOWN_PRICING, None, None)
    if usage is None or usage.input_tokens is None or usage.output_tokens is None:
        return CostResult(STATUS_UNKNOWN_USAGE, None, pricing.currency)
    cached = usage.cached_input_tokens
    reasoning = usage.reasoning_tokens
    if cached is None and pricing.cached_input_per_million is not None:
        return CostResult(STATUS_UNKNOWN_USAGE, None, pricing.currency)
    if cached and pricing.cached_input_per_million is None:
        return CostResult(STATUS_UNKNOWN_PRICING, None, pricing.currency)
    if reasoning is None and pricing.reasoning_per_million is not None:
        return CostResult(STATUS_UNKNOWN_USAGE, None, pricing.currency)
    with localcontext() as ctx:
        ctx.prec = 60
        cached_n = cached or 0
        reasoning_n = reasoning or 0
        input_cost = Decimal(usage.input_tokens - cached_n) * pricing.input_per_million
        if cached_n:
            input_cost += Decimal(cached_n) * pricing.cached_input_per_million
        if pricing.reasoning_per_million is None:
            output_cost = Decimal(usage.output_tokens) * pricing.output_per_million
        else:
            output_cost = (Decimal(usage.output_tokens - reasoning_n) * pricing.output_per_million
                           + Decimal(reasoning_n) * pricing.reasoning_per_million)
        total = (input_cost + output_cost) / MILLION
    return CostResult(STATUS_PRICED, total, pricing.currency)


def worst_case_cost(pricing: PricingVersion, max_input_tokens: int, max_output_tokens: int) -> Decimal:
    """Upper bound from the request limits. Highest configured price per side, so it never undershoots."""
    input_price = max(pricing.input_per_million, pricing.cached_input_per_million or Decimal(0))
    output_price = max(pricing.output_per_million, pricing.reasoning_per_million or Decimal(0))
    with localcontext() as ctx:
        ctx.prec = 60
        return (Decimal(max_input_tokens) * input_price + Decimal(max_output_tokens) * output_price) / MILLION
