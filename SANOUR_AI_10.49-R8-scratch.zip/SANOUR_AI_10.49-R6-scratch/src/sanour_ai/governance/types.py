"""Shared governance types (Stage 10.49). No I/O, no imports from the rest of the governance package."""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal

from sanour_ai.models.usage import Usage


@dataclass(frozen=True)
class Bounds:
    """Upper limits for one profile, from the validated configuration. Used for worst-case reservations."""

    max_input_tokens: int
    max_output_tokens: int


class Refusal(Exception):
    """A budget or quota refused admission. Raised before any provider call. Fixed reason names only."""

    def __init__(self, kind: str, reason: str, scope_type: str, period: str, metric: str | None = None) -> None:
        super().__init__("usage limit reached")
        self.kind = kind          # "budget" | "quota"
        self.reason = reason      # cost_unknown | budget_exceeded | bounds_unknown | quota_exceeded
        self.scope_type = scope_type
        self.period = period
        self.metric = metric


@dataclass(frozen=True)
class BudgetLine:
    budget_id: int
    scope_type: str
    period: str
    currency: str
    window_start: str
    amount: Decimal


@dataclass(frozen=True)
class QuotaLine:
    quota_id: int
    scope_type: str
    period: str
    metric: str
    window_start: str
    amount: int


@dataclass(frozen=True)
class Ticket:
    """Returned by admit(). Carries no amounts: settle() reads the reserved lines from storage."""

    request_id: str
    budget_lines: int
    quota_lines: int
    pricing_version_id: int | None


@dataclass(frozen=True)
class Settlement:
    """How a request ended. provider_started False means no provider call was made (release)."""

    kind: str  # completed | failed | timed_out
    provider_started: bool
    usage: Usage | None = None


@dataclass(frozen=True)
class SettleResult:
    applied: bool
    reason: str  # settled | released | expired | already_settled | not_found
    cost_status: str | None = None
    charged_from: str | None = None
    # Stage 10.49-R3: the decision is committed when applied is True. audit_status says where the external audit
    # event stands: pending (not attempted), delivered (sink confirmed), failed (sink refused, kept for retry).
    # A failed audit delivery never changes applied and never rolls back the committed decision.
    audit_status: str | None = None
