"""Governance storage (Stage 10.49): pricing, budgets, quotas, reservations, cost records.

Same SQLite file as the usage ledger in production, in its own tables. Every operation runs in one
BEGIN IMMEDIATE transaction, so concurrent processes serialize on the write lock. Money is kept as text
(Decimal strings), never as SQL REAL. Migrations are versioned in schema_migrations and each one runs once.

Failures raise GovernanceStorageError with a fixed message. A failed write is never reported as success.
"""

from __future__ import annotations

import contextlib
import sqlite3
import threading
from collections.abc import Iterator
from decimal import Decimal

from sanour_ai.governance.cost import PricingVersion, format_money

SCHEMA_VERSION = 6
SCOPE_TYPES = ("global", "provider", "model", "profile")
PERIODS = ("daily", "monthly")
QUOTA_METRICS = ("requests", "input_tokens", "output_tokens", "total_tokens")
RESERVATION_STATES = ("reserved", "settlement_pending", "exposed", "settled", "released", "written_off")
_MAX_PATH_LENGTH = 1024


class GovernanceStorageError(RuntimeError):
    def __init__(self) -> None:
        super().__init__("governance storage unavailable")


class GovernanceConflictError(ValueError):
    def __init__(self) -> None:
        super().__init__("governance configuration already exists with different values")


_MIGRATIONS = {
    1: """
CREATE TABLE IF NOT EXISTS pricing_versions (
    pricing_version_id INTEGER PRIMARY KEY AUTOINCREMENT,
    provider_id TEXT NOT NULL,
    model_id TEXT NOT NULL,
    currency TEXT NOT NULL CHECK (length(currency) = 3),
    effective_from TEXT NOT NULL CHECK (length(effective_from) = 10),
    input_per_million TEXT NOT NULL,
    output_per_million TEXT NOT NULL,
    cached_input_per_million TEXT,
    reasoning_per_million TEXT,
    UNIQUE (provider_id, model_id, effective_from)
);
CREATE TABLE IF NOT EXISTS budgets (
    budget_id INTEGER PRIMARY KEY AUTOINCREMENT,
    scope_type TEXT NOT NULL CHECK (scope_type IN ('global', 'provider', 'model', 'profile')),
    scope_value TEXT NOT NULL,
    period TEXT NOT NULL CHECK (period IN ('daily', 'monthly')),
    currency TEXT NOT NULL CHECK (length(currency) = 3),
    limit_amount TEXT NOT NULL,
    UNIQUE (scope_type, scope_value, period, currency)
);
CREATE TABLE IF NOT EXISTS budget_windows (
    budget_id INTEGER NOT NULL REFERENCES budgets (budget_id),
    window_start TEXT NOT NULL,
    reserved TEXT NOT NULL DEFAULT '0',
    spent TEXT NOT NULL DEFAULT '0',
    PRIMARY KEY (budget_id, window_start)
);
CREATE TABLE IF NOT EXISTS quota_limits (
    quota_id INTEGER PRIMARY KEY AUTOINCREMENT,
    scope_type TEXT NOT NULL CHECK (scope_type IN ('global', 'provider', 'model', 'profile')),
    scope_value TEXT NOT NULL,
    period TEXT NOT NULL CHECK (period IN ('daily', 'monthly')),
    metric TEXT NOT NULL CHECK (metric IN ('requests', 'input_tokens', 'output_tokens', 'total_tokens')),
    limit_value INTEGER NOT NULL CHECK (limit_value >= 0),
    UNIQUE (scope_type, scope_value, period, metric)
);
CREATE TABLE IF NOT EXISTS quota_windows (
    quota_id INTEGER NOT NULL REFERENCES quota_limits (quota_id),
    window_start TEXT NOT NULL,
    reserved INTEGER NOT NULL DEFAULT 0 CHECK (reserved >= 0),
    used INTEGER NOT NULL DEFAULT 0 CHECK (used >= 0),
    PRIMARY KEY (quota_id, window_start)
);
CREATE TABLE IF NOT EXISTS reservations (
    request_id TEXT PRIMARY KEY CHECK (length(request_id) BETWEEN 1 AND 64),
    state TEXT NOT NULL CHECK (state IN ('reserved', 'settled', 'released', 'expired')),
    provider_id TEXT NOT NULL,
    model_id TEXT NOT NULL,
    profile_id TEXT NOT NULL,
    utc_day TEXT NOT NULL,
    pricing_version_id INTEGER,
    currency TEXT,
    reserved_cost TEXT,
    created_at INTEGER NOT NULL,
    expires_at INTEGER NOT NULL,
    settled_at INTEGER,
    settlement TEXT
);
CREATE TABLE IF NOT EXISTS reservation_lines (
    request_id TEXT NOT NULL REFERENCES reservations (request_id),
    line_kind TEXT NOT NULL CHECK (line_kind IN ('budget', 'quota')),
    line_id INTEGER NOT NULL,
    window_start TEXT NOT NULL,
    amount TEXT NOT NULL,
    PRIMARY KEY (request_id, line_kind, line_id)
);
CREATE TABLE IF NOT EXISTS cost_records (
    request_id TEXT PRIMARY KEY REFERENCES reservations (request_id),
    cost_status TEXT NOT NULL CHECK (cost_status IN ('priced', 'unknown_pricing', 'unknown_usage', 'not_billed')),
    currency TEXT,
    actual_cost TEXT,
    pricing_version_id INTEGER,
    charged_from TEXT NOT NULL CHECK (charged_from IN ('actual', 'reserved', 'none')),
    over_reservation INTEGER NOT NULL DEFAULT 0 CHECK (over_reservation IN (0, 1))
);
""",
    2: """
ALTER TABLE budget_windows ADD COLUMN exposed TEXT NOT NULL DEFAULT '0';
ALTER TABLE quota_windows ADD COLUMN exposed INTEGER NOT NULL DEFAULT 0 CHECK (exposed >= 0);
ALTER TABLE reservation_lines ADD COLUMN outcome TEXT NOT NULL DEFAULT 'open'
    CHECK (outcome IN ('open', 'actual', 'exposed', 'released'));
CREATE TABLE reservations_v2 (
    request_id TEXT PRIMARY KEY CHECK (length(request_id) BETWEEN 1 AND 64),
    state TEXT NOT NULL CHECK (state IN ('reserved', 'settlement_pending', 'exposed', 'settled', 'released')),
    provider_id TEXT NOT NULL,
    model_id TEXT NOT NULL,
    profile_id TEXT NOT NULL,
    utc_day TEXT NOT NULL,
    pricing_version_id INTEGER,
    currency TEXT,
    reserved_cost TEXT,
    created_at INTEGER NOT NULL,
    expires_at INTEGER NOT NULL,
    settled_at INTEGER,
    settlement TEXT,
    intent_kind TEXT,
    intent_started INTEGER,
    intent_input INTEGER,
    intent_output INTEGER,
    intent_total INTEGER,
    intent_cached INTEGER,
    intent_reasoning INTEGER
);
INSERT INTO reservations_v2 (request_id, state, provider_id, model_id, profile_id, utc_day, pricing_version_id,
    currency, reserved_cost, created_at, expires_at, settled_at, settlement)
    SELECT request_id, CASE WHEN state = 'expired' THEN 'exposed' ELSE state END, provider_id, model_id, profile_id,
    utc_day, pricing_version_id, currency, reserved_cost, created_at, expires_at, settled_at, settlement FROM reservations;
DROP TABLE reservations;
ALTER TABLE reservations_v2 RENAME TO reservations;
CREATE TABLE cost_records_v2 (
    request_id TEXT PRIMARY KEY REFERENCES reservations (request_id),
    cost_status TEXT NOT NULL CHECK (cost_status IN ('priced', 'unknown_pricing', 'unknown_usage', 'not_billed')),
    currency TEXT,
    actual_cost TEXT,
    pricing_version_id INTEGER,
    charged_from TEXT NOT NULL CHECK (charged_from IN ('actual', 'exposed', 'none')),
    over_reservation INTEGER NOT NULL DEFAULT 0 CHECK (over_reservation IN (0, 1))
);
INSERT INTO cost_records_v2 SELECT request_id, cost_status, currency, actual_cost, pricing_version_id,
    CASE WHEN charged_from = 'reserved' THEN 'exposed' ELSE charged_from END, over_reservation FROM cost_records;
DROP TABLE cost_records;
ALTER TABLE cost_records_v2 RENAME TO cost_records;
""",
    3: """
ALTER TABLE budget_windows ADD COLUMN written_off TEXT NOT NULL DEFAULT '0';
ALTER TABLE quota_windows ADD COLUMN written_off INTEGER NOT NULL DEFAULT 0 CHECK (written_off >= 0);
CREATE TABLE reservation_lines_v3 (
    request_id TEXT NOT NULL REFERENCES reservations (request_id),
    line_kind TEXT NOT NULL CHECK (line_kind IN ('budget', 'quota')),
    line_id INTEGER NOT NULL,
    window_start TEXT NOT NULL,
    amount TEXT NOT NULL,
    outcome TEXT NOT NULL DEFAULT 'open'
        CHECK (outcome IN ('open', 'actual', 'exposed', 'released', 'written_off')),
    PRIMARY KEY (request_id, line_kind, line_id)
);
INSERT INTO reservation_lines_v3 (request_id, line_kind, line_id, window_start, amount, outcome)
    SELECT request_id, line_kind, line_id, window_start, amount, outcome FROM reservation_lines;
DROP TABLE reservation_lines;
ALTER TABLE reservation_lines_v3 RENAME TO reservation_lines;
CREATE TABLE reservations_v3 (
    request_id TEXT PRIMARY KEY CHECK (length(request_id) BETWEEN 1 AND 64),
    state TEXT NOT NULL CHECK (state IN ('reserved', 'settlement_pending', 'exposed', 'settled', 'released',
        'written_off')),
    provider_id TEXT NOT NULL,
    model_id TEXT NOT NULL,
    profile_id TEXT NOT NULL,
    utc_day TEXT NOT NULL,
    pricing_version_id INTEGER,
    currency TEXT,
    reserved_cost TEXT,
    created_at INTEGER NOT NULL,
    expires_at INTEGER NOT NULL,
    settled_at INTEGER,
    settlement TEXT,
    intent_kind TEXT,
    intent_started INTEGER,
    intent_input INTEGER,
    intent_output INTEGER,
    intent_total INTEGER,
    intent_cached INTEGER,
    intent_reasoning INTEGER,
    intent_digest TEXT,
    intent_source TEXT,
    applied_at INTEGER,
    recovery_attempts INTEGER NOT NULL DEFAULT 0 CHECK (recovery_attempts >= 0),
    last_failure TEXT
);
INSERT INTO reservations_v3 (request_id, state, provider_id, model_id, profile_id, utc_day, pricing_version_id,
    currency, reserved_cost, created_at, expires_at, settled_at, settlement, intent_kind, intent_started,
    intent_input, intent_output, intent_total, intent_cached, intent_reasoning)
    SELECT request_id, state, provider_id, model_id, profile_id, utc_day, pricing_version_id, currency,
    reserved_cost, created_at, expires_at, settled_at, settlement, intent_kind, intent_started, intent_input,
    intent_output, intent_total, intent_cached, intent_reasoning FROM reservations;
DROP TABLE reservations;
ALTER TABLE reservations_v3 RENAME TO reservations;
CREATE TABLE exposure_resolutions (
    resolution_id INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id TEXT NOT NULL REFERENCES reservations (request_id),
    resolution TEXT NOT NULL CHECK (resolution IN ('verified_usage', 'write_off', 'retain')),
    actor TEXT NOT NULL,
    reason TEXT NOT NULL CHECK (length(reason) BETWEEN 1 AND 500),
    evidence_ref TEXT,
    decided_at INTEGER NOT NULL,
    currency TEXT,
    UNIQUE (request_id, resolution)
);
CREATE TABLE governance_log (
    log_id INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id TEXT,
    operation TEXT NOT NULL,
    outcome TEXT NOT NULL CHECK (outcome IN ('ok', 'failed', 'refused')),
    actor TEXT,
    at INTEGER NOT NULL
);
CREATE INDEX governance_log_request ON governance_log (request_id);
""",
    4: """
CREATE TABLE audit_outbox (
    outbox_id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_key TEXT NOT NULL UNIQUE CHECK (length(event_key) BETWEEN 1 AND 96),
    log_id INTEGER NOT NULL REFERENCES governance_log (log_id),
    event TEXT NOT NULL CHECK (length(event) BETWEEN 1 AND 64),
    fields TEXT NOT NULL CHECK (length(fields) <= 2048),
    status TEXT NOT NULL CHECK (status IN ('pending', 'delivered', 'failed')),
    attempts INTEGER NOT NULL DEFAULT 0 CHECK (attempts >= 0),
    last_error TEXT,
    created_at INTEGER NOT NULL,
    delivered_at INTEGER
);
CREATE INDEX audit_outbox_status ON audit_outbox (status, outbox_id);
""",
    5: """
CREATE TABLE audit_outbox_v5 (
    outbox_id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_key TEXT NOT NULL UNIQUE CHECK (length(event_key) BETWEEN 1 AND 96),
    log_id INTEGER NOT NULL REFERENCES governance_log (log_id),
    event TEXT NOT NULL CHECK (length(event) BETWEEN 1 AND 64),
    fields TEXT NOT NULL CHECK (length(fields) <= 2048),
    status TEXT NOT NULL CHECK (status IN ('pending', 'delivered', 'failed', 'unknown', 'conflict')),
    attempts INTEGER NOT NULL DEFAULT 0 CHECK (attempts >= 0),
    last_error TEXT,
    created_at INTEGER NOT NULL,
    delivered_at INTEGER,
    receipt_id INTEGER,
    lease_token TEXT,
    lease_expires_at INTEGER
);
INSERT INTO audit_outbox_v5 (outbox_id, event_key, log_id, event, fields, status, attempts, last_error, created_at,
    delivered_at)
    SELECT outbox_id, event_key, log_id, event, fields, status, attempts, last_error, created_at, delivered_at
    FROM audit_outbox;
DROP TABLE audit_outbox;
ALTER TABLE audit_outbox_v5 RENAME TO audit_outbox;
CREATE INDEX audit_outbox_claim ON audit_outbox (status, lease_expires_at, outbox_id);
""",
    6: """
ALTER TABLE reservations ADD COLUMN admission_gate TEXT NOT NULL DEFAULT 'open' CHECK (admission_gate IN ('closed', 'open'));
CREATE TABLE conflict_resolutions (
    resolution_id INTEGER PRIMARY KEY AUTOINCREMENT,
    outbox_id INTEGER NOT NULL UNIQUE REFERENCES audit_outbox (outbox_id),
    event_key TEXT NOT NULL UNIQUE CHECK (length(event_key) BETWEEN 1 AND 96),
    log_id INTEGER NOT NULL REFERENCES governance_log (log_id),
    decision TEXT NOT NULL CHECK (decision IN ('acknowledged')),
    actor TEXT NOT NULL CHECK (length(actor) BETWEEN 1 AND 64),
    reason TEXT NOT NULL CHECK (length(reason) BETWEEN 1 AND 500),
    evidence_ref TEXT NOT NULL CHECK (length(evidence_ref) BETWEEN 1 AND 128),
    original_digest TEXT NOT NULL CHECK (length(original_digest) = 64),
    decided_at INTEGER NOT NULL
);
CREATE TRIGGER conflict_resolutions_no_update BEFORE UPDATE ON conflict_resolutions BEGIN SELECT RAISE(ABORT, 'conflict resolutions are append-only'); END;
CREATE TRIGGER conflict_resolutions_no_delete BEFORE DELETE ON conflict_resolutions BEGIN SELECT RAISE(ABORT, 'conflict resolutions are append-only'); END;
CREATE TRIGGER audit_outbox_conflict_no_update BEFORE UPDATE ON audit_outbox WHEN OLD.status = 'conflict' BEGIN SELECT RAISE(ABORT, 'conflict rows are immutable'); END;
CREATE TRIGGER audit_outbox_conflict_no_delete BEFORE DELETE ON audit_outbox WHEN OLD.status = 'conflict' BEGIN SELECT RAISE(ABORT, 'conflict rows are immutable'); END;
""",
}


class GovernanceStore:
    def __init__(self, path: str) -> None:
        if not isinstance(path, str) or not path or "\x00" in path or len(path) > _MAX_PATH_LENGTH:
            raise GovernanceStorageError()
        self._lock = threading.RLock()
        self.path = path
        self._conn: sqlite3.Connection | None = None
        try:
            conn = sqlite3.connect(path, timeout=10.0, isolation_level=None, check_same_thread=False)
        except sqlite3.Error:
            raise GovernanceStorageError() from None
        self._conn = conn
        try:
            conn.execute("PRAGMA busy_timeout=10000")
            if path != ":memory:":
                mode = conn.execute("PRAGMA journal_mode=WAL").fetchone()
                if mode is None or str(mode[0]).lower() != "wal":
                    raise GovernanceStorageError()
            conn.execute("PRAGMA synchronous=FULL")
            self._migrate()
            if conn.execute("PRAGMA integrity_check").fetchall() != [("ok",)]:
                raise GovernanceStorageError()
        except GovernanceStorageError:
            self._discard()
            raise
        except sqlite3.Error:
            self._discard()
            raise GovernanceStorageError() from None

    def _discard(self) -> None:
        conn, self._conn = self._conn, None
        if conn is not None:
            with contextlib.suppress(sqlite3.Error):
                conn.close()

    def _migrate(self) -> None:
        conn = self._conn
        conn.execute("BEGIN IMMEDIATE")
        try:
            conn.execute("CREATE TABLE IF NOT EXISTS schema_migrations "
                         "(version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL)")
            applied = {row[0] for row in conn.execute("SELECT version FROM schema_migrations")}
            if applied - set(_MIGRATIONS):
                raise GovernanceStorageError()  # written by a newer release: refuse, do not guess
            for version in sorted(_MIGRATIONS):
                if version not in applied:
                    for statement in _MIGRATIONS[version].split(";\n"):
                        if statement.strip():
                            conn.execute(statement)
                    conn.execute("INSERT INTO schema_migrations (version, applied_at) VALUES (?, strftime('%s','now'))",
                                 (version,))
            conn.execute("COMMIT")
        except GovernanceStorageError:
            self._rollback()
            raise
        except sqlite3.Error:
            self._rollback()
            raise GovernanceStorageError() from None

    def _rollback(self) -> None:
        with contextlib.suppress(sqlite3.Error):
            self._conn.execute("ROLLBACK")

    def schema_version(self) -> int:
        with self._lock:
            conn = self._live()
            return max((row[0] for row in conn.execute("SELECT version FROM schema_migrations")), default=0)

    def _live(self) -> sqlite3.Connection:
        if self._conn is None:
            raise GovernanceStorageError()
        return self._conn

    @contextlib.contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        """One write transaction. Commits on success, rolls back on any exception."""
        with self._lock:
            conn = self._live()
            try:
                conn.execute("BEGIN IMMEDIATE")
            except sqlite3.Error:
                raise GovernanceStorageError() from None
            try:
                yield conn
            except BaseException:
                self._rollback()
                raise
            try:
                conn.execute("COMMIT")
            except sqlite3.Error:
                self._rollback()
                raise GovernanceStorageError() from None

    def read(self, fn):
        """Read-only access: fn(connection) runs without a write transaction. Never used for mutations."""
        with self._lock:
            return fn(self._live())

    def integrity_ok(self) -> bool:
        with self._lock:
            try:
                return self._live().execute("PRAGMA integrity_check").fetchall() == [("ok",)]
            except sqlite3.Error:
                raise GovernanceStorageError() from None

    def close(self) -> None:
        with self._lock:
            conn, self._conn = self._conn, None
            if conn is not None:
                with contextlib.suppress(sqlite3.Error):
                    conn.close()

    # ------------------------------------------------------------ configuration (own transactions)
    def upsert_pricing(self, version: PricingVersion) -> int:
        """Add a pricing version. Same key and same values is a no-op. Different values for an existing key
        is refused, so a historical price can never be rewritten."""
        with self.transaction() as conn:
            row = conn.execute(
                "SELECT pricing_version_id, currency, input_per_million, output_per_million, "
                "cached_input_per_million, reasoning_per_million FROM pricing_versions "
                "WHERE provider_id = ? AND model_id = ? AND effective_from = ?",
                (version.provider_id, version.model_id, version.effective_from),
            ).fetchone()
            wanted = (version.currency, _text(version.input_per_million), _text(version.output_per_million),
                      _text(version.cached_input_per_million), _text(version.reasoning_per_million))
            if row is not None:
                if tuple(row[1:]) != wanted:
                    raise GovernanceConflictError()
                return int(row[0])
            cursor = conn.execute(
                "INSERT INTO pricing_versions (provider_id, model_id, currency, effective_from, input_per_million, "
                "output_per_million, cached_input_per_million, reasoning_per_million) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (version.provider_id, version.model_id, version.currency, version.effective_from, *wanted[1:],
                 ),
            )
            return int(cursor.lastrowid)

    def pricing_versions(self, provider_id: str, model_id: str) -> list[PricingVersion]:
        from decimal import Decimal
        with self._lock:
            rows = self._live().execute(
                "SELECT pricing_version_id, provider_id, model_id, currency, effective_from, input_per_million, "
                "output_per_million, cached_input_per_million, reasoning_per_million FROM pricing_versions "
                "WHERE provider_id = ? AND model_id = ? ORDER BY effective_from",
                (provider_id, model_id),
            ).fetchall()
        return [PricingVersion(
            pricing_version_id=r[0], provider_id=r[1], model_id=r[2], currency=r[3], effective_from=r[4],
            input_per_million=Decimal(r[5]), output_per_million=Decimal(r[6]),
            cached_input_per_million=None if r[7] is None else Decimal(r[7]),
            reasoning_per_million=None if r[8] is None else Decimal(r[8]),
        ) for r in rows]

    def upsert_budget(self, scope_type: str, scope_value: str, period: str, currency: str, limit: str) -> int:
        from sanour_ai.governance.cost import parse_price
        if scope_type not in SCOPE_TYPES or period not in PERIODS:
            raise ValueError("budget scope or period is not allowed")
        if scope_type == "global" and scope_value != "":
            raise ValueError("global budget takes no scope value")
        if scope_type != "global" and not scope_value:
            raise ValueError("scope value is required")
        if not isinstance(currency, str) or len(currency) != 3 or not currency.isupper():
            raise ValueError("currency must be a three-letter ISO code")
        amount = parse_price(limit) if not isinstance(limit, Decimal) else limit
        if amount < 0 or not amount.is_finite():
            raise ValueError("budget limit must not be negative")
        with self.transaction() as conn:
            conn.execute(
                "INSERT INTO budgets (scope_type, scope_value, period, currency, limit_amount) VALUES (?, ?, ?, ?, ?) "
                "ON CONFLICT (scope_type, scope_value, period, currency) DO UPDATE SET limit_amount = excluded.limit_amount",
                (scope_type, scope_value, period, currency, format_money(amount)),
            )
            return int(conn.execute(
                "SELECT budget_id FROM budgets WHERE scope_type = ? AND scope_value = ? AND period = ? AND currency = ?",
                (scope_type, scope_value, period, currency)).fetchone()[0])

    def upsert_quota(self, scope_type: str, scope_value: str, period: str, metric: str, limit: int) -> int:
        if scope_type not in SCOPE_TYPES or period not in PERIODS or metric not in QUOTA_METRICS:
            raise ValueError("quota scope, period or metric is not allowed")
        if scope_type == "global" and scope_value != "":
            raise ValueError("global quota takes no scope value")
        if scope_type != "global" and not scope_value:
            raise ValueError("scope value is required")
        if isinstance(limit, bool) or not isinstance(limit, int) or limit < 0:
            raise ValueError("quota limit must be a non-negative whole number")
        with self.transaction() as conn:
            conn.execute(
                "INSERT INTO quota_limits (scope_type, scope_value, period, metric, limit_value) VALUES (?, ?, ?, ?, ?) "
                "ON CONFLICT (scope_type, scope_value, period, metric) DO UPDATE SET limit_value = excluded.limit_value",
                (scope_type, scope_value, period, metric, limit),
            )
            return int(conn.execute(
                "SELECT quota_id FROM quota_limits WHERE scope_type = ? AND scope_value = ? AND period = ? AND metric = ?",
                (scope_type, scope_value, period, metric)).fetchone()[0])


def _text(value) -> str | None:
    return None if value is None else format_money(value)
