"""Admission, settlement, recovery and explicit exposure resolution (Stage 10.49-R2).

admit(): one BEGIN IMMEDIATE transaction checks every applicable budget and quota and writes the reservation.

settle(): two persistent phases.
  Phase 1 (record intent): one transaction stores the verified outcome (kind, provider_started, usage, digest)
           and moves the reservation to settlement_pending. From here on the usage is durable: a later failure, a
           crash or a restart cannot destroy it. A second intent with the same digest is a duplicate (no-op).
           A second intent with a different digest is a conflict: refused, first intent kept.
  Phase 2 (apply): one transaction turns the stored intent into actual cost, exposure or release. It runs only on
           settlement_pending, under the write lock, so concurrent recovery applies it exactly once.

Exposure (provider may have been charged, usage unknown) stays reserved against the budget until explicitly
resolved through one of three paths:
  - verified usage reconciliation (resolve_exposure): authorized actor, priced usage moves exposure into actual cost.
  - authorized write-off (write_off): exposure leaves availability and goes to written_off. Never actual cost.
  - authorized retention (retain): the exposure is reviewed and kept. No money changes.
Every manual path needs an authorized actor (controller configuration), a reason and an optional evidence reference.
Stage 10.49-R3: governance_log is the durable record of every decision, and each decision's governance_log row is
written in the same transaction as the mutation. The external audit event of a committed decision is written to
audit_outbox in that same transaction, and delivered only after commit. Delivery states are pending, delivered and
failed. A failed delivery never rolls back a committed decision and is kept for retry. Recovery (sweep) delivers
pending and failed events. Delivery is idempotent on outbox_key. Admission events are a pre-provider gate: the
provider is not invoked unless the sink confirms them (Stage 10.49-R4).
Stage 10.49-R4: delivery goes to a separate durable audit sink (sink.py). Outbox rows are claimed under a lease, so two
workers never deliver the same pending event at once, and a crashed worker's lease expires so the event is reclaimed.
Only a sink receipt marks an event delivered. Duplicates are absorbed by the sink's deduplication on outbox_key.
"""

from __future__ import annotations

import contextlib
import hashlib
import json
import re
import sqlite3
import time
import uuid
from collections.abc import Callable, Mapping
from datetime import datetime, timezone
from decimal import Decimal

from sanour_ai.errors import ErrorCode, FailureKind, SanourError
from sanour_ai.governance import budget, quota
from sanour_ai.governance.budget import window_for
from sanour_ai.governance.cost import (
    STATUS_PRICED, PricingVersion, actual_cost, format_money, worst_case_cost,
)
from sanour_ai.governance.store import GovernanceStorageError, GovernanceStore
from sanour_ai.governance.types import Bounds, Refusal, SettleResult, Settlement, Ticket
from sanour_ai.models.usage import Usage
from sanour_ai.governance.sink import DurableSqliteSink
from sanour_ai.governance.sink_contract import AuditSink, SinkFailed, SinkOutcomeUnknown, SinkPayloadConflict  # noqa: F401
from sanour_ai.observability.audit import AuditLogger

GOVERNANCE_REFUSED_MESSAGE = "usage limit reached"
GOVERNANCE_UNAVAILABLE_MESSAGE = "usage governance unavailable; request not processed"
SETTLEMENT_KINDS = frozenset({"completed", "failed", "timed_out", "expired", "released"})
_GRACE_SECONDS = 60
_ACTOR = re.compile(r"[A-Za-z0-9._@:-]{1,64}")
_OUTBOX_KEY_PATTERN = re.compile(r"gov:[0-9]{1,18}:[a-z_.]{1,48}")
_EVIDENCE = re.compile(r"[A-Za-z0-9._:/#-]{1,128}")
RECONCILIATION_ACTOR = "reconciliation"

OP_INTENT = "settle_intent"
OP_APPLY = "settle_apply"
OP_RECOVERY_APPLY = "recovery_apply"
OP_RECOVERY_EXPIRE = "recovery_expire"
OP_VERIFIED = "verified_usage"
OP_WRITE_OFF = "write_off"
OP_RETAIN = "retain"
OP_ADMIT = "admit"
OP_RECOVERY_RELEASE = "recovery_release"
OP_CONFLICT = "conflict_resolve"


def _utc_day(epoch: float) -> str:
    return datetime.fromtimestamp(epoch, tz=timezone.utc).strftime("%Y-%m-%d")


def intent_digest(kind: str, started: bool, usage: Usage | None) -> str:
    """Identity of a settlement outcome. Equal digests are duplicates; different digests are conflicts."""
    counts = ([usage.input_tokens, usage.output_tokens, usage.total_tokens, usage.cached_input_tokens,
               usage.reasoning_tokens] if usage is not None else [None] * 5)
    return hashlib.sha256(json.dumps([kind, bool(started), counts]).encode("utf-8")).hexdigest()


class _Refused(Exception):
    """Internal: a refusal inside a transaction. Raising it rolls the transaction back."""

    def __init__(self, reason: str) -> None:
        super().__init__(reason)
        self.reason = reason


def _pricing_in_force(conn: sqlite3.Connection, provider_id: str, model_id: str, day: str) -> PricingVersion | None:
    rows = conn.execute(
        "SELECT pricing_version_id, provider_id, model_id, currency, effective_from, input_per_million, "
        "output_per_million, cached_input_per_million, reasoning_per_million FROM pricing_versions "
        "WHERE provider_id = ? AND model_id = ? AND effective_from <= ? ORDER BY effective_from DESC LIMIT 1",
        (provider_id, model_id, day),
    ).fetchall()
    return _pricing_row(rows[0]) if rows else None


def _pricing_by_id(conn: sqlite3.Connection, pricing_version_id: int | None) -> PricingVersion | None:
    if pricing_version_id is None:
        return None
    row = conn.execute(
        "SELECT pricing_version_id, provider_id, model_id, currency, effective_from, input_per_million, "
        "output_per_million, cached_input_per_million, reasoning_per_million FROM pricing_versions "
        "WHERE pricing_version_id = ?", (pricing_version_id,)).fetchone()
    return _pricing_row(row) if row else None


def _pricing_row(row: tuple) -> PricingVersion:
    return PricingVersion(
        pricing_version_id=int(row[0]), provider_id=row[1], model_id=row[2], currency=row[3],
        effective_from=row[4], input_per_million=Decimal(row[5]), output_per_million=Decimal(row[6]),
        cached_input_per_million=None if row[7] is None else Decimal(row[7]),
        reasoning_per_million=None if row[8] is None else Decimal(row[8]),
    )


def _quota_values(usage: Usage | None) -> dict[str, int]:
    """Known counts only. A count that was not reported is absent, never zero."""
    values: dict[str, int] = {"requests": 1}
    if usage is None:
        return values
    if usage.input_tokens is not None:
        values["input_tokens"] = usage.input_tokens
    if usage.output_tokens is not None:
        values["output_tokens"] = usage.output_tokens
    total = usage.total_tokens
    if total is None and usage.input_tokens is not None and usage.output_tokens is not None:
        total = usage.input_tokens + usage.output_tokens
    if total is not None:
        values["total_tokens"] = total
    return values


def _exposed_count(conn: sqlite3.Connection, request_id: str) -> int:
    return conn.execute("SELECT COUNT(*) FROM reservation_lines WHERE request_id = ? AND outcome = 'exposed'",
                        (request_id,)).fetchone()[0]


_STATE_PRECEDENCE = ("conflict", "failed", "unknown", "attempted", "pending", "conflict_resolved", "confirmed")


def _aggregate(states) -> str:
    """The worst state wins. Confirmed only when every event is confirmed."""
    present = set(states)
    for state in _STATE_PRECEDENCE:
        if state in present:
            return state
    return "pending"


def _log(conn: sqlite3.Connection, request_id: str | None, operation: str, outcome: str, actor: str | None,
         now: int) -> int:
    cursor = conn.execute("INSERT INTO governance_log (request_id, operation, outcome, actor, at) "
                          "VALUES (?, ?, ?, ?, ?)", (request_id, operation, outcome, actor, now))
    return int(cursor.lastrowid)


def _enqueue(conn: sqlite3.Connection, log_id: int, event: str, now: int, **fields) -> str:
    """Stage 10.49-R3: the external audit event of a committed decision. Written in the SAME transaction as the
    governance mutation and its governance_log row, so it exists if and only if the decision exists. Delivery
    happens only after commit. The key is derived from the log row, so it is unique and stable across retries."""
    key = f"gov:{log_id}:{event}"
    conn.execute("INSERT INTO audit_outbox (event_key, log_id, event, fields, status, attempts, created_at) "
                 "VALUES (?, ?, ?, ?, 'pending', 0, ?)", (key, log_id, event, json.dumps(fields, sort_keys=True), now))
    return key


class AdmissionController:
    """Injected into the core. Holds no provider logic and never changes the chosen profile."""

    def __init__(self, store: GovernanceStore, *, audit: AuditLogger, bounds: Mapping[str, Bounds],
                 clock: Callable[[], float] = time.time, required_audit: bool = True,
                 authorized_actors: frozenset[str] = frozenset(), sink=None,
                 lease_seconds: float = 60.0) -> None:
        self._store = store
        self._audit = audit
        if not (1.0 <= float(lease_seconds) <= 3600.0):
            raise ValueError("lease_seconds must be between 1 and 3600")
        self._lease = float(lease_seconds)
        self.recovery_read_failures = 0  # Stage 10.49-R6: visible count of recovery reads/writes that failed
        self._diagnostic_log_failures = 0  # Stage 10.49-R6-R1: refusal/failure records that could not be written
        # Stage 10.49-R4: the audit sink is a separate durable store. Default: a sibling file of the governance DB.
        self._sink = sink if sink is not None else DurableSqliteSink(
            ":memory:" if store.path == ":memory:" else store.path + ".sink", clock=clock)
        self._bounds = dict(bounds)
        self._clock = clock
        self._required_audit = required_audit
        self._authorized = frozenset(authorized_actors)
        for name in self._authorized:
            if not isinstance(name, str) or not _ACTOR.fullmatch(name):
                raise ValueError("authorized actor identifiers must match the actor pattern")

    def close(self) -> None:
        self._store.close()
        with contextlib.suppress(Exception):
            self._sink.close()

    # ------------------------------------------------------------------ admission
    def admit(self, request, profile) -> Ticket:
        now = self._clock()
        day = _utc_day(now)
        required: list[str] = []
        bound = self._bounds.get(profile.alias)
        max_output = min(request.max_output_tokens, bound.max_output_tokens) if bound else None
        amounts = quota.amounts_for(bound.max_input_tokens, max_output) if bound else None
        try:
            with self._store.transaction() as conn:
                pricing = _pricing_in_force(conn, profile.provider, profile.model_id, day)
                worst = (worst_case_cost(pricing, bound.max_input_tokens, max_output)
                         if pricing is not None and bound is not None else None)
                budget_rows = budget.applicable(conn, profile.provider, profile.model_id, profile.alias)
                quota_rows = quota.applicable(conn, profile.provider, profile.model_id, profile.alias)
                blines = budget.check_and_reserve(conn, budget_rows, pricing, worst, day) if budget_rows else []
                qlines = quota.check_and_reserve(conn, quota_rows, amounts, day) if quota_rows else []
                timeout = int(request.timeout_seconds) + 1
                conn.execute(
                    "INSERT INTO reservations (request_id, state, provider_id, model_id, profile_id, utc_day, "
                    "pricing_version_id, currency, reserved_cost, created_at, expires_at, admission_gate) "
                    "VALUES (?, 'reserved', ?, ?, ?, ?, ?, ?, ?, ?, ?, 'closed')",
                    (request.request_id, profile.provider, profile.model_id, profile.alias, day,
                     pricing.pricing_version_id if pricing else None,
                     pricing.currency if pricing else None,
                     format_money(worst) if worst is not None else None,
                     int(now), int(now) + timeout + _GRACE_SECONDS),
                )
                budget.write_reservation(conn, request.request_id, blines)
                quota.write_reservation(conn, request.request_id, qlines)
                admit_log = _log(conn, request.request_id, OP_ADMIT, "ok", None, int(now))
                if blines:
                    required.append(_enqueue(conn, admit_log, "budget.reserved", int(now),
                                             request_id=request.request_id, budget_count=len(blines)))
                if qlines:
                    required.append(_enqueue(conn, admit_log, "quota.reserved", int(now),
                                             request_id=request.request_id, quota_count=len(qlines)))
        except Refusal as refusal:
            self._log_best_effort(request.request_id, OP_ADMIT, "refused", None, int(now))
            self._audit_refusal(request, profile, refusal)
            raise SanourError(ErrorCode.PROVIDER_RATE_LIMITED, GOVERNANCE_REFUSED_MESSAGE, retryable=False,
                              scope=refusal.kind, internal_kind=FailureKind.LIMIT_REACHED) from None
        except (sqlite3.Error, GovernanceStorageError):
            raise SanourError(ErrorCode.INTERNAL_ERROR, GOVERNANCE_UNAVAILABLE_MESSAGE) from None

        pricing_id = pricing.pricing_version_id if pricing else None
        if pricing is not None:
            self._audit.emit("pricing.version_selected", request_id=request.request_id, provider=profile.provider,
                             model_id=profile.model_id, pricing_version_id=pricing_id)
        else:
            self._audit.emit("cost.unknown", request_id=request.request_id, cost_status="unknown_pricing")
        ticket = Ticket(request.request_id, len(blines), len(qlines), pricing_id)
        # Stage 10.49-R4: the reservation's audit events must be CONFIRMED by the sink before any provider call.
        # Not confirmed and required: release through a committed settlement and refuse. No provider call.
        if required:
            states = self._deliver_states(required)
            if self._required_audit and any(v != "confirmed" for v in states.values()):
                self._fail_closed_after_reserve(ticket)
        # Stage 10.49-R5: the provider may run only after this commit. A failure here fails closed as well.
        if not self._open_gate(request.request_id):
            self._fail_closed_after_reserve(ticket)
        return ticket

    def _open_gate(self, request_id: str) -> bool:
        """The only path to a provider call. The gate opens in its own transaction, and only for a reservation that is
        still reserved and closed. Returns False when the gate did not open (storage failure or no such reservation)."""
        try:
            with self._store.transaction() as conn:
                cursor = conn.execute("UPDATE reservations SET admission_gate = 'open' WHERE request_id = ? "
                                      "AND state = 'reserved' AND admission_gate = 'closed'", (request_id,))
                return cursor.rowcount == 1
        except (sqlite3.Error, GovernanceStorageError):
            return False

    def _fail_closed_after_reserve(self, ticket: Ticket) -> None:
        self.settle_by_id(ticket.request_id, Settlement("released", provider_started=False))
        raise SanourError(ErrorCode.INTERNAL_ERROR, GOVERNANCE_UNAVAILABLE_MESSAGE)

    def _audit_refusal(self, request, profile, refusal: Refusal) -> None:
        event = "budget.rejected" if refusal.kind == "budget" else "quota.rejected"
        fields = {"request_id": request.request_id, "provider": profile.provider, "model_id": profile.model_id,
                  "scope_type": refusal.scope_type, "period": refusal.period,
                  "governance_reason": refusal.reason}
        if refusal.metric:
            fields["quota_metric"] = refusal.metric
        self._audit.emit(event, **fields)
        if refusal.reason == "cost_unknown":
            self._audit.emit("cost.unknown", request_id=request.request_id, cost_status="unknown_pricing")

    # ------------------------------------------------------------------ settlement, phase 1
    def settle(self, ticket: Ticket, settlement: Settlement) -> SettleResult:
        return self.settle_by_id(ticket.request_id, settlement)

    def settle_by_id(self, request_id: str, settlement: Settlement, *, operation: str = OP_INTENT) -> SettleResult:
        if settlement.kind not in SETTLEMENT_KINDS:
            raise ValueError("unknown settlement kind")
        status = self._record_intent(request_id, settlement, operation)
        if status == "not_found":
            return SettleResult(False, "not_found")
        if status == "final":
            return SettleResult(False, "already_settled")
        if status == "failed":
            return SettleResult(False, "settlement_failed")
        if status == "conflict":
            self._audit.emit("settlement.conflict", request_id=request_id, settlement="reconcile_failed")
            return SettleResult(False, "intent_conflict")
        return self._apply(request_id, OP_APPLY if operation == OP_INTENT else operation)

    def _record_intent(self, request_id: str, settlement: Settlement, operation: str) -> str:
        digest = intent_digest(settlement.kind, settlement.provider_started, settlement.usage)
        now = int(self._clock())
        try:
            with self._store.transaction() as conn:
                row = conn.execute("SELECT state, intent_digest FROM reservations WHERE request_id = ?",
                                   (request_id,)).fetchone()
                if row is None:
                    return "not_found"
                state, stored = row
                if state == "reserved":
                    usage = settlement.usage
                    cursor = conn.execute(
                        "UPDATE reservations SET state = 'settlement_pending', intent_kind = ?, intent_started = ?, "
                        "intent_input = ?, intent_output = ?, intent_total = ?, intent_cached = ?, "
                        "intent_reasoning = ?, intent_digest = ?, intent_source = ? "
                        "WHERE request_id = ? AND state = 'reserved'",
                        (settlement.kind, 1 if settlement.provider_started else 0,
                         usage.input_tokens if usage else None, usage.output_tokens if usage else None,
                         usage.total_tokens if usage else None, usage.cached_input_tokens if usage else None,
                         usage.reasoning_tokens if usage else None, digest, operation, request_id))
                    if cursor.rowcount != 1:
                        raise ValueError("reservation changed while recording intent")
                    _log(conn, request_id, operation, "ok", None, now)
                    return "recorded"
                if state == "settlement_pending":
                    # Same outcome again: a duplicate. A different outcome: a conflict. Either way the stored
                    # intent is the one that will be applied.
                    return "duplicate" if stored == digest else "conflict"
                return "final"
        except (sqlite3.Error, GovernanceStorageError, ValueError):
            self._audit.emit("settlement.failed", request_id=request_id, operation=operation, decision="failed")
            self._log_best_effort(request_id, operation, "failed", None, now)
            return "failed"

    # ------------------------------------------------------------------ settlement, phase 2
    def _apply(self, request_id: str, operation: str) -> SettleResult:
        now = int(self._clock())
        keys: list[str] = []
        try:
            with self._store.transaction() as conn:
                row = conn.execute(
                    "SELECT state, intent_kind, intent_started, intent_input, intent_output, intent_total, "
                    "intent_cached, intent_reasoning, pricing_version_id, reserved_cost FROM reservations "
                    "WHERE request_id = ?", (request_id,)).fetchone()
                if row is None:
                    return SettleResult(False, "not_found")
                if row[0] != "settlement_pending":
                    return SettleResult(False, "already_settled")
                kind, started = row[1], bool(row[2])
                usage = None
                if row[3] is not None or row[4] is not None:
                    usage = Usage(input_tokens=row[3], output_tokens=row[4], total_tokens=row[5],
                                  cached_input_tokens=row[6], reasoning_tokens=row[7])
                pricing = _pricing_by_id(conn, row[8])
                reserved_cost = row[9]
                if not started:
                    budget.apply(conn, request_id, None, release=True)
                    quota.apply(conn, request_id, {}, release=True)
                    cost_status, charged_from, actual, over = "not_billed", "none", None, False
                    state, settlement_kind = "released", "released"
                else:
                    cost = actual_cost(pricing, usage)
                    budget_actual = cost.amount if cost.status == STATUS_PRICED else None
                    outcomes = budget.apply(conn, request_id, budget_actual, release=False)
                    quota.apply(conn, request_id, _quota_values(usage), release=False)
                    if "actual" in outcomes:
                        charged_from = "actual"
                    elif "exposed" in outcomes:
                        charged_from = "exposed"
                    else:
                        charged_from = "none"
                    actual = cost.amount if cost.status == STATUS_PRICED else None
                    over = bool(outcomes and actual is not None and reserved_cost is not None
                                and actual > Decimal(reserved_cost))
                    cost_status = cost.status
                    state = "exposed" if _exposed_count(conn, request_id) else "settled"
                    settlement_kind = kind
                cursor = conn.execute(
                    "UPDATE reservations SET state = ?, settled_at = ?, settlement = ?, applied_at = ? "
                    "WHERE request_id = ? AND state = 'settlement_pending'",
                    (state, now, settlement_kind, now, request_id))
                if cursor.rowcount != 1:
                    raise ValueError("reservation changed while applying")
                conn.execute(
                    "INSERT INTO cost_records (request_id, cost_status, currency, actual_cost, pricing_version_id, "
                    "charged_from, over_reservation) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (request_id, cost_status, pricing.currency if pricing else None,
                     format_money(actual) if actual is not None else None,
                     pricing.pricing_version_id if pricing else None, charged_from, 1 if over else 0))
                log_id = _log(conn, request_id, operation, "ok", None, now)
                events = self._settled_events(request_id, settlement_kind, cost_status, charged_from, state)
                if operation != OP_APPLY:
                    events.append(("recovery.decision", {"request_id": request_id, "operation": operation,
                                                         "decision": "applied"}))
                for event, fields in events:
                    keys.append(_enqueue(conn, log_id, event, now, **fields))
        except (sqlite3.Error, GovernanceStorageError, ValueError):
            # Nothing was written. The intent is still stored, so recovery can apply it later. Never reported ok.
            self._audit.emit("settlement.failed", request_id=request_id, operation=operation, decision="failed")
            self._log_best_effort(request_id, operation, "failed", None, now)
            self._mark_failure(request_id, now)
            return SettleResult(False, "settlement_pending")
        audit_status = self._deliver(keys)
        return SettleResult(True, settlement_kind if started else "released", cost_status, charged_from,
                            audit_status=audit_status)

    def _settled_events(self, request_id, kind, cost_status, charged_from, state) -> list[tuple[str, dict]]:
        safe = kind if kind in SETTLEMENT_KINDS else "released"
        events = [("budget.reconciled", {"request_id": request_id, "settlement": safe,
                                         "cost_status": cost_status, "charged_from": charged_from}),
                  ("quota.reconciled", {"request_id": request_id, "settlement": safe})]
        if cost_status != STATUS_PRICED:
            events.append(("cost.unknown", {"request_id": request_id, "cost_status": cost_status}))
        if state == "exposed":
            events.append(("exposure.open", {"request_id": request_id}))
        return events

    def _log_best_effort(self, request_id, operation, outcome, actor, now) -> None:
        """Stage 10.49-R6-R1: DIAGNOSTIC records only (refusals and failures). The refusal or failure itself is
        already returned to the caller and audited, so losing this row never changes money. Losing it is never
        silent: it is counted (diagnostic_log_failures) and emitted. Required decisions are never routed here; their
        governance_log row is written in the mutation's own transaction, and its failure aborts the mutation.
        No recursion: this method writes one row, and the audit emit touches no database and never raises."""
        try:
            with self._store.transaction() as conn:
                _log(conn, request_id, operation, outcome, actor, now)
        except (sqlite3.Error, GovernanceStorageError, ValueError):
            self._diagnostic_log_failures += 1
            self._audit.emit("governance.log_failed", operation=operation, decision="failed")

    def diagnostic_log_failures(self) -> int:
        """Visible count of refusal and failure records that could not be written since this controller started."""
        return self._diagnostic_log_failures

    # ------------------------------------------------------------------ audit outbox (Stage 10.49-R3, R4)
    # Claim (governance DB, one write transaction) -> deliver (sink, its own durable commit, no governance lock)
    # -> settle (governance DB, only if this worker still holds the lease). Lease expiry gives crash recovery.
    def _now(self) -> float:
        return float(self._clock())

    def _deliver_states(self, keys: list[str]) -> dict[str, str]:
        """Synchronous attempt for the given outbox keys, then the state of each. Used for required admission events."""
        if not keys:
            return {}
        self.deliver_outbox(keys=keys)
        return self._states(keys)

    def _deliver(self, keys: list[str]) -> str | None:
        """Called only after the governance transaction has committed. Returns the aggregated audit state."""
        if not keys:
            return None
        return _aggregate(self._deliver_states(keys).values())

    def deliver_outbox(self, keys: list[str] | None = None) -> int:
        """Claim and deliver pending, failed and unknown events whose lease is free or expired. Returns how many this
        call confirmed. A confirmed receipt is the only thing that marks an event delivered. Outcomes:
        confirmed (sink receipt), failed (sink definitively did not record), unknown (sink outcome not known; retried
        safely because the sink de-duplicates), conflict (same key, different payload; never retried automatically)."""
        now = self._now()
        confirmed = 0
        for outbox_id, key, event, fields_text, token in self._claim(keys, now):
            receipt_id = None
            try:
                fields = json.loads(fields_text)
                receipt = self._sink.deliver(key, event, fields)
                outcome, last_error, receipt_id = "delivered", None, receipt.receipt_id
            except SinkPayloadConflict:
                outcome, last_error = "conflict", "payload_conflict"
            except SinkFailed:
                outcome, last_error = "failed", "sink_failed"
            except SinkOutcomeUnknown:
                outcome, last_error = "unknown", "sink_outcome_unknown"
            except Exception:  # noqa: BLE001  any unexpected sink error may hide a commit: classify as unknown
                outcome, last_error = "unknown", "sink_outcome_unknown"
            if self._settle_attempt(outbox_id, token, outcome, receipt_id, last_error, self._now()):
                confirmed += 1
        return confirmed

    def _claim(self, keys: list[str] | None, now: float) -> list[tuple]:
        try:
            with self._store.transaction() as conn:
                sql = ("SELECT outbox_id, event_key, event, fields FROM audit_outbox WHERE status IN "
                       "('pending', 'failed', 'unknown') AND (lease_token IS NULL OR lease_expires_at < ?)")
                params: list = [now]
                if keys is not None:
                    sql += " AND event_key IN (" + ",".join("?" * len(keys)) + ")"
                    params += list(keys)
                rows = conn.execute(sql + " ORDER BY outbox_id", params).fetchall()
                claimed = []
                for outbox_id, key, event, fields in rows:
                    token = uuid.uuid4().hex
                    cursor = conn.execute(
                        "UPDATE audit_outbox SET lease_token = ?, lease_expires_at = ?, attempts = attempts + 1 "
                        "WHERE outbox_id = ? AND status IN ('pending', 'failed', 'unknown') "
                        "AND (lease_token IS NULL OR lease_expires_at < ?)",
                        (token, now + self._lease, outbox_id, now))
                    if cursor.rowcount == 1:
                        claimed.append((outbox_id, key, event, fields, token))
                return claimed
        except (sqlite3.Error, GovernanceStorageError):
            return []

    def _settle_attempt(self, outbox_id: int, token: str, outcome: str, receipt_id: int | None,
                        last_error: str | None, now: float) -> bool:
        """Records an attempt's outcome only if this worker still holds the lease. A confirmed row is never overwritten."""
        try:
            with self._store.transaction() as conn:
                row = conn.execute("SELECT status, lease_token FROM audit_outbox WHERE outbox_id = ?",
                                   (outbox_id,)).fetchone()
                if row is None or row[0] == "delivered" or row[1] != token:
                    return False  # stale worker or already confirmed: nothing is written
                if outcome == "delivered":
                    conn.execute("UPDATE audit_outbox SET status = 'delivered', receipt_id = ?, delivered_at = ?, "
                                 "last_error = NULL, lease_token = NULL, lease_expires_at = NULL WHERE outbox_id = ?",
                                 (receipt_id, int(now), outbox_id))
                    return True
                conn.execute("UPDATE audit_outbox SET status = ?, last_error = ?, lease_token = NULL, "
                             "lease_expires_at = NULL WHERE outbox_id = ?", (outcome, last_error, outbox_id))
                return False
        except (sqlite3.Error, GovernanceStorageError):
            # The lease stays until it expires. The next attempt re-sends the same key and the sink returns the receipt.
            return False

    def delivery_states(self, keys: list[str]) -> dict[str, str]:
        """Read-only. Per outbox key: pending, attempted, confirmed, failed, unknown or conflict. Governance decision
        state is separate and is read from governance_log and reservations, never from this."""
        return self._states(list(keys)) if keys else {}

    def _states(self, keys: list[str]) -> dict[str, str]:
        now = self._now()
        try:
            rows = self._store.read(lambda conn: conn.execute(
                "SELECT o.event_key, o.status, o.attempts, o.lease_token, o.lease_expires_at, "
                "(SELECT COUNT(*) FROM conflict_resolutions c WHERE c.event_key = o.event_key) FROM audit_outbox o "
                "WHERE o.event_key IN ({})".format(",".join("?" * len(keys))), keys).fetchall())
        except (sqlite3.Error, GovernanceStorageError):
            return {key: "pending" for key in keys}
        out: dict[str, str] = {}
        for key, status, attempts, token, expires, resolved in rows:
            if status == "delivered":
                out[key] = "confirmed"
            elif status == "conflict":
                out[key] = "conflict_resolved" if resolved else "conflict"
            elif token is not None and expires is not None and expires >= now:
                out[key] = "attempted"
            elif status in ("failed", "unknown"):
                out[key] = status
            elif attempts > 0:
                out[key] = "unknown"  # an attempt started, its lease expired, its outcome was never recorded
            else:
                out[key] = "pending"
        for key in keys:
            out.setdefault(key, "pending")
        return out

    def _mark_failure(self, request_id: str, now: int) -> None:
        try:
            with self._store.transaction() as conn:
                conn.execute("UPDATE reservations SET last_failure = 'apply_write', "
                             "recovery_attempts = recovery_attempts + 1 WHERE request_id = ? "
                             "AND state = 'settlement_pending'", (request_id,))
        except (sqlite3.Error, GovernanceStorageError):
            # Stage 10.49-R6: the intent stays pending either way; the failure to record the attempt is counted.
            self.recovery_read_failures += 1
            self._audit.emit("recovery.mark_failed", request_id=request_id, decision="failed")

    # ------------------------------------------------------------------ recovery
    def sweep(self, *, everything: bool = False) -> int:
        """Recovery. Applies stored intents once each, and turns unfinished expired reservations into exposure once
        each (all of them when everything is set, at shutdown). One attempt per reservation per call: no retry loop."""
        now = int(self._clock())
        self.deliver_outbox()
        try:
            with self._store.transaction() as conn:
                pending = [r[0] for r in conn.execute(
                    "SELECT request_id FROM reservations WHERE state = 'settlement_pending' ORDER BY request_id")]
                expired = [(r[0], r[1]) for r in conn.execute(
                    "SELECT request_id, admission_gate FROM reservations WHERE state = 'reserved' "
                    "AND (? OR expires_at < ?) ORDER BY request_id", (1 if everything else 0, now))]
        except (sqlite3.Error, GovernanceStorageError):
            # Stage 10.49-R6: a failed recovery read is visible (counter and audit event), never a silent zero.
            self.recovery_read_failures += 1
            self._audit.emit("recovery.read_failed", decision="failed")
            return 0
        applied = 0
        for request_id in pending:
            if self._apply(request_id, OP_RECOVERY_APPLY).applied:
                applied += 1
        for request_id, gate in expired:
            if gate == "closed":
                # Stage 10.49-R5: the gate never opened, so no provider call can have happened. Release, never expose.
                result = self.settle_by_id(request_id, Settlement("released", provider_started=False),
                                           operation=OP_RECOVERY_RELEASE)
            else:
                result = self.settle_by_id(request_id, Settlement("expired", provider_started=True),
                                           operation=OP_RECOVERY_EXPIRE)
            if result.applied:
                applied += 1
        return applied

    # ------------------------------------------------------------------ exposure resolution
    def _check_manual(self, actor: str, reason: str, evidence_ref: str | None) -> str | None:
        """Returns a refusal reason, or None when the input is well formed. Never echoes the input."""
        if not isinstance(actor, str) or not _ACTOR.fullmatch(actor):
            return "invalid_input"
        if not isinstance(reason, str) or not (1 <= len(reason) <= 500) or any(
                ord(ch) < 32 for ch in reason):
            return "invalid_input"
        if evidence_ref is not None and (not isinstance(evidence_ref, str) or not _EVIDENCE.fullmatch(evidence_ref)):
            return "invalid_input"
        return None

    def _refuse(self, request_id: str, operation: str, reason: str, actor: str | None) -> SettleResult:
        self._audit.emit("exposure.refused", request_id=request_id, operation=operation,
                         governance_reason=reason, actor=actor if actor and _ACTOR.fullmatch(actor) else None,
                         decision="refused")
        self._log_best_effort(request_id, operation, "refused", actor if actor and _ACTOR.fullmatch(actor) else None,
                              int(self._clock()))
        return SettleResult(False, reason)

    def resolve_exposure(self, request_id: str, usage: Usage, *, actor: str,
                         evidence_ref: str | None = None) -> SettleResult:
        """Verified usage reconciliation (authorized actor required: usage can move exposure into spending). Replaces exposure with priced usage. The usage is the evidence, and the
        action is recorded under the reconciliation actor. Refused unless the usage prices exactly and covers every
        exposed count. Refusals roll back every write."""
        invalid = self._check_manual(actor, "verified usage reconciliation", evidence_ref)
        if invalid is not None:
            return self._refuse(request_id, OP_VERIFIED, invalid, None)
        if actor not in self._authorized:
            return self._refuse(request_id, OP_VERIFIED, "unauthorized", actor)
        now = int(self._clock())
        keys: list[str] = []
        try:
            with self._store.transaction() as conn:
                row = conn.execute("SELECT state, pricing_version_id, currency FROM reservations WHERE request_id = ?",
                                   (request_id,)).fetchone()
                if row is None:
                    raise _Refused("not_found")
                if row[0] != "exposed":
                    raise _Refused("not_exposed")
                pricing = _pricing_by_id(conn, row[1])
                cost = actual_cost(pricing, usage)
                if cost.status != STATUS_PRICED:
                    raise _Refused("usage_not_priced")
                if budget.exposed_lines(conn, request_id):
                    budget.resolve_exposed(conn, request_id, cost.amount)
                    conn.execute("UPDATE cost_records SET cost_status = 'priced', actual_cost = ?, "
                                 "charged_from = 'actual' WHERE request_id = ?",
                                 (format_money(cost.amount), request_id))
                try:
                    quota.resolve_exposed(conn, request_id, _quota_values(usage))
                except ValueError:
                    raise _Refused("usage_incomplete") from None
                fully = _exposed_count(conn, request_id) == 0
                if fully:
                    conn.execute("UPDATE reservations SET state = 'settled' WHERE request_id = ?", (request_id,))
                conn.execute("INSERT INTO exposure_resolutions (request_id, resolution, actor, reason, evidence_ref, "
                             "decided_at, currency) VALUES (?, 'verified_usage', ?, ?, ?, ?, ?)",
                             (request_id, actor, "verified usage reconciliation", evidence_ref,
                              now, row[2]))
                log_id = _log(conn, request_id, OP_VERIFIED, "ok", actor, now)
                keys.append(_enqueue(conn, log_id, "exposure.resolved", now, request_id=request_id,
                                     resolution="verified_usage", actor=actor, decision="applied"))
        except _Refused as refused:
            return self._refuse(request_id, OP_VERIFIED, refused.reason, actor)
        except sqlite3.IntegrityError:
            return self._refuse(request_id, OP_VERIFIED, "already_resolved", actor)
        except (sqlite3.Error, GovernanceStorageError):
            return SettleResult(False, "storage_error")
        return SettleResult(True, "resolved" if fully else "partially_resolved", STATUS_PRICED, "actual",
                            audit_status=self._deliver(keys))

    def write_off(self, request_id: str, *, actor: str, reason: str, evidence_ref: str | None = None) -> SettleResult:
        """Authorized manual write-off. Exposure leaves availability and is recorded as written_off. It is never
        recorded as actual cost, and no provider usage is created."""
        return self._manual(request_id, actor, reason, evidence_ref, OP_WRITE_OFF)

    def retain(self, request_id: str, *, actor: str, reason: str, evidence_ref: str | None = None) -> SettleResult:
        """Authorized manual review that keeps the exposure as it is. No money changes."""
        return self._manual(request_id, actor, reason, evidence_ref, OP_RETAIN)

    def _manual(self, request_id: str, actor: str, reason: str, evidence_ref: str | None, operation: str) -> SettleResult:
        invalid = self._check_manual(actor, reason, evidence_ref)
        if invalid is not None:
            return self._refuse(request_id, operation, invalid, None)
        if actor not in self._authorized:
            return self._refuse(request_id, operation, "unauthorized", actor)
        now = int(self._clock())
        resolution = "write_off" if operation == OP_WRITE_OFF else "retain"
        keys: list[str] = []
        try:
            with self._store.transaction() as conn:
                row = conn.execute("SELECT state, currency FROM reservations WHERE request_id = ?",
                                   (request_id,)).fetchone()
                if row is None:
                    raise _Refused("not_found")
                state = row[0]
                if state in ("written_off", "settled", "released"):
                    raise _Refused("already_resolved")
                if state != "exposed":
                    raise _Refused("not_exposed")
                if operation == OP_WRITE_OFF:
                    budget.write_off(conn, request_id)
                    quota.write_off(conn, request_id)
                    if _exposed_count(conn, request_id) == 0:
                        conn.execute("UPDATE reservations SET state = 'written_off' WHERE request_id = ?",
                                     (request_id,))
                conn.execute("INSERT INTO exposure_resolutions (request_id, resolution, actor, reason, evidence_ref, "
                             "decided_at, currency) VALUES (?, ?, ?, ?, ?, ?, ?)",
                             (request_id, resolution, actor, reason, evidence_ref, now, row[1]))
                log_id = _log(conn, request_id, operation, "ok", actor, now)
                keys.append(_enqueue(conn, log_id, "exposure.resolved", now, request_id=request_id,
                                     resolution=resolution, actor=actor, decision="applied"))
        except _Refused as refused:
            return self._refuse(request_id, operation, refused.reason, actor)
        except sqlite3.IntegrityError:
            return self._refuse(request_id, operation, "already_resolved", actor)
        except (sqlite3.Error, GovernanceStorageError):
            return SettleResult(False, "storage_error")
        return SettleResult(True, "written_off" if operation == OP_WRITE_OFF else "retained",
                            audit_status=self._deliver(keys))

    def resolve_conflict(self, outbox_key: str, *, actor: str, reason: str, evidence_ref: str) -> SettleResult:
        """Operator acknowledgement of a terminal conflict row (Stage 10.49-R5). Append-only: the conflict row and its
        original payload are kept unchanged, and the acknowledgement is a new resolution row plus a governance_log row,
        written in one transaction. It never retries the sink, never deletes, never moves money.
        Requires an authorized actor (controller allowlist), a non-empty reason, and an evidence reference."""
        if not isinstance(outbox_key, str) or not _OUTBOX_KEY_PATTERN.fullmatch(outbox_key):
            return self._refuse_conflict(outbox_key, "invalid_input", None)
        if not isinstance(evidence_ref, str) or not _EVIDENCE.fullmatch(evidence_ref):
            return self._refuse_conflict(outbox_key, "invalid_input", None)
        invalid = self._check_manual(actor, reason, evidence_ref)
        if invalid is None and not reason.strip():
            invalid = "invalid_input"  # whitespace is not a reason
        if invalid is not None:
            return self._refuse_conflict(outbox_key, invalid, None)
        if actor not in self._authorized:
            return self._refuse_conflict(outbox_key, "unauthorized", actor)
        now = int(self._clock())
        try:
            with self._store.transaction() as conn:
                row = conn.execute("SELECT outbox_id, status, fields FROM audit_outbox WHERE event_key = ?",
                                   (outbox_key,)).fetchone()
                if row is None:
                    raise _Refused("not_found")
                if row[1] != "conflict":
                    raise _Refused("not_conflict")
                digest = hashlib.sha256(row[2].encode("utf-8")).hexdigest()
                log_id = _log(conn, None, OP_CONFLICT, "ok", actor, now)
                conn.execute("INSERT INTO conflict_resolutions (outbox_id, event_key, log_id, decision, actor, reason, "
                             "evidence_ref, original_digest, decided_at) VALUES (?, ?, ?, 'acknowledged', ?, ?, ?, ?, ?)",
                             (row[0], outbox_key, log_id, actor, reason, evidence_ref, digest, now))
        except _Refused as refused:
            return self._refuse_conflict(outbox_key, refused.reason, actor)
        except sqlite3.IntegrityError:
            return self._refuse_conflict(outbox_key, "already_resolved", actor)
        except (sqlite3.Error, GovernanceStorageError):
            return SettleResult(False, "storage_error")
        return SettleResult(True, "resolved", audit_status="conflict_resolved")

    def _refuse_conflict(self, outbox_key, reason: str, actor: str | None) -> SettleResult:
        safe_actor = actor if isinstance(actor, str) and _ACTOR.fullmatch(actor) else None
        self._log_best_effort(None, OP_CONFLICT, "refused", safe_actor, int(self._clock()))
        return SettleResult(False, reason)

    def governance_report(self, **filters) -> dict[str, object]:
        """Read-only, per-currency report. Filters: provider, model, profile, currency, utc_day."""
        from sanour_ai.governance.reporting import governance_report
        return governance_report(self._store, **filters)

    # ------------------------------------------------------------------ position report (per window)
    def report(self, utc_day: str) -> dict[str, object]:
        """Per budget and per quota window for one UTC day. Each figure has its own name. See also
        governance.reporting.governance_report for the filterable, per-currency report."""
        with self._store.transaction() as conn:
            budgets = []
            for budget_id, scope_type, scope_value, period, currency, limit_text in conn.execute(
                    "SELECT budget_id, scope_type, scope_value, period, currency, limit_amount FROM budgets "
                    "ORDER BY budget_id"):
                window = window_for(period, utc_day)
                reserved, spent, exposed = budget.totals(conn, budget_id, window)
                limit = Decimal(limit_text)
                budgets.append({
                    "scope_type": scope_type, "scope_value": scope_value, "period": period, "window": window,
                    "currency": currency, "limit": format_money(limit),
                    "actual_spent": format_money(spent), "reserved_in_flight": format_money(reserved),
                    "uncertain_exposure": format_money(exposed),
                    "written_off": format_money(budget.written_off_amount(conn, budget_id, window)),
                    "available": format_money(limit - reserved - spent - exposed),
                })
            quotas = []
            for quota_id, scope_type, scope_value, period, metric, limit in conn.execute(
                    "SELECT quota_id, scope_type, scope_value, period, metric, limit_value FROM quota_limits "
                    "ORDER BY quota_id"):
                window = window_for(period, utc_day)
                used, reserved, exposed = quota.totals(conn, quota_id, window)
                quotas.append({
                    "scope_type": scope_type, "scope_value": scope_value, "period": period, "window": window,
                    "metric": metric, "limit": limit, "actual_used": used, "reserved_in_flight": reserved,
                    "uncertain_exposure": exposed, "available": limit - used - reserved - exposed,
                })
        return {"budgets": budgets, "quotas": quotas}
