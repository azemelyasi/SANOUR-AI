"""Provider-independent cost, budget and quota governance (Stage 10.49). Import the parts you need."""
