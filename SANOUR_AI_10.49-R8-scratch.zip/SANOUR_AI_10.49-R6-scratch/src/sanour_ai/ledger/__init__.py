"""Stage 10.48: persistent usage ledger. Storage-independent contract, local SQLite implementation."""
