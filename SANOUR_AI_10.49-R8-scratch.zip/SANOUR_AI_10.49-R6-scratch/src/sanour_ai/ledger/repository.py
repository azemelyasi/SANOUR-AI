"""Repository contract for the usage ledger, independent of the storage engine.

append() is atomic: it either stores the whole record and returns True, stores nothing and returns False
(the same request was already stored with the same content), or raises. It never returns True without a
durable write. A different record for an existing request id raises LedgerConflictError.

report() returns the same shape from every engine (see ledger/report.py). Filters are validated exact
matches. The in-memory engine computes it in Python; the SQLite engine computes it inside SQLite.
"""

from __future__ import annotations

import abc
import threading
from collections.abc import Mapping, Sequence

from sanour_ai.ledger.record import LedgerRecord
from sanour_ai.ledger.report import DIMENSIONS, build_report


class LedgerStorageError(RuntimeError):
    """The ledger could not durably store or read. Fixed message: no engine text, no paths, no values."""

    def __init__(self) -> None:
        super().__init__("usage ledger storage unavailable")


class LedgerConflictError(ValueError):
    """The same request id arrived with different content. The stored record is kept unchanged."""

    def __init__(self) -> None:
        super().__init__("usage ledger already holds a different record for this request")


class UsageRepository(abc.ABC):
    @abc.abstractmethod
    def append(self, record: LedgerRecord) -> bool:
        """Store one record atomically. True if stored, False if an identical record already exists."""

    @abc.abstractmethod
    def records(self) -> list[LedgerRecord]:
        """Every stored record, in a deterministic order (recorded_at, then request id)."""

    def report(self, filters: Mapping[str, object] | None = None,
               dimensions: Sequence[str] = DIMENSIONS) -> dict[str, object]:
        """Report over stored records. Engines may override this to aggregate inside storage."""
        return build_report(self.records(), filters, dimensions)

    def close(self) -> None:
        """Release resources. Durable records remain durable."""


class InMemoryUsageRepository(UsageRepository):
    """Non-persistent implementation. Same contract. Test and development use only (never production)."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._by_id: dict[str, LedgerRecord] = {}

    def append(self, record: LedgerRecord) -> bool:
        with self._lock:
            existing = self._by_id.get(record.request_id)
            if existing is not None:
                if existing.identity() == record.identity():
                    return False
                raise LedgerConflictError()
            self._by_id[record.request_id] = record
            return True

    def records(self) -> list[LedgerRecord]:
        with self._lock:
            return sorted(self._by_id.values(), key=lambda r: (r.recorded_at, r.request_id))

    def report(self, filters: Mapping[str, object] | None = None,
               dimensions: Sequence[str] = DIMENSIONS) -> dict[str, object]:
        return build_report(self.records(), filters, dimensions)
