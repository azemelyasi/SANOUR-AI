"""Report contract for the usage ledger (Stage 10.48-R1). One definition, two engines.

- Pure Python reference: build_report(). The in-memory repository uses it, and tests use it as the
  reference the SQLite aggregation must equal.
- SQLite repository computes the same shape with GROUP BY (see sqlite_repository.py).

Rules shared by both:
- A token sum covers only the records that reported that field. sum is None when none did.
- known_count / unknown_count say how many records did and did not report the field.
- tokens_complete says whether the sum covers every request in the bucket. False means the sum is
  a partial total and must not be shown as the full figure. Unknown is never counted as zero.
- Filters are exact matches on a fixed set of keys. Anything else is refused, never passed through.
"""

from __future__ import annotations

import re
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass, field
from datetime import date

from sanour_ai.ledger.record import LedgerRecord
from sanour_ai.models.usage import USAGE_FIELDS

DIMENSIONS = ("provider", "profile", "model", "period", "delivery", "audit")
FILTER_KEYS = DIMENSIONS
DELIVERY_VALUES = frozenset({"delivered", "withheld"})
AUDIT_VALUES = frozenset({"recorded", "failed", "unavailable"})

_IDENT = re.compile(r"[a-z][a-z0-9_]{0,63}")
_MODEL = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}")
_DAY = re.compile(r"\d{4}-\d{2}-\d{2}")
_BAD_FILTER = "report filter is not allowed"
_BAD_DIMENSION = "unknown aggregation dimension"

KEY_OF = {
    "provider": lambda r: r.provider_id,
    "profile": lambda r: r.profile_id,
    "model": lambda r: r.model_id,
    "period": lambda r: r.utc_day,
    "delivery": lambda r: r.delivery,
    "audit": lambda r: r.audit_status,
}


def _valid_value(key: str, value: str) -> bool:
    if key in ("provider", "profile"):
        return bool(_IDENT.fullmatch(value))
    if key == "model":
        return bool(_MODEL.fullmatch(value))
    if key == "period":
        if not _DAY.fullmatch(value):
            return False
        try:
            date.fromisoformat(value)
        except ValueError:
            return False
        return True
    if key == "delivery":
        return value in DELIVERY_VALUES
    if key == "audit":
        return value in AUDIT_VALUES
    return False


def normalize_filters(filters: Mapping[str, object] | None) -> dict[str, str]:
    """Validated exact-match filters. None values mean 'no filter'. Anything unknown is refused."""
    if filters is None:
        return {}
    if not isinstance(filters, Mapping):
        raise ValueError(_BAD_FILTER)
    clean: dict[str, str] = {}
    for key, value in filters.items():
        if key not in FILTER_KEYS:
            raise ValueError(_BAD_FILTER)
        if value is None:
            continue
        if not isinstance(value, str) or not _valid_value(key, value):
            raise ValueError(_BAD_FILTER)
        clean[key] = value
    return clean


def checked_dimensions(dimensions: Sequence[str]) -> tuple[str, ...]:
    dims = tuple(dimensions)
    if any(d not in DIMENSIONS for d in dims):
        raise ValueError(_BAD_DIMENSION)
    return dims


def matches(record: LedgerRecord, filters: Mapping[str, str]) -> bool:
    return all(KEY_OF[key](record) == value for key, value in filters.items())


def format_bucket(*, requests: int, with_usage: int, delivered: int, withheld: int,
                  audit_recorded: int, audit_failed: int, audit_unavailable: int,
                  fields: Mapping[str, tuple[int | None, int]]) -> dict[str, object]:
    """The one bucket shape. fields maps each token name to (sum, known_count)."""
    tokens: dict[str, object] = {}
    complete: dict[str, bool] = {}
    for name in USAGE_FIELDS:
        total, known = fields[name]
        unknown = requests - known
        tokens[name] = {"sum": total, "known_count": known, "unknown_count": unknown}
        complete[name] = unknown == 0
    return {
        "requests": requests,
        "requests_with_usage": with_usage,
        "requests_without_usage": requests - with_usage,
        "delivery": {"delivered": delivered, "withheld": withheld},
        "usage_audit": {"recorded": audit_recorded, "failed": audit_failed, "unavailable": audit_unavailable},
        "tokens": tokens,
        "tokens_complete": complete,
    }


@dataclass
class FieldTotal:
    known_count: int = 0
    unknown_count: int = 0
    sum: int | None = None  # None until at least one record reports the field

    def add(self, value: int | None) -> None:
        if value is None:
            self.unknown_count += 1
            return
        self.known_count += 1
        self.sum = value if self.sum is None else self.sum + value


@dataclass
class Bucket:
    requests: int = 0
    requests_with_usage: int = 0
    requests_without_usage: int = 0
    audit_recorded: int = 0
    audit_failed: int = 0
    audit_unavailable: int = 0
    delivered: int = 0
    withheld: int = 0
    totals: dict[str, FieldTotal] = field(default_factory=lambda: {n: FieldTotal() for n in USAGE_FIELDS})

    def add(self, usage: dict[str, int | None] | None, audit: str, delivery: str) -> None:
        self.requests += 1
        if delivery == "delivered":
            self.delivered += 1
        elif delivery == "withheld":
            self.withheld += 1
        else:
            raise ValueError("unknown delivery status")
        if audit == "recorded":
            self.audit_recorded += 1
        elif audit == "failed":
            self.audit_failed += 1
        elif audit == "unavailable":
            self.audit_unavailable += 1
        else:
            raise ValueError("unknown usage audit status")
        if usage is None:
            for name in USAGE_FIELDS:
                self.totals[name].add(None)
            return
        self.requests_with_usage += 1
        for name in USAGE_FIELDS:
            self.totals[name].add(usage[name])

    def snapshot(self) -> dict[str, object]:
        return format_bucket(
            requests=self.requests,
            with_usage=self.requests_with_usage,
            delivered=self.delivered,
            withheld=self.withheld,
            audit_recorded=self.audit_recorded,
            audit_failed=self.audit_failed,
            audit_unavailable=self.audit_unavailable,
            fields={n: (t.sum, t.known_count) for n, t in self.totals.items()},
        )


def build_report(records: Iterable[LedgerRecord], filters: Mapping[str, object] | None = None,
                 dimensions: Sequence[str] = DIMENSIONS) -> dict[str, object]:
    """Reference report from records. Pure: the same records and filters give the same report."""
    flt = normalize_filters(filters)
    dims = checked_dimensions(dimensions)
    total = Bucket()
    by: dict[str, dict[str, Bucket]] = {d: {} for d in dims}
    for record in records:
        if not matches(record, flt):
            continue
        usage = record.counts() if record.usage_status == "reported" else None
        total.add(usage, record.audit_status, record.delivery)
        for dim in dims:
            by[dim].setdefault(KEY_OF[dim](record), Bucket()).add(usage, record.audit_status, record.delivery)
    report: dict[str, object] = {"total": total.snapshot()}
    for dim in dims:
        report[dim] = {key: bucket.snapshot() for key, bucket in sorted(by[dim].items())}
    return report
