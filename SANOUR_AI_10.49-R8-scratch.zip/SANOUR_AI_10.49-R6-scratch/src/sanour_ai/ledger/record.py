"""One usage ledger entry. Identifiers, the UTC day, delivery and audit status, and five nullable counters.

Nothing else is stored: no prompt, no output, no key, no provider payload, no price, no currency.
Unknown counters are None and stay None. Zero is never substituted.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime, timezone

from sanour_ai.models.execution import ExecutionResult
from sanour_ai.models.usage import USAGE_FIELDS

DELIVERY_STATUSES = frozenset({"delivered", "withheld"})
AUDIT_STATUSES = frozenset({"recorded", "failed", "unavailable"})
USAGE_STATUSES = frozenset({"reported", "unavailable"})

_REQUEST_ID = re.compile(r"[A-Za-z0-9_-]{1,64}")  # identifiers only, bounded
_IDENTIFIER = re.compile(r"[a-z][a-z0-9_]{0,63}")          # provider and profile identifiers
_MODEL = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}")  # model identities, never free text
_DAY = re.compile(r"\d{4}-\d{2}-\d{2}")


def _count(name: str, value: object) -> None:
    if value is None:
        return
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"ledger counter must be a non-negative whole number or unknown: {name}")


@dataclass(frozen=True)
class LedgerRecord:
    request_id: str
    utc_day: str
    recorded_at: str  # UTC, ISO 8601, seconds precision
    provider_id: str
    profile_id: str
    model_id: str
    api_surface: str | None
    delivery: str
    audit_status: str
    usage_status: str
    input_tokens: int | None
    output_tokens: int | None
    total_tokens: int | None
    cached_input_tokens: int | None
    reasoning_tokens: int | None

    def __post_init__(self) -> None:
        if not isinstance(self.request_id, str) or not _REQUEST_ID.fullmatch(self.request_id):
            raise ValueError("ledger request id must be 1 to 64 identifier characters")
        if not isinstance(self.utc_day, str) or not _DAY.fullmatch(self.utc_day):
            raise ValueError("ledger UTC day must be YYYY-MM-DD")
        if not isinstance(self.recorded_at, str) or not self.recorded_at.endswith("+00:00"):
            raise ValueError("ledger timestamp must be UTC")
        for name in ("provider_id", "profile_id"):
            if not isinstance(getattr(self, name), str) or not _IDENTIFIER.fullmatch(getattr(self, name)):
                raise ValueError(f"ledger identifier is not allowed: {name}")
        if not isinstance(self.model_id, str) or not _MODEL.fullmatch(self.model_id):
            raise ValueError("ledger model identity is not allowed")
        if self.api_surface is not None and (not isinstance(self.api_surface, str)
                                             or not _IDENTIFIER.fullmatch(self.api_surface)):
            raise ValueError("ledger API surface is not allowed")
        if self.delivery not in DELIVERY_STATUSES:
            raise ValueError("ledger delivery status is not allowed")
        if self.audit_status not in AUDIT_STATUSES:
            raise ValueError("ledger audit status is not allowed")
        if self.usage_status not in USAGE_STATUSES:
            raise ValueError("ledger usage status is not allowed")
        counts = self.counts()
        for name in USAGE_FIELDS:
            _count(name, counts[name])
        if self.usage_status == "unavailable" and any(v is not None for v in counts.values()):
            raise ValueError("unavailable usage cannot carry counters")
        if counts["total_tokens"] is not None and counts["input_tokens"] is not None \
                and counts["output_tokens"] is not None \
                and counts["total_tokens"] != counts["input_tokens"] + counts["output_tokens"]:
            raise ValueError("ledger usage totals are inconsistent")
        if counts["cached_input_tokens"] is not None and counts["input_tokens"] is not None \
                and counts["cached_input_tokens"] > counts["input_tokens"]:
            raise ValueError("ledger cached tokens exceed input tokens")
        if counts["reasoning_tokens"] is not None and counts["output_tokens"] is not None \
                and counts["reasoning_tokens"] > counts["output_tokens"]:
            raise ValueError("ledger reasoning tokens exceed output tokens")

    def counts(self) -> dict[str, int | None]:
        return {name: getattr(self, name) for name in USAGE_FIELDS}

    def identity(self) -> tuple:
        """Everything except the time of recording. A retry of the same accepted result has this same identity."""
        return (self.request_id, self.provider_id, self.profile_id, self.model_id, self.api_surface,
                self.delivery, self.audit_status, self.usage_status, tuple(self.counts().items()))

    @classmethod
    def from_execution(cls, result: ExecutionResult, recorded_at: float) -> LedgerRecord:
        if not isinstance(result, ExecutionResult):
            raise ValueError("only completed execution results can be recorded")
        moment = datetime.fromtimestamp(recorded_at, tz=timezone.utc)
        counts = result.usage.as_dict() if result.usage is not None else {n: None for n in USAGE_FIELDS}
        return cls(
            request_id=result.request_id,
            utc_day=moment.strftime("%Y-%m-%d"),
            recorded_at=moment.isoformat(timespec="seconds"),
            provider_id=result.provider_id,
            profile_id=result.profile_id,
            model_id=result.requested_model_id,
            api_surface=result.api_surface,
            delivery=result.delivery,
            audit_status=result.usage_audit,
            usage_status="reported" if result.usage is not None else "unavailable",
            **counts,
        )
