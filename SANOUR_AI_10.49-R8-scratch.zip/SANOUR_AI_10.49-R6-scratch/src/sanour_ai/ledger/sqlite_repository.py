"""Durable local ledger on SQLite (stdlib, no network, no server).

Atomicity: each append is one IMMEDIATE transaction. The duplicate check and the insert run under the
same write lock, so two processes cannot both insert one request id. The row is either committed whole
or not visible at all (crash before COMMIT leaves no partial row).
Durability: WAL journal with synchronous=FULL, so a committed record survives a process crash or restart.
Integrity: the schema repeats the record rules as CHECK constraints. PRAGMA integrity_check runs when the
file is opened; a failing check refuses the file. Any storage or corruption error is raised as
LedgerStorageError; it is never reported as a successful write.
Reports (Stage 10.48-R1): aggregation runs inside SQLite (GROUP BY). Filter values are bound parameters
and column names come from a fixed map, so no report input is ever placed into SQL text.
"""

from __future__ import annotations

import sqlite3
import threading
from collections.abc import Mapping, Sequence

from sanour_ai.ledger.record import LedgerRecord
from sanour_ai.ledger.report import DIMENSIONS, checked_dimensions, format_bucket, normalize_filters
from sanour_ai.ledger.repository import LedgerConflictError, LedgerStorageError, UsageRepository
from sanour_ai.models.usage import USAGE_FIELDS

SCHEMA_VERSION = 1
_MAX_PATH_LENGTH = 1024
_COLUMNS = (
    "request_id", "utc_day", "recorded_at", "provider_id", "profile_id", "model_id", "api_surface",
    "delivery", "audit_status", "usage_status",
) + USAGE_FIELDS

# Fixed map: dimension or filter key -> column. Only these names ever appear in SQL text.
_COLUMN_OF = {
    "provider": "provider_id",
    "profile": "profile_id",
    "model": "model_id",
    "period": "utc_day",
    "delivery": "delivery",
    "audit": "audit_status",
}

_SCHEMA = """
CREATE TABLE IF NOT EXISTS usage_records (
    request_id TEXT PRIMARY KEY CHECK (length(request_id) BETWEEN 1 AND 64),
    utc_day TEXT NOT NULL CHECK (length(utc_day) = 10),
    recorded_at TEXT NOT NULL,
    provider_id TEXT NOT NULL,
    profile_id TEXT NOT NULL,
    model_id TEXT NOT NULL,
    api_surface TEXT,
    delivery TEXT NOT NULL CHECK (delivery IN ('delivered', 'withheld')),
    audit_status TEXT NOT NULL CHECK (audit_status IN ('recorded', 'failed', 'unavailable')),
    usage_status TEXT NOT NULL CHECK (usage_status IN ('reported', 'unavailable')),
    input_tokens INTEGER CHECK (input_tokens IS NULL OR input_tokens >= 0),
    output_tokens INTEGER CHECK (output_tokens IS NULL OR output_tokens >= 0),
    total_tokens INTEGER CHECK (total_tokens IS NULL OR total_tokens >= 0),
    cached_input_tokens INTEGER CHECK (cached_input_tokens IS NULL OR cached_input_tokens >= 0),
    reasoning_tokens INTEGER CHECK (reasoning_tokens IS NULL OR reasoning_tokens >= 0),
    CHECK (usage_status = 'reported' OR (input_tokens IS NULL AND output_tokens IS NULL
        AND total_tokens IS NULL AND cached_input_tokens IS NULL AND reasoning_tokens IS NULL))
)
"""


def _aggregate_sql() -> str:
    """One row per group: request counts, status counts, then (sum, non-null count) per token field.
    COUNT(field) counts only known values, so unknown = requests - COUNT(field). SUM skips NULL and is
    NULL when nothing is known, so an unknown is never summed as zero."""
    parts = [
        "COUNT(*)",
        "COALESCE(SUM(CASE WHEN usage_status = 'reported' THEN 1 ELSE 0 END), 0)",
        "COALESCE(SUM(CASE WHEN delivery = 'delivered' THEN 1 ELSE 0 END), 0)",
        "COALESCE(SUM(CASE WHEN delivery = 'withheld' THEN 1 ELSE 0 END), 0)",
        "COALESCE(SUM(CASE WHEN audit_status = 'recorded' THEN 1 ELSE 0 END), 0)",
        "COALESCE(SUM(CASE WHEN audit_status = 'failed' THEN 1 ELSE 0 END), 0)",
        "COALESCE(SUM(CASE WHEN audit_status = 'unavailable' THEN 1 ELSE 0 END), 0)",
    ]
    for name in USAGE_FIELDS:
        parts.append(f"SUM({name})")
        parts.append(f"COUNT({name})")
    return ", ".join(parts)


_AGGREGATE = _aggregate_sql()


def _bucket_from_row(row: Sequence[object]) -> dict[str, object]:
    requests, with_usage, delivered, withheld, recorded, failed, unavailable = row[:7]
    fields = {}
    for index, name in enumerate(USAGE_FIELDS):
        total, known = row[7 + 2 * index], row[8 + 2 * index]
        fields[name] = (total, known)
    return format_bucket(
        requests=requests, with_usage=with_usage, delivered=delivered, withheld=withheld,
        audit_recorded=recorded, audit_failed=failed, audit_unavailable=unavailable, fields=fields,
    )


def _to_row(record: LedgerRecord) -> tuple:
    values = {name: getattr(record, name) for name in _COLUMNS}
    return tuple(values[name] for name in _COLUMNS)


def _from_row(row: tuple) -> LedgerRecord:
    return LedgerRecord(**dict(zip(_COLUMNS, row)))


class SqliteUsageRepository(UsageRepository):
    def __init__(self, path: str) -> None:
        # ":memory:" is refused: it is not durable, and this class exists only for durable storage.
        if (not isinstance(path, str) or not path or path == ":memory:" or "\x00" in path
                or len(path) > _MAX_PATH_LENGTH):
            raise LedgerStorageError()
        self._lock = threading.Lock()
        self._conn: sqlite3.Connection | None = None  # set only after a successful open
        try:
            conn = sqlite3.connect(path, timeout=10.0, isolation_level=None, check_same_thread=False)
        except sqlite3.Error:
            raise LedgerStorageError() from None
        self._conn = conn
        try:
            conn.execute("PRAGMA busy_timeout=10000")
            mode = conn.execute("PRAGMA journal_mode=WAL").fetchone()
            if mode is None or str(mode[0]).lower() != "wal":
                raise LedgerStorageError()
            conn.execute("PRAGMA synchronous=FULL")
            version = conn.execute("PRAGMA user_version").fetchone()[0]
            if version not in (0, SCHEMA_VERSION):
                raise LedgerStorageError()
            conn.execute("BEGIN IMMEDIATE")
            conn.execute(_SCHEMA)
            conn.execute(f"PRAGMA user_version={SCHEMA_VERSION}")
            conn.execute("COMMIT")
            if conn.execute("PRAGMA integrity_check").fetchall() != [("ok",)]:
                raise LedgerStorageError()
        except LedgerStorageError:
            self._discard()
            raise
        except sqlite3.Error:
            self._discard()
            raise LedgerStorageError() from None

    def _discard(self) -> None:
        """Roll back and close a connection that never became usable. Errors are dropped."""
        conn, self._conn = self._conn, None
        if conn is None:
            return
        try:
            conn.execute("ROLLBACK")
        except sqlite3.Error:
            pass
        try:
            conn.close()
        except sqlite3.Error:
            pass

    def _live(self) -> sqlite3.Connection:
        if self._conn is None:
            raise LedgerStorageError()
        return self._conn

    def _rollback_quietly(self) -> None:
        if self._conn is None:
            return
        try:
            self._conn.execute("ROLLBACK")
        except sqlite3.Error:
            pass

    def append(self, record: LedgerRecord) -> bool:
        if not isinstance(record, LedgerRecord):
            raise ValueError("only ledger records can be stored")
        placeholders = ", ".join("?" for _ in _COLUMNS)
        with self._lock:
            try:
                conn = self._live()
                conn.execute("BEGIN IMMEDIATE")
                row = conn.execute(
                    f"SELECT {', '.join(_COLUMNS)} FROM usage_records WHERE request_id = ?",
                    (record.request_id,),
                ).fetchone()
                if row is not None:
                    conn.execute("ROLLBACK")
                    existing = _from_row(row)
                    if existing.identity() == record.identity():
                        return False
                    raise LedgerConflictError()
                conn.execute(
                    f"INSERT INTO usage_records ({', '.join(_COLUMNS)}) VALUES ({placeholders})",
                    _to_row(record),
                )
                conn.execute("COMMIT")
                return True
            except LedgerConflictError:
                raise
            except (sqlite3.Error, ValueError):
                self._rollback_quietly()
                raise LedgerStorageError() from None

    def records(self) -> list[LedgerRecord]:
        with self._lock:
            try:
                rows = self._live().execute(
                    f"SELECT {', '.join(_COLUMNS)} FROM usage_records ORDER BY recorded_at, request_id"
                ).fetchall()
                return [_from_row(row) for row in rows]
            except (sqlite3.Error, ValueError):
                raise LedgerStorageError() from None

    def report(self, filters: Mapping[str, object] | None = None,
               dimensions: Sequence[str] = DIMENSIONS) -> dict[str, object]:
        # Validation happens before any SQL. Bad input raises ValueError, never a storage error.
        flt = normalize_filters(filters)
        dims = checked_dimensions(dimensions)
        keys = sorted(flt)
        where = (" WHERE " + " AND ".join(f"{_COLUMN_OF[k]} = ?" for k in keys)) if keys else ""
        params = [flt[k] for k in keys]
        with self._lock:
            try:
                conn = self._live()
                total_row = conn.execute(f"SELECT {_AGGREGATE} FROM usage_records{where}", params).fetchone()
                report: dict[str, object] = {"total": _bucket_from_row(total_row)}
                for dim in dims:
                    column = _COLUMN_OF[dim]
                    rows = conn.execute(
                        f"SELECT {column}, {_AGGREGATE} FROM usage_records{where} "
                        f"GROUP BY {column} ORDER BY {column}",
                        params,
                    ).fetchall()
                    report[dim] = {row[0]: _bucket_from_row(row[1:]) for row in rows}
                return report
            except (sqlite3.Error, ValueError, OverflowError):
                raise LedgerStorageError() from None

    def integrity_ok(self) -> bool:
        """PRAGMA integrity_check on the open file. True only for the single row 'ok'."""
        with self._lock:
            try:
                return self._live().execute("PRAGMA integrity_check").fetchall() == [("ok",)]
            except sqlite3.Error:
                raise LedgerStorageError() from None

    def close(self) -> None:
        """Idempotent. Waits for any write in progress (the lock), then releases the file."""
        with self._lock:
            conn, self._conn = self._conn, None
            if conn is None:
                return
            try:
                conn.close()
            except sqlite3.Error:
                pass
