"""Configuration governance (Stage 10.33, consolidated in 10.33-R1). The single owner of settings.

- This module is the only place that reads Runtime environment settings and decides whether they
  are valid. It owns the environment policy (blocked variables, the key requirement) and calls
  config.settings only to parse the worker-cap values.
- The provider adapter never reads the environment for configuration. It receives a validated
  SecretStr from here and checks only the SDK client it was given (see providers/openai_provider).
- Validation is fail closed: an invalid, incomplete, or contradictory value raises ConfigError.
  The message names the setting, never its value.
- No guessed defaults. The provider must be named explicitly. The only default is the documented
  safe worker cap (4), which an operator can change.
- The API key is held as SecretStr, hidden from repr and comparison, and never returned by describe().
- RuntimeConfig can only be created by load_runtime_config(). Any other construction is refused.
- Nothing here chooses a provider or a model. It only records what the operator named.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import secrets
from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Any

from pydantic import SecretStr

from sanour_ai.config.settings import ENV_PROVIDER_CONCURRENCY, ConfigError, load_settings
from sanour_ai.models.requests import DEFAULT_TIMEOUT_SECONDS, MAX_TIMEOUT_SECONDS
from sanour_ai.observability.audit import AUDIT_LOGGER_NAME

OPENAI_PROVIDER_NAME = "openai"  # the only provider this runtime can select
ENV_PROVIDER = "SANOUR_PROVIDER"
ENV_OPENAI_MODEL_ID = "SANOUR_OPENAI_MODEL_ID"
ENV_OPENAI_MAX_CONTEXT_TOKENS = "SANOUR_OPENAI_MAX_CONTEXT_TOKENS"
ENV_OPENAI_MAX_OUTPUT_TOKENS = "SANOUR_OPENAI_MAX_OUTPUT_TOKENS"
ENV_OPENAI_API_KEY = "OPENAI_API_KEY"
ENV_ANTHROPIC_API_KEY = "ANTHROPIC_API_KEY"
ENV_GEMINI_API_KEY = "GEMINI_API_KEY"
ENV_XAI_API_KEY = "XAI_API_KEY"
OPENAI_ALIAS = "openai_primary"

# Environment variables the OpenAI SDK would read to redirect or re-credential requests. The adapter
# pins its endpoint and refuses them. Policy lives here; the adapter only checks the client it gets.
BLOCKED_ENV_VARS = ("OPENAI_BASE_URL", "OPENAI_CUSTOM_HEADERS", "OPENAI_ORG_ID", "OPENAI_PROJECT_ID")

# Positive whole numbers only: no sign, no decimals, no leading zero, no spaces.
_POSITIVE_INT = re.compile(r"^[1-9][0-9]{0,11}$")
# Model ids are opaque strings from the operator. Only the shape is checked, never the value.
_MODEL_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._\-]{0,127}$")

# Per-process salt for key comparison. Key fingerprints are comparable only inside one process
# and cannot be reversed or matched across processes.
_SALT = secrets.token_bytes(32)
# Only load_runtime_config() holds this object, so only it can create a valid RuntimeConfig.
_SEAL = object()


def check_environment(environ: Mapping[str, str] | None = None) -> None:
    """Fail closed when a blocked variable is present, even if empty. Names only, never values.

    This is the one implementation. The OpenAI adapter calls it before the SDK reads the environment.
    """
    env: Mapping[str, str] = os.environ if environ is None else environ
    present = [name for name in BLOCKED_ENV_VARS if name in env]
    if present:
        raise ConfigError(
            "unsupported environment settings present: "
            + ", ".join(present)
            + " (the adapter pins its endpoint and does not accept these; unset them)"
        )


# The one table of provider secrets (Stage 10.34). Each provider id maps to the variable it reads.
# Adapters never read the environment: they receive the SecretStr that load_provider_secret returns.
PROVIDER_SECRET_ENV: Mapping[str, str] = {
    "openai": ENV_OPENAI_API_KEY,
    "anthropic": ENV_ANTHROPIC_API_KEY,
    "gemini": ENV_GEMINI_API_KEY,
    "grok": ENV_XAI_API_KEY,
    "grok_responses": ENV_XAI_API_KEY,
}


def load_provider_secret(provider_id: str, environ: Mapping[str, str] | None = None) -> SecretStr:
    """Read one provider's API key from the environment. Errors name the setting, never the value."""
    if provider_id not in PROVIDER_SECRET_ENV:
        raise ConfigError("no secret is defined for this provider")
    env: Mapping[str, str] = os.environ if environ is None else environ
    name = PROVIDER_SECRET_ENV[provider_id]
    raw = env.get(name)
    if raw is None or not raw.strip():
        raise ConfigError(f"{name} must be set to a non-empty value")
    return SecretStr(raw.strip())


def load_api_key(environ: Mapping[str, str] | None = None) -> SecretStr:
    """Read the OpenAI key. Kept for existing callers; delegates to load_provider_secret."""
    return load_provider_secret("openai", environ)


def _required(env: Mapping[str, str], name: str) -> str:
    raw = env.get(name)
    if raw is None or not raw.strip():
        raise ConfigError(f"{name} must be set")
    return raw.strip()


def _positive_int(env: Mapping[str, str], name: str) -> int:
    raw = _required(env, name)
    if not _POSITIVE_INT.match(raw):
        raise ConfigError(f"{name} must be a positive whole number")
    return int(raw)


def _model_id(env: Mapping[str, str]) -> str:
    raw = _required(env, ENV_OPENAI_MODEL_ID)
    if not _MODEL_ID.match(raw):
        raise ConfigError(f"{ENV_OPENAI_MODEL_ID} has an invalid format")
    return raw


def _key_fingerprint(key: SecretStr) -> str:
    return hmac.new(_SALT, key.get_secret_value().encode("utf-8"), hashlib.sha256).hexdigest()[:16]


@dataclass(frozen=True)
class RuntimeConfig:
    """The validated configuration one Runtime is built from. Immutable.

    Constructed only by load_runtime_config(). Direct construction raises ConfigError, and a copy
    made with dataclasses.replace() is checked again by __post_init__.
    """

    provider: str
    model_id: str
    max_context_tokens: int
    max_output_tokens: int
    max_concurrent_provider_calls: int
    provider_limits: tuple[tuple[str, int], ...]
    api_key: SecretStr = field(repr=False, compare=False)
    _seal: object = field(default=None, repr=False, compare=False)

    def __post_init__(self) -> None:
        if self._seal is not _SEAL:
            raise ConfigError("runtime configuration must come from the validated loader")
        if self.provider != OPENAI_PROVIDER_NAME or not _MODEL_ID.match(self.model_id):
            raise ConfigError("runtime configuration is invalid")
        if not (1 <= self.max_output_tokens <= self.max_context_tokens):
            raise ConfigError("runtime configuration is invalid")
        if not 1 <= self.max_concurrent_provider_calls <= 16:
            raise ConfigError("runtime configuration is invalid")
        for name, limit in self.provider_limits:
            if name != OPENAI_PROVIDER_NAME or not 1 <= limit <= self.max_concurrent_provider_calls:
                raise ConfigError("runtime configuration is invalid")

    def describe(self) -> dict[str, dict[str, Any]]:
        """Non-secret view, grouped. The key is reported as configured, never as a value."""
        return {
            "core": {
                "provider_selection": "explicit",
                "fallback": "disabled",
                "auto_retry": "disabled",
                "auto_select": "disabled",
            },
            "providers": {
                "selected": self.provider,
                "alias": OPENAI_ALIAS,
                "model_id": self.model_id,
                "max_context_tokens": self.max_context_tokens,
                "max_output_tokens": self.max_output_tokens,
            },
            "capacity": {
                "max_concurrent_provider_calls": self.max_concurrent_provider_calls,
                "provider_limits": dict(self.provider_limits),
            },
            "deadlines": {
                "default_request_timeout_seconds": DEFAULT_TIMEOUT_SECONDS,
                "max_request_timeout_seconds": MAX_TIMEOUT_SECONDS,
            },
            "security": {
                "openai_api_key": "configured",
                "endpoint": "pinned_in_code",
                "redirects": "refused",
                "environment_proxies": "ignored",
            },
            "observability": {
                "audit_logger": AUDIT_LOGGER_NAME,
                "prompt_logging": "never",
                "secret_logging": "never",
            },
        }

    def fingerprint(self) -> str:
        """Stable for equal non-secret config. Includes a salted key fingerprint, never the key."""
        canonical = json.dumps(self.describe(), sort_keys=True, default=str)
        digest = hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:16]
        return f"{digest}:{_key_fingerprint(self.api_key)}"

    def changed_fields(self, other: RuntimeConfig) -> tuple[str, ...]:
        """Names of the settings that differ, as group.name. Values are never included."""
        before, after = self.describe(), other.describe()
        names = [
            f"{group}.{key}"
            for group in before
            for key in before[group]
            if before[group][key] != after[group].get(key)
        ]
        if _key_fingerprint(self.api_key) != _key_fingerprint(other.api_key):
            names.append("security.openai_api_key")
        return tuple(names)


def load_runtime_config(environ: Mapping[str, str] | None = None) -> RuntimeConfig:
    """Read and validate every setting in one place. Raises ConfigError; never guesses."""
    env: Mapping[str, str] = os.environ if environ is None else environ

    # Exact match only. No stripping, no case folding: the switch must say exactly "openai".
    if env.get(ENV_PROVIDER) != OPENAI_PROVIDER_NAME:
        raise ConfigError(f"{ENV_PROVIDER} must be set to '{OPENAI_PROVIDER_NAME}' to enable a provider")

    settings = load_settings(env)
    check_environment(env)

    model_id = _model_id(env)
    max_context = _positive_int(env, ENV_OPENAI_MAX_CONTEXT_TOKENS)
    max_output = _positive_int(env, ENV_OPENAI_MAX_OUTPUT_TOKENS)
    if max_output > max_context:
        raise ConfigError(
            f"{ENV_OPENAI_MAX_OUTPUT_TOKENS} must not be greater than {ENV_OPENAI_MAX_CONTEXT_TOKENS}"
        )

    api_key = load_api_key(env)

    # Contradictions between capacity settings and the selected provider are refused here, at
    # configuration time, not later in the gateway.
    for name, limit in settings.provider_limits.items():
        if name != OPENAI_PROVIDER_NAME or limit > settings.max_concurrent_provider_calls:
            raise ConfigError(
                f"{ENV_PROVIDER_CONCURRENCY} names an unknown provider or a limit above the global cap"
            )

    return RuntimeConfig(
        provider=OPENAI_PROVIDER_NAME,
        model_id=model_id,
        max_context_tokens=max_context,
        max_output_tokens=max_output,
        max_concurrent_provider_calls=settings.max_concurrent_provider_calls,
        provider_limits=tuple(sorted(settings.provider_limits.items())),
        api_key=api_key,
        _seal=_SEAL,
    )


# Placeholder used in place of the real key before a test factory loads configuration. The factory
# never reads the real value; the offline fake never uses any key.
TEST_KEY_PLACEHOLDER = "offline-test-placeholder-not-a-credential"


def load_offline_test_config(environ: Mapping[str, str] | None = None) -> RuntimeConfig:
    """Configuration for the test factories. Never exposes a production credential.

    The real OPENAI_API_KEY value is never read here: its presence is noted and it is replaced by a
    placeholder before the normal loader validates the rest. Every other setting is still checked.
    """
    source: Mapping[str, str] = os.environ if environ is None else environ
    sanitized: dict[str, str] = {}
    for name in source.keys():
        if name != ENV_OPENAI_API_KEY:
            sanitized[name] = source[name]
    if ENV_OPENAI_API_KEY in source:
        sanitized[ENV_OPENAI_API_KEY] = TEST_KEY_PLACEHOLDER
    return load_runtime_config(sanitized)
