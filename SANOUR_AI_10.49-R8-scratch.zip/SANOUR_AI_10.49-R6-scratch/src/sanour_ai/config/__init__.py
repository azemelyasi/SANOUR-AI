"""Minimal typed runtime settings."""
