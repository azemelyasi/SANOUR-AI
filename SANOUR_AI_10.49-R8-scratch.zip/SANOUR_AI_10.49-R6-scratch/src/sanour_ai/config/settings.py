"""Minimal typed runtime settings. Only operational limits live here. No secrets.

Phase 1 needs one configurable value: the cap on live provider worker threads.
Invalid values fail at startup. Error messages name the setting but never echo its value.
"""

from __future__ import annotations

import os
import re
from collections.abc import Mapping

from pydantic import BaseModel, ConfigDict, Field, ValidationError

ENV_MAX_CONCURRENT_PROVIDER_CALLS = "SANOUR_MAX_CONCURRENT_PROVIDER_CALLS"


class ConfigError(ValueError):
    """Raised at startup for invalid configuration."""


class RuntimeSettings(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    max_concurrent_provider_calls: int = Field(default=4, ge=1, le=16)
    provider_limits: dict[str, int] = Field(default_factory=dict)


def _load_global_settings(env: Mapping[str, str]) -> RuntimeSettings:
    raw = env.get(ENV_MAX_CONCURRENT_PROVIDER_CALLS)
    if raw is None:
        return RuntimeSettings()
    try:
        value = int(raw.strip())
    except ValueError:
        raise ConfigError(f"{ENV_MAX_CONCURRENT_PROVIDER_CALLS} must be an integer") from None
    try:
        return RuntimeSettings(max_concurrent_provider_calls=value)
    except ValidationError:
        raise ConfigError(
            f"{ENV_MAX_CONCURRENT_PROVIDER_CALLS} must be between 1 and 16"
        ) from None


ENV_PROVIDER_CONCURRENCY = "SANOUR_PROVIDER_CONCURRENCY"
_PROVIDER_NAME = re.compile(r"^[a-z][a-z0-9_]{1,31}$")
_LIMIT_TEXT = re.compile(r"^[0-9]{1,2}$")
_CONCURRENCY_HINT = "must be a comma-separated list of name=limit pairs, each limit 1 to 16"


def _parse_provider_limits(raw: str | None) -> dict[str, int]:
    """Parse "openai=2,other_name=3". Errors name the setting, never echo the value."""
    if raw is None or not raw.strip():
        return {}
    limits: dict[str, int] = {}
    for item in raw.split(","):
        name, separator, value = item.strip().partition("=")
        if not separator or not _PROVIDER_NAME.match(name) or not _LIMIT_TEXT.match(value.strip()):
            raise ConfigError(f"{ENV_PROVIDER_CONCURRENCY} {_CONCURRENCY_HINT}")
        limit = int(value.strip())
        if not 1 <= limit <= 16:
            raise ConfigError(f"{ENV_PROVIDER_CONCURRENCY} {_CONCURRENCY_HINT}")
        if name in limits:
            raise ConfigError(f"{ENV_PROVIDER_CONCURRENCY} lists a provider more than once")
        limits[name] = limit
    return limits


def load_settings(environ: Mapping[str, str] | None = None) -> RuntimeSettings:
    env = os.environ if environ is None else environ
    base = _load_global_settings(env)
    return RuntimeSettings(
        max_concurrent_provider_calls=base.max_concurrent_provider_calls,
        provider_limits=_parse_provider_limits(env.get(ENV_PROVIDER_CONCURRENCY)),
    )

