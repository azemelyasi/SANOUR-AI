"""Structured error codes and the single exception type used across the core.

Messages carried by SanourError are fixed, safe strings. Raw provider text never
goes into a SanourError message.
"""

from enum import StrEnum


# Fixed internal classification of a provider failure. Never built from raw provider text.
FAILURE_REASONS = frozenset({"quota", "billing", "unknown"})


class FailureKind(StrEnum):
    """Typed internal kind of a failure (Stage 10.37-R1). Set by the code that raises it, never
    derived from message text. Never sent to callers and never logged."""

    UNCLASSIFIED = "unclassified"
    AUTHENTICATION = "authentication"
    PERMISSION = "permission"
    MODEL_NOT_FOUND = "model_not_found"
    REQUEST_REJECTED = "request_rejected"
    SERVER_ERROR = "server_error"
    CONNECTION = "connection"
    CALL_TIMEOUT = "call_timeout"
    CALL_FAILED = "call_failed"
    RATE_LIMIT = "rate_limit"
    LIMIT_REACHED = "limit_reached"
    PAYMENT_REQUIRED = "payment_required"
    RESPONSE_TOO_LARGE = "response_too_large"
    INCOMPLETE_RESPONSE = "incomplete_response"
    CONTENT_BLOCKED = "content_blocked"
    DEADLINE_MISSING = "deadline_missing"
    DEADLINE_EXPIRED = "deadline_expired"
    DEADLINE_LATE = "deadline_late"
    DEADLINE_IN_CALL = "deadline_in_call"
    INVALID_MODEL_ID = "invalid_model_id"
    CLIENT_CHANGED = "client_changed"
    GATEWAY_SHUT_DOWN = "gateway_shut_down"
    PROVIDER_NOT_REGISTERED = "provider_not_registered"


class ErrorCode(StrEnum):
    INVALID_REQUEST = "invalid_request"
    NO_ELIGIBLE_MODEL = "no_eligible_model"
    PROVIDER_FAILED = "provider_failed"
    PROVIDER_TIMEOUT = "provider_timeout"
    PROVIDER_OVERLOADED = "provider_overloaded"
    PROVIDER_RATE_LIMITED = "provider_rate_limited"
    PROVIDER_INVALID_RESPONSE = "provider_invalid_response"
    PROVIDER_CONTENT_BLOCKED = "provider_content_blocked"
    INTERNAL_ERROR = "internal_error"


class SanourError(Exception):
    def __init__(
        self,
        code: ErrorCode,
        message: str,
        *,
        retryable: bool = False,
        scope: str | None = None,
        status_code: int | None = None,
        failure_reason: str | None = None,
        retry_after_seconds: int | None = None,
        internal_detail: str | None = None,
        internal_kind: FailureKind | None = None,
    ) -> None:
        super().__init__(message)
        if internal_kind is not None and not isinstance(internal_kind, FailureKind):
            raise TypeError("internal_kind must be a FailureKind")
        self.code = code
        self.message = message
        self.retryable = retryable
        # Internal only: "global" or "provider" for capacity rejections. Never sent to callers.
        self.scope = scope
        # Internal diagnostics for audit and metrics. Never sent to callers.
        self.status_code = status_code
        self.failure_reason = failure_reason
        self.retry_after_seconds = retry_after_seconds
        # Internal only (Stage 10.37): the adapter's fixed message, used to classify the failure for
        # audit. Never sent to callers and never logged.
        self.internal_detail = internal_detail
        # Internal only (Stage 10.37-R1): the typed kind used for classification. Never text-derived.
        self.internal_kind = internal_kind
