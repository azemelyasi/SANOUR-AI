"""Audit events. Fields are whitelisted, so prompts and other content never reach the log."""

from __future__ import annotations

import json
import logging
import re
import threading
from typing import Any

from sanour_ai.errors import FAILURE_REASONS
from sanour_ai.security.redaction import RedactingFilter, redact

AUDIT_LOGGER_NAME = "sanour_ai.audit"

# Fixed reasons for a refused request. Anything else is dropped.
REFUSAL_REASONS = frozenset({"runtime_not_ready"})

_ALLOWED_FIELDS = frozenset(
    {
        "refusal",
        "request_id",
        "task_type",
        "model_alias",
        "model_id",
        "status",
        "error_code",
        "retryable",
        "latency_ms",
        "exc_type",
        "capacity_scope",
        "provider",
        "status_code",
        "failure_reason",
        "api_surface",
        "reason",
        "error_kind",
        "usage_status",
        "input_tokens",
        "output_tokens",
        "total_tokens",
        "cached_input_tokens",
        "reasoning_tokens",
        "withheld_reason",
        # Stage 10.49: governance. Enumerated values only (see GOVERNANCE_ENUMS below).
        "scope_type",
        "period",
        "quota_metric",
        "governance_reason",
        "cost_status",
        "settlement",
        "charged_from",
        "pricing_version_id",
        "budget_count",
        "quota_count",
        # Stage 10.49-R2: actor identifiers (pattern checked), operations and decisions (enumerated).
        "actor",
        "operation",
        "resolution",
        "decision",
        # Stage 10.49-R3: idempotency key of an outbox event (pattern checked). Lets a sink drop duplicates.
        "outbox_key",
    }
)
GOVERNANCE_ENUMS = {
    "scope_type": frozenset({"global", "provider", "model", "profile"}),
    "period": frozenset({"daily", "monthly"}),
    "quota_metric": frozenset({"requests", "input_tokens", "output_tokens", "total_tokens"}),
    "governance_reason": frozenset({"cost_unknown", "budget_exceeded", "bounds_unknown", "quota_exceeded",
                                    "unauthorized", "invalid_input", "not_exposed", "already_resolved",
                                    "usage_not_priced", "usage_incomplete", "audit_unavailable", "not_found",
                                    "intent_conflict", "storage_error"}),
    "operation": frozenset({"settle_intent", "settle_apply", "recovery_apply", "recovery_expire",
                            "verified_usage", "write_off", "retain"}),
    "resolution": frozenset({"verified_usage", "write_off", "retain"}),
    "decision": frozenset({"applied", "failed", "refused"}),
    "cost_status": frozenset({"priced", "unknown_pricing", "unknown_usage", "not_billed"}),
    "settlement": frozenset({"completed", "failed", "timed_out", "expired", "released", "reconcile_failed",
                             "resolved_exposure"}),
    "charged_from": frozenset({"actual", "exposed", "none"}),
}
_OUTBOX_KEY = re.compile(r"gov:[0-9]{1,18}:[a-z_.]{1,48}")
GOVERNANCE_COUNTS = frozenset({"pricing_version_id", "budget_count", "quota_count"})
GOVERNANCE_ACTOR = re.compile(r"[A-Za-z0-9._@:-]{1,64}")
WITHHELD_REASONS = frozenset({"usage_audit_unavailable", "completion_audit_unavailable"})
USAGE_TOKEN_FIELDS = frozenset({"input_tokens", "output_tokens", "total_tokens", "cached_input_tokens", "reasoning_tokens"})
USAGE_STATUSES = frozenset({"reported", "unavailable"})
_ERROR_KIND = re.compile(r"^[a-z_]{1,48}$")  # internal kind names only (error_taxonomy)

# Fixed reasons only (Stage 10.36). Anything else is dropped, never logged.
ROUTING_REASONS = frozenset(
    {"missing_profile", "unknown_profile", "disabled_profile", "unsuitable_profile", "identity_conflict"}
)
_SURFACE = re.compile(r"^[a-z][a-z0-9_]{1,63}$")


class AuditLogger:
    def __init__(self, logger: logging.Logger | None = None) -> None:
        self._counter_lock = threading.Lock()
        self._emitted = 0
        self._failed = 0
        self._logger = logger or logging.getLogger(AUDIT_LOGGER_NAME)
        if self._logger.level == logging.NOTSET:
            self._logger.setLevel(logging.INFO)
        if not any(isinstance(f, RedactingFilter) for f in self._logger.filters):
            self._logger.addFilter(RedactingFilter())

    def emit(self, event: str, **fields: Any) -> bool:
        """Write one event. Returns True only if the write returned without error (Stage 10.45).
        A failed write is counted and reported as False. The exception text is never kept or logged."""
        try:
            line = self._format(event, fields)
            self._logger.info("%s %s", redact(event), line)
        except Exception:
            with self._counter_lock:
                self._failed += 1
            return False
        with self._counter_lock:
            self._emitted += 1
        return True

    def counters(self) -> dict[str, Any]:
        """Read-only audit health: counts and a fixed health word. Never event content."""
        with self._counter_lock:
            failed = self._failed
            emitted = self._emitted
        return {"emitted": emitted, "failed": failed, "health": "ok" if failed == 0 else "degraded"}

    def _format(self, event: str, fields: dict[str, Any]) -> str:
        safe: dict[str, Any] = {}
        for key, value in fields.items():
            if key not in _ALLOWED_FIELDS:
                continue
            # Diagnostic fields must come from fixed sets. Anything else is dropped, never logged.
            if key == "failure_reason" and not (isinstance(value, str) and value in FAILURE_REASONS):
                continue
            if key == "reason" and value not in ROUTING_REASONS:
                continue
            if key == "error_kind" and not (isinstance(value, str) and _ERROR_KIND.match(value)):
                continue
            if key == "refusal" and value not in REFUSAL_REASONS:
                continue
            if key in GOVERNANCE_ENUMS and value not in GOVERNANCE_ENUMS[key]:
                continue
            if key == "outbox_key" and not (isinstance(value, str) and _OUTBOX_KEY.fullmatch(value)):
                continue
            if key == "actor" and not (isinstance(value, str) and GOVERNANCE_ACTOR.fullmatch(value)):
                continue
            if key in GOVERNANCE_COUNTS and (isinstance(value, bool) or not isinstance(value, int) or value < 0):
                continue
            # Stage 10.47-R1: usage counters. None is kept as null (unknown), never turned into 0.
            if key in USAGE_TOKEN_FIELDS and value is not None and (
                isinstance(value, bool) or not isinstance(value, int) or value < 0
            ):
                continue
            if key == "usage_status" and value not in USAGE_STATUSES:
                continue
            if key == "withheld_reason" and value not in WITHHELD_REASONS:
                continue
            if key == "api_surface" and not (isinstance(value, str) and _SURFACE.match(value)):
                continue
            if key == "status_code" and (
                isinstance(value, bool) or not isinstance(value, int) or not 100 <= value <= 599
            ):
                continue
            safe[key] = value
        return json.dumps(safe, sort_keys=True, default=str)
