"""Capability intelligence (Stage 10.35): three independent levels, never merged.

Level 1, Provider/API: what the official documentation says the API surface supports.
    Source: models/provider_matrix.py. A VERIFIED matrix cell means "documented" here, so it maps to
    DOCUMENTED_ONLY, never to VERIFIED. Documentation is not SANOUR AI support.
Level 2, Adapter: what the adapter in this repository actually implements (its ProviderCapabilities).
    IMPLEMENTED_UNVERIFIED when the adapter declares it. Declared is not proven by a live call.
Level 3, Verified Runtime: what a reviewed test has proven at runtime. Evidence is an explicit
    record with a test reference. No evidence exists in this repository, so nothing is VERIFIED.

Status values (the only five): VERIFIED, IMPLEMENTED_UNVERIFIED, DOCUMENTED_ONLY, UNSUPPORTED, UNKNOWN.
A category the matrix does not describe is UNKNOWN. It is never inferred from a similar one.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import StrEnum

from sanour_ai.models import provider_matrix as pm
from sanour_ai.models.model_catalog import CATEGORIES


class Status(StrEnum):
    VERIFIED = "VERIFIED"
    IMPLEMENTED_UNVERIFIED = "IMPLEMENTED_UNVERIFIED"
    DOCUMENTED_ONLY = "DOCUMENTED_ONLY"
    UNSUPPORTED = "UNSUPPORTED"
    UNKNOWN = "UNKNOWN"


class Level(StrEnum):
    PROVIDER_API = "provider_api"
    ADAPTER = "adapter"
    RUNTIME_VERIFIED = "runtime_verified"


# category -> (matrix capability row or None, adapter ProviderCapabilities flag or None).
# A None means "no row" or "no adapter flag": the level reports UNKNOWN or DOCUMENTED_ONLY, never a guess.
CATEGORY_SOURCES: dict[str, tuple[str | None, str | None]] = {
    "text_generation": ("text_generation", "text_generation"),
    "structured_output": ("structured_output", "structured_output"),
    "json_mode": (None, None),
    "function_calling": ("tools", "tool_calling"),
    "tools": ("tools", "tool_calling"),
    "vision": ("vision", "image_input"),
    "image_input": ("vision", "image_input"),
    "audio_input": ("audio", None),
    "audio_output": (None, None),
    "video_input": (None, None),
    "streaming": ("streaming", "streaming"),
    "reasoning": ("reasoning", None),
    "embeddings": (None, None),
    "batch_processing": (None, None),
    "file_input": (None, None),
}
assert set(CATEGORY_SOURCES) == set(CATEGORIES)


# Stage 10.47: the only evidence sources and methods that may ever count as VERIFIED. Fake
# transports, mocks, environment variables and documentation are not on either list, so they can
# never produce VERIFIED evidence, even if someone builds a record by hand.
APPROVED_EVIDENCE_SOURCES = frozenset({"approved_live_verification"})
APPROVED_EVIDENCE_METHODS = frozenset({"live_provider_test"})
_VERIFIED_AT_FORMAT = "%Y-%m-%dT%H:%M:%SZ"


@dataclass(frozen=True)
class RuntimeEvidence:
    """One runtime proof record.

    Compatibility (Stage 10.47-R1): the original four-argument form still constructs:
        RuntimeEvidence(provider_id, surface, category, test_reference)
    Such a record, and any record missing provenance, is INERT: it can never produce VERIFIED.
    Provenance is never inferred or defaulted. Only is_verified_eligible() decides.

    Values that ARE supplied are checked: a non-approved source, method, status, or malformed
    timestamp raises ValueError, so an explicitly bad record cannot be created at all.
    """

    provider_id: str
    surface: str
    category: str
    test_reference: str
    model_id: str | None = None
    source: str | None = None
    method: str | None = None
    verified_at: str | None = None
    status: str | None = None

    def __post_init__(self) -> None:
        if self.source is not None and self.source not in APPROVED_EVIDENCE_SOURCES:
            raise ValueError("runtime evidence source is not an approved verification process")
        if self.method is not None and self.method not in APPROVED_EVIDENCE_METHODS:
            raise ValueError("runtime evidence method is not an approved live verification method")
        if self.status is not None and self.status != "VERIFIED":
            raise ValueError("runtime evidence status must be VERIFIED to be recorded")
        if self.verified_at is not None and self.verified_at.strip():
            try:
                datetime.strptime(self.verified_at, _VERIFIED_AT_FORMAT)
            except ValueError:
                raise ValueError("runtime evidence timestamp must be UTC YYYY-MM-DDTHH:MM:SSZ") from None

    def is_verified_eligible(self) -> bool:
        """True only for a complete, approved, VERIFIED record. Anything missing makes it inert."""
        required = (self.provider_id, self.surface, self.category, self.test_reference,
                    self.model_id, self.source, self.method, self.verified_at)
        if not all(isinstance(v, str) and v.strip() for v in required):
            return False
        if self.status != "VERIFIED":
            return False
        if self.source not in APPROVED_EVIDENCE_SOURCES or self.method not in APPROVED_EVIDENCE_METHODS:
            return False
        try:
            datetime.strptime(self.verified_at, _VERIFIED_AT_FORMAT)
        except ValueError:
            return False
        return True


# Empty on purpose: no runtime test in this repository has proven any capability against a live API.
RUNTIME_EVIDENCE: tuple[RuntimeEvidence, ...] = ()


def provider_api_status(surface: str, category: str) -> Status:
    """Level 1. Documentation only. Never VERIFIED."""
    row, _flag = CATEGORY_SOURCES[category]
    if row is None or surface not in pm.MATRIX:
        return Status.UNKNOWN
    cell = pm.MATRIX[surface][row]
    if cell.status == pm.VERIFIED:
        return Status.DOCUMENTED_ONLY
    if cell.status == pm.UNSUPPORTED:
        return Status.UNSUPPORTED
    return Status.UNKNOWN


def adapter_status(surface: str, category: str, adapter_caps: object) -> Status:
    """Level 2. What the adapter declares, checked against the level 1 documentation."""
    _row, flag = CATEGORY_SOURCES[category]
    if flag is not None and bool(getattr(adapter_caps, flag, False)):
        return Status.IMPLEMENTED_UNVERIFIED
    documented = provider_api_status(surface, category)
    if documented is Status.UNSUPPORTED:
        return Status.UNSUPPORTED
    if documented is Status.DOCUMENTED_ONLY:
        return Status.DOCUMENTED_ONLY
    return Status.UNKNOWN


def runtime_status(provider_id: str, surface: str, category: str, adapter_caps: object,
                   evidence: tuple[RuntimeEvidence, ...] | None = None, *,
                   model_id: str | None = None) -> Status:
    """Level 3. VERIFIED only with a matching evidence record for the exact model that names its test.
    Without a model_id, no evidence matches: a capability cannot be verified for "some model"."""
    evidence = RUNTIME_EVIDENCE if evidence is None else evidence  # resolved per call, never frozen at import
    if model_id is None:
        if adapter_status(surface, category, adapter_caps) is Status.UNSUPPORTED:
            return Status.UNSUPPORTED
        return Status.UNKNOWN
    for item in evidence:
        if (item.provider_id, item.surface, item.category, item.model_id) == (
            provider_id, surface, category, model_id
        ):
            # Evidence proves a capability only if the adapter actually declares it (no mismatch).
            if (item.is_verified_eligible()
                    and adapter_status(surface, category, adapter_caps) is Status.IMPLEMENTED_UNVERIFIED):
                return Status.VERIFIED
    if adapter_status(surface, category, adapter_caps) is Status.UNSUPPORTED:
        return Status.UNSUPPORTED
    return Status.UNKNOWN


def levels(provider_id: str, surface: str, adapter_caps: object,
           evidence: tuple[RuntimeEvidence, ...] | None = None) -> dict[str, dict[str, Status]]:
    """All three levels for every category, keyed category -> level -> status."""
    evidence = RUNTIME_EVIDENCE if evidence is None else evidence
    return {
        category: {
            Level.PROVIDER_API: provider_api_status(surface, category),
            Level.ADAPTER: adapter_status(surface, category, adapter_caps),
            Level.RUNTIME_VERIFIED: runtime_status(provider_id, surface, category, adapter_caps, evidence),
        }
        for category in CATEGORIES
    }


def implemented_categories(surface: str, adapter_caps: object) -> tuple[str, ...]:
    return tuple(c for c in CATEGORIES if adapter_status(surface, c, adapter_caps) is Status.IMPLEMENTED_UNVERIFIED)


def production_ready(provider_id: str, surface: str, adapter_caps: object,
                     evidence: tuple[RuntimeEvidence, ...] | None = None, *,
                     model_id: str | None = None) -> tuple[str, ...]:
    """Categories that may be called production-ready for one exact model. Needs level 3 VERIFIED."""
    evidence = RUNTIME_EVIDENCE if evidence is None else evidence
    return tuple(c for c in CATEGORIES
                 if runtime_status(provider_id, surface, c, adapter_caps, evidence,
                                   model_id=model_id) is Status.VERIFIED)
