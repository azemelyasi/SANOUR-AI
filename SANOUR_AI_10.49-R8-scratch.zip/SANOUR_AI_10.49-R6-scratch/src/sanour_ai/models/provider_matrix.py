"""Provider capability matrix, keyed by API surface (endpoint), not by vendor.

The same vendor can differ between endpoints (for example, xAI Chat Completions documents no reasoning
content, while xAI Responses does). Each cell is one of:

- VERIFIED: stated in an official document checked on 2026-11-07. The source is named in the cell's
  note. Only VERIFIED capabilities may be declared by an adapter.
- UNSUPPORTED: an official document says the surface does not do this.
- UNVERIFIED: not confirmed from an official source in this environment. Never used for production.

Nothing here is inferred from a model name, marketing text, or a similar API. Changing a cell requires
a new official source. ProviderCapabilities (Stage 10.18) keeps its shape. An adapter may declare a flag
only when the matrix cell for its surface is VERIFIED (see tests).
"""

from __future__ import annotations

from dataclasses import dataclass

VERIFIED = "verified"
UNSUPPORTED = "unsupported"
UNVERIFIED = "unverified"
STATUSES = frozenset({VERIFIED, UNSUPPORTED, UNVERIFIED})

CAPABILITIES = (
    "text_generation",
    "streaming",
    "tools",
    "vision",
    "image_generation",
    "audio",
    "structured_output",
    "reasoning",
)


@dataclass(frozen=True)
class Cell:
    status: str
    note: str


def _u(note: str = "not confirmed from an official source in this environment") -> Cell:
    return Cell(UNVERIFIED, note)


def _v(note: str) -> Cell:
    return Cell(VERIFIED, note)


def _x(note: str) -> Cell:
    return Cell(UNSUPPORTED, note)


MATRIX: dict[str, dict[str, Cell]] = {
    "openai_responses": {
        "text_generation": _v("POST /v1/responses create reference (developers.openai.com)"),
        "streaming": _u(),
        "tools": _v("create reference lists built-in tool call items (file search, computer, web search)"),
        "vision": _v("create reference: ResponseInputImage (input_image)"),
        "image_generation": _u(),
        "audio": _u("create reference mentions audio input; output not confirmed"),
        "structured_output": _u(),
        "reasoning": _u(),
    },
    "anthropic_messages": {
        "text_generation": _v("Messages API reference (docs.anthropic.com/en/api/messages)"),
        "streaming": _v("errors page refers to the streaming Messages API and mid-stream error events"),
        "tools": _v("tool_use / tool_result blocks in Messages reference; tool_use stop reason"),
        "vision": _v("Messages reference: ImageBlockParam"),
        "image_generation": _u(),
        "audio": _u(),
        "structured_output": _v("errors page: structured outputs via output_config.format"),
        "reasoning": _v("errors page: thinking.type adaptive / enabled; thinking blocks in Messages reference"),
    },
    "gemini_generate_content": {
        "text_generation": _v("generateContent reference and examples (ai.google.dev/api)"),
        "streaming": _u(),
        "tools": _u("finishReason MALFORMED_FUNCTION_CALL exists; tool support not confirmed here"),
        "vision": _u(),
        "image_generation": _u(),
        "audio": _u(),
        "structured_output": _u(),
        "reasoning": _u("thoughtSignature not confirmed from an official page in this environment"),
    },
    "grok_chat_completions": {
        "text_generation": _v("Chat Completions docs example (docs.x.ai, legacy section)"),
        "streaming": _v("Chat Completions docs: streaming covered by a separate page"),
        "tools": _v("comparison page: chat supports function calling only"),
        "vision": _v("Chat Completions docs: image_url content parts"),
        "image_generation": _u("image generation is a separate endpoint; not on this surface"),
        "audio": _u(),
        "structured_output": _u(),
        "reasoning": _x("comparison page: Chat Completions returns no reasoning content"),
    },
    "grok_responses": {
        "text_generation": _v("Responses reference (docs.x.ai/docs/api-reference)"),
        "streaming": _v("Responses reference: stream parameter"),
        "tools": _v("Responses reference: tools (functions and web search)"),
        "vision": _v("Responses reference: text or image prompts"),
        "image_generation": _u(),
        "audio": _u(),
        "structured_output": _u("text.format is documented; the variants are not confirmed here"),
        "reasoning": _v("Responses reference: reasoning items and reasoning.effort"),
    },
}

# Adapter name -> the API surface it implements.
ADAPTER_SURFACE = {
    "openai": "openai_responses",
    "anthropic": "anthropic_messages",
    "gemini": "gemini_generate_content",
    "grok": "grok_chat_completions",
    "grok_responses": "grok_responses",
}


def status(surface: str, capability: str) -> str:
    if surface not in MATRIX or capability not in CAPABILITIES:
        raise KeyError("unknown surface or capability")
    return MATRIX[surface][capability].status


def declared_flags_are_verified(surface: str, declared: dict[str, bool]) -> list[str]:
    """Flags an adapter declares as True that the matrix does not mark VERIFIED. Empty means fine."""
    return [flag for flag, on in declared.items() if on and status(surface, flag) != VERIFIED]


# Stage 10.31: ProviderCapabilities/ModelCapabilities flag names differ from matrix names.
# The mapping is explicit. A True flag with no mapping (for example video_output) has no matrix row
# and is refused. The 10.30 function above is unchanged.
PROVIDER_FLAG_TO_CAPABILITY = {
    "text_generation": "text_generation",
    "streaming": "streaming",
    "tool_calling": "tools",
    "image_input": "vision",
    "image_output": "image_generation",
    "structured_output": "structured_output",
}


def provider_flags_are_verified(surface: str, declared: dict[str, bool]) -> list[str]:
    """Provider-side flags declared True that are NOT verified on the surface. Empty means fine."""
    refused = []
    for flag, on in declared.items():
        if not on:
            continue
        capability = PROVIDER_FLAG_TO_CAPABILITY.get(flag)
        if capability is None or surface not in MATRIX or status(surface, capability) != VERIFIED:
            refused.append(flag)
    return refused
