"""Model gateway: one deadline-bounded provider call per request, with bounded worker threads.

Timeout and worker policy
- The caller passes an absolute deadline (a time.monotonic() value). The gateway waits only for
  the time that remains. An expired deadline fails before any provider call is made.
- Provider calls run in daemon threads. Python cannot forcibly stop a thread. A call that
  outlives its deadline keeps running until the provider returns, and its result is discarded.
  Nothing here claims that an abandoned thread was stopped.
- A semaphore caps live worker threads, including abandoned ones, at max_concurrent_calls.
  When the cap is reached, a new call fails at once with PROVIDER_OVERLOADED and starts no thread.
- A slot is released only when its worker returns. A provider call that never returns keeps one
  slot for the life of the process. This is a known limit; recovering it requires a restart.
- There is no cancellation and no retry.

Slot ownership on launch
- A call takes its slot and counter before the thread is built. Ownership is decided under the
  gateway lock by a per-call flag: the worker claims the call when it begins running, and a
  caller that fails before the claim cancels it. Exactly one side releases the slot and
  decrements in_flight. A worker that never claimed the call never runs the provider.
- If a start failure happens after the worker has claimed the call, the worker keeps ownership.

Process-control exceptions (BaseException)
- A BaseException raised by a provider is captured in the worker and re-raised unchanged in the
  caller thread. It is never classified as an invalid response.
- It is counted in unclassified_errors, and the exception still propagates to the caller.
- If the caller already timed out, the exception cannot reach anyone. It is logged as a warning
  containing only the exception type name, and it is not counted in any outcome category.

Metrics
- Each generate() call records exactly one terminal outcome, decided by the caller.
  A worker that finishes after its caller timed out is never a successful call.
- peak_in_flight is the highest number of workers running at the same time. A worker counts
  from the moment it claims its call until it returns, abandoned workers included. A call that is
  reserved but never starts, or is cancelled before its worker claims it, never counts.
  This is tracked separately from in_flight, which keeps its legacy meaning.
- If a log sink fails while recording an abandoned BaseException, capacity and the caller are
  still released. The sink's error then reaches threading.excepthook. The BaseException's type
  name is lost in that case.
- All counters are guarded by the gateway lock. The lock is never held during a provider call
  or a wait. stats() returns an immutable snapshot.
"""

from __future__ import annotations

import logging
import threading
import time
from collections.abc import Callable, Mapping

from pydantic import BaseModel, ConfigDict, Field

from sanour_ai.errors import ErrorCode, FailureKind, SanourError
from sanour_ai.models.base import ModelCall, ModelProvider, ModelResult, ProviderError
from sanour_ai.models.capabilities import ModelProfile, ProviderCapabilities, unsupported_flags
from sanour_ai.models.request_identity import REQUEST_IDENTITY_SCOPE, RequestIdentity

MAX_RESULT_CHARS = 100_000
# Internal marker on SanourError.scope for an identity rejection. Never sent to callers.
IDENTITY_MISMATCH_SCOPE = "model_identity"
_log = logging.getLogger("sanour_ai.gateway")


class SettlementAborted(BaseException):
    """Raised out of a settler thread when provider close() raised a BaseException (Stage 10.43).
    The message is the exception TYPE NAME only, so the thread's default error hook never prints text."""


class GatewayStats(BaseModel):
    """Immutable point-in-time snapshot of gateway counters. Every field is a non-negative int."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    successful_calls: int = Field(ge=0)
    provider_failures: int = Field(ge=0)
    timeouts: int = Field(ge=0)
    overload_rejections: int = Field(ge=0)
    invalid_responses: int = Field(ge=0)
    unclassified_errors: int = Field(ge=0)
    content_blocked: int = Field(ge=0)
    in_flight: int = Field(ge=0)
    abandoned_in_flight: int = Field(ge=0)
    peak_in_flight: int = Field(ge=0)
    # Workers that claimed a call and have not returned yet (abandoned ones included).
    active_workers: int = Field(ge=0)
    # Provider close() calls that raised (Stage 10.40). Counted only; the error text is never kept.
    provider_close_failures: int = Field(default=0, ge=0)
    # Stage 10.42: settlement and start-failure observability. All counts, no content.
    active_settlers: int = Field(default=0, ge=0)
    providers_waiting_for_workers: int = Field(default=0, ge=0)
    providers_closing: int = Field(default=0, ge=0)
    settler_threads_started: int = Field(default=0, ge=0)
    cancelled_before_start: int = Field(default=0, ge=0)


def _identity_conflicts(identity: RequestIdentity, profile: ModelProfile, call: ModelCall,
                        provider: ModelProvider) -> bool:
    """True when the identity does not match the profile, the call, or the adapter. Exact checks."""
    if identity.profile_id != profile.alias or identity.provider_id != profile.provider:
        return True
    if identity.requested_model_id != profile.model_id or call.model_id != profile.model_id:
        return True
    if identity.accepted_reported_model_ids != frozenset(profile.accepted_reported_model_ids):
        return True  # an allowlist must never travel to another profile
    if profile.api_surface is not None and identity.api_surface != profile.api_surface:
        return True
    if identity.api_surface is not None and profile.api_surface is None:
        return True  # an identity carrying a surface must not reach a profile that has none
    declared = getattr(provider, "surface", None)
    if declared is not None and identity.api_surface is not None and declared != identity.api_surface:
        return True  # the adapter speaks a different API surface than the profile was validated for
    return False


class _CallState:
    """Per-call ownership and status flags. Guarded by ModelGateway._lock."""

    __slots__ = ("started", "cancelled", "done", "abandoned", "provider_slot", "provider_name")

    def __init__(self) -> None:
        self.started = False  # worker has claimed the call and will run the provider
        self.cancelled = False  # caller released the call before any worker claimed it
        self.done = False  # worker has finished and released its counters
        self.abandoned = False  # caller gave up while the worker was still running
        self.provider_slot = None  # per-provider semaphore held together with the global slot
        self.provider_name = None  # provider this call was admitted under


# Fixed labels for the outcome of response validation. The gateway owns the classification and
# tags each failure; the coordinator only records the tag. Never built from provider text.
VALIDATION_OUTCOMES = frozenset(
    {"passed", "incomplete_response", "invalid_response", "identity_mismatch",
     "content_blocked", "provider_error"}
)


class CallObserver:
    """Read-only hooks the gateway calls during one call. Default: do nothing.

    on_admitted: capacity is held and the worker is about to start.
    on_validating: the worker finished in time and the gateway is now validating the outcome.
    Neither is called for a call refused before admission, or one that timed out before validation.
    """

    def on_admitted(self) -> None:
        return None

    def on_validating(self) -> None:
        return None


def _tagged(exc: SanourError, outcome: str) -> SanourError:
    exc.validation_outcome = outcome  # internal only; never sent to callers
    return exc


class ModelGateway:
    def __init__(
        self,
        providers: Mapping[str, ModelProvider],
        *,
        max_concurrent_calls: int,
        provider_limits: Mapping[str, int] | None = None,
    ) -> None:
        if max_concurrent_calls < 1:
            raise ValueError("max_concurrent_calls must be at least 1")
        # Provider contract at registration: a callable generate(), and a name that equals its key.
        # Anything else is a configuration error, caught before any request is accepted.
        for key, provider in providers.items():
            if not callable(getattr(provider, "generate", None)):
                raise ValueError("provider must implement generate()")
            if getattr(provider, "name", None) != key:
                raise ValueError("provider name must match its registry key")
            if not isinstance(getattr(provider, "capabilities", None), ProviderCapabilities):
                raise ValueError("provider must declare ProviderCapabilities")
        self._providers = dict(providers)
        self.max_concurrent_calls = max_concurrent_calls
        self._slots = threading.BoundedSemaphore(max_concurrent_calls)
        # Per-provider capacity. Defaults to the global cap; can only be lowered, never raised.
        limits = dict(provider_limits or {})
        self._provider_slots: dict[str, threading.BoundedSemaphore] = {}
        for name in self._providers:
            limit = limits.pop(name, max_concurrent_calls)
            if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= max_concurrent_calls:
                raise ValueError("provider limit must be between 1 and max_concurrent_calls")
            self._provider_slots[name] = threading.BoundedSemaphore(limit)
        if limits:
            raise ValueError("provider_limits names a provider that is not registered")
        self._lock = threading.Lock()
        # Legacy counter: wait-expiry timeouts only. Keeps the original `timeouts` meaning.
        self._timeouts = 0
        self._in_flight = 0
        self._running = 0  # workers that claimed a call and have not returned
        # Metrics counters (all guarded by _lock).
        self._successful = 0
        self._provider_failures = 0
        self._timeout_outcomes = 0
        self._overloads = 0
        self._invalid_responses = 0
        self._unclassified = 0
        self._content_blocked = 0
        self._abandoned = 0
        self._peak = 0
        self._closed = False
        self._closed_providers: set[str] = set()
        self._settled: dict[str, str] = {}  # provider name -> "closed" | "failed" once its close finished
        self._close_failures = 0
        self._observers: list = []  # callables (provider_id, outcome); run outside every lock
        # Admitted calls per provider: counted exactly where _in_flight is counted.
        self._provider_in_flight = {name: 0 for name in self._providers}
        # Stage 10.41: worker threads still alive per provider (claimed, not yet at their last statement),
        # and the settler threads waiting for them. Condition shares the gateway lock: no polling.
        self._unfinished = {name: 0 for name in self._providers}
        self._settlers: set[str] = set()  # providers that have (or had) a settler; guard against duplicates
        self._settler_running: set[str] = set()  # settler threads alive: waiting or closing
        self._settler_started_total = 0
        self._cancelled_before_start = 0
        self._idle_cv = threading.Condition(self._lock)

    @property
    def in_flight(self) -> int:
        """Live worker threads, including abandoned ones that have not returned yet."""
        with self._lock:
            return self._in_flight

    @property
    def is_shut_down(self) -> bool:
        """True once shutdown() has been called. Calls are refused from then on."""
        with self._lock:
            return self._closed

    @property
    def timeouts(self) -> int:
        """Wait-expiry timeouts only. Expired-before-start calls are not included here."""
        with self._lock:
            return self._timeouts

    def stats(self) -> GatewayStats:
        """Read-only snapshot. Does not change any counter."""
        with self._lock:
            successful = self._successful
            provider_failures = self._provider_failures
            timeouts = self._timeout_outcomes
            overloads = self._overloads
            invalid = self._invalid_responses
            unclassified = self._unclassified
            content_blocked = self._content_blocked
            in_flight = self._in_flight
            abandoned = self._abandoned
            peak = self._peak
            active = self._running
            close_failures = self._close_failures
            phases = [self._phase_locked(n) for n in self._providers]
            active_settlers = len(self._settler_running)
            settler_total = self._settler_started_total
            cancelled = self._cancelled_before_start
        return GatewayStats(
            provider_close_failures=close_failures,
            active_settlers=active_settlers,
            providers_waiting_for_workers=phases.count("waiting"),
            providers_closing=phases.count("closing"),
            settler_threads_started=settler_total,
            cancelled_before_start=cancelled,
            successful_calls=successful,
            provider_failures=provider_failures,
            timeouts=timeouts,
            overload_rejections=overloads,
            invalid_responses=invalid,
            unclassified_errors=unclassified,
            content_blocked=content_blocked,
            in_flight=in_flight,
            abandoned_in_flight=abandoned,
            peak_in_flight=peak,
            active_workers=active,
        )

    def shutdown(self, timeout: float = 5.0) -> int:
        """Refuse new calls, wait up to timeout for workers, then close idle providers.

        Returns how many workers were still running when it returned. A provider with a live
        worker is not closed; a later shutdown() call closes it once it is idle. Each provider is
        closed at most once, and a close() error is logged by type name only.
        """
        with self._lock:
            self._closed = True
        end = time.monotonic() + max(0.0, timeout)
        with self._lock:
            # Count admitted calls (not only started workers): a call admitted a moment before
            # shutdown() may not have started its worker yet, and its provider must stay open.
            # Event-driven: waits on the condition, which every finishing call notifies. No polling.
            while self._in_flight > 0:
                remaining = end - time.monotonic()
                if remaining <= 0:
                    break
                self._idle_cv.wait(remaining)
            still_running = self._in_flight
        first_abort = None
        for name in list(self._providers):
            try:
                self._settle_or_defer(name)
            except BaseException as exc:  # recorded, the other providers still settle, then re-raised
                if first_abort is None:
                    first_abort = exc
        if first_abort is not None:
            raise first_abort
        # Providers handed to a settler are awaited within the same deadline, so a worker that
        # finished in time is closed before shutdown() returns.
        with self._lock:
            while any(n in self._settlers and n not in self._settled for n in self._providers):
                remaining = end - time.monotonic()
                if remaining <= 0:
                    break
                self._idle_cv.wait(remaining)
        return still_running

    def add_settlement_observer(self, observer) -> None:
        """Register observer(provider_id, outcome). outcome is "closed" or "failed". Called once per
        provider, after its capacity was returned, outside every gateway lock."""
        with self._lock:
            self._observers.append(observer)

    def _settle_or_defer(self, name: str) -> None:
        """Entry point after shutdown() began. An idle provider is closed here, exactly once. A busy one
        gets a single settler thread (at most one per provider) that waits, without polling, until its
        last worker thread has finished, and only then closes it."""
        with self._lock:
            if not self._closed or name in self._closed_providers or name in self._settlers:
                return
            busy = self._provider_in_flight[name] != 0 or self._unfinished[name] != 0
            if busy:
                self._settlers.add(name)
                self._settler_running.add(name)
                self._settler_started_total += 1
            else:
                self._closed_providers.add(name)
                provider = self._providers[name]
        if busy:
            try:
                threading.Thread(
                    target=self._settle_when_idle, args=(name,),
                    name=f"sanour-settle-{name}", daemon=True,
                ).start()
            except Exception as exc:
                with self._lock:
                    self._settlers.discard(name)  # a later shutdown() may try again
                    self._settler_running.discard(name)
                    self._settler_started_total -= 1
                _log.warning("provider settlement could not start: %s", type(exc).__name__)
            return
        self._finish_close(name, provider)

    def _settle_when_idle(self, name: str) -> None:
        with self._lock:
            while self._provider_in_flight[name] != 0 or self._unfinished[name] != 0:
                self._idle_cv.wait()
            self._closed_providers.add(name)
            provider = self._providers[name]
        try:
            self._finish_close(name, provider)
        except BaseException as exc:
            # Bookkeeping already ran. Re-raise sanitized: the thread ends, the text is not printed.
            raise SettlementAborted(type(exc).__name__) from None

    def _finish_close(self, name: str, provider) -> None:
        """Close one claimed provider outside every lock. Bookkeeping runs on EVERY exit path:
        a BaseException from close() is recorded as a failed close, the settler leaves the running set,
        and observers are told exactly once. Only then is the BaseException re-raised (never swallowed)."""
        outcome, error_name = "failed", None
        aborted = None
        try:
            outcome, error_name = self._close_provider(provider)
        except BaseException as exc:
            aborted = exc
            error_name = type(exc).__name__
        finally:
            with self._lock:
                self._settled[name] = outcome
                if outcome == "failed":
                    self._close_failures += 1
                self._settler_running.discard(name)
                self._idle_cv.notify_all()
                observers = list(self._observers)
            if error_name is not None:
                _log.warning("provider close failed: %s", error_name)
            for observer in observers:
                try:
                    observer(name, outcome)
                except Exception as exc:
                    _log.warning("provider settlement observer failed: %s", type(exc).__name__)
        if aborted is not None:
            raise aborted

    @staticmethod
    def _close_provider(provider) -> tuple[str, str | None]:
        close = getattr(provider, "close", None)
        if not callable(close):
            return "closed", None
        try:
            close()
        except Exception as exc:
            return "failed", type(exc).__name__
        return "closed", None

    def provider_state(self, name: str) -> str:
        """Close outcome of one provider: unknown, open, closing, closed or failed."""
        with self._lock:
            if name not in self._providers:
                return "unknown"
            phase = self._phase_locked(name)
            return "open" if phase == "waiting" else phase

    def _phase_locked(self, name: str) -> str:
        """One phase per provider. Caller holds the lock.
        open -> waiting (settler waits for its workers) -> closing (close() running) -> closed | failed."""
        if name in self._settled:
            return self._settled[name]
        if name in self._closed_providers:
            return "closing"
        if name in self._settlers:
            return "waiting"
        return "open"

    def settlement_snapshot(self) -> dict:
        """Read-only settlement view: counts and per-provider phase names only."""
        with self._lock:
            phases = {n: self._phase_locked(n) for n in self._providers}
            return {
                "active_settlers": len(self._settler_running),
                "providers_waiting_for_workers": sum(1 for p in phases.values() if p == "waiting"),
                "providers_closing": sum(1 for p in phases.values() if p == "closing"),
                "phases": phases,
            }

    def generate(
        self,
        profile: ModelProfile,
        call: ModelCall,
        deadline: float,
        observer: CallObserver | None = None,
        identity: RequestIdentity | None = None,
    ) -> ModelResult:
        """observer, if given, receives the read-only hooks defined by CallObserver.

        identity is mandatory (Stage 10.36-R1). A call without a RequestIdentity is refused before any
        provider I/O, capacity, or shutdown check. There is no profile-only path.
        """
        try:
            result = self._generate(profile, call, deadline, observer, identity)
        except SanourError as exc:
            self._record_failure(exc.code)
            raise
        except BaseException:
            # Any other exception escaping generate(), including BaseException, is unclassified.
            with self._lock:
                self._unclassified += 1
            raise
        with self._lock:
            self._successful += 1
        return result

    def _record_failure(self, code: ErrorCode) -> None:
        with self._lock:
            if code is ErrorCode.PROVIDER_TIMEOUT:
                self._timeout_outcomes += 1
            elif code in (ErrorCode.PROVIDER_FAILED, ErrorCode.PROVIDER_RATE_LIMITED):
                self._provider_failures += 1
            elif code is ErrorCode.PROVIDER_OVERLOADED:
                self._overloads += 1
            elif code is ErrorCode.PROVIDER_INVALID_RESPONSE:
                self._invalid_responses += 1
            elif code is ErrorCode.PROVIDER_CONTENT_BLOCKED:
                self._content_blocked += 1
            else:
                self._unclassified += 1

    def _cancel_unclaimed(self, state: _CallState) -> bool:
        """Release the caller's slot and counter if no worker has claimed the call.

        Returns True if a worker already claimed the call, in which case the worker owns cleanup.
        """
        with self._lock:
            if state.started:
                return True
            state.cancelled = True
            self._cancelled_before_start += 1
            self._in_flight -= 1
            self._provider_in_flight[state.provider_name] -= 1
            self._idle_cv.notify_all()
        self._release_slots(state)
        return False

    def _release_slots(self, state: _CallState) -> None:
        # Inner (provider) slot first, then the global slot. Acquire order is the reverse.
        if state.provider_slot is not None:
            state.provider_slot.release()
        self._slots.release()

    def _mark_abandoned(self, state: _CallState) -> None:
        with self._lock:
            if not state.done and not state.abandoned:
                state.abandoned = True
                self._abandoned += 1

    def _generate(
        self,
        profile: ModelProfile,
        call: ModelCall,
        deadline: float,
        observer: CallObserver | None = None,
        identity: RequestIdentity | None = None,
    ) -> ModelResult:
        # Mandatory identity (Stage 10.36-R1). Checked first, before the shutdown check, capacity,
        # provider lookup, or any I/O.
        if not isinstance(identity, RequestIdentity):
            raise SanourError(
                ErrorCode.NO_ELIGIBLE_MODEL,
                "the requested model cannot handle this request",
                scope=REQUEST_IDENTITY_SCOPE,
            )
        # Refuse before any capacity is taken: a shut-down gateway admits nothing new.
        with self._lock:
            if self._closed:
                raise SanourError(ErrorCode.PROVIDER_FAILED, "model gateway is shut down",
                                  internal_kind=FailureKind.GATEWAY_SHUT_DOWN)
        provider = self._providers.get(profile.provider)
        if provider is None:
            raise SanourError(ErrorCode.PROVIDER_FAILED, "model provider is not registered",
                              internal_kind=FailureKind.PROVIDER_NOT_REGISTERED)
        if _identity_conflicts(identity, profile, call, provider):
            # The request identity does not describe this profile, provider, or call. Refused before
            # any capacity is taken. Nothing is retried and no other model is tried.
            raise SanourError(
                ErrorCode.NO_ELIGIBLE_MODEL,
                "the requested model cannot handle this request",
                scope=REQUEST_IDENTITY_SCOPE,
            )
        if unsupported_flags(profile.capabilities, provider.capabilities):
            # Fail closed: the model claims a capability its provider does not offer. No call is made.
            raise SanourError(
                ErrorCode.NO_ELIGIBLE_MODEL, "the requested model cannot handle this request"
            )

        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise SanourError(ErrorCode.PROVIDER_TIMEOUT, "model call timed out", retryable=True)

        if not self._slots.acquire(blocking=False):
            raise SanourError(
                ErrorCode.PROVIDER_OVERLOADED,
                "model capacity is full, try again shortly",
                retryable=True,
                scope="global",
            )
        provider_slot = self._provider_slots[profile.provider]
        if not provider_slot.acquire(blocking=False):
            self._slots.release()  # give back the global slot taken above
            raise SanourError(
                ErrorCode.PROVIDER_OVERLOADED,
                "model capacity is full, try again shortly",
                retryable=True,
                scope="provider",
            )

        outcome: dict[str, object] = {}
        finished = threading.Event()
        state = _CallState()
        state.provider_slot = provider_slot
        state.provider_name = profile.provider
        with self._lock:
            closed = self._closed
            if not closed:
                self._in_flight += 1
                self._provider_in_flight[profile.provider] += 1
        if closed:
            self._release_slots(state)
            raise SanourError(ErrorCode.PROVIDER_FAILED, "model gateway is shut down",
                                  internal_kind=FailureKind.GATEWAY_SHUT_DOWN)

        def _worker() -> None:
            with self._lock:
                if state.cancelled:
                    # The caller already released the slot and counter. Do nothing.
                    return
                state.started = True
                self._unfinished[state.provider_name] += 1
                self._running += 1
                self._peak = max(self._peak, self._running)
            try:
                try:
                    outcome["result"] = provider.generate(call)
                except Exception as exc:  # provider code is untrusted; capture everything
                    outcome["error"] = exc
                except BaseException as exc:  # process-control exceptions: re-raised by caller
                    outcome["fatal"] = exc
                finally:
                    with self._lock:
                        state.done = True
                        self._in_flight -= 1
                        self._provider_in_flight[state.provider_name] -= 1
                        self._running -= 1
                        self._idle_cv.notify_all()
                        log_fatal = False
                        if state.abandoned:
                            self._abandoned -= 1
                            log_fatal = "fatal" in outcome
                    if log_fatal:
                        # A failing log sink may raise here. The outer finally still runs.
                        _log.warning(
                            "abandoned provider call raised %s", type(outcome["fatal"]).__name__
                        )
            finally:
                # Unconditional: capacity is returned and the caller is released
                # even if the logging call above raised.
                # Last statements of the worker. Capacity is released, the caller is released, and only
                # then is this thread counted as finished. No provider code runs after this point.
                self._release_slots(state)
                finished.set()
                with self._lock:
                    self._unfinished[state.provider_name] -= 1
                    self._idle_cv.notify_all()

        try:
            if observer is not None:
                observer.on_admitted()
            thread = threading.Thread(
                target=_worker, name=f"sanour-model-{profile.alias}", daemon=True
            )
            thread.start()
        except BaseException as exc:
            claimed = self._cancel_unclaimed(state)
            if claimed:
                # A worker is already running and owns cleanup. The caller is leaving early.
                self._mark_abandoned(state)
            if isinstance(exc, Exception):
                raise SanourError(ErrorCode.PROVIDER_FAILED, "model provider failed") from None
            raise

        try:
            # Recompute from the clock: time spent starting the worker must not extend the wait.
            finished_in_time = finished.wait(max(0.0, deadline - time.monotonic()))
        except BaseException:
            self._mark_abandoned(state)
            raise
        if not finished_in_time:
            with self._lock:
                self._timeouts += 1
            self._mark_abandoned(state)
            raise SanourError(ErrorCode.PROVIDER_TIMEOUT, "model call timed out", retryable=True)

        # A process-control exception is re-raised first, whatever the clock says.
        fatal = outcome.get("fatal")
        if isinstance(fatal, BaseException):
            raise fatal

        # wait() can report success after the deadline has passed. Such a result is discarded.
        # The worker has already finished, so nothing is abandoned.
        if time.monotonic() >= deadline:
            raise SanourError(ErrorCode.PROVIDER_TIMEOUT, "model call timed out", retryable=True)

        if observer is not None:
            observer.on_validating()
        if "error" in outcome:
            exc = outcome["error"]
            retryable = isinstance(exc, ProviderError) and exc.retryable
            tag = getattr(exc, "error_code", None) if isinstance(exc, ProviderError) else None
            if tag == ErrorCode.PROVIDER_RATE_LIMITED.value:
                code, label = ErrorCode.PROVIDER_RATE_LIMITED, "provider_error"
            elif tag == ErrorCode.PROVIDER_INVALID_RESPONSE.value:
                code, label = ErrorCode.PROVIDER_INVALID_RESPONSE, "incomplete_response"
            elif tag == ErrorCode.PROVIDER_CONTENT_BLOCKED.value:
                code, label = ErrorCode.PROVIDER_CONTENT_BLOCKED, "content_blocked"
            else:
                code, label = ErrorCode.PROVIDER_FAILED, "provider_error"
            raise _tagged(
                SanourError(
                    code,
                    "model provider failed",
                    retryable=retryable,
                    status_code=getattr(exc, "status_code", None) if isinstance(exc, ProviderError) else None,
                    failure_reason=getattr(exc, "failure_reason", None) if isinstance(exc, ProviderError) else None,
                    retry_after_seconds=(
                        getattr(exc, "retry_after_seconds", None) if isinstance(exc, ProviderError) else None
                    ),
                    internal_detail=str(exc) if isinstance(exc, ProviderError) else None,
                    internal_kind=exc.kind if isinstance(exc, ProviderError) else None,
                ),
                label,
            )

        result = outcome.get("result")
        if not isinstance(result, ModelResult):
            raise _tagged(
                SanourError(ErrorCode.PROVIDER_INVALID_RESPONSE, "model returned an invalid response"),
                "invalid_response",
            )
        # Identity first: the provider's self-reported id must be the requested model, or one of
        # the exact ids this profile explicitly accepts. Anything else (empty, missing, unknown)
        # is rejected. The answer is still attributed to the profile, never to the reported id.
        if not identity.accepts_reported(result.reported_model_id):
            raise _tagged(
                SanourError(
                    ErrorCode.PROVIDER_INVALID_RESPONSE,
                    "model returned an invalid response",
                    scope=IDENTITY_MISMATCH_SCOPE,
                ),
                "identity_mismatch",
            )
        if not result.text.strip() or len(result.text) > MAX_RESULT_CHARS:
            raise _tagged(
                SanourError(ErrorCode.PROVIDER_INVALID_RESPONSE, "model returned an invalid response"),
                "invalid_response",
            )
        return result
