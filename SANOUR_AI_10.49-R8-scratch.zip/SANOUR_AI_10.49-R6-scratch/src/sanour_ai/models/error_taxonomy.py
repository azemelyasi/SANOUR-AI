"""Internal error taxonomy (Stage 10.37, made structural in 10.37-R1).

Every failure that reaches the Coordinator is mapped to exactly one InternalErrorKind. The decision
reads only typed fields: the public ErrorCode, the typed FailureKind set by the code that raised the
failure (SanourError.internal_kind), and the fixed failure_reason. Message text (SanourError.message
and SanourError.internal_detail) never takes part in classification. It is kept for internal
diagnostics only.

It never creates a public ErrorCode, and retryable is a hint only: no code path retries on it.
"""

from __future__ import annotations

from enum import StrEnum

from sanour_ai.errors import ErrorCode, FailureKind, SanourError
from sanour_ai.models.request_identity import REQUEST_IDENTITY_SCOPE
from sanour_ai.models.router import RoutingRefusal


class InternalErrorKind(StrEnum):
    REQUEST_VALIDATION = "request_validation"
    PROFILE_RESOLUTION = "profile_resolution"
    IDENTITY_VALIDATION = "identity_validation"
    CAPABILITY_VALIDATION = "capability_validation"
    CAPACITY_REJECTED = "capacity_rejected"
    PROVIDER_TRANSPORT = "provider_transport"
    PROVIDER_AUTHENTICATION = "provider_authentication"
    PROVIDER_RATE_LIMIT = "provider_rate_limit"
    PROVIDER_QUOTA = "provider_quota"  # billing and quota share this group; failure_reason tells them apart
    PROVIDER_CONTENT_BLOCKED = "provider_content_blocked"
    PROVIDER_INCOMPLETE_RESPONSE = "provider_incomplete_response"
    PROVIDER_INVALID_RESPONSE = "provider_invalid_response"
    PROVIDER_REQUEST_REJECTED = "provider_request_rejected"  # 400, 404: the request or model was refused
    DEADLINE_EXCEEDED = "deadline_exceeded"
    PROVIDER_LIFECYCLE = "provider_lifecycle"
    PROVIDER_LIMIT_UNCONFIRMED = "provider_limit_unconfirmed"  # 429 with no structural code: not rate, not quota
    PROVIDER_UNCLASSIFIED = "provider_unclassified"
    INTERNAL_EXECUTION = "internal_execution"


# Typed FailureKind -> internal kind. Every FailureKind member must appear here (enforced by tests).
_KIND_TO_INTERNAL: dict[FailureKind, InternalErrorKind] = {
    FailureKind.AUTHENTICATION: InternalErrorKind.PROVIDER_AUTHENTICATION,
    FailureKind.PERMISSION: InternalErrorKind.PROVIDER_AUTHENTICATION,
    FailureKind.CONNECTION: InternalErrorKind.PROVIDER_TRANSPORT,
    FailureKind.CALL_TIMEOUT: InternalErrorKind.PROVIDER_TRANSPORT,
    FailureKind.SERVER_ERROR: InternalErrorKind.PROVIDER_TRANSPORT,
    FailureKind.MODEL_NOT_FOUND: InternalErrorKind.PROVIDER_REQUEST_REJECTED,
    FailureKind.REQUEST_REJECTED: InternalErrorKind.PROVIDER_REQUEST_REJECTED,
    FailureKind.RATE_LIMIT: InternalErrorKind.PROVIDER_RATE_LIMIT,
    FailureKind.CONTENT_BLOCKED: InternalErrorKind.PROVIDER_CONTENT_BLOCKED,
    FailureKind.INCOMPLETE_RESPONSE: InternalErrorKind.PROVIDER_INCOMPLETE_RESPONSE,
    # The request path always sets a deadline, so a missing one is an internal fault, not an expiry.
    FailureKind.DEADLINE_MISSING: InternalErrorKind.INTERNAL_EXECUTION,
    FailureKind.DEADLINE_EXPIRED: InternalErrorKind.DEADLINE_EXCEEDED,
    FailureKind.DEADLINE_LATE: InternalErrorKind.DEADLINE_EXCEEDED,
    FailureKind.DEADLINE_IN_CALL: InternalErrorKind.DEADLINE_EXCEEDED,
    FailureKind.INVALID_MODEL_ID: InternalErrorKind.REQUEST_VALIDATION,
    FailureKind.CLIENT_CHANGED: InternalErrorKind.PROVIDER_LIFECYCLE,
    FailureKind.GATEWAY_SHUT_DOWN: InternalErrorKind.PROVIDER_LIFECYCLE,
    FailureKind.PROVIDER_NOT_REGISTERED: InternalErrorKind.PROVIDER_LIFECYCLE,
    # Intentionally unclassified: non-retryable, and never guessed into a category.
    FailureKind.UNCLASSIFIED: InternalErrorKind.PROVIDER_UNCLASSIFIED,
    FailureKind.CALL_FAILED: InternalErrorKind.PROVIDER_UNCLASSIFIED,
    # Decisions (Stage 10.38, documented in docs/FAILURE_KIND_DECISIONS.md):
    FailureKind.LIMIT_REACHED: InternalErrorKind.PROVIDER_LIMIT_UNCONFIRMED,
    FailureKind.PAYMENT_REQUIRED: InternalErrorKind.PROVIDER_QUOTA,
    FailureKind.RESPONSE_TOO_LARGE: InternalErrorKind.PROVIDER_INVALID_RESPONSE,
}


def classify(error: SanourError) -> InternalErrorKind:
    """Map one failure to one internal kind using typed fields only. Unknown combinations fail closed."""
    code = error.code
    if code is ErrorCode.INVALID_REQUEST:
        return InternalErrorKind.REQUEST_VALIDATION
    if code is ErrorCode.NO_ELIGIBLE_MODEL:
        if error.scope == REQUEST_IDENTITY_SCOPE:
            return InternalErrorKind.IDENTITY_VALIDATION
        if isinstance(error, RoutingRefusal):
            return InternalErrorKind.PROFILE_RESOLUTION
        return InternalErrorKind.CAPABILITY_VALIDATION
    if code is ErrorCode.PROVIDER_OVERLOADED:
        return InternalErrorKind.CAPACITY_REJECTED
    if code is ErrorCode.PROVIDER_TIMEOUT:
        return InternalErrorKind.DEADLINE_EXCEEDED
    if code is ErrorCode.PROVIDER_RATE_LIMITED:
        return InternalErrorKind.PROVIDER_RATE_LIMIT
    if code is ErrorCode.PROVIDER_CONTENT_BLOCKED:
        return InternalErrorKind.PROVIDER_CONTENT_BLOCKED
    if code is ErrorCode.PROVIDER_INVALID_RESPONSE:
        if getattr(error, "validation_outcome", None) == "incomplete_response":
            return InternalErrorKind.PROVIDER_INCOMPLETE_RESPONSE
        return InternalErrorKind.PROVIDER_INVALID_RESPONSE
    if code is ErrorCode.PROVIDER_FAILED:
        if error.failure_reason in ("quota", "billing"):
            return InternalErrorKind.PROVIDER_QUOTA
        kind = getattr(error, "internal_kind", None)
        if not isinstance(kind, FailureKind):
            return InternalErrorKind.PROVIDER_UNCLASSIFIED
        return _KIND_TO_INTERNAL[kind]
    return InternalErrorKind.INTERNAL_EXECUTION
