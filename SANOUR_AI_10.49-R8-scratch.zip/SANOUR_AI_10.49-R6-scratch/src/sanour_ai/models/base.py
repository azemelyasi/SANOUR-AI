"""Provider protocol. Every adapter, including the future SANOUR model, implements this."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, runtime_checkable

from sanour_ai.errors import FAILURE_REASONS, FailureKind
from sanour_ai.models.usage import Usage


@dataclass(frozen=True)
class ModelCall:
    """One provider attempt.

    deadline: absolute time.monotonic() value for the whole request, set by SanourCore.handle().
    The core is the only place it is computed. No layer may extend or reset it. It is None only
    for callers that predate this field; the request path always sets it.

    Contract for future adapters (documentation only; no adapter exists yet):
    - Compute the remaining budget as deadline - time.monotonic() at the start of every I/O step.
      If it is <= 0, fail with ProviderError(retryable=True) before any network I/O.
    - Every internal timeout (connect, read, write, pool) must be min(configured, remaining).
      Read timeouts are per read, so also check the remaining budget between reads.
    - Stop I/O when the deadline passes where the transport allows it. The gateway stays the
      authority: a late result is discarded, and the worker keeps its slot until it returns.
    - No internal retries. Cancellation is not part of this contract.
    """

    model_id: str
    prompt: str
    max_output_tokens: int
    deadline: float | None = None


@dataclass(frozen=True)
class ModelResult:
    """What a provider reported. reported_model_id is the provider's own identity claim.

    It is checked by the gateway against the profile's requested model_id and its explicit
    allowlist. It is never used as the model that answered: the profile always is.
    """

    text: str
    reported_model_id: str
    usage: Usage | None = None  # None: not reported or not derivable (Stage 10.47)


class ProviderError(Exception):
    """Raised by provider adapters. `detail` is for internal use only and never reaches callers.

    status_code, failure_reason (from the fixed FAILURE_REASONS set) and retry_after_seconds are
    internal metadata. They are copied to the gateway's SanourError and never sent to callers.
    """

    def __init__(
        self,
        detail: str,
        *,
        retryable: bool = False,
        status_code: int | None = None,
        failure_reason: str | None = None,
        retry_after_seconds: int | None = None,
        kind: FailureKind = FailureKind.UNCLASSIFIED,
    ) -> None:
        super().__init__(detail)
        if not isinstance(kind, FailureKind):
            raise TypeError("kind must be a FailureKind")
        # Typed and structural (Stage 10.37-R1). Classification reads only this field, never the text.
        self.kind = kind
        if failure_reason is not None and failure_reason not in FAILURE_REASONS:
            raise ValueError("failure_reason must come from the fixed set")
        self.retryable = retryable
        self.status_code = status_code
        self.failure_reason = failure_reason
        self.retry_after_seconds = retry_after_seconds


@runtime_checkable
class ModelProvider(Protocol):
    name: str

    def generate(self, call: ModelCall) -> ModelResult: ...
