"""Stage 10.47: provider-independent usage model.

Every field is either a validated non-negative integer or None. None means "not reported or not
derivable". It is never replaced by zero, and no value is invented.

Semantics (identical across adapters after normalization):
- input_tokens: all prompt tokens, including cached ones.
- output_tokens: all generated tokens, including reasoning tokens.
- cached_input_tokens: the part of input_tokens served from cache (subset of input_tokens).
- reasoning_tokens: the part of output_tokens spent on reasoning (subset of output_tokens).
- total_tokens: input_tokens + output_tokens. Cached and reasoning tokens are never added again.
  total_tokens is kept only when input and output are both known, and it must match their sum.

No prices, no currency, no raw provider payload. Only these five integers are stored.
"""

from __future__ import annotations

from dataclasses import dataclass

USAGE_FIELDS = ("input_tokens", "output_tokens", "total_tokens", "cached_input_tokens", "reasoning_tokens")


def _check_count(name: str, value: object) -> int | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"usage field must be a whole number or unknown: {name}")
    if value < 0:
        raise ValueError(f"usage field must not be negative: {name}")
    return value


@dataclass(frozen=True)
class Usage:
    input_tokens: int | None = None
    output_tokens: int | None = None
    total_tokens: int | None = None
    cached_input_tokens: int | None = None
    reasoning_tokens: int | None = None

    def __post_init__(self) -> None:
        for name in USAGE_FIELDS:
            _check_count(name, getattr(self, name))
        if self.input_tokens is not None and self.output_tokens is not None and self.total_tokens is not None:
            if self.total_tokens != self.input_tokens + self.output_tokens:
                raise ValueError("usage totals are inconsistent")
        if self.cached_input_tokens is not None and self.input_tokens is not None:
            if self.cached_input_tokens > self.input_tokens:
                raise ValueError("cached input tokens exceed input tokens")
        if self.reasoning_tokens is not None and self.output_tokens is not None:
            if self.reasoning_tokens > self.output_tokens:
                raise ValueError("reasoning tokens exceed output tokens")

    def as_dict(self) -> dict[str, int | None]:
        """Only the five normalized fields. Unknown stays None."""
        return {name: getattr(self, name) for name in USAGE_FIELDS}


def _get(obj: object, name: str) -> object:
    """Read a field from a dict or an SDK object. Missing is None, never a default."""
    if obj is None:
        return None
    if isinstance(obj, dict):
        return obj.get(name)
    return getattr(obj, name, None)


def usage_from_openai_style(usage: object) -> Usage | None:
    """OpenAI Responses and xAI Responses shape: input_tokens, output_tokens, total_tokens,
    input_tokens_details.cached_tokens, output_tokens_details.reasoning_tokens."""
    if usage is None:
        return None
    input_details = _get(usage, "input_tokens_details")
    output_details = _get(usage, "output_tokens_details")
    return _build(**dict(
        input_tokens=_get(usage, "input_tokens"),
        output_tokens=_get(usage, "output_tokens"),
        total_tokens=_get(usage, "total_tokens"),
        cached_input_tokens=_get(input_details, "cached_tokens"),
        reasoning_tokens=_get(output_details, "reasoning_tokens"),
    ))


def usage_from_chat_completions(usage: object) -> Usage | None:
    """Chat Completions shape: prompt_tokens, completion_tokens, total_tokens,
    prompt_tokens_details.cached_tokens, completion_tokens_details.reasoning_tokens."""
    if usage is None:
        return None
    prompt_details = _get(usage, "prompt_tokens_details")
    completion_details = _get(usage, "completion_tokens_details")
    return _build(**dict(
        input_tokens=_get(usage, "prompt_tokens"),
        output_tokens=_get(usage, "completion_tokens"),
        total_tokens=_get(usage, "total_tokens"),
        cached_input_tokens=_get(prompt_details, "cached_tokens"),
        reasoning_tokens=_get(completion_details, "reasoning_tokens"),
    ))


def usage_from_anthropic(usage: object) -> Usage | None:
    """Messages shape. input_tokens EXCLUDES cache reads and cache creation, so the normalized
    input is their sum. If either cache field is missing, the input total is unknown (None), since
    it cannot be derived. Output is kept. No total is reported (none is documented)."""
    if usage is None:
        return None
    raw_input = _get(usage, "input_tokens")
    cache_read = _get(usage, "cache_read_input_tokens")
    cache_creation = _get(usage, "cache_creation_input_tokens")
    output = _get(usage, "output_tokens")
    if raw_input is None or cache_read is None or cache_creation is None:
        normalized_input = None
        cached = None
    else:
        try:
            normalized_input = _check_count("input_tokens", raw_input) + _check_count(
                "cache_read_input_tokens", cache_read) + _check_count(
                "cache_creation_input_tokens", cache_creation)
        except ValueError:
            return None
        cached = cache_read
    return _build(**dict(input_tokens=normalized_input, output_tokens=output, cached_input_tokens=cached))


def usage_from_gemini(usage: object) -> Usage | None:
    """usageMetadata shape. candidatesTokenCount excludes thoughts, so normalized output is candidates
    plus thoughts. thoughtsTokenCount absent means reasoning is unknown, and then the total is also
    unknown (never derived). cachedContentTokenCount is a subset of promptTokenCount."""
    if usage is None:
        return None
    prompt = _get(usage, "promptTokenCount")
    candidates = _get(usage, "candidatesTokenCount")
    thoughts = _get(usage, "thoughtsTokenCount")
    total = _get(usage, "totalTokenCount")
    cached = _get(usage, "cachedContentTokenCount")
    try:
        _check_count("promptTokenCount", prompt)
        _check_count("candidatesTokenCount", candidates)
        _check_count("thoughtsTokenCount", thoughts)
    except ValueError:
        return None
    if candidates is None:
        output = None
    elif thoughts is None:
        output = candidates
    else:
        output = candidates + thoughts
    reasoning = thoughts
    total_out = total if (thoughts is not None and total is not None) else None
    return _build(**dict(input_tokens=prompt, output_tokens=output, total_tokens=total_out,
                       cached_input_tokens=cached, reasoning_tokens=reasoning))


def _build(**fields: object) -> Usage | None:
    """A payload that fails any usage invariant is dropped entirely: no partial guess, no zero.
    The answer text itself is still valid, so the response is not failed over usage."""
    try:
        return Usage(**fields)  # type: ignore[arg-type]
    except (ValueError, TypeError):
        return None


def usage_audit_fields(usage: Usage | None) -> dict[str, object]:
    """Counters for the usage audit event. Unknown stays None; nothing is derived or defaulted."""
    if usage is None:
        return {"usage_status": "unavailable", **{name: None for name in USAGE_FIELDS}}
    return {"usage_status": "reported", **usage.as_dict()}
