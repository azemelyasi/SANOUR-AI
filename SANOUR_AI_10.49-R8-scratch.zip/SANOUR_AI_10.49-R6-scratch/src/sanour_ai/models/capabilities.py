"""Capability and profile metadata. Capabilities are declared, never assumed."""

from __future__ import annotations

import re

from pydantic import BaseModel, ConfigDict, Field, field_validator

# Same identifier shape as the adapters use for model ids. Full-match only, so a trailing
# newline or any other character outside the shape is rejected.
_REPORTED_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._\-]{0,127}")
ACCEPTED_REPORTED_IDS_MAX = 8


class AllowlistConfigError(Exception):
    """Invalid accepted_reported_model_ids. Deliberately NOT a ValueError.

    Pydantic copies the rejected input into the text of any ValueError it wraps, which would echo
    configuration values. A non-ValueError propagates unchanged, so only this fixed message exists.
    """


class ModelCapabilities(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    text_generation: bool = False
    structured_output: bool = False
    tool_calling: bool = False
    image_input: bool = False
    image_output: bool = False
    video_output: bool = False
    streaming: bool = False
    max_context_tokens: int = Field(gt=0)
    max_output_tokens: int = Field(gt=0)


class ModelProfile(BaseModel):
    """A configured model the router may choose. `alias` is what the core refers to."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    alias: str = Field(pattern=r"^[a-z][a-z0-9_]{1,63}$")
    provider: str = Field(pattern=r"^[a-z][a-z0-9_]{1,63}$")
    model_id: str = Field(min_length=1, max_length=128)
    capabilities: ModelCapabilities
    runs_locally: bool = False
    # DEPRECATED (Stage 10.36-R1): kept for type compatibility only. No operational path reads it.
    priority: int = Field(default=100, ge=0)
    # Exact provider-reported ids this profile accepts besides model_id itself (e.g. a dated
    # snapshot). No prefixes, wildcards or patterns. Empty means exact match only.
    accepted_reported_model_ids: frozenset[str] = Field(default=frozenset())
    # Stage 10.36: the API surface this profile was validated against (None for legacy profiles).
    api_surface: str | None = Field(default=None, pattern=r"^[a-z][a-z0-9_]{1,63}$")

    @field_validator("accepted_reported_model_ids")
    @classmethod
    def _allowlist_is_strict(cls, value: frozenset[str]) -> frozenset[str]:
        if len(value) > ACCEPTED_REPORTED_IDS_MAX:
            raise AllowlistConfigError("too many accepted reported model ids")
        for item in value:
            if not isinstance(item, str) or not _REPORTED_ID.fullmatch(item):
                raise AllowlistConfigError("accepted reported model id has an invalid format")
        return value


CAPABILITY_FLAGS: tuple[str, ...] = (
    "text_generation",
    "structured_output",
    "tool_calling",
    "image_input",
    "image_output",
    "video_output",
    "streaming",
)


class ProviderCapabilities(BaseModel):
    """What a provider adapter can do at most. Declared by the adapter, never discovered.

    A model profile may only declare flags that its provider declares (see unsupported_flags).
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    text_generation: bool = False
    structured_output: bool = False
    tool_calling: bool = False
    image_input: bool = False
    image_output: bool = False
    video_output: bool = False
    streaming: bool = False


def unsupported_flags(model: ModelCapabilities, provider: ProviderCapabilities) -> tuple[str, ...]:
    """Flags the model claims but the provider does not support. Must be empty to be usable."""
    return tuple(f for f in CAPABILITY_FLAGS if getattr(model, f) and not getattr(provider, f))


def missing_flags(model: ModelCapabilities, required: tuple[str, ...]) -> tuple[str, ...]:
    """Requested flags the model does not declare. Empty means the request is supported."""
    return tuple(f for f in required if not getattr(model, f))

