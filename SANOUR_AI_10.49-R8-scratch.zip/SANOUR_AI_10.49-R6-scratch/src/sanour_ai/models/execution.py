"""Execution result contract (Stage 10.37). Immutable, typed, and honest about unknown values.

- Identity: requested_model_id and provider_reported_model_id are separate fields. They are never merged.
  The reported id is recorded only after the Gateway has accepted it as exactly the requested id or an
  allowlisted id. A rejected reported id never reaches this object.
- usage: None means the provider did not report usage. It is never replaced by zero. No adapter in this
  repository reads usage, so every result carries None today.
- verification_status: always "implemented_unverified". No live provider test exists, so nothing is
  VERIFIED (see docs/MODEL_VERIFICATION_POLICY.md).
- No key, no prompt, no response text beyond the normalized output, and no provider error text.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Literal

from sanour_ai.models.usage import Usage


class ExecutionStage(StrEnum):
    """The fifteen pipeline stages, in the only order the Coordinator runs them."""

    REQUEST_RECEIVED = "request_received"
    REQUEST_VALIDATION = "request_validation"
    EXPLICIT_PROFILE_RESOLUTION = "explicit_profile_resolution"
    REQUEST_IDENTITY_VALIDATION = "request_identity_validation"
    CAPABILITY_AND_MODEL_CONSTRAINTS = "capability_and_model_constraints"
    CAPACITY_ADMISSION = "capacity_admission"
    PROVIDER_REQUEST_CONSTRUCTION = "provider_request_construction"
    PROVIDER_EXECUTION = "provider_execution"
    RAW_RESPONSE_RECEPTION = "raw_response_reception"
    RESPONSE_NORMALIZATION = "response_normalization"
    RESPONSE_INTEGRITY_VALIDATION = "response_integrity_validation"
    IDENTITY_VALIDATION = "identity_validation"
    RESULT_CONSTRUCTION = "result_construction"
    AUDIT_AND_METRICS = "audit_and_metrics"
    REQUEST_COMPLETION = "request_completion"


VERIFICATION_STATUS = "implemented_unverified"


@dataclass(frozen=True)
class ExecutionResult:
    request_id: str
    profile_id: str
    provider_id: str
    api_surface: str | None
    requested_model_id: str
    provider_reported_model_id: str
    output: str
    finish_status: Literal["completed"]
    execution_ms: int
    usage: Usage | None = None  # None: not reported by the provider (Stage 10.47: typed)
    completion_status: Literal["completed"] = "completed"
    verification_status: str = field(default=VERIFICATION_STATUS)
    # Stage 10.47-R1: "recorded" only if the usage audit write returned success; "failed" if it did not
    # (allowed only when audit is not required); "not_recorded" otherwise.
    usage_audit: str = "unavailable"
    # Stage 10.47-R2: "delivered" if the output reached the caller, "withheld" if it did not.
    delivery: str = "delivered"

    def __post_init__(self) -> None:
        for name in ("request_id", "profile_id", "provider_id", "requested_model_id",
                     "provider_reported_model_id"):
            value = getattr(self, name)
            if not isinstance(value, str) or not value:
                raise ValueError(f"execution result field is empty: {name}")
        if not isinstance(self.output, str) or not self.output.strip():
            raise ValueError("execution result has no output")
        if self.execution_ms < 0:
            raise ValueError("execution duration is negative")
        if self.usage_audit not in ("recorded", "failed", "unavailable"):
            raise ValueError("usage audit status is not one of the fixed values")
        if self.delivery not in ("delivered", "withheld"):
            raise ValueError("delivery status is not one of the fixed values")
        if self.verification_status != VERIFICATION_STATUS:
            raise ValueError("execution results cannot claim a verification status")
        if self.usage is not None and not isinstance(self.usage, Usage):
            raise ValueError("reported usage must be a validated Usage record")
