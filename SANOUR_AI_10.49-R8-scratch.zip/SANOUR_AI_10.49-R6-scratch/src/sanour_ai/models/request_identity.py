"""Request identity (Stage 10.36). One immutable object per request, created once and never changed.

- Created by the Coordinator only after the named profile has been resolved and checked.
- Holds identifiers only: request_id, profile_id, provider_id, api_surface, requested_model_id, and
  the exact allowlist of the profile. It holds no key, no prompt, no response, and no deadline. The
  deadline stays in the Coordinator, which is the single owner of it.
- Frozen dataclass with frozen values. Attribute assignment raises. The allowlist is a frozenset.
- The Gateway compares the provider's reported id with this object only. Matching is exact. There
  are no wildcards, no prefixes, and no fallback to any other model.
"""

from __future__ import annotations

from dataclasses import dataclass

from sanour_ai.models.capabilities import ModelProfile

REQUEST_IDENTITY_SCOPE = "request_identity"  # internal marker on a refusal, never sent to callers


@dataclass(frozen=True)
class RequestIdentity:
    request_id: str
    profile_id: str
    provider_id: str
    api_surface: str | None  # None only for legacy profiles that were never validated against a surface
    requested_model_id: str
    accepted_reported_model_ids: frozenset[str]

    @classmethod
    def for_profile(cls, request_id: str, profile: ModelProfile) -> RequestIdentity:
        return cls(
            request_id=request_id,
            profile_id=profile.alias,
            provider_id=profile.provider,
            api_surface=profile.api_surface,
            requested_model_id=profile.model_id,
            accepted_reported_model_ids=frozenset(profile.accepted_reported_model_ids),
        )

    def accepts_reported(self, reported: object) -> bool:
        """Exact match against the requested id or the profile's own allowlist. Anything else: False."""
        if not isinstance(reported, str) or not reported:
            return False
        if reported == self.requested_model_id:
            return True
        return reported in self.accepted_reported_model_ids

    def log_fields(self) -> dict[str, str]:
        """Identifiers only, safe for audit. Never includes a provider-reported value."""
        fields = {
            "request_id": self.request_id,
            "model_alias": self.profile_id,
            "provider": self.provider_id,
        }
        if self.api_surface is not None:
            fields["api_surface"] = self.api_surface
        return fields
