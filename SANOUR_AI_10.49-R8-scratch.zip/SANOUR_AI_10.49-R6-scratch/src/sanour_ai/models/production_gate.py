"""Production model verification gate (Stage 10.45).

A production runtime is built only when BOTH hold:
1. every capability it needs is VERIFIED for its provider surface (capability_intelligence.production_ready);
2. the exact (provider, surface, model_id) triple is in APPROVED_PRODUCTION_MODELS.

Today neither holds: RUNTIME_EVIDENCE is empty and APPROVED_PRODUCTION_MODELS is empty. An operator-declared
model id is NOT verified. Environment variables cannot change either input; only a reviewed code change can.
The refusal message names no provider, model, or value.
"""

from __future__ import annotations

from collections.abc import Iterable

from sanour_ai.models import capability_intelligence

# Reviewed approvals only. Empty: nothing is approved for production.
APPROVED_PRODUCTION_MODELS: frozenset[tuple[str, str, str]] = frozenset()


class ProductionGateRefused(Exception):
    """Fixed-message refusal. Carries no provider, model, or configuration value."""


def check(
    provider_id: str,
    surface: str,
    adapter_caps: object,
    required_categories: Iterable[str],
    model_id: str,
    *,
    approved: frozenset[tuple[str, str, str]] | None = None,
) -> None:
    verified = set(capability_intelligence.production_ready(provider_id, surface, adapter_caps,
                                                            model_id=model_id))
    if not set(required_categories) <= verified:
        raise ProductionGateRefused("capability not verified")
    allowed = APPROVED_PRODUCTION_MODELS if approved is None else approved
    if (provider_id, surface, model_id) not in allowed:
        raise ProductionGateRefused("model not verified")
