"""Legacy model catalog (Stage 10.2). DEPRECATED since Stage 10.36-R1.

It holds a tuple of ModelProfiles and nothing else. It is NOT used by any operational path: the
production composition builds profiles through models/model_catalog.py and models/profile_management.py.
It is kept only so that existing tests of its validation rules still run. It never routes or selects.
Constructing it emits a DeprecationWarning.
"""

from __future__ import annotations

import warnings

from pydantic import BaseModel, ConfigDict, Field, field_validator

from sanour_ai.models.capabilities import ModelProfile


class ModelCatalog(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    profiles: tuple[ModelProfile, ...] = Field(min_length=1)

    def model_post_init(self, __context: object) -> None:
        warnings.warn(
            "sanour_ai.models.catalog.ModelCatalog is deprecated and not used operationally",
            DeprecationWarning,
            stacklevel=2,
        )

    @field_validator("profiles")
    @classmethod
    def _aliases_are_unique(cls, profiles: tuple[ModelProfile, ...]) -> tuple[ModelProfile, ...]:
        # Input order decides which duplicate is reported, so the result is deterministic.
        seen: set[str] = set()
        for profile in profiles:
            if profile.alias in seen:
                raise ValueError(f"duplicate model alias: {profile.alias}")
            seen.add(profile.alias)
        return profiles
