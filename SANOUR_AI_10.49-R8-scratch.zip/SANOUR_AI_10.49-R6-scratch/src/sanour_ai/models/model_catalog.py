"""Model catalog (Stage 10.35): a versioned, validated record of models, one entry per provider.

What this module is
- A store of facts about models: identity, documented capabilities, documented limits, lifecycle,
  verification status, and the source of every fact. It does not route, fetch, or call providers.
- Identity is (provider_id, model_id). Model ids are stored exactly as given: no case folding, no
  trimming, no normalisation. The same id under another provider is a different model.

What this module refuses
- Any fact the caller does not state. Unknown values are None or UNKNOWN, never guessed.
- A token limit or a DOCUMENTED_ONLY capability without a documentation reference (operator-declared
  limits are the one exception, and they stay marked as operator-declared).
- Re-registering an identity that already exists, including a removed one. Removal is permanent.
- Any write after freeze(). Reads never change anything.
- A deactivation without explicit authorization (authorized must be exactly True).

Errors never echo the rejected value. They name fields and fixed reasons only.
"""

from __future__ import annotations

import re
import threading
from collections.abc import Iterable
from dataclasses import dataclass
from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator, model_validator

from sanour_ai.models import provider_matrix as pm


class CatalogError(Exception):
    """Catalog refusal. Messages are fixed or name a field; never a rejected value."""


class LifecycleStatus(StrEnum):
    ACTIVE = "active"
    DEPRECATED = "deprecated"
    REMOVED = "removed"
    UNKNOWN = "unknown"


class VerificationStatus(StrEnum):
    DOCUMENTED = "documented"  # an official document was checked and cited
    UNVERIFIED = "unverified"  # nothing was checked; the record is a claim, not a fact


class SourceKind(StrEnum):
    OFFICIAL_DOCUMENTATION = "official_documentation"
    OPERATOR_CONFIGURATION = "operator_configuration"
    UNKNOWN = "unknown"


class CapabilityStatus(StrEnum):
    """Status of one capability. The catalog stores only documentary claims, so it never holds
    VERIFIED or IMPLEMENTED_UNVERIFIED (those belong to capability_intelligence)."""

    DOCUMENTED_ONLY = "documented_only"
    UNSUPPORTED = "unsupported"
    UNKNOWN = "unknown"


# The 14 categories the catalog and the capability levels use. Order is fixed for output.
CATEGORIES: tuple[str, ...] = (
    "text_generation", "structured_output", "json_mode", "function_calling", "tools",
    "vision", "image_input", "audio_input", "audio_output", "video_input", "streaming",
    "reasoning", "embeddings", "batch_processing", "file_input",
)
MODALITIES = frozenset({"text", "image", "audio", "video", "file"})

_MODEL_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:\-]{0,127}$")  # exact shape; no spaces, no control chars
_PROVIDER_ID = re.compile(r"^[a-z][a-z0-9_]{1,63}$")
_MAX_LIMIT = 10_000_000
_MAX_LIMITATIONS = 16


class ModelRecord(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    model_id: str
    provider_id: str
    vendor: str = Field(min_length=1, max_length=64)
    api_surface: str
    display_name: str = Field(min_length=1, max_length=100)
    model_family: str = Field(default="unknown", max_length=64)
    model_version: str = Field(default="unknown", max_length=64)
    capabilities: dict[str, CapabilityStatus]
    context_window: int | None = Field(default=None, ge=1, le=_MAX_LIMIT)
    input_token_limit: int | None = Field(default=None, ge=1, le=_MAX_LIMIT)
    output_token_limit: int | None = Field(default=None, ge=1, le=_MAX_LIMIT)
    supported_modalities: tuple[str, ...] = ()
    lifecycle_status: LifecycleStatus = LifecycleStatus.UNKNOWN
    verification_status: VerificationStatus = VerificationStatus.UNVERIFIED
    documentation_reference: str = Field(default="", max_length=300)
    limitations: tuple[str, ...] = Field(default=(), max_length=_MAX_LIMITATIONS)
    source: SourceKind = SourceKind.UNKNOWN

    @field_validator("model_id")
    @classmethod
    def _exact_model_id(cls, value: str) -> str:
        if not _MODEL_ID.fullmatch(value):
            raise ValueError("model_id has an invalid format")
        return value

    @field_validator("provider_id")
    @classmethod
    def _provider_shape(cls, value: str) -> str:
        if not _PROVIDER_ID.fullmatch(value):
            raise ValueError("provider_id has an invalid format")
        return value

    @field_validator("capabilities")
    @classmethod
    def _every_category_stated(cls, value: dict[str, CapabilityStatus]) -> dict[str, CapabilityStatus]:
        if set(value) != set(CATEGORIES):
            raise ValueError("capabilities must state every category, and only those")
        for status in value.values():
            if status is not CapabilityStatus.UNKNOWN and not isinstance(status, CapabilityStatus):
                raise ValueError("capability status is not allowed")
        return value

    @field_validator("supported_modalities")
    @classmethod
    def _modalities_known(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        if len(set(value)) != len(value) or not set(value) <= MODALITIES:
            raise ValueError("supported_modalities contains an unknown or repeated value")
        return value

    @model_validator(mode="after")
    def _facts_need_sources(self) -> ModelRecord:
        if self.api_surface not in pm.MATRIX:
            raise ValueError("api_surface is not a known API surface")
        has_limit = any(v is not None for v in (self.context_window, self.input_token_limit,
                                                 self.output_token_limit))
        claims_support = any(v is CapabilityStatus.DOCUMENTED_ONLY for v in self.capabilities.values())
        cites = bool(self.documentation_reference.strip())
        operator = self.source is SourceKind.OPERATOR_CONFIGURATION
        if (has_limit or claims_support) and not cites and not operator:
            raise ValueError("limits and documented capabilities need a documentation reference")
        if claims_support and self.source is not SourceKind.OFFICIAL_DOCUMENTATION:
            raise ValueError("documented capabilities need an official documentation source")
        if operator and any(v is not CapabilityStatus.UNKNOWN for v in self.capabilities.values()):
            raise ValueError("operator-declared models cannot state capabilities")
        if self.verification_status is VerificationStatus.DOCUMENTED and not cites:
            raise ValueError("documented verification status needs a documentation reference")
        return self

    @property
    def confidence(self) -> str:
        return {
            SourceKind.OFFICIAL_DOCUMENTATION: "documented",
            SourceKind.OPERATOR_CONFIGURATION: "operator_declared",
            SourceKind.UNKNOWN: "unknown",
        }[self.source]


def _key(provider_id: str, model_id: str) -> tuple[str, str]:
    return (provider_id, model_id)


class ModelCatalogReader:
    """Read-only view. It has no write methods, so holding one cannot change the catalog."""

    def __init__(self, catalog: ModelCatalog) -> None:
        self._catalog = catalog

    def get_model(self, provider_id: str, model_id: str) -> ModelRecord:
        return self._catalog.get_model(provider_id, model_id)

    def list_models(self, provider_id: str | None = None, *, active_only: bool = False) -> tuple[ModelRecord, ...]:
        return self._catalog.list_models(provider_id, active_only=active_only)

    def validate_model(self, record: object) -> tuple[str, ...]:
        return self._catalog.validate_model(record)

    @property
    def version(self) -> int:
        return self._catalog.version


class ModelCatalog:
    """The writable catalog. Versioned. Freezing it makes every later write fail."""

    def __init__(self, records: Iterable[ModelRecord] = ()) -> None:
        self._lock = threading.Lock()
        self._records: dict[tuple[str, str], ModelRecord] = {}
        self._version = 0
        self._frozen = False
        self._log: list[tuple[int, str, str, str]] = []  # (version, action, provider_id, model_id)
        for record in records:
            self.register_model(record)

    # ------------------------------------------------------------ validation (pure)
    def validate_model(self, record: object) -> tuple[str, ...]:
        """Problems with a candidate record, by field name. Empty means valid. Never echoes values."""
        if isinstance(record, ModelRecord):
            return ()
        if not isinstance(record, dict):
            return ("record must be a ModelRecord",)
        try:
            ModelRecord.model_validate(record)
        except ValidationError as exc:
            names = sorted({str(err["loc"][0]) for err in exc.errors() if err.get("loc")})
            return tuple(names) or ("record",)
        return ()

    # ------------------------------------------------------------ writes
    def register_model(self, record: ModelRecord) -> None:
        if not isinstance(record, ModelRecord):
            raise CatalogError("record must be a ModelRecord")
        with self._lock:
            self._refuse_if_frozen()
            key = _key(record.provider_id, record.model_id)
            if key in self._records:
                raise CatalogError("this model identity is already registered")
            self._records[key] = record
            self._version += 1
            self._log.append((self._version, "register_model", record.provider_id, record.model_id))

    def deactivate_model(self, provider_id: str, model_id: str, *, authorized: bool, reason: str) -> None:
        """Mark a model removed. Requires authorized is True. Removal is permanent for the identity."""
        if authorized is not True:
            raise CatalogError("deactivation requires explicit authorization")
        if not isinstance(reason, str) or not reason.strip() or len(reason) > 200:
            raise CatalogError("deactivation requires a reason of 1 to 200 characters")
        with self._lock:
            self._refuse_if_frozen()
            key = _key(provider_id, model_id)
            current = self._records.get(key)
            if current is None:
                raise CatalogError("unknown model")
            if current.lifecycle_status is LifecycleStatus.REMOVED:
                return  # idempotent: already removed
            self._records[key] = current.model_copy(update={"lifecycle_status": LifecycleStatus.REMOVED})
            self._version += 1
            self._log.append((self._version, "deactivate_model", provider_id, model_id))

    def freeze(self) -> None:
        with self._lock:
            self._frozen = True

    # ------------------------------------------------------------ reads
    def get_model(self, provider_id: str, model_id: str) -> ModelRecord:
        with self._lock:
            record = self._records.get(_key(provider_id, model_id))
        if record is None:
            raise CatalogError("unknown model")
        return record

    def list_models(self, provider_id: str | None = None, *, active_only: bool = False) -> tuple[ModelRecord, ...]:
        with self._lock:
            items = list(self._records.values())
        out = [
            r for r in items
            if (provider_id is None or r.provider_id == provider_id)
            and (not active_only or r.lifecycle_status is LifecycleStatus.ACTIVE)
        ]
        return tuple(sorted(out, key=lambda r: (r.provider_id, r.model_id)))

    def reader(self) -> ModelCatalogReader:
        return ModelCatalogReader(self)

    @property
    def version(self) -> int:
        with self._lock:
            return self._version

    @property
    def frozen(self) -> bool:
        with self._lock:
            return self._frozen

    @property
    def change_log(self) -> tuple[tuple[int, str, str, str], ...]:
        with self._lock:
            return tuple(self._log)

    def _refuse_if_frozen(self) -> None:
        if self._frozen:
            raise CatalogError("catalog is frozen; it cannot change while requests can run")


@dataclass(frozen=True)
class RejectedRecord:
    """Describes a refused candidate for reports. Field names only."""

    fields: tuple[str, ...]


def blank_capabilities(status: CapabilityStatus = CapabilityStatus.UNKNOWN) -> dict[str, CapabilityStatus]:
    return {category: status for category in CATEGORIES}


def build_model_record(**fields: object) -> ModelRecord:
    """Construct a ModelRecord. On refusal, raise CatalogError naming fields only, never values."""
    try:
        return ModelRecord.model_validate(fields)
    except ValidationError as exc:
        names = sorted({str(err["loc"][0]) for err in exc.errors() if err.get("loc")})
        raise CatalogError("invalid model record: " + (", ".join(names) or "record")) from None
