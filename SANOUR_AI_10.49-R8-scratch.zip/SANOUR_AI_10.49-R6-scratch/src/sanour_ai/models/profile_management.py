"""Model Profile management (Stage 10.35). Profiles are explicit, validated, and frozen before use.

- A profile is linked to one provider, one model in the catalog, and one API surface. Nothing else.
- Every profile is checked against the catalog and against the adapter it will run on. A profile
  that fails any check is refused before a request can use it.
- A profile may require a capability only if the adapter implements it AND the model does not state
  it unsupported. Verification status is "unverified" for every profile, because no runtime evidence
  exists. The type forbids any other value.
- The router receives the ModelProfile objects produced here. It still resolves one named alias.
  Nothing in this module chooses a model or a provider on a request's behalf.
- Reads and writes are separate. freeze() stops writes. model_profile() re-checks the catalog on
  every call, so a removed model cannot serve a request.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from sanour_ai.models.capabilities import (
    AllowlistConfigError,
    ModelCapabilities,
    ModelProfile,
    ProviderCapabilities,
)
from sanour_ai.models.capability_intelligence import CATEGORY_SOURCES
from sanour_ai.models.model_catalog import (
    CATEGORIES,
    CapabilityStatus,
    CatalogError,
    LifecycleStatus,
    ModelCatalog,
    ModelRecord,
)

_PROFILE_ID = r"^[a-z][a-z0-9_]{1,63}$"


class ProfileError(Exception):
    """Profile refusal. Messages are fixed; they never echo a rejected value."""


class RequestLimits(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    max_output_tokens: int = Field(gt=0, le=1_000_000)
    max_context_tokens: int = Field(gt=0, le=10_000_000)

    @model_validator(mode="after")
    def _output_not_above_context(self) -> RequestLimits:
        if self.max_output_tokens > self.max_context_tokens:
            raise ValueError("max_output_tokens must not exceed max_context_tokens")
        return self


class TimeoutPolicy(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    default_seconds: float = Field(gt=0, le=60.0)
    max_seconds: float = Field(gt=0, le=60.0)


class ProfileRecord(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    profile_id: str = Field(pattern=_PROFILE_ID)
    provider_id: str = Field(pattern=r"^[a-z][a-z0-9_]{1,63}$")
    model_id: str = Field(min_length=1, max_length=128)
    api_surface: str = Field(min_length=1, max_length=64)
    capability_requirements: tuple[str, ...] = ("text_generation",)
    accepted_reported_model_ids: frozenset[str] = frozenset()
    request_limits: RequestLimits
    timeout_policy: TimeoutPolicy
    enabled: bool = True
    verification_status: Literal["unverified"] = "unverified"

    @field_validator("capability_requirements")
    @classmethod
    def _known_and_unique(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        if len(set(value)) != len(value) or not set(value) <= set(CATEGORIES):
            raise ValueError("capability_requirements contains an unknown or repeated category")
        return value

    @field_validator("timeout_policy")
    @classmethod
    def _default_within_max(cls, value: TimeoutPolicy) -> TimeoutPolicy:
        if value.default_seconds > value.max_seconds:
            raise ValueError("default timeout is above the maximum")
        return value


@dataclass(frozen=True)
class ProviderBinding:
    """What a profile is checked against: the registered adapter's identity and declared caps."""

    provider_id: str
    surface: str
    capabilities: ProviderCapabilities


def _flag_for(category: str) -> str | None:
    return CATEGORY_SOURCES[category][1]


class ProfileRegistry:
    def __init__(self, catalog: ModelCatalog) -> None:
        self._catalog = catalog
        self._lock = threading.Lock()
        self._profiles: dict[str, ProfileRecord] = {}
        self._frozen = False
        self._version = 0
        self._log: list[tuple[int, str, str]] = []  # (version, action, profile_id)

    # ------------------------------------------------------------ checks (pure)
    def check_profile(self, record: ProfileRecord, binding: ProviderBinding) -> ModelRecord:
        """Raise ProfileError on the first failed rule. Returns the linked model on success."""
        if not isinstance(record, ProfileRecord):
            raise ProfileError("profile must be a ProfileRecord")
        if record.provider_id != binding.provider_id:
            raise ProfileError("profile provider does not match the adapter")
        if record.api_surface != binding.surface:
            raise ProfileError("profile API surface does not match the adapter")
        try:
            model = self._catalog.get_model(record.provider_id, record.model_id)
        except CatalogError:
            raise ProfileError("profile is not linked to a known model of this provider") from None
        if model.api_surface != record.api_surface:
            raise ProfileError("model API surface does not match the profile")
        if record.enabled and model.lifecycle_status not in (LifecycleStatus.ACTIVE, LifecycleStatus.UNKNOWN):
            raise ProfileError("model lifecycle does not allow an enabled profile")
        if "text_generation" not in record.capability_requirements:
            raise ProfileError("profile must require text_generation")
        for category in record.capability_requirements:
            flag = _flag_for(category)
            if flag is None:
                raise ProfileError("capability has no adapter implementation: " + category)
            if not bool(getattr(binding.capabilities, flag)):
                raise ProfileError("adapter does not implement: " + category)
            if model.capabilities[category] is CapabilityStatus.UNSUPPORTED:
                raise ProfileError("model does not support: " + category)
        if model.output_token_limit is not None and record.request_limits.max_output_tokens > model.output_token_limit:
            raise ProfileError("request output limit exceeds the documented model limit")
        if model.context_window is not None and record.request_limits.max_context_tokens > model.context_window:
            raise ProfileError("request context limit exceeds the documented model limit")
        return model

    def _to_model_profile(self, record: ProfileRecord) -> ModelProfile:
        flags = {_flag_for(c): True for c in record.capability_requirements}
        caps = ModelCapabilities(
            **flags,
            max_context_tokens=record.request_limits.max_context_tokens,
            max_output_tokens=record.request_limits.max_output_tokens,
        )
        try:
            return ModelProfile(
                alias=record.profile_id,
                provider=record.provider_id,
                model_id=record.model_id,
                capabilities=caps,
                runs_locally=False,
                accepted_reported_model_ids=record.accepted_reported_model_ids,
                api_surface=record.api_surface,
            )
        except AllowlistConfigError:
            raise ProfileError("accepted reported model ids are invalid") from None

    # ------------------------------------------------------------ writes
    def register_profile(self, record: ProfileRecord, binding: ProviderBinding) -> None:
        with self._lock:
            self._refuse_if_frozen()
        self.check_profile(record, binding)
        self._to_model_profile(record)  # proves the allowlist and limits form a valid ModelProfile
        with self._lock:
            self._refuse_if_frozen()
            if record.profile_id in self._profiles:
                raise ProfileError("profile id is already registered")
            self._profiles[record.profile_id] = record
            self._version += 1
            self._log.append((self._version, "register_profile", record.profile_id))

    def deactivate_profile(self, profile_id: str, *, authorized: bool, reason: str) -> None:
        if authorized is not True:
            raise ProfileError("deactivation requires explicit authorization")
        if not isinstance(reason, str) or not reason.strip() or len(reason) > 200:
            raise ProfileError("deactivation requires a reason of 1 to 200 characters")
        with self._lock:
            self._refuse_if_frozen()
            current = self._profiles.get(profile_id)
            if current is None:
                raise ProfileError("unknown profile")
            if not current.enabled:
                return
            self._profiles[profile_id] = current.model_copy(update={"enabled": False})
            self._version += 1
            self._log.append((self._version, "deactivate_profile", profile_id))

    def freeze(self) -> None:
        with self._lock:
            self._frozen = True

    def _refuse_if_frozen(self) -> None:
        if self._frozen:
            raise ProfileError("profile registry is frozen; it cannot change while requests can run")

    # ------------------------------------------------------------ reads
    def get_profile(self, profile_id: str) -> ProfileRecord:
        with self._lock:
            record = self._profiles.get(profile_id)
        if record is None:
            raise ProfileError("unknown profile")
        return record

    def list_profiles(self, *, enabled_only: bool = False) -> tuple[ProfileRecord, ...]:
        with self._lock:
            items = list(self._profiles.values())
        return tuple(sorted((p for p in items if p.enabled or not enabled_only), key=lambda p: p.profile_id))

    def validate_profile(self, record: object, binding: ProviderBinding) -> tuple[str, ...]:
        """Problems as fixed messages. Empty means the profile passes every check now."""
        try:
            self.check_profile(record, binding)  # type: ignore[arg-type]
            self._to_model_profile(record)  # type: ignore[arg-type]
        except ProfileError as exc:
            return (str(exc),)
        except (TypeError, AttributeError):
            return ("profile must be a ProfileRecord",)
        return ()

    def model_profile(self, profile_id: str, binding: ProviderBinding) -> ModelProfile:
        """The router-facing profile. Re-checks the catalog now, so a removed model cannot serve."""
        record = self.get_profile(profile_id)
        if not record.enabled:
            raise ProfileError("profile is disabled")
        self.check_profile(record, binding)
        return self._to_model_profile(record)

    @property
    def version(self) -> int:
        with self._lock:
            return self._version

    @property
    def change_log(self) -> tuple[tuple[int, str, str], ...]:
        with self._lock:
            return tuple(self._log)
