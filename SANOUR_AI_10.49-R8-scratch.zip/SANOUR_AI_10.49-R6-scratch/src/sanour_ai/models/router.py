"""Explicit profile resolution (Stage 10.36). The router resolves the one profile a request names.

- There is no automatic selection of any kind. No first eligible profile, no nearest model, no
  default, no substitute, no fallback, no retry. `select()` was removed in Stage 10.36.
- A request is refused, never redirected, when its alias is unknown, disabled, or unsuitable for
  the request's limits and required capabilities. Every refusal uses the same public error and the
  same public message, so a caller cannot tell an unknown alias from a disabled one.
- The internal reason is kept on RoutingRefusal for audit only. It is never sent to the caller.
- The result depends only on the alias and the profile it names, not on registration order.
"""

from __future__ import annotations

import math
from collections.abc import Iterable

from sanour_ai.errors import ErrorCode, SanourError
from sanour_ai.models.capabilities import ModelProfile, missing_flags
from sanour_ai.models.requests import SanourRequest

PUBLIC_REFUSAL_MESSAGE = "the requested model cannot handle this request"
REASON_UNKNOWN = "unknown_profile"
REASON_DISABLED = "disabled_profile"
REASON_UNSUITABLE = "unsuitable_profile"
REASON_MISSING = "missing_profile"


class RoutingRefusal(SanourError):
    """A refusal to route. `reason` is internal and fixed. Callers only ever see the public error."""

    def __init__(self, reason: str) -> None:
        super().__init__(ErrorCode.NO_ELIGIBLE_MODEL, PUBLIC_REFUSAL_MESSAGE)
        self.reason = reason


def estimate_tokens(text: str) -> int:
    """Rough estimate of about 4 characters per token. Not a real tokenizer."""
    return math.ceil(len(text) / 4)


def _fits(profile: ModelProfile, request: SanourRequest, needed_tokens: int) -> bool:
    caps = profile.capabilities
    if not caps.text_generation:
        return False
    if caps.max_output_tokens < request.max_output_tokens:
        return False
    if caps.max_context_tokens < needed_tokens:
        return False
    return profile.runs_locally or not request.offline_only


def _has_required(profile: ModelProfile, required: tuple[str, ...]) -> bool:
    """True when the profile supports every requested capability. Empty means no requirement."""
    return not missing_flags(profile.capabilities, required)


class DeterministicRouter:
    def __init__(self, profiles: Iterable[ModelProfile], disabled_aliases: Iterable[str] = ()) -> None:
        ordered = list(profiles)
        aliases = [profile.alias for profile in ordered]
        if len(aliases) != len(set(aliases)):
            raise ValueError("duplicate model aliases in router configuration")
        self._by_alias = {profile.alias: profile for profile in ordered}
        self._disabled = frozenset(disabled_aliases)

    @property
    def profiles(self) -> tuple[ModelProfile, ...]:
        return tuple(sorted(self._by_alias.values(), key=lambda p: p.alias))

    def resolve(self, request: SanourRequest) -> ModelProfile:
        """Return exactly the profile named by request.profile_alias, or refuse. Never substitutes."""
        alias = request.profile_alias
        if not isinstance(alias, str) or not alias:
            raise RoutingRefusal(REASON_MISSING)
        if alias in self._disabled:
            raise RoutingRefusal(REASON_DISABLED)
        profile = self._by_alias.get(alias)
        if profile is None:
            raise RoutingRefusal(REASON_UNKNOWN)
        needed = estimate_tokens(request.prompt) + request.max_output_tokens
        if not (_fits(profile, request, needed) and _has_required(profile, request.required_capabilities)):
            raise RoutingRefusal(REASON_UNSUITABLE)
        return profile
