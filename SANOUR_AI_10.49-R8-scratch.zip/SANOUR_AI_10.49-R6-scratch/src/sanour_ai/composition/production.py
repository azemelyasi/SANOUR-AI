"""Production composition root (Stage 10.2, consolidated in Stage 10.33-R1). Opt-in only.

- The single production entry point is composition.runtime.Runtime.build(). It calls
  build_core_and_registry() below, which is the only function that assembles the production core.
- build_production_core() is kept for existing callers. It runs the same function and returns only
  the core. New code should use Runtime.build().
- Configuration is read and validated by config.governance. This module only wires objects, and it
  accepts only a RuntimeConfig that governance created.
- Nothing is enabled by default. SANOUR_PROVIDER must be set to exactly "openai".
- No mock, no fallback, no second provider, no automatic model choice.
- Building the core sends no network request. The first request happens only in handle().
- Every configuration error names the setting, never its value.
- If assembly fails after the adapter was created, the adapter is closed before the error is raised.
"""

from __future__ import annotations

import importlib.util
from collections.abc import Callable, Mapping

from sanour_ai.config.governance import (  # re-exported: the names other modules use
    ENV_OPENAI_MAX_CONTEXT_TOKENS,
    ENV_OPENAI_MAX_OUTPUT_TOKENS,
    ENV_OPENAI_API_KEY,
    ENV_OPENAI_MODEL_ID,
    ENV_PROVIDER,
    OPENAI_ALIAS,
    RuntimeConfig,
    _model_id,
    _positive_int,
    _required,
    load_offline_test_config,
    load_runtime_config,
)
from sanour_ai.config.settings import ENV_PROVIDER_CONCURRENCY, ConfigError
from sanour_ai.core.sanour_core import SanourCore
from sanour_ai.models import production_gate
from sanour_ai.models.base import ModelProvider
from sanour_ai.models.capabilities import (
    CAPABILITY_FLAGS,
    ModelCapabilities,
    ModelProfile,
    ProviderCapabilities,
    unsupported_flags,
)
from sanour_ai.models.gateway import ModelGateway
from sanour_ai.providers.offline_contract import OfflineTestProvider, check_test_provider
from sanour_ai.models.router import DeterministicRouter
from sanour_ai.observability.audit import AuditLogger
from sanour_ai.models.model_catalog import CatalogError, ModelCatalog, blank_capabilities, build_model_record
from sanour_ai.models.profile_management import (
    ProfileError,
    ProfileRecord,
    ProfileRegistry,
    ProviderBinding,
    RequestLimits,
    TimeoutPolicy,
)
from sanour_ai.models.requests import DEFAULT_TIMEOUT_SECONDS, MAX_TIMEOUT_SECONDS
from sanour_ai.providers.contract import contract_violations, identity_of
from sanour_ai.providers.openai_provider import OPENAI_PROVIDER_NAME, OpenAIProvider

from sanour_ai.providers.registry import ProviderRegistry, RegistryError

__all__ = [
    "ENV_OPENAI_MAX_CONTEXT_TOKENS",
    "ENV_OPENAI_MAX_OUTPUT_TOKENS",
    "ENV_OPENAI_MODEL_ID",
    "ENV_PROVIDER",
    "ENV_PROVIDER_CONCURRENCY",
    "OPENAI_ALIAS",
    "build_production_core",
    "load_offline_test_config",
    "core_from_config",
    "flags_of",
]


def flags_of(caps: ModelCapabilities) -> dict[str, bool]:
    """Boolean capability flags of a profile, by name."""
    return {flag: bool(getattr(caps, flag)) for flag in CAPABILITY_FLAGS}


def _sdk_present() -> bool:
    return (
        importlib.util.find_spec("openai") is not None
        and importlib.util.find_spec("httpx2") is not None
    )


def _assemble(
    profile: ModelProfile,
    providers: Mapping[str, ModelProvider],
    max_concurrent_calls: int,
    provider_limits: Mapping[str, int] | None = None,
    provider_states: Callable[[], Mapping[str, str]] | None = None,
    *,
    audit: AuditLogger | None = None,
    required_audit: bool = True,
    governance: object | None = None,
) -> SanourCore:
    """Wire the router, gateway, and core around one profile. Shared by production and tests."""
    if profile.provider not in providers:
        # Fail closed at construction: a profile must point at a registered provider.
        raise ConfigError("the configured model profile references an unregistered provider")
    provider_caps = getattr(providers[profile.provider], "capabilities", None)
    if not isinstance(provider_caps, ProviderCapabilities) or unsupported_flags(
        profile.capabilities, provider_caps
    ):
        raise ConfigError("the configured model declares capabilities its provider does not offer")
    return SanourCore(
        router=DeterministicRouter([profile]),
        gateway=ModelGateway(
            providers,
            max_concurrent_calls=max_concurrent_calls,
            provider_limits=provider_limits,
        ),
        audit=audit or AuditLogger(),
        provider_states=provider_states,
        required_audit=required_audit,
        governance=governance,
    )


def core_from_config(config: RuntimeConfig) -> SanourCore:
    core, _registry = build_core_and_registry(config)
    return core


def _release_unready(adapter: object) -> None:
    """Close an adapter that never became part of a ready core. Errors are dropped, never shown."""
    close = getattr(adapter, "close", None)
    if callable(close):
        try:
            close()
        except Exception:
            pass


def _governed_profile(config: RuntimeConfig) -> ModelProfile:
    """The one production profile, built through the catalog and checked against the adapter.

    The operator's model id becomes a catalog record marked operator-declared and unverified. The
    profile is validated, both registries are frozen, and only then is the router-facing profile
    returned. Any refusal becomes a ConfigError that names no value.
    """
    binding = ProviderBinding(
        provider_id=OPENAI_PROVIDER_NAME,
        surface=OpenAIProvider.surface,
        capabilities=OpenAIProvider.capabilities,
    )
    try:
        catalog = ModelCatalog()
        catalog.register_model(build_model_record(
            model_id=config.model_id,
            provider_id=OPENAI_PROVIDER_NAME,
            vendor=OpenAIProvider.vendor,
            api_surface=OpenAIProvider.surface,
            display_name=config.model_id,
            capabilities=blank_capabilities(),
            lifecycle_status="unknown",
            verification_status="unverified",
            source="operator_configuration",
        ))
        profiles = ProfileRegistry(catalog)
        profiles.register_profile(
            ProfileRecord(
                profile_id=OPENAI_ALIAS,
                provider_id=OPENAI_PROVIDER_NAME,
                model_id=config.model_id,
                api_surface=OpenAIProvider.surface,
                capability_requirements=("text_generation",),
                request_limits=RequestLimits(
                    max_output_tokens=config.max_output_tokens,
                    max_context_tokens=config.max_context_tokens,
                ),
                timeout_policy=TimeoutPolicy(default_seconds=DEFAULT_TIMEOUT_SECONDS,
                                             max_seconds=MAX_TIMEOUT_SECONDS),
            ),
            binding,
        )
        catalog.freeze()
        profiles.freeze()
        return profiles.model_profile(OPENAI_ALIAS, binding)
    except (CatalogError, ProfileError):
        raise ConfigError("the configured model profile is not allowed") from None


def _sdk_check_for_gated_path() -> None:
    if not _sdk_present():
        raise ConfigError("the OpenAI SDK is not installed; the openai extra is required")


def _default_test_provider() -> ModelProvider:
    """The only provider a test factory builds for itself. Tests may patch this seam; it never
    looks at the environment, the SDK, or a credential."""
    return OfflineTestProvider()


def _build(config: RuntimeConfig, *, gated: bool, audit: AuditLogger | None = None,
           provider: ModelProvider | None = None,
           governance: object | None = None) -> tuple[SanourCore, ProviderRegistry]:
    """Assemble the one provider-backed core and its registry from a validated configuration.

    gated=True (production): the SDK must be present, the gate must pass, and only then is the real
    OpenAI adapter constructed from the configuration's key. Injection is refused.
    gated=False (test factories): the real adapter is never constructed. The caller's fake provider
    or the offline default is used, and the configuration's key is never touched.

    Either returns a complete core or raises ConfigError. On failure the adapter is closed.
    """
    if not isinstance(config, RuntimeConfig):
        raise ConfigError("runtime configuration must come from the validated loader")
    if gated:
        if provider is not None:
            raise ConfigError("production construction does not accept an injected provider")
        _sdk_check_for_gated_path()

    # The production adapter must declare its full identity and follow the shared contract.
    if contract_violations(OpenAIProvider) or identity_of(OpenAIProvider).provider_id != OPENAI_PROVIDER_NAME:
        raise ConfigError("the configured provider does not follow the provider contract")
    profile = _governed_profile(config)
    if gated:
        # Fail closed before any adapter exists. The gate reads reviewed code, never the environment.
        try:
            production_gate.check(
                OPENAI_PROVIDER_NAME, OpenAIProvider.surface, OpenAIProvider.capabilities,
                ("text_generation",), config.model_id,
            )
        except production_gate.ProductionGateRefused:
            raise ConfigError("production model verification gate refused this runtime") from None
        adapter = OpenAIProvider(config.api_key)
    else:
        adapter = provider if provider is not None else _default_test_provider()
        check_test_provider(adapter)
    # Explicit registration, initialization, then a capability check. No implicit registration.
    # xAI Responses is never registered here.
    registry = ProviderRegistry()
    try:
        registry.register(OPENAI_PROVIDER_NAME, vendor="openai", surface="openai_responses", adapter=adapter)
        registry.initialize(OPENAI_PROVIDER_NAME)
        registry.validate_profile(OPENAI_PROVIDER_NAME, flags_of(profile.capabilities))
    except RegistryError:
        _release_unready(adapter)
        raise ConfigError("the configured provider or model profile is not allowed") from None
    try:
        core = _assemble(
            profile,
            registry.ready_providers(),
            config.max_concurrent_provider_calls,
            dict(config.provider_limits),
            provider_states=registry.states,
            audit=audit,
            required_audit=gated,
            governance=governance,
        )
    except ValueError:
        _release_unready(adapter)
        raise ConfigError(
            f"{ENV_PROVIDER_CONCURRENCY} names an unknown provider or a limit above the global cap"
        ) from None
    except BaseException:
        _release_unready(adapter)
        raise
    return core, registry


def build_core_and_registry(config: RuntimeConfig, *, audit: AuditLogger | None = None,
                            governance: object | None = None) -> tuple[SanourCore, ProviderRegistry]:
    """Production path. Gated: refuses unless the production model verification gate passes."""
    return _build(config, gated=True, audit=audit, governance=governance)


def core_from_config(config: RuntimeConfig) -> SanourCore:
    core, _registry = build_core_and_registry(config)
    return core


def build_test_core_and_registry(
    config: RuntimeConfig, audit: AuditLogger | None = None, *, provider: ModelProvider | None = None,
    governance: object | None = None,
) -> tuple[SanourCore, ProviderRegistry]:
    """Test factory. Never constructs a real adapter and never reads the production key. Uses the
    injected fake provider, or the offline default. Not reachable from configuration."""
    return _build(config, gated=False, audit=audit, provider=provider, governance=governance)


def core_from_config_for_tests(config: RuntimeConfig) -> SanourCore:
    core, _registry = build_test_core_and_registry(config)
    return core


def build_test_core(environ: Mapping[str, str] | None = None, *,
                    provider: ModelProvider | None = None) -> SanourCore:
    """Test-only counterpart of build_production_core(). Offline fake only; the key is never used."""
    core, _registry = build_test_core_and_registry(load_offline_test_config(environ), provider=provider)
    return core


def build_production_core(environ: Mapping[str, str] | None = None) -> SanourCore:
    """Compatibility entry: the same build path as Runtime.build(), returning only the core."""
    return core_from_config(load_runtime_config(environ))
