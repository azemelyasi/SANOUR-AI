"""Runtime governance and lifecycle (Stage 10.33, hardened in 10.33-R1, lifecycle completed in 10.39).

- Runtime.build() is the single production entry point. It validates configuration, assembles the
  core and registry, and only then becomes READY. Any failure raises ConfigError and produces no
  Runtime object. Resources created during a failed assembly are released first.
- Settings are never applied to a running Runtime. check_reload() reports changes and applies nothing.
- Lifecycle (10.39). The only legal moves are:
      READY -> DRAINING   shutdown() starts. New requests are refused from here on.
      DRAINING -> SHUTDOWN   every provider is closed or failed, so no worker is live.
      READY -> SHUTDOWN is not allowed directly, so a shutdown always passes through DRAINING.
  SHUTDOWN is terminal. A shutdown() call after it changes nothing and closes nothing.
- A provider with a live worker is never closed under that worker. The runtime stays DRAINING until
  a later shutdown() call finds every provider idle.
- handle() refuses requests that arrive when the state is not READY. The refusal never reaches the
  core, the router, or the audit. A request admitted just before shutdown() is still counted by the
  gateway, which waits for its real worker to end.
- stats() returns counters and states only. It never includes request content, identifiers, keys, or
  provider text.
"""

from __future__ import annotations

import dataclasses
import threading
import uuid
from collections.abc import Mapping
from dataclasses import dataclass
from enum import StrEnum
from typing import Any

from sanour_ai.composition.production import build_core_and_registry, build_test_core_and_registry
from sanour_ai.observability.audit import AuditLogger
from sanour_ai.config.governance import RuntimeConfig, load_offline_test_config, load_runtime_config
from sanour_ai.config.settings import ConfigError
from sanour_ai.core.sanour_core import SanourCore
from sanour_ai.core.usage_accounting import UsageAccountingService
from sanour_ai.ledger.repository import LedgerConflictError, LedgerStorageError
from sanour_ai.errors import ErrorCode, FailureKind, SanourError
from sanour_ai.models.responses import SanourResponse
from sanour_ai.providers.registry import ProviderRegistry

REFUSED_MESSAGE = "runtime is shut down"
# Top-level keys of Runtime.stats(). Anything else is a leak and is refused by the test suite.
STATS_KEYS = frozenset({"state", "refused_requests", "providers", "provider_close_failures",
                        "settlement", "coordinator", "audit", "mode"})


class RuntimeState(StrEnum):
    READY = "ready"
    DRAINING = "draining"
    SHUTDOWN = "shutdown"


RUNTIME_TRANSITIONS: dict[RuntimeState, frozenset[RuntimeState]] = {
    RuntimeState.READY: frozenset({RuntimeState.DRAINING}),
    RuntimeState.DRAINING: frozenset({RuntimeState.SHUTDOWN}),
    RuntimeState.SHUTDOWN: frozenset(),
}
_SETTLED = frozenset({"closed", "failed"})


class RuntimeTransitionError(Exception):
    """A runtime state move that the lifecycle does not allow. Fixed message."""


@dataclass(frozen=True)
class ReloadReport:
    changed: tuple[str, ...]  # group.name only, never values
    restart_required: bool
    applied: bool  # always False: a running Runtime never changes its settings


def _ledger(path: str | None):
    """Test and development only: a missing path means in-memory accounting (never production)."""
    if path is None:
        return None
    from sanour_ai.ledger.sqlite_repository import SqliteUsageRepository
    return SqliteUsageRepository(path)


def _open_production_governance(path: str, config, audit):
    """Stage 10.49: the governance store lives in the same durable file, in its own tables. Fail closed."""
    from sanour_ai.composition.production import OPENAI_ALIAS
    from sanour_ai.governance.admission import AdmissionController
    from sanour_ai.governance.store import GovernanceStorageError, GovernanceStore
    from sanour_ai.governance.types import Bounds
    try:
        store = GovernanceStore(path)
    except GovernanceStorageError:
        raise ConfigError("the durable governance storage is unavailable") from None
    bounds = {OPENAI_ALIAS: Bounds(max_input_tokens=config.max_context_tokens,
                                   max_output_tokens=config.max_output_tokens)}
    return AdmissionController(store, audit=audit, bounds=bounds, required_audit=True)


def _open_production_ledger(path: str | None):
    """Production storage policy (Stage 10.48-R1). Fail closed: no path, a bad path, or a storage that
    cannot be opened all refuse the runtime. There is no fallback to memory and no automatic choice."""
    if path is None:
        raise ConfigError("a durable usage ledger path is required in production")
    from sanour_ai.ledger.repository import LedgerStorageError
    from sanour_ai.ledger.sqlite_repository import SqliteUsageRepository
    try:
        return SqliteUsageRepository(path)
    except LedgerStorageError:
        raise ConfigError("the durable usage ledger is unavailable") from None


class Runtime:
    def __init__(self, config: RuntimeConfig, core: SanourCore, registry: ProviderRegistry,
                 *, mode: str = "production", usage_repository: Any = None,
                 governance: Any = None) -> None:
        self._governance = governance  # Stage 10.49: AdmissionController (sweep + close) or None
        self._mode = mode  # "production" (gated) or "test" (fake providers, gate skipped)
        self._config = config
        self._core = core
        self._registry = registry
        self._state = RuntimeState.READY
        self._refused = 0
        # Stage 10.47/10.48: accepted completions only. Durable when a repository is supplied.
        self._usage = UsageAccountingService(repository=usage_repository)
        self._stopped = threading.Event()  # set exactly when the state becomes SHUTDOWN
        self._lock = threading.Lock()
        # Stage 10.48-R1: admitted handle() calls not yet finished, including their ledger write. The
        # runtime completes SHUTDOWN and closes the ledger only when this is zero. Admission is refused
        # once the state leaves READY, so no new write can start after that point.
        self._admitted = 0
        self._providers_settled = False
        self._ledger_closed = False
        self._ledger_close_failures = 0
        # Event-driven settlement (Stage 10.40): no polling. The gateway reports each provider's close
        # outcome; the registry reports when everything is settled; the runtime completes DRAINING.
        core.shutdown_target().add_settlement_observer(registry.on_provider_settled)
        registry.add_settlement_listener(self._on_settled)

    @classmethod
    def build(cls, environ: Mapping[str, str] | None = None, *,
              usage_ledger_path: str | None = None) -> Runtime:
        """The production entry point. Refuses unless the production model verification gate passes.
        usage_ledger_path: required. A durable SQLite file for the usage ledger. Missing, unusable or
        unopenable storage refuses the runtime (fail closed). Nothing falls back to memory."""
        config = load_runtime_config(environ)
        # The ledger and the governance store are opened before any adapter exists. Missing or unusable
        # storage refuses the runtime. Neither one falls back to memory.
        ledger = _open_production_ledger(usage_ledger_path)
        audit = AuditLogger()
        try:
            governance = _open_production_governance(usage_ledger_path, config, audit)
        except BaseException:
            ledger.close()
            raise
        try:
            core, registry = build_core_and_registry(config, audit=audit, governance=governance)
            return cls(config, core, registry, mode="production", usage_repository=ledger, governance=governance)
        except BaseException:
            ledger.close()
            governance.close()
            raise

    @classmethod
    def build_for_tests(cls, environ: Mapping[str, str] | None = None,
                        audit: AuditLogger | None = None, *,
                        provider: Any = None, usage_ledger_path: str | None = None,
                        governance: Any = None) -> Runtime:
        """Test entry point. Offline fake only: never a real adapter, never the production key, and
        the environment's provider setting is ignored. Injected fakes are passed as `provider`."""
        config = load_offline_test_config(environ)
        core, registry = build_test_core_and_registry(config, audit=audit, provider=provider,
                                                      governance=governance)
        return cls(config, core, registry, mode="test", usage_repository=_ledger(usage_ledger_path),
                   governance=governance)

    @property
    def mode(self) -> str:
        return self._mode

    # ------------------------------------------------------------------ state
    @property
    def state(self) -> RuntimeState:
        with self._lock:
            return self._state

    def _on_settled(self) -> None:
        """Registry listener. Runs when every provider is closed or failed. Completes DRAINING once no
        admitted request is still finishing (its ledger write included)."""
        with self._lock:
            self._providers_settled = True
            self._finish_shutdown_if_ready()

    def _finish_shutdown_if_ready(self) -> None:
        """Caller holds the lock. SHUTDOWN needs: providers settled and no admitted request still running.
        The ledger closes in that same step, so no write can be in progress when it closes."""
        if self._state is RuntimeState.DRAINING and self._providers_settled and self._admitted == 0:
            self._move(RuntimeState.SHUTDOWN)
            self._close_ledger_locked()
            self._stopped.set()

    def _close_ledger_locked(self) -> None:
        """Close the ledger once. A close error is counted and audited, never raised past shutdown, and it
        does not stop anything else: providers are already settled at this point. Outstanding budget or quota
        reservations are settled first, conservatively (Stage 10.49)."""
        if self._ledger_closed:
            return
        self._ledger_closed = True
        if self._governance is not None:
            self._governance.sweep(everything=True)
            self._governance.close()
        try:
            self._usage.close()
        except Exception:
            self._ledger_close_failures += 1
            self._core.audit.emit("runtime.ledger_close_failed")

    def wait_stopped(self, timeout: float | None = None) -> bool:
        """Block until the runtime reaches SHUTDOWN, or until timeout. True when it has stopped."""
        return self._stopped.wait(timeout)

    def _move(self, to: RuntimeState) -> None:
        """Every state write goes through here. Caller holds the lock."""
        if to not in RUNTIME_TRANSITIONS[self._state]:
            raise RuntimeTransitionError("runtime state transition is not allowed")
        self._state = to

    def describe(self) -> dict[str, Any]:
        view: dict[str, Any] = self._config.describe()
        view["runtime"] = {"state": self.state.value, "fingerprint": self._config.fingerprint()}
        return view

    def check_reload(self, environ: Mapping[str, str] | None = None) -> ReloadReport:
        """Validate a candidate configuration without applying it. Invalid candidates raise ConfigError."""
        loader = load_offline_test_config if self._mode == "test" else load_runtime_config
        candidate = loader(environ)
        changed = self._config.changed_fields(candidate)
        return ReloadReport(changed=changed, restart_required=bool(changed), applied=False)

    # ------------------------------------------------------------------ requests
    def handle(self, raw: object) -> SanourResponse:
        with self._lock:
            accepting = self._state is RuntimeState.READY
            if not accepting:
                self._refused += 1
            else:
                self._admitted += 1
        if not accepting:
            request_id = uuid.uuid4().hex
            # Recorded as a fixed-field audit event. The outcome is a refusal whether or not the write works.
            self._core.audit.emit("runtime.request_refused", request_id=request_id, refusal="runtime_not_ready")
            return SanourResponse.failure(
                request_id=request_id,
                error=SanourError(
                    ErrorCode.PROVIDER_FAILED,
                    REFUSED_MESSAGE,
                    retryable=False,
                    internal_kind=FailureKind.GATEWAY_SHUT_DOWN,
                ),
                latency_ms=0,
            )
        # The lock is not held here, so shutdown() never waits for an active request.
        try:
            response, result = self._core.handle_with_result(raw)
            if result is not None:
                try:
                    self._usage.record(result)
                except (LedgerStorageError, LedgerConflictError):
                    # The response was already decided by the audit policy. The ledger failure is never
                    # reported as a successful record: it is counted in usage_summary()["health"].
                    pass
            return response
        finally:
            with self._lock:
                self._admitted -= 1
                self._finish_shutdown_if_ready()

    def close_usage_ledger(self) -> None:
        """Release the ledger's storage handle. Durable records stay durable and readable on restart.
        Idempotent. Normally the runtime closes it itself when shutdown completes."""
        self._usage.close()

    def usage_summary(self) -> dict[str, Any]:
        """Usage aggregated by provider, profile, model and day. Counts and integers only."""
        summary = self._usage.summary()
        with self._lock:
            summary["health"]["ledger_close_failures"] = self._ledger_close_failures
        return summary

    def usage_report(self, filters: Mapping[str, object] | None = None) -> dict[str, Any]:
        """Filtered usage report. Filters: provider, profile, model, period (UTC day), delivery, audit.
        Unknown filter keys or values are refused with ValueError and never reach storage."""
        return self._usage.report(filters)

    # ------------------------------------------------------------------ shutdown
    def shutdown(self, timeout: float = 5.0) -> dict[str, str]:
        """Shut down through the registry. Returns each provider's state afterwards.

        Idempotent. After SHUTDOWN it only reads the states. While a worker is still live the runtime
        stays DRAINING, and a later call finishes the job.
        """
        with self._lock:
            if self._state is RuntimeState.SHUTDOWN:
                return self._registry.states()
            if self._state is RuntimeState.READY:
                self._move(RuntimeState.DRAINING)
        states = self._registry.shutdown(self._core.shutdown_target(), timeout)
        if all(value in _SETTLED for value in states.values()):
            self._on_settled()  # normally already done by the listener; idempotent
        return states

    # ------------------------------------------------------------------ stats
    def core_stats(self) -> Any:
        return self._core.coordinator_stats()

    def stats(self) -> dict[str, Any]:
        """Counters and states only. Bounded, and free of request content and secrets."""
        with self._lock:
            state = self._state.value
            refused = self._refused
        return {
            "state": state,
            "refused_requests": refused,
            "providers": self._registry.states(),
            "provider_close_failures": self._core.gateway_stats().provider_close_failures,
            "settlement": self._core.settlement_stats(),
            "audit": self._core.audit_counters(),
            "mode": self._mode,
            "coordinator": dataclasses.asdict(self._core.coordinator_stats()),
        }
