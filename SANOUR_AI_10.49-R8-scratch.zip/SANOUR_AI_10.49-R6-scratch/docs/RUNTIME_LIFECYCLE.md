# Runtime lifecycle (Stage 10.39)

## States
- **READY**: accepts requests. Set by Runtime.build() only after every assembly step succeeded.
- **DRAINING**: shutdown() has started. New requests are refused. At least one provider worker may still run.
- **SHUTDOWN** (terminal): every provider is closed or failed. No worker is live.

Allowed moves: READY -> DRAINING, DRAINING -> SHUTDOWN. Nothing else. READY never jumps straight to SHUTDOWN.

## Who owns what
- **Runtime** owns the state and refuses requests when not READY. A refusal never reaches the core, router, or audit.
- **ProviderRegistry** owns per-provider states (registered, initializing, ready, closing, closed, failed).
  It closes idle providers only, once each.
- **ModelGateway** owns admission and live workers. After shutdown() it refuses new calls before any capacity is taken,
  and it closes a provider only when that provider has no admitted call. This is the authority for the race window
  between Runtime's fast-path check and the gateway's admission.
- **Adapters** own their own resources and release them in close(). They never see the lifecycle state.

## Rules tested
- No request is accepted once shutdown has started (Runtime fast path plus gateway admission check).
- An admitted request runs until its real worker ends. Its provider is not closed under it.
- A failed startup closes every adapter created so far. Unexpected errors still propagate.
- Repeated or concurrent shutdown() calls close each provider exactly once and return the same states.
- stats() returns state names and counters only. It contains no request content, identifiers, keys, or provider text.

## Event-driven settlement (Stage 10.40)
- When a worker ends, the gateway returns its capacity first, then (outside every lock) settles its provider if the
  gateway is shut down and the provider has no admitted call left. Cancelled-before-start calls do the same.
- Settlement claims the close once, closes outside the lock, records "closed" or "failed", and notifies observers
  (provider_id, outcome). The registry moves CLOSING to CLOSED or FAILED. When every provider is settled, the
  runtime moves DRAINING to SHUTDOWN and sets the stopped event. No polling is used.
- wait_stopped(timeout) blocks on that event and returns True once the runtime has stopped.
- provider_close_failures counts close() calls that raised. Only the exception type name is logged.

## Worker completion and settlement timeline (Stage 10.41 correction)
1. provider.generate() returns or raises. Admission counters (in_flight, provider in_flight, active_workers) drop.
2. The global and provider capacity semaphores are released.
3. The caller is released (finished event).
4. The worker thread's last statement: the per-provider unfinished-thread count drops and waiters are notified.
5. Only then can a settler close the provider. Settlement never runs on the worker thread.

Worker completion is therefore step 4, not step 1. Capacity is released at step 2, which is the last capacity-affecting
action, exactly as in the original design. Provider close runs in a settler thread, one per busy provider at most.
Settlement needs no polling: settlers and shutdown() wait on a condition variable notified by workers.
shutdown(timeout) returns only after any settlement that the timeout allows has finished.

## Settlement observability (Stage 10.42)
Per-provider phase: open, waiting (settler waits for its workers), closing (close() running), closed, failed.
Runtime.stats() adds `settlement`: active_settlers, providers_waiting_for_workers, providers_closing, phases.
Gateway counters add settler_threads_started, cancelled_before_start and provider_close_failures.
A close that never returns stays in phase "closing": the runtime stays DRAINING and wait_stopped(timeout) returns False.
Exactly one settler exists per busy provider; a blocked settler is never replaced.
All values are counts or fixed phase names. No request content, identifier, key, or provider text.

## BaseException-safe settlement (Stage 10.43)
Bookkeeping runs on every exit path of a close: the outcome is recorded (failed for a BaseException), the settler
leaves the running set, and observers are told exactly once. Only then is the BaseException re-raised. A settler
thread ends with SettlementAborted(type name), so its default error hook never prints exception text. Idle closes
re-raise the original exception to the caller, after every other provider has been settled.
Listeners are announced once per "all settled" episode.


## Ledger lifecycle (Stage 10.48-R1)
- Production: the durable ledger is opened in `Runtime.build()` before any adapter exists. Failure to open refuses the runtime.
- `handle()` counts an admitted request until its ledger write finishes.
- SHUTDOWN completes only when every provider is settled and no admitted request is still running. The ledger closes in that same step, so no write can be in progress when it closes.
- Shutdown is idempotent: the ledger closes once. A close error is counted and audited, and does not block provider settlement.
- No request is admitted once shutdown has started, so no write starts after shutdown.
