# Model Profile Guide

Stage 10.35. Code: `src/sanour_ai/models/profile_management.py`.

## What a profile is

A profile is a named, explicit way to call one model through one provider. A request names the
profile by alias. Nothing else chooses a model.

A `ProfileRecord` holds: profile_id, provider_id, model_id, api_surface, capability_requirements,
accepted_reported_model_ids, request_limits, timeout_policy, enabled, and verification_status.

## Registration checks

`register_profile` refuses a profile unless all of these hold:

1. The provider matches the adapter the profile will run on.
2. The API surface matches both the adapter and the linked model.
3. The model_id exists in the catalog under the same provider.
4. The model's lifecycle is `active` or `unknown`. Deprecated or removed models are refused for an
   enabled profile.
5. `text_generation` is among the requirements. Every requirement maps to a category with an
   adapter flag. The adapter must implement that flag. The model must not state it UNSUPPORTED.
6. Requested limits do not exceed documented model limits. Unknown limits are not checked and not
   invented.
7. The allowlist is valid: exact ids only, no wildcards, at most 8 entries.
8. `verification_status` is always `unverified`. The type rejects any other value.

## Using a profile

- `model_profile(profile_id, binding)` re-runs the catalog checks on every call. A removed model
  cannot serve a request, even if the profile was registered earlier.
- The router receives the resulting `ModelProfile` objects. It resolves one named alias and never
  substitutes another profile.
- A disabled profile is never returned.

## Identity at request time

Three identities are kept apart:

- `profile_id`: the alias the caller sends.
- `requested model_id`: the profile's model_id, which the adapter sends to the provider.
- `provider_reported_model_id`: what the provider says it used.

The gateway accepts the reported id only if it equals the requested id or appears exactly in the
profile's allowlist. Anything else, including an empty or missing id, fails closed as an invalid
response. The provider's id is never echoed back.

## Changing things

- Registries freeze before requests run. After that, registering or deactivating fails.
- Deactivation needs `authorized=True` and a reason.
- Changing a catalog record never rewrites an existing profile.
