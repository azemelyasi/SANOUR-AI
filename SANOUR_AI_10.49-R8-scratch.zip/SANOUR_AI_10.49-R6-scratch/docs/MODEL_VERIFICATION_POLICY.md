# Model Verification Policy

Stage 10.35. This policy decides what the word "verified" may mean in SANOUR AI.

## Three meanings, kept apart

| Level | Question it answers | Possible status values | Evidence required |
|---|---|---|---|
| Provider/API | Does the official API document this? | DOCUMENTED_ONLY, UNSUPPORTED, UNKNOWN | An official document, cited in `provider_matrix.py` |
| Adapter | Does this repository's adapter implement it? | IMPLEMENTED_UNVERIFIED, DOCUMENTED_ONLY, UNSUPPORTED, UNKNOWN | The adapter's declared capabilities |
| Runtime verified | Has a reviewed test proven it against the real behaviour? | VERIFIED, UNKNOWN, UNSUPPORTED | A `RuntimeEvidence` record with a test reference |

A documented capability is never reported as VERIFIED. An implemented capability is never reported
as VERIFIED. A fake transport proves only the adapter's own logic, not API compatibility.

## Current state

- No runtime evidence exists in this repository. Every category is therefore below VERIFIED at
  level 3.
- No model record may state VERIFIED or IMPLEMENTED_UNVERIFIED. The catalog's type rejects them.
- No profile may claim verified capabilities. `verification_status` is `unverified` by type.
- `production_ready()` returns nothing. A category becomes production-ready only when a
  RuntimeEvidence record names a test for it.

## What it takes to change the state

1. A reviewed test that calls the provider's real API for one capability, on one API surface, under
   operator control (not in this repository's default test run).
2. A `RuntimeEvidence` record that names that test.
3. A review that accepts the evidence.

No step may run automatically, and no step may use a real key in this repository.

## Unknown is a valid answer

If the documentation does not say, the status is UNKNOWN. Limits that no document gives stay `None`.
Nothing is inferred from a similar model, a similar provider, or a model name.
