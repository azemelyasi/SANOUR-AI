# Provider Conformance (Stage 10.37)

Suite: `tests/unit/test_stage1037_conformance.py`. Integration: `tests/unit/test_stage1037.py`.

## What the suite checks

Provider identity, API surface, model identity, deadline, request contract, response contract, size limit, no secret leak, no retry, no fallback, no model change, incomplete response, network error, shutdown, timeout, and a shared transport policy (redirects refused, environment proxies not used).

## Transport and clock

Fake transports and the real `time.monotonic` clock with short budgets. No vendor API is called, and no API key is read or sent.

## Skips (honest list)

- 58 tests are skipped because the `openai` and `httpx2` SDKs are not installed in this sandbox. They are all in the OpenAI provider unit tests (`tests/unit/test_openai_provider.py`, the SDK security, client validation, and behaviour classes) plus one OpenAI Production path integration test. They are not passed.
- 1 test skips the real-type check for `httpx2` for the same reason.
- 1 test is an explicit skip for OpenAI request-level conformance, which needs the SDK.

So the OpenAI adapter's SDK-level security checks are **Unverified in this run**. Skipped is not the same as passed.

Skipping does not enable a provider. xAI Responses stays disabled in Production.

## Integration coverage

The 35 integration tests cover valid request to fake provider, invalid alias, invalid identity, incompatible capability, full and incomplete responses, identity mismatch, rate limit, quota and billing, content block, invalid response, transport error, deadline before and during execution, capacity full, shutdown during a worker, close failure in one provider not stopping the others, and no retry or fallback on any error.

## Verification status

Every conformance result is **Implemented but Unverified**. No live provider test exists, so no adapter is **Verified**.
