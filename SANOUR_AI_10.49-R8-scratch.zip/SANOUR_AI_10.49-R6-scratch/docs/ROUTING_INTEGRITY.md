# Routing Integrity

Stage 10.36. Describes the router as it is in the code.

## The only routing operation

`DeterministicRouter.resolve(request)` returns the one profile named by `request.profile_alias`, or
it refuses. Nothing else in the router chooses a profile.

Removed in Stage 10.36:

- `DeterministicRouter.select()`, which returned the first eligible profile by priority and alias.
  Nothing in the codebase calls it any more. The old tests that used it now call `resolve()` with an
  explicit alias. A test asserts the method no longer exists.
- Any default profile, nearest-model logic, fallback list, or substitute provider. None existed in
  production, and none was added.

The `priority` field on `ModelProfile` is DEPRECATED (Stage 10.36-R1). It stays in the type for
compatibility, and no operational module reads it. A test scans the operational modules for it.

The legacy `models/catalog.py` `ModelCatalog` is DEPRECATED and is not imported by any operational
path. Constructing it emits a `DeprecationWarning`. It cannot select or route.

## Refusal, never redirection

The router refuses in these cases. Each uses the same public error, `NO_ELIGIBLE_MODEL`, with the
same public message, so a caller cannot tell an unknown alias from a disabled one.

| Internal reason | When |
|---|---|
| `missing_profile` | the alias is empty or not a string (the request schema already rejects this earlier) |
| `disabled_profile` | the alias is in the router's disabled set |
| `unknown_profile` | no profile has the alias |
| `unsuitable_profile` | the profile fails the text-generation, output-limit, context-limit, offline, or required-capability rules |

The reason is passed to the audit log as one of these fixed words. It is never the alias.

## Order independence

The router stores profiles in a dictionary keyed by alias. The result for a given alias does not
depend on registration order or on which other profiles exist. Duplicate aliases are refused when
the router is built.

## Provider, surface, catalog, and capability compatibility

- Catalog and profile checks run when a profile is registered and again on every
  `ProfileRegistry.model_profile()` call. A removed model or disabled profile cannot serve a request.
- The gateway checks the profile's provider, API surface, and declared capabilities against the
  adapter before any capacity is taken. A mismatch fails the request without a call.

## Request path

`accept()` validates the request, including `profile_alias`. `Coordinator` calls `resolve()`. On
refusal it logs `routing.auto_select_blocked` with the reason and returns the public error. There is
no second attempt.
