# Governance state machine (Stage 10.49-R6)

This document describes the runtime governance lifecycle as implemented in `sanour_ai.governance`: budget and quota
reservations, cost exposure, usage settlement, the admission gate, the audit outbox, sink delivery, conflict
resolution, shutdown and recovery. It is descriptive. The code is the authority, and the R6 tests
(`tests/unit/test_stage1049r6_*.py`) check the transitions listed here.

## 1. Reservation states

Each request has one row in `reservations`. Its `state` is one of:

| State | Meaning | Terminal |
|---|---|---|
| `reserved` | Budget and quota are held. The admission gate is `closed` (no provider call allowed yet) or `open` (provider call permitted). | no |
| `settlement_pending` | A settlement intent (kind, provider_started, usage) is committed. The apply transaction has not committed. | no |
| `exposed` | The provider may have been charged and the amount is not known or not priced. The reserved amount is held as exposure. | no (an operator may move it to `written_off`) |
| `settled` | Actual priced cost recorded. | yes |
| `released` | No provider call happened, or the gate never opened. Reserved amount returned. | yes |
| `written_off` | An operator resolved an exposure as written off. | yes |

## 2. Permitted transitions

    admit: reserve budget + quota, gate closed         -> reserved[gate=closed]
    gate open (own committed transaction, pre-call)    -> reserved[gate=open]
    settle intent (committed)                          -> settlement_pending
    settle apply (one transaction: budget, quota,
                  cost record, state, log, outbox)     -> settled | released | exposed
    sweep, expired, gate closed                        -> released (never exposed)
    sweep, expired, gate open                          -> exposed (via intent, then apply)
    operator write-off (authorized, reason)            -> written_off (exposure moved)
    operator exposure resolution (usage supplied)      -> settled

Not permitted (enforced by the store, and checked by the reconciler):

- terminal states never return to `reserved` or `settlement_pending`;
- a second settlement of a terminal reservation returns `already_settled` and writes no second cost record;
- a different outcome while an intent is pending returns `intent_conflict` and changes nothing;
- a `reserved` reservation with a closed gate never becomes `exposed`.

## 3. Outcomes and financial effects

| Outcome | provider_started | usage | State | charged_from | Budget effect |
|---|---|---|---|---|---|
| completed, priced | yes | yes | `settled` | `actual` | spent = priced amount |
| completed, usage unavailable | yes | none | `exposed` | `exposed` | exposure held |
| failed | yes | none | `exposed` | `exposed` | exposure held |
| timed out | yes | none | `exposed` | `exposed` | exposure held |
| refused before provider | no | n/a | `released` | `none` | reserved returned, nothing spent |
| gate closed, expired | no | n/a | `released` | `none` | reserved returned, nothing spent |
| gate open, expired (late or never settled) | yes | none | `exposed` | `exposed` | exposure held |
| withheld output after completion | yes | yes | `settled` | `actual` | as completed (usage kept, charged) |
| operator write-off | yes | none | `written_off` | `exposed` | exposure moved to written_off |

Withheld responses keep provider usage and are charged as completed. This is the accepted-usage contract in
`docs/USAGE_LEDGER.md`, not a defect. Usage is accounted only through that contract.

A late result that arrives after expiry is settled once, by sweep (gate open: exposure) or by the caller's own
settlement if it arrives first. A second arrival returns `already_settled`.

## 4. Admission gate

`AdmissionController.admit` validates the request, resolves pricing, checks budget and quota, reserves both in one
transaction with the gate `closed`, and records the admit log row. Only after that commit does the gate open, in its
own transaction. The coordinator calls the provider only with an open-gate ticket. If opening the gate fails, the
reservation stays `closed` and sweep releases it; the provider is never called. Admission events are fail-closed:
if they cannot be delivered to the sink, the request is refused before the provider call.

## 5. Audit outbox and sink

Every audited governance mutation writes an `audit_outbox` row in the same transaction as its `governance_log` row.
Delivery is a separate step:

- outbox statuses: `pending` (written, not claimed), `unknown` (claimed, outcome not recorded), `delivered` (sink
  holds a receipt), `failed` (sink refused; recovery retries), `conflict` (same key, different payload; operator);
- delivery claims a lease, delivers to the sink (its own durable transaction, deduplicated by `outbox_key`), and
  records the outcome only if the lease is still held;
- `delivered` is written only after the sink confirms.

| Fact | Where | Changed by audit failure? |
|---|---|---|
| governance decision committed | reservations, budget/quota windows, cost_records, governance_log | never |
| external audit event pending | `audit_outbox.status` in (pending, unknown) | n/a |
| external audit event delivered | `audit_outbox.status = delivered` plus sink receipt | n/a |
| external audit delivery failed | `audit_outbox.status = failed`, `last_error` | never |

## 6. Conflict resolution

Operator actions are append-only (`conflict_resolutions` and `governance_log`). Each needs an actor on the
host-supplied allowlist, a non-empty reason and an evidence reference. Nothing is overwritten silently.

## 7. Shutdown

Providers settle first. The sweep with `everything=True` runs only when the admitted count is zero. Shutdown turns
unfinished `reserved` reservations into exposure (gate open) or release (gate closed). It never marks
`settlement_pending` work or undelivered outbox events as completed. Those stay for recovery.

## 8. Recovery

`sweep()` is the single recovery entry point:

1. deliver pending outbox events (lease-based, idempotent);
2. apply each `settlement_pending` intent once (the apply transaction re-checks the state);
3. settle expired `reserved` reservations once: gate closed to release, gate open to exposure.

One attempt per reservation per call, no retry loop. A failed recovery read or write increments
`recovery_read_failures` and emits `recovery.read_failed` or `recovery.mark_failed`. It is never a silent zero.
Concurrent workers: the apply transaction requires `settlement_pending` and checks the row count, so each intent is
applied once. The concurrent-process test confirms one cost record per request.

## 9. Where subsystems can disagree

| Pair | Possible disagreement | Detected by (reconciler code) | Resolution |
|---|---|---|---|
| budget/quota windows vs reservation lines | drift from a bug or manual edit | BUDGET_WINDOW_MISMATCH, QUOTA_WINDOW_MISMATCH | operator; never automatic |
| reservation state vs cost record | terminal without a cost record | COST_RECORD_MISSING, COST_ORPHAN | operator |
| intent vs apply | intent committed, apply not | SETTLEMENT_PENDING, SETTLEMENT_NO_INTENT | recovery applies it |
| governance vs outbox | delivered without receipt; outbox without log row | AUDIT_DELIVERED_NO_RECEIPT, OUTBOX_ORPHAN | recovery / operator |
| governance vs sink | delivered but sink holds no receipt; receipt without event | SINK_RECEIPT_MISSING, SINK_RECEIPT_ORPHAN | idempotent redelivery / operator |
| audit conflicts | same key, different payload | AUDIT_CONFLICT_UNRESOLVED | operator resolution |
| governance vs usage ledger | ledger reports usage while governance holds exposure | LEDGER_EXPOSURE_DISAGREE | operator; ledger never edited |
| priced outcome vs ledger | priced completion without ledger row | LEDGER_MISSING_FOR_COMPLETION | operator |

## 10. Reconciliation report (read-only)

Design, implemented in `sanour_ai.governance.reconcile`:

- opens every database with SQLite's read-only URI mode (`?mode=ro`); the engine rejects writes, so the guarantee does
  not depend on the reconciler's own code. It never runs migrations and never calls a governance transaction;
- sections: reservations by state, pending reservations, uncertain exposures, pending settlements, budget and quota
  windows recomputed from reservation lines, audit outbox (failed, unknown, conflict), sink receipts, ledger;
- every finding has a code, a severity (error, warning, info), a subject and a detail; the report is `ok` only when
  there are no errors;
- Stage 10.49-R6-R1: `budget.spent` is recomputed from `cost_records.actual_cost` over requests whose budget line is
  `actual`; `quota.used` for `requests` from `actual` request lines; token metrics from persisted `reservations.intent_*`
  usage. Verified-usage resolutions never persist their token counts, so those quota buckets are reported as
  unverifiable and skipped, never guessed. A mismatch is an error and is never repaired;
- diagnostic (refusal and failure) log rows that cannot be written are counted (`diagnostic_log_failures`) and emitted
  as `governance.log_failed`. Required decision rows are written in their mutation's transaction, so their loss aborts
  the mutation;
- it reports schema-behind databases and skips the checks that need missing tables;
- it never repairs. Repair is an operator action through the governance API.
