# Audit sink boundary (Stage 10.49-R5)

## Layers
- **Contract (`src/sanour_ai/governance/sink_contract.py`).** The `AuditSink` protocol, `AuditReceipt`, and the classified failures `SinkFailed`, `SinkOutcomeUnknown`, `SinkPayloadConflict`. This module imports no storage library. The outbox depends only on it.
- **Local durable implementation (`src/sanour_ai/governance/sink.py`).** `DurableSqliteSink`: one SQLite file, WAL, `synchronous=FULL`, receipt and inbox rows written in one `BEGIN IMMEDIATE` transaction. It is the only sink shipped.
- **Governance (`admission.py`, `store.py`).** Decisions, outbox rows, leases, admission gate, conflict resolution. Uses the contract only.

## What the local sink guarantees
- A returned receipt means the sink's commit returned (fsynced under `synchronous=FULL`).
- Deduplication on `outbox_key` is durable and atomic within one file on one host.
- Process death at any transaction boundary leaves either nothing or one complete receipt. Verified by real child-process kills (test_stage1049r5_atomicity).

## What it does not guarantee
- **Single host only.** The sink file is local. Two hosts cannot share it safely over a network filesystem. Concurrency is correct only for processes on one machine using local SQLite locking.
- **No end-to-end exactly-once.** The outbox is at-least-once. The sink de-duplicates; the consumer of the sink is not covered.
- **Durability depends on the host.** Disk, filesystem, and fsync behaviour are assumed, not proven.
- **No external audit guarantee.** Tamper evidence, retention, and independent replication are not provided.

## Boundary to a future external multi-host audit service (not implemented)
An external service would implement the same `AuditSink` protocol. It must provide, at minimum:
1. A durable acknowledgement only after the service's own commit, with the same three failure classes.
2. Deduplication on `outbox_key` with payload-digest comparison, atomic with the receipt.
3. A stable receipt identifier returned on duplicates.
4. Authenticated callers; the host, not the caller, supplies the authorized actors.
5. Bounded clock assumptions: leases on the outbox side use the worker clock, so the lease must exceed the worst-case sink latency plus skew.
6. Its own migration and retention policy, separate from the governance database.

Nothing in this repository connects to such a service, and no test contacts one.

## Conflict resolution security model (R5)
- **Who.** An actor on the controller's allowlist. The host configures the allowlist. The repository does not authenticate users: the caller asserts an identifier, and the host must bind that identifier to a real, authenticated operator before calling the controller.
- **What must be supplied.** A non-empty reason (1 to 500 printable characters, not whitespace only) and an evidence reference (1 to 128 characters of letters, digits, and `._:/#-`).
- **What is recorded.** A new `conflict_resolutions` row (actor, reason, evidence reference, decision `acknowledged`, digest of the original payload, time), and a `governance_log` row with operation `conflict_resolve`. Both commit in one transaction.
- **What never changes.** The conflict row and its payload are immutable (database triggers). Resolution rows are append-only (database triggers). Nothing is deleted. No sink retry happens. No money moves.
- **Refusals.** Unauthorized actor, invalid key, invalid reason, invalid evidence, non-conflict row, duplicate resolution, storage failure. Each refusal is logged best-effort as `refused` and changes nothing.
- **Effect on delivery.** A resolved conflict is reported as `conflict_resolved`, which is terminal and is not confirmed delivery. A required admission event in this state still fails closed.
