# Model Catalog

Stage 10.35. Code: `src/sanour_ai/models/model_catalog.py`.

## What it is

A versioned store of facts about models. Each entry is one model under one provider, identified by
the pair (provider_id, model_id). The catalog does not route, fetch models from an API, or call any
provider. Nothing in it is discovered automatically.

## Record fields

Each `ModelRecord` holds: model_id, provider_id, vendor, api_surface, display_name, model_family,
model_version, capabilities (every one of the 14 categories, each stated), context_window,
input_token_limit, output_token_limit, supported_modalities, lifecycle_status, verification_status,
documentation_reference, limitations, and source.

## Rules

- **No guessing.** A value the caller does not state is `None` (numbers), `unknown` (text and
  lifecycle), or `UNKNOWN` (capabilities).
- **Exact identifiers.** `model_id` is stored as given. The format check does not trim, lower-case,
  or normalise. `GPT-X` and `gpt-x` are different strings. A trailing space is refused.
- **Provider scope.** The same model_id under two providers is two models.
- **Sources.** A token limit or a documented capability needs a documentation reference and an
  official source. An operator-declared model (source `operator_configuration`) may state limits
  but may not state capabilities. Its confidence is `operator_declared`.
- **No duplicates.** An identity is registered once. A removed identity cannot be registered again.
- **Versioned and traceable.** Each write raises the version by one and appends to `change_log`.
  The log holds the action, provider_id and model_id only.
- **Freeze.** `freeze()` makes every later write fail. Production freezes the catalog before the
  first request can run.
- **Read and write are separate.** `reader()` returns a view with no write methods.
- **Deactivation.** `deactivate_model` needs `authorized=True` (exactly True) and a reason. It sets
  the lifecycle to `removed`. It is permanent for that identity.

## Errors

Every error is a `CatalogError` with a fixed message or a list of field names. No error contains a
rejected value.

## Entries in this repository

| Model | Provider | Source | Confidence | Notes |
|---|---|---|---|---|
| The model named by the operator's `SANOUR_OPENAI_MODEL_ID` | openai | operator_configuration | operator_declared | Created at startup. Lifecycle unknown, capabilities unknown, limits left to the profile. |

No other model is registered. No documentation was fetched to add entries, so none were added.
