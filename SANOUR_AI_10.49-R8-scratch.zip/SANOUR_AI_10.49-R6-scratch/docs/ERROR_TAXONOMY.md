# Error Taxonomy (Stage 10.37)

Source of truth: `models/error_taxonomy.py`. `classify()` maps each failure to exactly one `InternalErrorKind`.

## Rules

1. Internal kinds are separate from public `ErrorCode`. The taxonomy never creates a public code. No public code was added in this stage.
2. Mapping uses the public code, a fixed `failure_reason`, the validation tag, and the adapter's fixed message. Raw provider text is never read.
3. `retryable` is a classification hint only. No code path retries because of it.
4. Quota and billing are one group (`PROVIDER_QUOTA`), kept apart from rate limit.
5. Unknown fixed messages that are not in the classified sets become `PROVIDER_UNCLASSIFIED`. A small set is listed as unclassified by design: `provider limit reached`, `provider payment required`, `provider call failed`, `provider response too large`.

## Kinds

RequestValidation, ProfileResolution, IdentityValidation, CapabilityValidation, CapacityRejected, ProviderTransport, ProviderAuthentication, ProviderRateLimit, ProviderQuota, ProviderContentBlocked, ProviderIncompleteResponse, ProviderInvalidResponse, ProviderRequestRejected, DeadlineExceeded, ProviderLifecycle, ProviderUnclassified, InternalExecution.

The two messages added in this pass: `client configuration changed; request refused` maps to ProviderLifecycle, and `request has no deadline` maps to DeadlineExceeded.

## Status

- Mapping for the fixed adapter messages: **Implemented**, checked by a test that scans every adapter for its messages.
- Provider-side meaning of 429, 402, and quota responses: **Unverified**. No live evidence exists, so the mapping is a reading of the documented behavior, not a verified fact.
