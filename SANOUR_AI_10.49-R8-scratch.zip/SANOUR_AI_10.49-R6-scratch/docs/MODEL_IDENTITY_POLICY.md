# Model Identity Policy

Stage 10.36. This describes what the code does today.

## Five identities, kept apart

| Identity | Where it comes from | Where it is checked |
|---|---|---|
| `profile_id` (the alias) | The request's `profile_alias`, after the router resolves it | Router, then `RequestIdentity` |
| `provider_id` | The resolved profile's `provider` | `RequestIdentity`, gateway pre-send check |
| `api_surface` | The profile's validated `api_surface` (set at registration) | `RequestIdentity`, gateway pre-send check against the adapter's declared `surface` |
| `requested_model_id` | The resolved `ModelProfile.model_id`, and the call's `model_id` | Gateway pre-send check, which requires both to match the profile |
| `provider_reported_model_id` | Only the provider's response (`ModelResult.reported_model_id`) | Gateway, after the response |

No identity is inferred from another. The reported id is never copied into the response, the
identity object, or a log line.

## Matching rules

1. The reported id is accepted only if it equals `requested_model_id` exactly, or appears exactly in
   that profile's `accepted_reported_model_ids`.
2. Matching is exact. There are no wildcards, prefixes, or patterns. `ModelProfile` refuses `*`,
   `?`, and similar characters when the allowlist is built.
3. An empty, missing, non-text, or unknown reported id fails closed as `PROVIDER_INVALID_RESPONSE`.
4. The allowlist belongs to one profile. The identity object carries a copy, and the gateway checks
   that the copy equals the profile's own allowlist. A mismatch is refused before any call.

## What is checked before a call

The gateway refuses the call before taking any capacity if the identity does not match:

- the profile alias or provider,
- the requested model id (profile and call must agree),
- the allowlist (identity and profile must agree),
- the API surface (when the profile has one),
- the adapter's declared API surface (when the adapter declares one).

Refusals use `NO_ELIGIBLE_MODEL` and the public message "the requested model cannot handle this
request". The internal scope `request_identity` is never sent to a caller.

## What is logged

Only identifiers: `request_id`, `model_alias`, `provider`, and `api_surface`. The audit whitelist
drops every other field. The `reason` field only accepts fixed words. Nothing from the prompt, the
response text, the key, or the provider's reported id is logged.

## Identity is mandatory

`ModelGateway.generate()` refuses any call without a `RequestIdentity` (Stage 10.36-R1). The refusal
happens before the shutdown check, capacity, provider lookup, or any provider I/O. The old
profile-only comparison was deleted. There is no fallback to it.
