# FailureKind decisions (Stage 10.38)

Internal only. Nothing here creates a public ErrorCode. Classification reads typed fields only.

## Deadline model

- The central request deadline (`ModelCall.deadline`, set by SanourCore) is the only deadline.
- Per-call transport timeouts (connect, read, write, pool) are `min(configured, remaining)`. They are
  never a deadline on their own.
- A transport failure is a deadline failure (`DEADLINE_IN_CALL`) when the central deadline has passed at the
  moment it is observed, or when the transport reports `DeadlineExpired`. Otherwise it is a connection
  failure (`CONNECTION`) or a per-call timeout (`CALL_TIMEOUT`).
- A response that arrives after the deadline is `DEADLINE_LATE` and is never a success.
- Worker capacity is held until the real worker returns (unchanged, tested).

## Decisions for the four ambiguous kinds

| FailureKind | Decision | Internal kind | Reason |
|---|---|---|---|
| LIMIT_REACHED | New internal kind PROVIDER_LIMIT_UNCONFIRMED | provider_limit_unconfirmed | An unknown 429 is neither a confirmed rate limit nor a confirmed quota. It is not retryable. It is kept apart from generic unclassified for audit. |
| PAYMENT_REQUIRED | PROVIDER_QUOTA | provider_quota | HTTP 402 is a billing condition. It is not retryable. |
| CALL_TIMEOUT | PROVIDER_TRANSPORT | provider_transport | A per-call timeout before the central deadline is a transport problem. It is retryable as a hint only. |
| RESPONSE_TOO_LARGE | PROVIDER_INVALID_RESPONSE | provider_invalid_response | An oversized body is malformed provider output. It is not retryable. |

## Other semantic checks

- DEADLINE_MISSING maps to INTERNAL_EXECUTION. The request path always sets a deadline, so a missing one is a fault in our code, not an expiry.
- DEADLINE_EXPIRED, DEADLINE_LATE and DEADLINE_IN_CALL map to DEADLINE_EXCEEDED.
- CALL_FAILED (unknown status) stays PROVIDER_UNCLASSIFIED. No guessing.
- CONTENT_BLOCKED, INCOMPLETE_RESPONSE, CLIENT_CHANGED, GATEWAY_SHUT_DOWN, PROVIDER_NOT_REGISTERED keep their existing kinds.

## Coverage

All FailureKind members are listed below. A test fails if one is missing from this file.

AUTHENTICATION, PERMISSION, MODEL_NOT_FOUND, REQUEST_REJECTED, SERVER_ERROR, CONNECTION, CALL_TIMEOUT,
CALL_FAILED, RATE_LIMIT, LIMIT_REACHED, PAYMENT_REQUIRED, RESPONSE_TOO_LARGE, INCOMPLETE_RESPONSE,
CONTENT_BLOCKED, DEADLINE_MISSING, DEADLINE_EXPIRED, DEADLINE_IN_CALL, DEADLINE_LATE, INVALID_MODEL_ID,
CLIENT_CHANGED, GATEWAY_SHUT_DOWN, PROVIDER_NOT_REGISTERED, UNCLASSIFIED
