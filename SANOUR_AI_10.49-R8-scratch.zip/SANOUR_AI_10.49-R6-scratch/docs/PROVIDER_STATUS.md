# Provider status (Stage 10.45)

Status labels, from weakest to strongest:

- **Implemented**: code exists in `src/sanour_ai/providers/`.
- **Tested with fakes**: offline tests pass against a fake client or fake transport.
- **SDK-tested**: the real SDK path ran in a test. Skipped where the SDK is not installed. Not counted as passed.
- **Live-verified**: a real provider call was checked. No provider has this status.
- **Production-ready**: the production gate would admit it. Nothing has this status today.

Nothing is labeled Verified or Production Ready unless the evidence exists in this repository.

| Provider | Surface | Implemented | Tested with fakes | SDK-tested | Live-verified | Production-ready |
|---|---|---|---|---|---|---|
| OpenAI | openai_responses | yes | yes | not executed here (60 SDK tests skip without `openai`/`httpx2`) | no | no (gate refuses: no approved model) |
| xAI Responses | grok_responses | yes | yes | no | no | no. Never registered in production. |
| Anthropic | anthropic_messages | yes | yes | no | no | no. Not in any composition root. |
| Gemini | gemini_generate_content | yes | yes | no | no | no. Not in any composition root. |
| Grok (chat completions) | grok_chat_completions | yes | yes | no | no | no. Not in any composition root. |
| Mock / test fake | n/a | n/a | yes (tests only) | n/a | n/a | never. Reachable only through `Runtime.build_for_tests()`. |

Notes:

- **Model verification.** `docs/MODEL_VERIFICATION_POLICY.md` governs it. `production_ready()` returns no categories while `RUNTIME_EVIDENCE` is empty, and `APPROVED_PRODUCTION_MODELS` is empty. An operator-declared model id is unverified.
- **Error mapping.** The mapping is by typed internal kind, not by message text. See `docs/FAILURE_KIND_DECISIONS.md`. Provider meaning of 429 and quota responses is **Unverified** (`docs/ERROR_TAXONOMY.md`).
- **Usage.** Each adapter extracts usage only from the response fields listed in `docs/RESPONSE_NORMALIZATION.md` (Stage 10.47). Missing or invalid usage stays `None`. No provider has verified usage reporting against a live API.
- **Known limits.** No recovery from a hung provider call. The per-phase SDK timeouts do not guarantee an overall deadline (see the OpenAI section of the README).
