# Cost, budget and quota governance (Stages 10.49 and 10.49-R1)

## Architecture
handle() -> coordinator: validate -> Router (one explicit profile)
  -> AdmissionController.admit(): one BEGIN IMMEDIATE transaction. CostEngine (Decimal) worst case from bounds,
     Budget Manager (every applicable budget), Quota Manager, writes reservation and open lines.
  -> ModelGateway (capacity, deadline, provider), only after admission.
  -> AdmissionController.settle(): phase 1 records intent, phase 2 applies it.
  -> Usage Ledger record (same file, own tables).
Recovery (startup, sweep, shutdown): applies stored intents; unfinished expired reservations become exposure.

## Four money concepts, never mixed
| Concept | Where | Meaning |
|---|---|---|
| Actual cost | budget_windows.spent, cost_records.actual_cost | Priced from valid provider usage. The only spending. |
| Reserved budget | budget_windows.reserved | In-flight worst case, held only while admitted or executing. |
| Uncertain exposure | budget_windows.exposed, quota_windows.exposed | Provider may have been charged, usage unknown or invalid. Reduces availability. Never spending. |
| Unknown cost | cost_records.cost_status = unknown_* | Stored as NULL, never as zero. |

Availability = limit - spent - reserved - exposed. Every applicable budget must have room.
Reports name each figure separately: actual_spent, reserved_in_flight, uncertain_exposure, available.

## Failure accounting rules
| Situation | Actual cost | Exposure | Reservation end state |
|---|---|---|---|
| Refused before provider call (capacity, shutdown, validation, audit) | none (not_billed) | none | released |
| Provider call started, valid usage priced | exact cost | none | settled |
| Provider call started, error, usage unknown or invalid | none (unknown_usage) | reserved worst case | exposed |
| Provider call started, error, valid usage reported | exact cost | none | settled |
| Timeout after call started, usage unknown | none | reserved worst case | exposed |
| Late provider result after timeout | never counted; the first intent stands | unchanged | unchanged |
| Expired or swept at restart or shutdown, no intent stored | none | reserved worst case | exposed |

- The gateway does not surface usage on failure, so the coordinator never passes usage for failures. Exposure is the honest outcome.
- Exposure is never auto-converted to cost. resolve_exposure(request_id, usage) replaces exposure with verified usage that prices exactly and covers every exposed count. Idempotent.
- Quota: requests are always counted (the request was sent). Token counts follow the cost rule.

## Settlement failure and recovery
Two persistent phases:
1. Record intent (one transaction): stores kind, provider_started and usage, moves the reservation to settlement_pending. Amounts stay reserved.
2. Apply (one transaction): turns the stored intent into actual cost, exposure or release, and writes cost_records.

- Failed phase 1: reservation stays reserved, response says settlement_failed.
- Failed phase 2: reservation stays settlement_pending with its intent stored, response says settlement_pending. Never success.
- Phase 1 keeps the first intent, so a late result cannot overwrite it. Phase 2 only runs on settlement_pending, so duplicates cannot double-count.
- recover() applies each stored intent once, then turns unfinished expired reservations into exposure once. One attempt per reservation per call. No retry loop.
- Each failed write emits settlement.failed. Failures stay visible.

## Currency
A budget in currency X applies only to pricing in X. Otherwise the request is refused as cost_unknown. Each request is priced in one currency. Budgets, reports and exposure are kept per currency.

## Persistence
Migrations are versioned in schema_migrations. Version 1 created the tables. Version 2 adds exposed columns, the line outcome column, intent columns, and rebuilds reservations and cost_records with the new states. Version 1 expired rows become exposed, and reserved charged rows become exposed. A newer version is refused.

## Error semantics (Part 4)
- Budget and quota refusals are local governance decisions, not provider responses.
- They currently use the public code PROVIDER_RATE_LIMITED. This is semantically imperfect: no provider rate-limited anything, and a caller cannot tell a local budget from a provider limit.
- Internal classification stays explicit: SanourError.scope is "budget" or "quota" (internal only), internal_kind LIMIT_REACHED. Audit events are budget.rejected and quota.rejected.
- No public ErrorCode was added. Proposed for approval: BUDGET_EXCEEDED (budget refused, including cost that cannot be bounded in the budget currency), QUOTA_EXCEEDED (quota refused), and GOVERNANCE_UNAVAILABLE for storage failures currently reported as INTERNAL_ERROR.

## Audit of record and external delivery (Stage 10.49-R3)
- **governance_log is the record of decisions.** Admission (`admit`), settlement, verified usage, write-off and retain each write their governance_log row in the same transaction as the mutation. A failed transaction leaves neither the mutation nor an ok row.
- **External audit goes through audit_outbox.** The event is written in the same transaction as the decision (key `gov:<log_id>:<event>`). It is delivered only after commit.
- **Delivery states, reported separately:** the decision is committed (`applied`), the event is `pending` (not attempted), `delivered` (sink write returned without error), or `failed` (sink refused; kept for retry, `last_error = sink_write_failed`).
- **A failed delivery never rolls back a committed decision.** The result keeps `applied=True` and reports `audit_status=failed`.
- **Recovery:** `sweep()` (startup, shutdown) delivers pending and failed events. Delivered events are never sent again by this path. This is outbox recovery, not a provider request retry.
- **Idempotency:** a crash between the sink write and the status update re-sends the event with the same `outbox_key`. The delivery is at least once, so a sink must de-duplicate on `outbox_key`. Financial effects are never re-applied, because they are not part of the outbox.
- **Admission events stay synchronous.** They gate the provider call. A failed sink there still fails closed before any provider call, and the reservation is released by a committed settlement.
- **Known limit:** "delivered" means the audit sink's write returned without error. The repository cannot prove the sink's durability beyond that.

## Audit sink contract, leased delivery and sink deduplication (Stage 10.49-R4)
- **Sink contract (`governance/sink.py`).** `deliver(outbox_key, event, fields)` returns a receipt only after the sink's own durable commit returned. Failure classes: `SinkFailed` (definitely not recorded), `SinkOutcomeUnknown` (may be recorded; safe to retry because of deduplication), `SinkPayloadConflict` (same key, different payload; fail closed, never retried automatically). Any unexpected sink exception is classified as unknown.
- **A Python logging handler is not a sink.** `logger.info()` returning proves nothing about persistence. The outbox trusts only `DurableSqliteSink`.
- **Durable deduplication.** The receipt row and the inbox row (`outbox_key` -> digest, receipt id) are written in one `BEGIN IMMEDIATE` transaction with WAL and `synchronous=FULL`. A duplicate key with the same digest returns the original receipt. A conflicting digest raises and records nothing. Writers serialize on SQLite's lock, so concurrent duplicates produce one receipt.
- **Delivery states, reported separately from the decision:** `pending` (never attempted), `attempted` (a live lease), `confirmed` (sink receipt stored in the outbox), `failed` (sink definitely did not record), `unknown` (outcome not known), `conflict` (terminal). The governance decision (governance_log, reservation, money) is committed independently and is never rolled back by a delivery state.
- **Leased claims (migration 5).** A worker claims an event in one write transaction: it sets a random lease token and an expiry (default 60 s). Only the holder may settle the attempt. A stale worker's result is refused, and a confirmed row is never overwritten. Expiry allows reclaim after a crash, so no claim is permanent. Keys are stable across attempts.
- **Required admission events.** `budget.reserved` and `quota.reserved` are outbox rows written in the reservation transaction, delivered synchronously after commit. If any is not `confirmed`, the reservation is released by a committed settlement, the request is refused, and the provider is not invoked.
- **Schema migration 5** rebuilds `audit_outbox` with the new states and the columns `receipt_id`, `lease_token`, `lease_expires_at`. It keeps every existing row. A v4 database upgrades in place.
- **Default sink location:** `<governance database>.sink`. Production must place it on durable storage. It must be a separate file from the governance database.

**Operational requirements.** Keep the sink on durable storage with working fsync. Keep the lease longer than the worst-case sink commit. Keep worker clocks synchronized, because skew shortens leases. Operators must handle `conflict` rows, which are never retried automatically.

**Limits.** No end-to-end exactly-once delivery is claimed. The guarantee is at-least-once delivery plus deduplication at the sink's storage. The governance database and the sink are two databases, so there is no cross-database transaction. The outbox bridges the gap. Operational logs such as `settlement.failed` remain log-only and are not confirmed deliveries.

## Audit
Events: pricing.version_selected, budget.reserved, budget.rejected, budget.reconciled, quota.reserved, quota.rejected, quota.reconciled, cost.unknown, exposure.open, exposure.resolved, settlement.failed. Allowlisted fields with enumerated values only. No amounts, prompts, outputs or paths.

## Stage 10.49-R5 additions
- Admission gate: a reservation starts `closed`; the provider runs only after the gate opens in its own committed transaction. Sweep releases gate-closed reservations (never exposes them).
- Conflict resolution: operator acknowledgement of terminal conflict rows, append-only, with an authorized actor, reason and evidence reference. See `AUDIT_SINK_BOUNDARY.md`.
- Migration 6: `reservations.admission_gate`, table `conflict_resolutions`, append-only and immutability triggers.
- Sink boundary and the future external service requirements: see `AUDIT_SINK_BOUNDARY.md`.
