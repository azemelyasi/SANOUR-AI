# Response Normalization (Stage 10.37)

Raw provider responses never reach a caller. Each adapter converts its own response into the internal shape, then the Coordinator checks it.

## Rules

1. Incomplete responses (for example a max-token stop) are not reported as success. They raise `ProviderIncompleteResponseError`.
2. A response missing required fields fails closed as `ProviderInvalidResponseError`.
3. Content blocked by the provider is reported as a content block, separate from technical errors.
4. Unknown values are `None`. Missing `usage` is `None`, never `0`.
5. The reported model id is recorded only after it passes identity validation. A rejected id never reaches `ExecutionResult`.
6. Full response text is not written to audit or metrics.

## Result fields

`ExecutionResult` holds: request_id, profile_id, provider_id, api_surface, requested_model_id, provider_reported_model_id, output, finish_status, execution_ms, usage (optional), completion_status, verification_status.

- `verification_status` is always `implemented_unverified`. The dataclass rejects any other value.
- `usage` is normalized per adapter (Stage 10.47, see the usage matrix below). Missing or invalid usage is `None`, never `0`. Extraction is **Implemented but Unverified**: fixture tests only, no live verification.

## Usage matrix (Stage 10.47)

| Adapter | Source fields | Status |
|---|---|---|
| OpenAI (Responses) | input_tokens, output_tokens, total_tokens, input_tokens_details.cached_tokens, output_tokens_details.reasoning_tokens | Extraction implemented; fixture-tested; not live-verified |
| xAI Responses | same shape as OpenAI Responses | Extraction implemented; fixture-tested; not live-verified |
| Grok Chat | prompt_tokens, completion_tokens, total_tokens, prompt_tokens_details.cached_tokens, completion_tokens_details.reasoning_tokens | Extraction implemented; fixture-tested; not live-verified |
| Anthropic | input_tokens (+ cache_read/cache_creation, summed), output_tokens | Extraction implemented; fixture-tested; not live-verified |
| Gemini | usageMetadata promptTokenCount, candidatesTokenCount (+ thoughtsTokenCount), totalTokenCount, cachedContentTokenCount | Extraction implemented; fixture-tested; not live-verified |

Status for every row: **field names UNVERIFIED**. No authoritative provider documentation was reachable offline in this stage, so the field names above were not confirmed against any official source. Extraction is covered only by fixture tests written for this repository, which prove the mapping, not the provider's actual response format. Do not treat any row as live-verified.
- Streaming and tool calling: **Unsupported**. Not enabled in any adapter.
- Structured output: **Unsupported** in this stage.
