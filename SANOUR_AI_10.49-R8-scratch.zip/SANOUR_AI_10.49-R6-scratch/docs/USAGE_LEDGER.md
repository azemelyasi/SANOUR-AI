# Usage Ledger (Stage 10.48)

- **Contract:** `sanour_ai.ledger.repository.UsageRepository` (`append`, `records`, `close`). Storage-independent.
- **Record:** `sanour_ai.ledger.record.LedgerRecord`. Identifiers, UTC day, delivery status, audit status, and five nullable counters. No prompt, output, key, price, or raw payload.
- **In memory:** `InMemoryUsageRepository`. Test and development only. Never used by production.
- **Durable local:** `sanour_ai.ledger.sqlite_repository.SqliteUsageRepository` (stdlib SQLite, WAL, synchronous=FULL). `Runtime.build(..., usage_ledger_path=...)` requires it.
- **Production storage policy (10.48-R1):** a missing, `:memory:`, unusable or unopenable path refuses the runtime (`ConfigError`, fixed message, no fallback, no automatic choice). Nothing is ever converted from SQLite to memory.
- **Open checks:** the file must be WAL, the schema version must match, and `PRAGMA integrity_check` must return exactly `ok`. Otherwise it is refused.
- **Atomicity:** each append is one `BEGIN IMMEDIATE` transaction. The duplicate check and insert run under one write lock, so two processes cannot both insert one request id. A crash before COMMIT leaves no row.
- **Duplicates:** `request_id` is the primary key. An identical retry returns `False`. A different record for the same id raises `LedgerConflictError` and the stored row is unchanged.
- **Failures:** any storage error raises `LedgerStorageError` with a fixed message. It is never reported as a successful write. Runtime counts it in `usage_summary()["health"]`.
- **Reports:** SQLite aggregates inside the engine (GROUP BY). The in-memory engine follows the same contract, and tests require identical output for identical data. Filters are exact matches on provider, profile, model, period (UTC day), delivery and audit. Values are validated and bound as parameters, and column names come from a fixed map.
- **Partial totals:** a token sum covers only the records that reported it. `tokens_complete` is `false` when some record in the bucket did not report it, so a partial sum is never shown as the full total. Unknown is never summed as zero.
- **Lifecycle:** the ledger closes when shutdown completes, after every admitted request has finished its write. A write after shutdown is refused. A close error is counted in `usage_summary()["health"]["ledger_close_failures"]` and audited, and it does not stop the runtime from settling.
- **Limits:** no billing, no pricing, no automatic provider selection, no retry. SDK behaviour is not verified.
