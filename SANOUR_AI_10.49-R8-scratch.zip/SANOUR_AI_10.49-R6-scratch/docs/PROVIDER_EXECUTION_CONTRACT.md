# Provider Execution Contract (Stage 10.37)

Source of truth: `providers/contract.py`. Built on the Stage 10.34 contract.

## What the contract owns (shared)

- `REQUIRED_ATTRIBUTES`: name, vendor, surface, auth_method, capabilities. `contract_violations()` checks them.
- `AUTH_METHODS`: a fixed set. A new method needs a reviewed change.
- `prepare_call()`: the shared prologue. Rejects a missing deadline, an invalid model id, and an expired deadline, all before any I/O.
- `send()`: the single send path. One attempt, the remaining budget as the timeout, OS errors mapped to one fixed message, and a response that arrives after the deadline is refused.
- `ensure_secret()`: the only accepted credential type (`SecretStr`). Error messages name the setting, never the value.

## What each adapter owns

- Its own request body (`_build_request`), response parser, and fixed error messages.
- Its own API surface and endpoint, fixed in code. User input cannot change endpoints.
- Adapters never read the environment, never choose a model or a provider, never retry, never fall back, and never create a Deadline.

## Status

| Adapter | Identity conformance | Request-level conformance |
|---|---|---|
| OpenAI Responses | Implemented but Unverified (identity check runs) | Skipped: openai and httpx2 SDKs not installed |
| Anthropic Messages | Implemented but Unverified | Implemented but Unverified (fake transport) |
| Gemini GenerateContent | Implemented but Unverified | Implemented but Unverified (fake transport) |
| xAI Grok Chat Completions | Implemented but Unverified | Implemented but Unverified (fake transport) |
| xAI Grok Responses | Implemented but Unverified; disabled in Production | Implemented but Unverified (fake transport); enabling is not part of this stage |

Fake transports prove the code's behavior, not the vendor's behavior. Nothing here is **Verified**.
