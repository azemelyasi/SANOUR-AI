# Request Identity Lifecycle

Stage 10.36. The steps below are the order the code runs them.

1. **Received.** `accept()` validates the raw request. It rejects a missing or malformed
   `profile_alias` with `INVALID_REQUEST`. The request is frozen after this step.
2. **Resolved.** `DeterministicRouter.resolve()` returns the named profile or refuses. A refusal logs
   `routing.auto_select_blocked` and ends the request with no provider call.
3. **Identity created.** `RequestIdentity.for_profile()` builds one frozen object from the resolved
   profile. It logs `request.profile.resolved` and `request.identity.created` with identifiers only.
   The identity holds no deadline, key, prompt, or response.
4. **Pre-send check.** A call without a `RequestIdentity` is refused first (Stage 10.36-R1). The gateway compares the identity with the profile, the call, and the adapter
   before taking capacity. A conflict logs `request.identity.rejected` (reason `identity_conflict`)
   and returns the public error. No provider call happens.
5. **Call.** The one attempt runs under the Coordinator's single deadline. The deadline is not part
   of the identity.
6. **Reported id check.** After the response, the gateway checks `provider_reported_model_id` with
   the identity's exact rules. A mismatch logs `model.identity.mismatch` and fails closed.
7. **Validated.** A matching reply logs `model.identity.validated` and returns the answer under the
   profile's alias and model id. The reported id is never returned.

## Immutability

`RequestIdentity` is a frozen dataclass. Its allowlist is a frozenset. Attempts to change a field
raise `FrozenInstanceError`. A new request creates a new identity.

## Timeout and capacity

A timeout returned to the caller does not stop the provider thread. The worker keeps its capacity
slot until it really ends, as in earlier stages. No identity step adds a retry or a second attempt.

## Audit events in this lifecycle

| Event | Fields |
|---|---|
| `routing.auto_select_blocked` | `request_id`, `reason` (fixed word) |
| `request.profile.resolved` | `request_id`, `model_alias`, `provider`, `api_surface` |
| `request.identity.created` | same as above |
| `request.identity.rejected` | same as above, plus `reason` |
| `model.identity.validated` | same as above |
| `model.identity.mismatch` | same as above |
