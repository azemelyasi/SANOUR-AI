# Unified Execution Pipeline (Stage 10.37)

Status legend: **Implemented** (in code, covered by tests), **Implemented but Unverified** (in code, no live provider evidence),
**Documented Only**, **Unsupported**, **Unknown**.

## Stages

The Coordinator (`core/coordinator.py`) runs the fifteen stages of `ExecutionStage` (`models/execution.py`) in a fixed order.

| # | Stage | Status |
|---|---|---|
| 1 | Request Received | Implemented |
| 2 | Request Validation | Implemented |
| 3 | Explicit Profile Resolution | Implemented (router refuses on missing or unknown alias; no auto-select) |
| 4 | RequestIdentity Validation | Implemented |
| 5 | Capability and Model Constraints | Implemented |
| 6 | Capacity Admission | Implemented (bounded semaphore; slot held until the real end of the worker) |
| 7 | Provider Request Construction | Implemented per adapter |
| 8 | Provider Execution | Implemented; a single attempt, no retry |
| 9 | Raw Response Reception | Implemented per adapter |
| 10 | Response Normalization | Implemented per adapter, see RESPONSE_NORMALIZATION.md |
| 11 | Response Integrity Validation | Implemented (incomplete and invalid responses fail closed) |
| 12 | Identity Validation | Implemented (reported model id must equal the requested id or an allowlisted id) |
| 13 | Result Construction | Implemented (`ExecutionResult`, frozen dataclass) |
| 14 | Audit and Metrics | Implemented (bounded counters, no content) |
| 15 | Request Completion | Implemented |

## Rules enforced in code

- One Deadline, set once in `SanourCore.handle()`. Stages and adapters read it; none creates a new one.
- No stage changes the ModelProfile or the RequestIdentity.
- No fallback, no automatic retry, no model auto-select. `retryable` is a classification hint only.
- Every failure maps to one internal kind (see ERROR_TAXONOMY.md) and returns through the normal completion path.

## Limits

- Python threads cannot be stopped. A timeout returns to the caller; the worker keeps its capacity slot until it really ends.
- HTTP timeouts are a budget passed to the transport. They are not a guarantee that the network request stopped.
- Cancellation is not implemented: no safe stop operation exists in this codebase. **Unsupported.**
- xAI Responses remains disabled in Production. Conformance tests do not enable it. **Unsupported in Production.**
