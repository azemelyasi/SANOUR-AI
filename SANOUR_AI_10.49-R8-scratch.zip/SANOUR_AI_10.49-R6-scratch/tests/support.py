"""Shared test helpers. Not production code."""

import threading
import time

from sanour_ai.models.base import ModelResult
from sanour_ai.models.capabilities import CAPABILITY_FLAGS, ProviderCapabilities

# Test-only fixture: a provider that supports every flag, so existing tests stay unchanged.
TEST_ALL_CAPS = ProviderCapabilities(**{flag: True for flag in CAPABILITY_FLAGS})

# Allowed caller-side overhead beyond the deadline, for scheduling jitter on slow machines.
TOLERANCE_SECONDS = 0.25


def deadline_in(seconds: float) -> float:
    return time.monotonic() + seconds


def wait_until(predicate, timeout: float = 2.0) -> bool:
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        if predicate():
            return True
        time.sleep(0.01)
    return predicate()


class GatedProvider:
    capabilities = TEST_ALL_CAPS
    """Blocks inside generate() until release_all(). Records entries and peak concurrency."""

    def __init__(self, name: str = "mock") -> None:
        self.name = name
        self._gate = threading.Event()
        self._lock = threading.Lock()
        self.calls = 0
        self.active = 0
        self.peak = 0

    def generate(self, call):
        with self._lock:
            self.calls += 1
            self.active += 1
            self.peak = max(self.peak, self.active)
        try:
            self._gate.wait()
        finally:
            with self._lock:
                self.active -= 1
        return ModelResult(text=f"gated:{call.prompt}", reported_model_id=call.model_id)

    def release_all(self) -> None:
        self._gate.set()


def request_identity_for(profile):
    """Test helper (Stage 10.36-R1): the one identity object a Coordinator would create for a profile."""
    from sanour_ai.models.request_identity import RequestIdentity

    return RequestIdentity.for_profile("r" * 32, profile)


def production_ledger_path():
    """Stage 10.48-R1: production builds need a durable ledger path. A fresh file per call, removed at exit."""
    import atexit
    import os
    import shutil
    import tempfile
    directory = tempfile.mkdtemp(prefix="sanour-prod-ledger-")
    atexit.register(shutil.rmtree, directory, True)
    return os.path.join(directory, "usage.db")
