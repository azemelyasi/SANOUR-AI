"""Stage 10.33-R1 tests: runtime integration, configuration ownership, shutdown coordination.

Fake OpenAI adapter only. No SDK, no network, no real key. Every wait is bounded.
"""

import dataclasses
import logging
import os
import pathlib
import re
import threading
import time
import unittest
from unittest import mock

from pydantic import SecretStr

from sanour_ai.providers.offline_contract import OfflineTestProvider
from sanour_ai.composition import production
from sanour_ai.composition.runtime import Runtime, RuntimeState
from sanour_ai.config import governance
from sanour_ai.config.settings import ConfigError
from sanour_ai.models.base import ModelCall, ModelResult, ProviderError
from sanour_ai.models.capabilities import ModelCapabilities, ModelProfile, ProviderCapabilities
from sanour_ai.models.gateway import ModelGateway
from sanour_ai.providers import openai_provider as op
from sanour_ai.providers.registry import ProviderRegistry, RegistryError
from tests.support import production_ledger_path

SRC = pathlib.Path(__file__).resolve().parents[2] / "src" / "sanour_ai"
SECRET = "STAGE1033R1-SECRET-KEY-ZX"  # fake, test-only
MODEL = "gpt-test-r1"
PROFILE = "openai_primary"


def env(**overrides):
    base = {
        "SANOUR_PROVIDER": "openai",
        "SANOUR_OPENAI_MODEL_ID": MODEL,
        "SANOUR_OPENAI_MAX_CONTEXT_TOKENS": "8192",
        "SANOUR_OPENAI_MAX_OUTPUT_TOKENS": "1024",
        "OPENAI_API_KEY": SECRET,
    }
    for name, value in overrides.items():
        if value is None:
            base.pop(name, None)
        else:
            base[name] = value
    return base


class FakeOpenAI(OfflineTestProvider):
    """Adapter stand-in with the real adapter's surface. Counts construction and close."""

    name = "openai"
    vendor = "openai"
    surface = "openai_responses"
    auth_method = "sdk_bearer_client"
    capabilities = ProviderCapabilities(text_generation=True)
    constructed = 0
    closes = 0
    close_error = None
    gate = None  # optional threading.Event: generate() waits on it (bounded)
    entered = None  # set when generate() starts
    calls: list = []
    raise_detail = None  # ProviderError detail text, to prove it never reaches callers

    def __init__(self, api_key):
        FakeOpenAI.constructed += 1
        self.key = api_key

    def generate(self, call):
        FakeOpenAI.calls.append(call.model_id)
        if FakeOpenAI.entered is not None:
            FakeOpenAI.entered.set()
        if FakeOpenAI.gate is not None:
            FakeOpenAI.gate.wait(5.0)
        if FakeOpenAI.raise_detail is not None:
            raise ProviderError(FakeOpenAI.raise_detail, retryable=False)
        return ModelResult(text="fake", reported_model_id=call.model_id)

    def close(self):
        FakeOpenAI.closes += 1
        if FakeOpenAI.close_error is not None:
            raise FakeOpenAI.close_error


class Base(unittest.TestCase):
    def setUp(self):
        FakeOpenAI.constructed = 0
        FakeOpenAI.closes = 0
        FakeOpenAI.close_error = None
        FakeOpenAI.gate = None
        FakeOpenAI.entered = None
        FakeOpenAI.calls = []
        FakeOpenAI.raise_detail = None
        self._patches = [
            mock.patch.object(production, "OpenAIProvider", FakeOpenAI), mock.patch.object(production, "_default_test_provider", lambda: FakeOpenAI("test")),
            mock.patch.object(production, "_sdk_present", return_value=True),
        ]
        for p in self._patches:
            p.start()
            self.addCleanup(p.stop)

    def build(self, environ=None):
        return Runtime.build_for_tests(env() if environ is None else environ)


# ---------------------------------------------------------------- one production entry path
class ProductionEntryTests(Base):
    def test_runtime_build_goes_through_the_governed_loader_and_assembler(self):
        from sanour_ai.composition import runtime as runtime_mod

        real_loader = runtime_mod.load_runtime_config
        real_assemble = runtime_mod.build_core_and_registry
        with mock.patch.object(runtime_mod, "load_runtime_config", wraps=real_loader) as loader, \
                mock.patch.object(runtime_mod, "build_core_and_registry", wraps=real_assemble) as assemble:
            with self.assertRaises(ConfigError):  # production entry: the gate refuses an unverified model
                Runtime.build(env(), usage_ledger_path=production_ledger_path())
        loader.assert_called_once()
        assemble.assert_called_once()
        self.assertIsInstance(assemble.call_args.args[0], governance.RuntimeConfig)

    def test_build_production_core_shares_the_same_assembler(self):
        with mock.patch.object(production, "build_core_and_registry",
                               wraps=production.build_core_and_registry) as assemble:
            with self.assertRaises(ConfigError):  # same assembler, refused by the production gate
                production.build_production_core(env())
        assemble.assert_called_once()

    def test_assembler_refuses_anything_but_a_governed_configuration(self):
        with self.assertRaises(ConfigError):
            production.build_test_core_and_registry({"provider": "openai"})  # type: ignore[arg-type]
        self.assertEqual(FakeOpenAI.constructed, 0)

    def test_no_configuration_means_no_adapter_is_ever_created(self):
        for bad in (env(SANOUR_PROVIDER=None), env(SANOUR_OPENAI_MODEL_ID="bad model"),
                    env(OPENAI_API_KEY=None), env(OPENAI_BASE_URL="https://x.example/v1")):
            with self.subTest(bad=sorted(bad)):
                with self.assertRaises(ConfigError):
                    self.build(bad)
        self.assertEqual(FakeOpenAI.constructed, 0)

    def test_failure_after_adapter_creation_closes_it_and_produces_no_runtime(self):
        with mock.patch.object(production.ProviderRegistry, "validate_profile",
                               side_effect=RegistryError("refused")):
            with self.assertRaises(ConfigError):
                self.build()
        self.assertEqual(FakeOpenAI.constructed, 1)
        self.assertEqual(FakeOpenAI.closes, 1)  # not left open behind a failed build

    def test_failure_in_assembly_also_closes_the_adapter(self):
        with mock.patch.object(production, "_assemble", side_effect=ConfigError("bad")):
            with self.assertRaises(ConfigError):
                self.build()
        self.assertEqual(FakeOpenAI.closes, 1)

    def test_runtime_refuses_direct_construction_of_configuration(self):
        with self.assertRaises(ConfigError):
            governance.RuntimeConfig(
                provider="openai", model_id=MODEL, max_context_tokens=8, max_output_tokens=4,
                max_concurrent_provider_calls=1, provider_limits=(), api_key=SecretStr(SECRET),
            )

    def test_a_copy_of_a_valid_configuration_is_checked_again(self):
        valid = governance.load_runtime_config(env())
        with self.assertRaises(ConfigError):
            dataclasses.replace(valid, max_output_tokens=valid.max_context_tokens + 1)
        with self.assertRaises(ConfigError):
            dataclasses.replace(valid, provider="anthropic")
        self.assertIsInstance(dataclasses.replace(valid, max_output_tokens=16), governance.RuntimeConfig)


# ---------------------------------------------------------------- one owner of environment settings
class ConfigurationOwnershipTests(Base):
    def test_one_implementation_of_the_environment_policy(self):
        self.assertIs(op.check_environment, governance.check_environment)
        self.assertIs(op.load_api_key, governance.load_api_key)
        self.assertIs(op.BLOCKED_ENV_VARS, governance.BLOCKED_ENV_VARS)

    def test_provider_module_defines_no_second_reader(self):
        text = (SRC / "providers" / "openai_provider.py").read_text(encoding="utf-8")
        self.assertIsNone(re.search(r"^def (check_environment|load_api_key)\b", text, re.M))
        self.assertIsNone(re.search(r"os\.environ|os\.getenv", text))

    def test_production_path_modules_never_read_the_environment_themselves(self):
        # The production path is composition, core, models, config and the OpenAI adapter.
        # Only governance and settings may read the environment there.
        production_dirs = ("composition", "core", "models", "config", "observability", "security")
        readers = set()
        for path in SRC.rglob("*.py"):
            rel = path.relative_to(SRC).as_posix()
            if not rel.startswith(production_dirs) and rel != "providers/openai_provider.py":
                continue
            if re.search(r"os\.environ|os\.getenv", path.read_text(encoding="utf-8")):
                readers.add(rel)
        self.assertEqual(readers, {"config/governance.py", "config/settings.py"})

    def test_unwired_provider_key_loaders_are_not_on_the_production_path(self):
        # Known limit: anthropic, gemini and grok keep their own key loaders. They are not wired
        # into any composition root, so they cannot affect a production Runtime (see README).
        for path in (SRC / "composition").rglob("*.py"):
            text = path.read_text(encoding="utf-8")
            for name in ("anthropic_provider", "gemini_provider", "grok_provider", "xai_responses_provider"):
                self.assertNotIn(name, text, path.name)

    def test_settings_parsers_are_called_only_from_governance(self):
        callers = set()
        for path in SRC.rglob("*.py"):
            text = path.read_text(encoding="utf-8")
            if re.search(r"\bload_settings\(", text) and path.name != "settings.py":
                callers.add(path.relative_to(SRC).as_posix())
        self.assertEqual(callers, {"config/governance.py"})

    def test_provider_rejects_a_blocked_environment_through_the_shared_guard(self):
        with mock.patch.dict(os.environ, {"OPENAI_ORG_ID": "org-x"}):
            with self.assertRaises(ConfigError) as ctx:
                governance.check_environment()
        self.assertIn("OPENAI_ORG_ID", str(ctx.exception))
        self.assertNotIn("org-x", str(ctx.exception))


# ---------------------------------------------------------------- no secret leaks
class SecretExposureTests(Base):
    def test_secret_never_appears_in_runtime_views_or_reload_reports(self):
        rt = self.build()
        blob = repr(rt) + repr(rt.describe()) + repr(rt._config) + str(rt.describe())  # noqa: SLF001
        blob += repr(rt.check_reload(env()))
        blob += repr(rt.core_stats())
        self.assertNotIn(SECRET, blob)

    def test_secret_never_appears_in_build_errors(self):
        for bad in (env(SANOUR_OPENAI_MODEL_ID="bad model " + SECRET),
                    env(SANOUR_OPENAI_MAX_CONTEXT_TOKENS=SECRET),
                    env(SANOUR_PROVIDER_CONCURRENCY="openai=" + SECRET)):
            with self.subTest(bad=sorted(bad)):
                with self.assertRaises(ConfigError) as ctx:
                    self.build(bad)
                self.assertNotIn(SECRET, str(ctx.exception))

    def test_provider_error_detail_and_secret_stay_out_of_response_and_audit(self):
        rt = self.build()
        FakeOpenAI.raise_detail = "upstream said key " + SECRET
        with self.assertLogs("sanour_ai.audit", level=logging.INFO) as logs:
            resp = rt.handle({"profile_alias": PROFILE, "prompt": "hi", "timeout_seconds": 5})
        self.assertEqual(resp.status, "error")
        self.assertNotIn(SECRET, repr(resp.model_dump()))
        self.assertNotIn(SECRET, "\n".join(logs.output))


# ---------------------------------------------------------------- shutdown and registry coherence
class ShutdownCoordinationTests(Base):
    def test_shutdown_reports_the_registry_state_exactly(self):
        rt = self.build()
        states = rt.shutdown(0.1)
        self.assertEqual(states, rt._registry.states())  # noqa: SLF001
        self.assertEqual(states, {"openai": "closed"})
        self.assertEqual(rt.state, RuntimeState.SHUTDOWN)

    def test_shutdown_is_idempotent_and_closes_once(self):
        rt = self.build()
        first = rt.shutdown(0.1)
        second = rt.shutdown(0.1)
        third = rt.shutdown(0.1)
        self.assertEqual(first, second)
        self.assertEqual(second, third)
        self.assertEqual(FakeOpenAI.closes, 1)

    def test_busy_worker_keeps_provider_closing_until_it_really_ends(self):
        rt = self.build()
        FakeOpenAI.gate = threading.Event()
        FakeOpenAI.entered = threading.Event()
        resp = rt.handle({"profile_alias": PROFILE, "prompt": "hi", "timeout_seconds": 0.05})
        self.assertEqual(resp.error.code.value, "provider_timeout")
        self.assertTrue(FakeOpenAI.entered.wait(2.0))
        states = rt.shutdown(0.05)
        self.assertEqual(states, {"openai": "closing"})
        self.assertEqual(rt._registry.states(), {"openai": "closing"})  # noqa: SLF001
        self.assertEqual(FakeOpenAI.closes, 0)  # not closed under a live worker
        self.assertEqual(rt._core._gateway.in_flight, 1)  # noqa: SLF001 - capacity still held

        FakeOpenAI.gate.set()
        deadline = time.monotonic() + 3.0
        while time.monotonic() < deadline and rt._core._gateway.in_flight:  # noqa: SLF001
            time.sleep(0.01)
        self.assertEqual(rt._core._gateway.in_flight, 0)  # noqa: SLF001
        self.assertEqual(rt.shutdown(0.1), {"openai": "closed"})
        self.assertEqual(FakeOpenAI.closes, 1)

    def test_requests_are_refused_after_shutdown_and_no_new_provider_call_happens(self):
        rt = self.build()
        rt.shutdown(0.1)
        resp = rt.handle({"profile_alias": PROFILE, "prompt": "hi"})
        self.assertEqual(resp.status, "error")
        self.assertEqual(FakeOpenAI.calls, [])

    def test_runtime_does_not_reach_into_private_core_or_gateway_fields(self):
        text = (SRC / "composition" / "runtime.py").read_text(encoding="utf-8")
        self.assertNotIn("_core._gateway", text)
        self.assertNotIn("SLF001", text)
        self.assertIn("shutdown_target()", text)


def _fake_adapter(pid, *, close_error=None, log=None):
    class _Adapter:
        name = pid
        capabilities = ProviderCapabilities(text_generation=True)

        def generate(self, call):
            return ModelResult(text="ok", reported_model_id=call.model_id)

        def close(self):
            if log is not None:
                log.append(pid)
            if close_error is not None:
                raise close_error

    return _Adapter()


class ShutdownIsolationTests(unittest.TestCase):
    """Registry-level: a failing close on one provider never blocks the others."""

    def _registry(self, adapters):
        registry = ProviderRegistry()
        for pid, adapter in adapters.items():
            registry.register(pid, vendor="openai", surface="openai_responses", adapter=adapter)
            registry.initialize(pid)
        return registry

    def test_one_failing_close_does_not_stop_the_other_providers(self):
        log = []
        adapters = {
            "alpha": _fake_adapter("alpha", close_error=RuntimeError("boom"), log=log),
            "beta": _fake_adapter("beta", log=log),
            "gamma": _fake_adapter("gamma", log=log),
        }
        registry = self._registry(adapters)
        gateway = ModelGateway(registry.ready_providers(), max_concurrent_calls=2)
        states = registry.shutdown(gateway, 0.1)
        self.assertEqual(states, {"alpha": "failed", "beta": "closed", "gamma": "closed"})
        self.assertEqual(sorted(log), ["alpha", "beta", "gamma"])

    def test_direct_close_path_is_isolated_too(self):
        log = []
        registry = ProviderRegistry()
        registry.register("alpha", vendor="openai", surface="openai_responses",
                          adapter=_fake_adapter("alpha", close_error=RuntimeError("x"), log=log))
        registry.register("beta", vendor="openai", surface="openai_responses",
                          adapter=_fake_adapter("beta", log=log))
        gateway = ModelGateway({}, max_concurrent_calls=1)
        states = registry.shutdown(gateway, 0.1)  # neither was initialized: both closed directly
        self.assertEqual(states, {"alpha": "failed", "beta": "closed"})
        self.assertEqual(sorted(log), ["alpha", "beta"])

    def test_repeated_shutdown_never_closes_a_provider_twice(self):
        log = []
        registry = self._registry({"alpha": _fake_adapter("alpha", close_error=RuntimeError("x"), log=log)})
        gateway = ModelGateway(registry.ready_providers(), max_concurrent_calls=1)
        registry.shutdown(gateway, 0.1)
        again = registry.shutdown(gateway, 0.1)
        self.assertEqual(again, {"alpha": "failed"})
        self.assertEqual(log, ["alpha"])

    def test_gateway_is_the_only_shutdown_interface_the_registry_needs(self):
        registry = self._registry({"alpha": _fake_adapter("alpha")})
        gateway = ModelGateway(registry.ready_providers(), max_concurrent_calls=1)
        self.assertTrue(callable(gateway.shutdown))
        self.assertTrue(callable(gateway.provider_state))
        self.assertEqual(registry.shutdown(gateway, 0.1), {"alpha": "closed"})


# ---------------------------------------------------------------- preserved behaviour
class PreservedBehaviourTests(Base):
    def test_one_profile_no_fallback_and_one_attempt(self):
        rt = self.build()
        resp = rt.handle({"profile_alias": "not_a_profile", "prompt": "hi"})
        self.assertEqual(resp.status, "error")
        self.assertEqual(FakeOpenAI.calls, [])
        resp = rt.handle({"profile_alias": PROFILE, "prompt": "hi"})
        self.assertEqual(resp.status, "success")
        self.assertEqual(FakeOpenAI.calls, [MODEL])  # exactly one attempt

    def test_worker_cap_from_configuration_is_still_enforced(self):
        rt = self.build(env(SANOUR_MAX_CONCURRENT_PROVIDER_CALLS="1"))
        self.assertEqual(rt._core._gateway._slots._value, 1)  # noqa: SLF001
        self.assertEqual(rt.describe()["capacity"]["max_concurrent_provider_calls"], 1)

    def test_xai_responses_is_not_active_in_production(self):
        rt = self.build()
        self.assertEqual(set(rt._registry.states()), {"openai"})  # noqa: SLF001

    def test_no_stage_1034_surface_is_exposed(self):
        self.assertFalse(hasattr(Runtime, "stream"))
        self.assertFalse(hasattr(Runtime, "reload"))  # reload is only check_reload (report only)


if __name__ == "__main__":
    unittest.main()
