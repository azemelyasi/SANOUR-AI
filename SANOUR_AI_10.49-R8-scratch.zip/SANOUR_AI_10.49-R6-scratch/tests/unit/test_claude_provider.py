"""Anthropic adapter tests. Fake transport only: no network, no real key, no SDK."""

from tests.support import request_identity_for as _rid
import json
import time
import unittest
import urllib.error
import urllib.request

from pydantic import SecretStr

from sanour_ai.config.settings import ConfigError
from sanour_ai.errors import ErrorCode, SanourError
from sanour_ai.models.base import ModelCall, ModelResult, ProviderError
from sanour_ai.models.capabilities import ModelCapabilities, ModelProfile, ProviderCapabilities
from sanour_ai.models.gateway import ModelGateway
from sanour_ai.providers.anthropic_provider import (
    ANTHROPIC_VERSION,
    PINNED_URL,
    AnthropicProvider,
    _RefuseRedirects,
    load_anthropic_api_key,
)

FAKE_KEY = "sk-ant-TESTONLY-0123456789"


class FakeTransport:
    def __init__(self, status=200, body=None, raise_exc=None):
        self.status = status
        self.body = body if body is not None else self._ok_body()
        self.raise_exc = raise_exc
        self.calls = []

    @staticmethod
    def _ok_body(text="hello", model="claude-test-1"):
        return json.dumps({"model": model, "stop_reason": "end_turn",
                           "content": [{"type": "text", "text": text}]}).encode("utf-8")

    def __call__(self, url, headers, body, timeout):
        self.calls.append({"url": url, "headers": headers, "body": body, "timeout": timeout})
        if self.raise_exc is not None:
            raise self.raise_exc
        return self.status, self.body


def call(deadline_in=5.0, model="claude-test-1", max_tokens=64, prompt="hi"):
    return ModelCall(model_id=model, prompt=prompt, max_output_tokens=max_tokens,
                     deadline=time.monotonic() + deadline_in)


def make(transport):
    return AnthropicProvider(SecretStr(FAKE_KEY), transport=transport)


class CapabilityDeclarationTests(unittest.TestCase):
    def test_declares_only_text_generation(self):
        self.assertEqual(AnthropicProvider.capabilities, ProviderCapabilities(text_generation=True))
        self.assertEqual(AnthropicProvider.name, "anthropic")


class AuthenticationTests(unittest.TestCase):
    def test_key_read_from_environment_and_stripped(self):
        self.assertEqual(load_anthropic_api_key({"ANTHROPIC_API_KEY": "  abc  "}).get_secret_value(), "abc")

    def test_missing_or_blank_key_names_setting_not_value(self):
        for env in ({}, {"ANTHROPIC_API_KEY": "   "}):
            with self.subTest(env=env), self.assertRaises(ConfigError) as ctx:
                load_anthropic_api_key(env)
            self.assertIn("ANTHROPIC_API_KEY", str(ctx.exception))

    def test_adapter_requires_secret_str_with_content(self):
        with self.assertRaises(ConfigError):
            AnthropicProvider("plain-string-key", transport=FakeTransport())
        with self.assertRaises(ConfigError):
            AnthropicProvider(SecretStr("  "), transport=FakeTransport())


class RequestShapeTests(unittest.TestCase):
    def test_pinned_endpoint_headers_and_body(self):
        t = FakeTransport()
        make(t).generate(call(model="claude-test-1", max_tokens=64, prompt="ping"))
        sent = t.calls[0]
        self.assertEqual(sent["url"], PINNED_URL)
        self.assertEqual(sent["headers"]["x-api-key"], FAKE_KEY)
        self.assertEqual(sent["headers"]["anthropic-version"], ANTHROPIC_VERSION)
        self.assertEqual(sent["headers"]["content-type"], "application/json")
        self.assertEqual(json.loads(sent["body"]), {
            "model": "claude-test-1", "max_tokens": 64,
            "messages": [{"role": "user", "content": "ping"}],
        })

    def test_timeout_is_min_of_cap_and_remaining_budget(self):
        t = FakeTransport()
        make(t).generate(call(deadline_in=2.0))
        self.assertLessEqual(t.calls[0]["timeout"], 2.0)
        self.assertGreater(t.calls[0]["timeout"], 1.0)

    def test_missing_deadline_is_refused_before_io(self):
        t = FakeTransport()
        with self.assertRaises(ProviderError) as ctx:
            make(t).generate(ModelCall(model_id="m", prompt="p", max_output_tokens=8, deadline=None))
        self.assertFalse(ctx.exception.retryable)
        self.assertEqual(t.calls, [])

    def test_expired_deadline_makes_no_call(self):
        t = FakeTransport()
        with self.assertRaises(ProviderError) as ctx:
            make(t).generate(ModelCall(model_id="m", prompt="p", max_output_tokens=8,
                                       deadline=time.monotonic() - 1))
        self.assertTrue(ctx.exception.retryable)
        self.assertEqual(t.calls, [])


class ResponseParsingTests(unittest.TestCase):
    def test_text_blocks_are_joined_and_model_echoed(self):
        body = json.dumps({"model": "claude-test-1", "stop_reason": "end_turn", "content": [
            {"type": "text", "text": "one "}, {"type": "tool_use", "id": "x"}, {"type": "text", "text": "two"},
        ]}).encode()
        result = make(FakeTransport(body=body)).generate(call())
        self.assertEqual(result, ModelResult(text="one two", reported_model_id="claude-test-1"))

    def test_malformed_or_non_text_body_yields_empty_result_for_gateway_to_reject(self):
        for body in (b"not json", b"[]", json.dumps({"model": "m", "stop_reason": "end_turn", "content": [{"type": "image"}]}).encode()):
            with self.subTest(body=body):
                result = make(FakeTransport(body=body)).generate(call())
                self.assertEqual(result.text, "")

    def test_oversized_response_is_refused(self):
        with self.assertRaises(ProviderError):
            make(FakeTransport(body=b"x" * 2_000_001)).generate(call())


class ErrorMappingTests(unittest.TestCase):
    CASES = [
        (429, False, None),  # Stage 10.28: an empty body is unknown, so not retryable
        (401, False, None),
        (403, False, None),
        (404, False, None),
        (400, False, None),
        (500, True, None),
        (503, True, None),
        (529, True, None),
        (418, False, None),
    ]

    def test_status_codes_map_to_expected_retryability(self):
        for status, retryable, error_code in self.CASES:
            with self.subTest(status=status):
                with self.assertRaises(ProviderError) as ctx:
                    make(FakeTransport(status=status, body=b"")).generate(call())
                self.assertEqual(ctx.exception.retryable, retryable)
                self.assertEqual(getattr(ctx.exception, "error_code", None), error_code)

    def test_network_failure_is_retryable_and_hides_details(self):
        t = FakeTransport(raise_exc=urllib.error.URLError("dns failed for internal-host sk-ant-LEAK"))
        with self.assertRaises(ProviderError) as ctx:
            make(t).generate(call())
        self.assertTrue(ctx.exception.retryable)
        self.assertNotIn("LEAK", str(ctx.exception))

    def test_error_body_and_key_never_reach_exception_text(self):
        t = FakeTransport(status=401, body=b'{"error": "bad key sk-ant-SECRETBODY"}')
        with self.assertRaises(ProviderError) as ctx:
            make(t).generate(call())
        text = str(ctx.exception) + repr(ctx.exception)
        self.assertNotIn("SECRETBODY", text)
        self.assertNotIn(FAKE_KEY, text)

    def test_redirects_are_refused(self):
        handler = _RefuseRedirects()
        with self.assertRaises(urllib.error.HTTPError):
            handler.redirect_request(urllib.request.Request(PINNED_URL), None, 302, "Found", {},
                                     "https://evil.example/")


class GatewayIntegrationTests(unittest.TestCase):
    PROFILE = ModelProfile(
        alias="claude_primary",
        provider="anthropic",
        model_id="claude-test-1",
        capabilities=ModelCapabilities(text_generation=True, max_context_tokens=8192, max_output_tokens=4096),
        runs_locally=False,
    )

    def _gateway(self, transport):
        return ModelGateway({"anthropic": make(transport)}, max_concurrent_calls=2)

    def test_success_through_gateway(self):
        gw = self._gateway(FakeTransport())
        result = gw.generate(self.PROFILE, call(), time.monotonic() + 5, identity=_rid(self.PROFILE))
        self.assertEqual(result.text, "hello")

    def test_unknown_rate_limit_through_gateway_is_one_attempt_and_failed(self):
        t = FakeTransport(status=429, body=b"")
        gw = self._gateway(t)
        with self.assertRaises(SanourError) as ctx:
            gw.generate(self.PROFILE, call(), time.monotonic() + 5, identity=_rid(self.PROFILE))
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_FAILED)
        self.assertFalse(ctx.exception.retryable)
        self.assertEqual(len(t.calls), 1)

    def test_wrong_model_echo_is_rejected_by_gateway(self):
        t = FakeTransport(body=FakeTransport._ok_body(model="claude-other-9"))
        with self.assertRaises(SanourError) as ctx:
            self._gateway(t).generate(self.PROFILE, call(), time.monotonic() + 5, identity=_rid(self.PROFILE))
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_INVALID_RESPONSE)

    def test_shutdown_closes_nothing_and_refuses_later_calls(self):
        gw = self._gateway(FakeTransport())
        self.assertEqual(gw.shutdown(timeout=0.1), 0)
        with self.assertRaises(SanourError):
            gw.generate(self.PROFILE, call(), time.monotonic() + 5, identity=_rid(self.PROFILE))


if __name__ == "__main__":
    unittest.main()
