"""Stage 10.16-A tests: explicit profile_alias, exact resolution, dual-level capacity. Mock only."""

from tests.support import request_identity_for as _rid
import threading
import time
import unittest
from tests.support import TEST_ALL_CAPS

from sanour_ai.errors import ErrorCode, SanourError
from sanour_ai.core.request_manager import accept
from sanour_ai.core.sanour_core import SanourCore
from sanour_ai.models.base import ModelCall, ModelResult
from sanour_ai.models.capabilities import ModelCapabilities, ModelProfile
from sanour_ai.models.gateway import ModelGateway
from sanour_ai.models.router import DeterministicRouter
from sanour_ai.observability.audit import AuditLogger
from tests.support import GatedProvider, deadline_in, wait_until

RID = "c" * 32


def profile(alias, provider, priority=100, max_output=4096):
    return ModelProfile(
        alias=alias,
        provider=provider,
        model_id=f"{alias}-id",
        capabilities=ModelCapabilities(
            text_generation=True, max_context_tokens=8192, max_output_tokens=max_output
        ),
        runs_locally=True,
        priority=priority,
    )


class CountingProvider:
    capabilities = TEST_ALL_CAPS
    def __init__(self, name):
        self.name = name
        self.calls = 0

    def generate(self, call):
        self.calls += 1
        return ModelResult(text=f"{self.name}:{call.prompt}", reported_model_id=call.model_id)


def make_core(providers, profiles, max_concurrent=4):
    return SanourCore(
        router=DeterministicRouter(profiles),
        gateway=ModelGateway(providers, max_concurrent_calls=max_concurrent),
        audit=AuditLogger(),
    )


def call_for(profile_obj):
    return ModelCall(model_id=profile_obj.model_id, prompt="hi", max_output_tokens=16, deadline=None)


class ExplicitAliasTests(unittest.TestCase):
    def test_missing_profile_alias_is_rejected(self):
        with self.assertRaises(SanourError) as ctx:
            accept({"prompt": "hi"}, RID)
        self.assertEqual(ctx.exception.code, ErrorCode.INVALID_REQUEST)

    def test_malformed_profile_alias_is_rejected(self):
        for bad in ("", "Has Space", "x", "a/b", "A_B", "x" * 65):
            with self.subTest(bad=bad), self.assertRaises(SanourError):
                accept({"profile_alias": bad, "prompt": "hi"}, RID)

    def test_exact_alias_wins_over_higher_priority_profile(self):
        a, b = CountingProvider("alpha"), CountingProvider("beta")
        core = make_core(
            {"alpha": a, "beta": b},
            [profile("first_model", "alpha", priority=1), profile("second_model", "beta", priority=2)],
        )
        resp = core.handle({"profile_alias": "second_model", "prompt": "hi"})
        self.assertEqual(resp.status, "success")
        self.assertEqual(resp.model_alias, "second_model")
        self.assertEqual((a.calls, b.calls), (0, 1))

    def test_unknown_alias_is_never_substituted(self):
        a = CountingProvider("alpha")
        core = make_core({"alpha": a}, [profile("only_model", "alpha")])
        resp = core.handle({"profile_alias": "missing_model", "prompt": "hi"})
        self.assertEqual(resp.error.code, ErrorCode.NO_ELIGIBLE_MODEL)
        self.assertEqual(a.calls, 0)

    def test_unsuitable_named_profile_does_not_fall_back_to_another(self):
        small, large = CountingProvider("small"), CountingProvider("large")
        core = make_core(
            {"small": small, "large": large},
            [profile("small_model", "small", max_output=100), profile("large_model", "large")],
        )
        resp = core.handle({"profile_alias": "small_model", "prompt": "hi", "max_output_tokens": 512})
        self.assertEqual(resp.error.code, ErrorCode.NO_ELIGIBLE_MODEL)
        self.assertEqual((small.calls, large.calls), (0, 0))


class DualCapacityTests(unittest.TestCase):
    def _gateway(self, max_concurrent, provider_limits=None):
        self.gated_a = GatedProvider("alpha")
        self.gated_b = GatedProvider("beta")
        return ModelGateway(
            {"alpha": self.gated_a, "beta": self.gated_b},
            max_concurrent_calls=max_concurrent,
            provider_limits=provider_limits,
        )

    def _start_blocking(self, gateway, profile_obj):
        outcome = {}

        def run():
            try:
                outcome["result"] = gateway.generate(profile_obj, call_for(profile_obj), deadline_in(5.0), identity=_rid(profile_obj))
            except SanourError as exc:
                outcome["error"] = exc

        thread = threading.Thread(target=run, daemon=True)
        thread.start()
        return thread, outcome

    def test_provider_limit_blocks_second_call_to_same_provider(self):
        gw = self._gateway(3, {"alpha": 1})
        pa, pb = profile("a_model", "alpha"), profile("b_model", "beta")
        thread, _ = self._start_blocking(gw, pa)
        self.assertTrue(wait_until(lambda: gw.in_flight == 1))
        with self.assertRaises(SanourError) as ctx:
            gw.generate(pa, call_for(pa), deadline_in(2.0), identity=_rid(pa))
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_OVERLOADED)
        # Another provider is not blocked by a's private cap (global cap 3 still has room).
        self.gated_b.release_all()
        self.assertEqual(gw.generate(pb, call_for(pb), deadline_in(2.0), identity=_rid(pb)).reported_model_id, "b_model-id")
        self.gated_a.release_all()
        thread.join(timeout=3)

    def test_global_cap_blocks_other_providers(self):
        gw = self._gateway(1)
        pa, pb = profile("a_model", "alpha"), profile("b_model", "beta")
        thread, _ = self._start_blocking(gw, pa)
        self.assertTrue(wait_until(lambda: gw.in_flight == 1))
        with self.assertRaises(SanourError) as ctx:
            gw.generate(pb, call_for(pb), deadline_in(2.0), identity=_rid(pb))
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_OVERLOADED)
        self.gated_a.release_all()
        thread.join(timeout=3)

    def test_rejected_provider_slot_returns_global_slot(self):
        gw = self._gateway(1, {"alpha": 1})
        pa, pb = profile("a_model", "alpha"), profile("b_model", "beta")
        thread, _ = self._start_blocking(gw, pa)
        self.assertTrue(wait_until(lambda: gw.in_flight == 1))
        with self.assertRaises(SanourError):
            gw.generate(pa, call_for(pa), deadline_in(2.0), identity=_rid(pa))  # provider cap full, must not leak global
        self.gated_a.release_all()
        thread.join(timeout=3)
        self.assertTrue(wait_until(lambda: gw.in_flight == 0))
        self.gated_b.release_all()
        self.assertEqual(gw.generate(pb, call_for(pb), deadline_in(2.0), identity=_rid(pb)).reported_model_id, "b_model-id")

    def test_provider_slot_held_until_worker_really_returns(self):
        gw = self._gateway(2, {"alpha": 1})
        pa = profile("a_model", "alpha")
        outcome = {}

        def run():
            try:
                gw.generate(pa, call_for(pa), deadline_in(0.2), identity=_rid(pa))  # caller gives up while worker blocks
            except SanourError as exc:
                outcome["error"] = exc

        thread = threading.Thread(target=run, daemon=True)
        thread.start()
        thread.join(timeout=3)
        self.assertEqual(outcome["error"].code, ErrorCode.PROVIDER_TIMEOUT)
        # Worker still blocked: provider slot must remain held.
        with self.assertRaises(SanourError) as ctx:
            gw.generate(pa, call_for(pa), deadline_in(2.0), identity=_rid(pa))
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_OVERLOADED)
        self.gated_a.release_all()
        self.assertTrue(wait_until(lambda: gw.in_flight == 0))
        self.assertEqual(gw.generate(pa, call_for(pa), deadline_in(2.0), identity=_rid(pa)).reported_model_id, "a_model-id")

    def test_invalid_provider_limits_rejected(self):
        bad_cases = [
            {"alpha": 0},
            {"alpha": 3},
            {"alpha": True},
            {"alpha": "1"},
            {"ghost": 1},
        ]
        for limits in bad_cases:
            with self.subTest(limits=limits), self.assertRaises(ValueError):
                ModelGateway(
                    {"alpha": CountingProvider("alpha")}, max_concurrent_calls=2, provider_limits=limits
                )

    def test_default_provider_limit_equals_global(self):
        gw = ModelGateway({"alpha": CountingProvider("alpha")}, max_concurrent_calls=3)
        self.assertEqual(gw._provider_slots["alpha"]._value, 3)


if __name__ == "__main__":
    unittest.main()
