"""Stage 10.46-R2: test factories are isolated from real adapters, and production stays gated.

Offline only. The real OpenAI adapter is guarded: constructing it, or building its SDK client,
raises AssertionError, so any leak fails the test. No key, no network, no SDK.
"""

import os
import unittest
from unittest import mock

from sanour_ai.composition import production
from sanour_ai.composition.runtime import Runtime
from sanour_ai.config.governance import load_offline_test_config
from sanour_ai.config.settings import ConfigError
from sanour_ai.models import production_gate
from sanour_ai.models.base import ModelResult
from sanour_ai.models.capabilities import ProviderCapabilities
from sanour_ai.providers import openai_provider
from sanour_ai.providers.offline_contract import OfflineTestProvider
from tests.support import production_ledger_path

SECRET = "R2-SECRET-KEY-DO-NOT-USE-ZZ"
MODEL = "gpt-r2-test"
ALIAS = "openai_primary"


def env(**extra):
    base = {
        "SANOUR_PROVIDER": "openai",
        "SANOUR_OPENAI_MODEL_ID": MODEL,
        "SANOUR_OPENAI_MAX_CONTEXT_TOKENS": "8192",
        "SANOUR_OPENAI_MAX_OUTPUT_TOKENS": "1024",
        "OPENAI_API_KEY": SECRET,
    }
    base.update(extra)
    return base


class InjectedFake(OfflineTestProvider):
    """A test double supplied explicitly. Records calls; never touches the network."""

    name = "openai"
    vendor = "openai"
    surface = "openai_responses"
    auth_method = "sdk_bearer_client"
    capabilities = ProviderCapabilities(text_generation=True)

    def __init__(self, text="injected fake"):
        self.text = text
        self.calls = []

    def initialize(self):
        pass

    def generate(self, call):
        self.calls.append(call.model_id)
        return ModelResult(text=self.text, reported_model_id=call.model_id)

    def close(self):
        pass


class Guarded(unittest.TestCase):
    """Makes any real-adapter construction fail loudly, and records every attempt."""

    def setUp(self):
        self.real_constructions = []

        def refuse_init(self_, *args, **kwargs):
            self.real_constructions.append("init")
            raise AssertionError("real OpenAI adapter constructed")

        def refuse_client(*args, **kwargs):
            self.real_constructions.append("client")
            raise AssertionError("real SDK client built")

        for p in (
            mock.patch.object(openai_provider.OpenAIProvider, "__init__", refuse_init),
            mock.patch.object(openai_provider, "_build_default_client", refuse_client),
            mock.patch.object(production, "_sdk_present", return_value=True),
            mock.patch.dict(os.environ, {}, clear=False),
        ):
            p.start()
            self.addCleanup(p.stop)

    def assert_no_real_adapter(self):
        self.assertEqual(self.real_constructions, [])


class A_BuildForTestsIsolation(Guarded):
    def test_build_for_tests_cannot_construct_real_adapter(self):
        with mock.patch.dict(os.environ, env(), clear=True):
            rt = Runtime.build_for_tests()
            response = rt.handle({"profile_alias": ALIAS, "prompt": "hi"})
        self.assertEqual(response.status, "success")
        self.assert_no_real_adapter()


class B_BuildTestCoreIsolation(Guarded):
    def test_build_test_core_cannot_construct_real_adapter(self):
        with mock.patch.dict(os.environ, env(), clear=True):
            core = production.build_test_core()
            response = core.handle({"profile_alias": ALIAS, "prompt": "hi"})
        self.assertEqual(response.status, "success")
        self.assert_no_real_adapter()


class C_ProviderSettingDoesNotSelect(Guarded):
    def test_sanour_provider_openai_does_not_change_factory_behaviour(self):
        with mock.patch.dict(os.environ, env(), clear=True):
            rt_with = Runtime.build_for_tests()
            out_with = rt_with.handle({"profile_alias": ALIAS, "prompt": "hi"}).output
        with mock.patch.dict(os.environ, env(), clear=True), \
                mock.patch.object(production, "_default_test_provider",
                                  side_effect=production._default_test_provider) as seam:
            rt = Runtime.build_for_tests()
            out = rt.handle({"profile_alias": ALIAS, "prompt": "hi"}).output
        self.assertEqual(out_with, out)
        self.assertEqual(seam.call_count, 1)
        self.assert_no_real_adapter()


class D_SdkInstallDoesNotChange(Guarded):
    def test_factories_never_probe_the_sdk(self):
        probe = mock.patch.object(production, "_sdk_present", side_effect=AssertionError("probed"))
        probe.start()
        self.addCleanup(probe.stop)
        rt = Runtime.build_for_tests(env())
        core = production.build_test_core(env())
        self.assertEqual(rt.handle({"profile_alias": ALIAS, "prompt": "x"}).status, "success")
        self.assertEqual(core.handle({"profile_alias": ALIAS, "prompt": "x"}).status, "success")
        self.assert_no_real_adapter()

    def test_sdk_absent_or_present_gives_identical_test_behaviour(self):
        with mock.patch.object(production, "_sdk_present", return_value=False):
            absent = Runtime.build_for_tests(env()).handle({"profile_alias": ALIAS, "prompt": "x"}).output
        present = Runtime.build_for_tests(env()).handle({"profile_alias": ALIAS, "prompt": "x"}).output
        self.assertEqual(absent, present)


class E_InjectedFakesWork(Guarded):
    def test_injected_fake_serves_runtime_and_core(self):
        fake = InjectedFake("from the injected fake")
        rt = Runtime.build_for_tests(env(), provider=fake)
        self.assertEqual(rt.handle({"profile_alias": ALIAS, "prompt": "x"}).output, "from the injected fake")
        core = production.build_test_core(env(), provider=InjectedFake("core fake"))
        self.assertEqual(core.handle({"profile_alias": ALIAS, "prompt": "x"}).output, "core fake")
        self.assertEqual(fake.calls, [MODEL])
        self.assert_no_real_adapter()


class F_NoCredentialAccess(Guarded):
    def test_test_factory_never_reads_the_key_value(self):
        class Recording(dict):
            reads: list = []

            def __getitem__(self, key):
                Recording.reads.append(key)
                return super().__getitem__(key)

            def get(self, key, default=None):
                Recording.reads.append(key)
                return super().get(key, default)

        Recording.reads = []
        source = Recording(env())
        config = load_offline_test_config(source)
        self.assertNotIn("OPENAI_API_KEY", Recording.reads)
        self.assertNotEqual(config.api_key.get_secret_value(), SECRET)
        production.build_test_core(source, provider=InjectedFake())
        self.assertNotIn("OPENAI_API_KEY", Recording.reads)
        self.assert_no_real_adapter()


class G_ProductionRequiresGate(Guarded):
    def test_official_build_refused_without_approval(self):
        with mock.patch.dict(os.environ, env(), clear=True):
            with self.assertRaises(ConfigError):
                Runtime.build()
        self.assert_no_real_adapter()

    def test_official_build_refused_on_every_production_entry_point(self):
        from sanour_ai.config.governance import load_runtime_config
        for call in (
            lambda: production.build_production_core(env()),
            lambda: production.core_from_config(load_runtime_config(env())),
            lambda: production.build_core_and_registry(load_runtime_config(env())),
        ):
            with self.assertRaises(ConfigError):
                call()
        self.assert_no_real_adapter()

    def test_injection_is_refused_on_the_production_path(self):
        from sanour_ai.config.governance import load_runtime_config
        with self.assertRaises(ConfigError):
            production._build(load_runtime_config(env()), gated=True, provider=InjectedFake())
        self.assert_no_real_adapter()


class H_GateRefusalBeforeAdapter(Guarded):
    def test_gate_refusal_precedes_adapter_construction(self):
        with mock.patch.object(production_gate, "check",
                               side_effect=production_gate.ProductionGateRefused("x")):
            with self.assertRaises(ConfigError):
                Runtime.build(env(), usage_ledger_path=production_ledger_path())
        self.assert_no_real_adapter()


class I_NoSelectionOrFallback(Guarded):
    def test_only_one_provider_is_registered(self):
        rt = Runtime.build_for_tests(env())
        self.assertEqual(set(rt.stats()["providers"].keys()), {"openai"})
        self.assert_no_real_adapter()

    def test_mismatched_injected_name_is_refused_not_substituted(self):
        class Other(InjectedFake):
            name = "anthropic"
        with self.assertRaises(ConfigError):
            Runtime.build_for_tests(env(), provider=Other())

    def test_real_adapter_cannot_be_injected_into_test_factories(self):
        real = openai_provider.OpenAIProvider.__new__(openai_provider.OpenAIProvider)
        with self.assertRaises(ConfigError):
            Runtime.build_for_tests(env(), provider=real)
        with self.assertRaises(ConfigError):
            production.build_test_core(env(), provider=real)
        self.assert_no_real_adapter()
