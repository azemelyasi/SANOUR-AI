"""Stage 10.49-R5 test support: statement-level fault injection for SQLite connections, and child-process scripts.

Process death is simulated with os._exit at a chosen statement boundary. Child processes touch only temporary files.
"""

import os
import sqlite3


class RaiseOn:
    """Connection wrapper: a statement that starts with the prefix raises a storage error (nothing reaches SQLite)."""

    def __init__(self, real, prefix):
        self._real, self._prefix = real, prefix

    def execute(self, sql, *args):
        if sql.startswith(self._prefix):
            raise sqlite3.OperationalError("injected storage failure")
        return self._real.execute(sql, *args)

    def close(self):
        self._real.close()


class DieBefore:
    """Connection wrapper: the process dies (os._exit) just BEFORE the first statement with the prefix runs."""

    def __init__(self, real, prefix, code=7):
        self._real, self._prefix, self._code = real, prefix, code

    def execute(self, sql, *args):
        if sql.startswith(self._prefix):
            os._exit(self._code)
        return self._real.execute(sql, *args)

    def close(self):
        self._real.close()


class DieAfter(DieBefore):
    """Connection wrapper: the process dies (os._exit) just AFTER the first statement with the prefix returned."""

    def execute(self, sql, *args):
        out = self._real.execute(sql, *args)
        if sql.startswith(self._prefix):
            os._exit(self._code)
        return out


# Transaction boundaries of DurableSqliteSink.deliver, as statement prefixes.
SINK_POINTS = {
    "after_begin": ("before", "INSERT INTO audit_receipts"),
    "between_receipt_and_inbox": ("before", "INSERT INTO audit_inbox"),
    "before_commit": ("before", "COMMIT"),
    "after_commit": ("after", "COMMIT"),
}

SINK_DELIVER_CHILD = r'''
import os, sys
from sanour_ai.governance.sink import DurableSqliteSink
from tests.unit.r5_support import DieAfter, DieBefore, SINK_POINTS
sinkp, point, key = sys.argv[1:4]
where, prefix = SINK_POINTS[point]
s = DurableSqliteSink(sinkp)
wrap = DieBefore if where == "before" else DieAfter
s._conn = wrap(s._conn, prefix, 7)  # noqa: SLF001
s.deliver(key, "exposure.resolved", {"request_id": "r-atomic", "resolution": "write_off", "actor": "ops.alice",
                                     "decision": "applied"})
os._exit(0)  # reached only if the death point was never hit
'''

GOV_DELIVER_CHILD = r'''
import logging, os, sys
from sanour_ai.governance.store import GovernanceStore
from sanour_ai.governance.admission import AdmissionController
from sanour_ai.governance.sink import DurableSqliteSink
from sanour_ai.observability.audit import AuditLogger
from tests.unit.test_stage1049 import BOUNDS, Clock
from tests.unit.r5_support import DieAfter, DieBefore, SINK_POINTS
gov, sinkp, where_, point, rid = sys.argv[1:6]
where, prefix = SINK_POINTS[point] if where_ == "sink" else ("before", "UPDATE audit_outbox SET status = 'delivered'")
wrap = DieBefore if where == "before" else DieAfter
store = GovernanceStore(gov)
sink = DurableSqliteSink(sinkp)
if where_ == "sink":
    sink._conn = wrap(sink._conn, prefix, 7)  # noqa: SLF001
else:
    store._conn = wrap(store._conn, prefix, 7)  # noqa: SLF001
c = AdmissionController(store, audit=AuditLogger(logging.getLogger("child")), bounds=BOUNDS, clock=Clock(),
                        authorized_actors=frozenset({"ops.alice"}), sink=sink)
c.write_off(rid, actor="ops.alice", reason="atomic boundary")
os._exit(0)
'''

ADMIT_CHILD = r'''
import json, logging, os, sys, time
from sanour_ai.composition.runtime import Runtime
from sanour_ai.governance.admission import AdmissionController
from sanour_ai.governance.sink import DurableSqliteSink
from sanour_ai.governance.sink_contract import SinkFailed
from sanour_ai.governance.store import GovernanceStore
from sanour_ai.models.usage import Usage
from sanour_ai.observability.audit import AuditLogger
from tests.unit.r5_support import RaiseOn
from tests.unit.test_stage1047r1 import UsageProvider
from tests.unit.test_stage1048 import env, raw
from tests.unit.test_stage1049 import BOUNDS
gov, sinkp, mode, out = sys.argv[1:5]

class MarkedProvider(UsageProvider):
    def generate(self, call):
        with open(os.environ["PROVIDER_MARK"], "a") as fh:
            fh.write("called\n")
        return super().generate(call)

class DieSink(DurableSqliteSink):
    def deliver(self, *args, **kwargs):
        os._exit(9)  # the reservation is committed; the process dies before the admission event is confirmed

class DownSink(DurableSqliteSink):
    def deliver(self, *args, **kwargs):
        raise SinkFailed("sink down")

store = GovernanceStore(gov)
if mode == "release_fail":
    store._conn = RaiseOn(store._conn, "UPDATE reservations SET state = 'settlement_pending'")  # noqa: SLF001
    sink = DownSink(sinkp)
else:
    sink = DieSink(sinkp)
ctl = AdmissionController(store, audit=AuditLogger(logging.getLogger("child")), bounds=BOUNDS,
                          authorized_actors=frozenset({"ops.alice"}), sink=sink)
rt = Runtime.build_for_tests(env(), provider=MarkedProvider(Usage(input_tokens=4, output_tokens=2, total_tokens=6)),
                             usage_ledger_path=gov, governance=ctl)
response = rt.handle(raw(max_output_tokens=512))
json.dump({"status": response.status, "code": response.error.code.value if response.error else None},
          open(out, "w"))
os._exit(0)  # no shutdown: a shutdown would sweep the reservation and hide the state under test
'''
