"""Stage 10.29 tests: one shared deadline, bounded reads, worker accounting, shutdown lifecycle.

Fake transports, a fake clock, and events only. Waits are bounded and event-driven, not fixed sleeps.
No network, no real key, no SDK.
"""

from tests.support import request_identity_for as _rid
import http.client
import io
import json
import logging
import socket
import threading
import time
import unittest
import urllib.error
import urllib.request
from types import SimpleNamespace
from unittest import mock

from pydantic import SecretStr

from sanour_ai.core.sanour_core import SanourCore
from sanour_ai.errors import ErrorCode, SanourError
from sanour_ai.models.base import ModelCall, ModelResult, ProviderError
from sanour_ai.models.capabilities import ModelCapabilities, ModelProfile
from sanour_ai.models.gateway import ModelGateway
from sanour_ai.models.router import DeterministicRouter
from sanour_ai.observability.audit import AUDIT_LOGGER_NAME, AuditLogger
from sanour_ai.providers import common
from sanour_ai.providers.anthropic_provider import AnthropicProvider
from sanour_ai.providers.common import (
    MAX_ERROR_BODY_BYTES,
    MAX_RESPONSE_BYTES,
    DeadlineExpired,
    IncompleteResponseError,
    RequestTimeout,
    default_transport,
)
from sanour_ai.providers.gemini_provider import GeminiProvider
from sanour_ai.providers.grok_provider import GrokProvider
from tests.support import TEST_ALL_CAPS, deadline_in, wait_until

KEY = "STAGE1029-TESTONLY-KEY"
MODEL = "model-1029"


# ---------------------------------------------------------------- fakes
class Clock:
    def __init__(self):
        # Anchored to the real monotonic clock: deadlines are built from time.monotonic(), so a
        # fixed origin fails on hosts whose uptime is below that origin (10.33-R1 fix).
        self.t = time.monotonic()

    def now(self):
        return self.t

    def advance(self, seconds):
        self.t += seconds


class FakeSocket:
    def __init__(self):
        self.timeouts = []

    def settimeout(self, seconds):
        self.timeouts.append(seconds)


class FakeResponse:
    """Stands in for http.client.HTTPResponse: read1, headers, status, context manager."""

    def __init__(self, status=200, chunks=(), headers=None, clock=None, step=0.0, sock=None):
        self.status = status
        self.headers = headers or {}
        self._chunks = list(chunks)
        self.clock, self.step = clock, step
        self.reads = 0
        self.closed = False
        self.fp = SimpleNamespace(raw=SimpleNamespace(_sock=sock)) if sock is not None else None

    def read1(self, n):
        self.reads += 1
        if self.clock is not None:
            self.clock.advance(self.step)
        if not self._chunks:
            return b""
        item = self._chunks.pop(0)
        if isinstance(item, BaseException):
            raise item
        if len(item) > n:
            self._chunks.insert(0, item[n:])
            item = item[:n]
        return item

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.closed = True
        return False

    def close(self):
        self.closed = True


class FakeOpener:
    def __init__(self, outcome):
        self.outcome = outcome
        self.timeouts = []
        self.calls = 0

    def open(self, request, timeout):
        self.calls += 1
        self.timeouts.append(timeout)
        if isinstance(self.outcome, BaseException):
            raise self.outcome
        return self.outcome


def run_transport(opener, clock, *, budget=5.0, timeout=30.0):
    deadline = clock.now() + budget
    with mock.patch.object(common, "OPENER", opener), mock.patch.object(common, "_now", clock.now):
        return default_transport("https://example.invalid/x", {}, b"{}", RequestTimeout(timeout, deadline))


def call(budget=5.0):
    return ModelCall(model_id=MODEL, prompt="hi", max_output_tokens=16, deadline=time.monotonic() + budget)


# ---------------------------------------------------------------- transport: deadline and reads
class TransportDeadlineTests(unittest.TestCase):
    def test_expired_deadline_sends_nothing(self):
        clock, opener = Clock(), FakeOpener(FakeResponse())
        with mock.patch.object(common, "OPENER", opener), mock.patch.object(common, "_now", clock.now):
            with self.assertRaises(DeadlineExpired):
                default_transport("https://example.invalid/x", {}, b"{}", RequestTimeout(5.0, clock.now() - 1))
        self.assertEqual(opener.calls, 0)

    def test_connect_timeout_is_min_of_timeout_and_remaining_not_a_30s_cap(self):
        clock = Clock()
        opener = FakeOpener(socket.timeout("connect"))
        with self.assertRaises(OSError):
            run_transport(opener, clock, budget=1.5, timeout=30.0)
        self.assertEqual(opener.timeouts, [1.5])  # not 30: the request budget is the only bound

    def test_trickling_response_stops_at_the_shared_deadline(self):
        clock = Clock()
        resp = FakeResponse(chunks=[b"x"] * 100, clock=clock, step=0.4)
        with self.assertRaises(DeadlineExpired):
            run_transport(FakeOpener(resp), clock, budget=1.0)
        self.assertLessEqual(resp.reads, 3)  # reads at t=0, 0.4, 0.8; the 4th check is past 1.0
        self.assertTrue(resp.closed)  # local resources released on the way out

    def test_socket_read_timeout_is_treated_as_deadline_expiry(self):
        clock = Clock()
        resp = FakeResponse(chunks=[socket.timeout("read")], clock=clock)
        with self.assertRaises(DeadlineExpired):
            run_transport(FakeOpener(resp), clock, budget=5.0)
        self.assertTrue(resp.closed)

    def test_each_socket_read_is_bounded_by_remaining_budget(self):
        clock = Clock()
        sock = FakeSocket()
        resp = FakeResponse(chunks=[b"ab", b"cd"], clock=clock, step=0.25, sock=sock)
        status, _raw = run_transport(FakeOpener(resp), clock, budget=1.0)
        self.assertEqual(status, 200)
        self.assertTrue(sock.timeouts)
        self.assertTrue(all(0 < t <= 1.0 for t in sock.timeouts))
        self.assertLess(sock.timeouts[-1], sock.timeouts[0])  # the budget shrinks as time passes

    def test_complete_body_is_returned_in_full(self):
        clock = Clock()
        resp = FakeResponse(chunks=[b"hello", b" world"], headers={"Content-Length": "11"}, clock=clock)
        status, raw = run_transport(FakeOpener(resp), clock)
        self.assertEqual((status, raw), (200, b"hello world"))

    def test_oversized_success_body_is_bounded_and_detectable(self):
        clock = Clock()
        resp = FakeResponse(chunks=[b"a" * 65536] * 40, clock=clock)  # 2.6 MB offered
        status, raw = run_transport(FakeOpener(resp), clock, budget=60.0)
        self.assertEqual(len(raw), MAX_RESPONSE_BYTES + 1)
        self.assertLessEqual(resp.reads, MAX_RESPONSE_BYTES // 8192 + 3)  # reads stop at the cap

    def test_body_shorter_than_content_length_is_incomplete(self):
        clock = Clock()
        resp = FakeResponse(chunks=[b"x" * 40], headers={"Content-Length": "100"}, clock=clock)
        with self.assertRaises(IncompleteResponseError) as ctx:
            run_transport(FakeOpener(resp), clock)
        self.assertFalse(ctx.exception.retryable)

    def test_http_client_incomplete_read_is_incomplete_not_unclassified(self):
        clock = Clock()
        resp = FakeResponse(chunks=[http.client.IncompleteRead(b"ab", 10)], clock=clock)
        with self.assertRaises(IncompleteResponseError):
            run_transport(FakeOpener(resp), clock)

    def test_error_body_is_bounded_and_status_is_kept(self):
        clock = Clock()
        err = urllib.error.HTTPError("https://example.invalid/x", 429, "x", {},
                                     FakeResponse(chunks=[b"y" * 20000], clock=clock))
        status, raw = run_transport(FakeOpener(err), clock)
        self.assertEqual(status, 429)
        self.assertEqual(len(raw), MAX_ERROR_BODY_BYTES + 1)

    def test_error_body_deadline_keeps_status_with_empty_body(self):
        clock = Clock()
        err = urllib.error.HTTPError("https://example.invalid/x", 429, "x", {},
                                     FakeResponse(chunks=[socket.timeout("read")], clock=clock))
        self.assertEqual(run_transport(FakeOpener(err), clock), (429, b""))

    def test_redirect_refusal_and_proxy_policy_are_unchanged(self):
        handlers = common.OPENER.handlers
        self.assertTrue(any(isinstance(h, common.RefuseRedirects) for h in handlers))
        # No handler reads environment proxies: any ProxyHandler present has an empty mapping.
        self.assertFalse(any(isinstance(h, urllib.request.ProxyHandler) and h.proxies for h in handlers))


# ---------------------------------------------------------------- adapters: one deadline
class _RecordingTransport:
    def __init__(self, status=200, body=b""):
        self.status, self.body, self.calls, self.timeouts = status, body, 0, []

    def __call__(self, url, headers, body, timeout):
        self.calls += 1
        self.timeouts.append(timeout)
        return self.status, self.body


OK_BODY = json.dumps({"candidates": [{"content": {"parts": [{"text": "hi"}]}, "finishReason": "STOP"}],
                      "modelVersion": MODEL}).encode()


class AdapterDeadlineTests(unittest.TestCase):
    def _adapters(self, transport):
        return [
            GeminiProvider(SecretStr(KEY), transport=transport),
            AnthropicProvider(SecretStr(KEY), transport=transport),
            GrokProvider(SecretStr(KEY), transport=transport),
        ]

    def test_expired_deadline_makes_no_call_for_any_urllib_adapter(self):
        t = _RecordingTransport(body=OK_BODY)
        for provider in self._adapters(t):
            with self.subTest(provider=provider.name):
                expired = ModelCall(model_id=MODEL, prompt="p", max_output_tokens=8,
                                    deadline=time.monotonic() - 1)
                with self.assertRaises(ProviderError):
                    provider.generate(expired)
        self.assertEqual(t.calls, 0)

    def test_per_call_timeout_is_remaining_budget_without_a_30_second_cap(self):
        t = _RecordingTransport(body=OK_BODY)
        deadline = time.monotonic() + 60.0
        GeminiProvider(SecretStr(KEY), transport=t).generate(
            ModelCall(model_id=MODEL, prompt="p", max_output_tokens=8, deadline=deadline))
        timeout = t.timeouts[0]
        self.assertGreater(float(timeout), 30.0)
        self.assertLessEqual(float(timeout), 60.0)
        self.assertEqual(timeout.deadline, deadline)  # the one shared deadline travels with it

    def test_truncated_body_through_real_transport_is_invalid_response_via_gateway(self):
        clock = Clock()
        resp = FakeResponse(chunks=[b'{"candidates": [{"content'], headers={"Content-Length": "500"},
                            clock=clock)
        profile = ModelProfile(alias="gem_profile", provider="gemini", model_id=MODEL,
                               capabilities=ModelCapabilities(text_generation=True, max_context_tokens=8192,
                                                              max_output_tokens=4096))
        opener = FakeOpener(resp)
        with mock.patch.object(common, "OPENER", opener), mock.patch.object(common, "_now", clock.now):
            provider = GeminiProvider(SecretStr(KEY))
            gw = ModelGateway({"gemini": provider}, max_concurrent_calls=1)
            with self.assertRaises(SanourError) as ctx:
                gw.generate(profile, call(), time.monotonic() + 5, identity=_rid(profile))
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_INVALID_RESPONSE)
        self.assertFalse(ctx.exception.retryable)
        self.assertEqual(opener.calls, 1)  # one attempt, no retry


# ---------------------------------------------------------------- gateway: workers and capacity
class BlockingProvider:
    """Blocks until released. Bounded wait so a broken test cannot hang the run."""

    capabilities = TEST_ALL_CAPS

    def __init__(self, name="mock"):
        self.name = name
        self.release = threading.Event()
        self.started = threading.Event()
        self.lock = threading.Lock()
        self.calls = 0
        self.closed = 0
        self.deadlines = []

    def generate(self, call):
        with self.lock:
            self.calls += 1
            self.deadlines.append(call.deadline)
        self.started.set()
        self.release.wait(5)
        return ModelResult(text="ok", reported_model_id=call.model_id)

    def close(self):
        with self.lock:
            self.closed += 1


class _Spy:
    capabilities = TEST_ALL_CAPS

    def __init__(self, name):
        self.name, self.calls = name, 0

    def generate(self, call):
        self.calls += 1
        return ModelResult(text="spy", reported_model_id=call.model_id)


def profile_for(name, alias=None, priority=0):
    return ModelProfile(alias=alias or f"{name}_profile", provider=name, model_id=MODEL, priority=priority,
                        capabilities=ModelCapabilities(text_generation=True, max_context_tokens=8192,
                                                       max_output_tokens=4096))


class WorkerAccountingTests(unittest.TestCase):
    def test_timed_out_worker_holds_capacity_until_it_really_ends(self):
        prov = BlockingProvider()
        gw = ModelGateway({"mock": prov}, max_concurrent_calls=1)
        with self.assertRaises(SanourError) as timed:
            gw.generate(profile_for("mock"), call(), deadline_in(0.05), identity=_rid(profile_for("mock")))
        self.assertEqual(timed.exception.code, ErrorCode.PROVIDER_TIMEOUT)
        self.assertTrue(prov.started.wait(5))  # the worker has claimed its call before we count it
        stats = gw.stats()
        self.assertEqual((stats.timeouts, stats.in_flight, stats.abandoned_in_flight, stats.active_workers),
                         (1, 1, 1, 1))
        with self.assertRaises(SanourError) as busy:
            gw.generate(profile_for("mock"), call(), deadline_in(2.0), identity=_rid(profile_for("mock")))
        self.assertEqual(busy.exception.code, ErrorCode.PROVIDER_OVERLOADED)  # slot still held
        prov.release.set()
        self.assertTrue(wait_until(lambda: gw.in_flight == 0))
        stats = gw.stats()
        self.assertEqual((stats.in_flight, stats.abandoned_in_flight, stats.active_workers), (0, 0, 0))
        result = gw.generate(profile_for("mock"), call(), deadline_in(2.0), identity=_rid(profile_for("mock")))
        self.assertEqual(result.text, "ok")

    def test_late_finishing_worker_is_never_counted_as_success(self):
        prov = BlockingProvider()
        gw = ModelGateway({"mock": prov}, max_concurrent_calls=1)
        with self.assertRaises(SanourError):
            gw.generate(profile_for("mock"), call(), deadline_in(0.05), identity=_rid(profile_for("mock")))
        prov.release.set()
        self.assertTrue(wait_until(lambda: gw.in_flight == 0))
        self.assertEqual(gw.stats().successful_calls, 0)

    def test_rejected_calls_create_no_threads(self):
        prov = BlockingProvider()
        gw = ModelGateway({"mock": prov}, max_concurrent_calls=1)
        with self.assertRaises(SanourError):
            gw.generate(profile_for("mock"), call(), deadline_in(0.05), identity=_rid(profile_for("mock")))
        before = threading.active_count()
        for _ in range(30):
            with self.assertRaises(SanourError) as ctx:
                gw.generate(profile_for("mock"), call(), deadline_in(1.0), identity=_rid(profile_for("mock")))
            self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_OVERLOADED)
        self.assertEqual(threading.active_count(), before)
        self.assertEqual(prov.calls, 1)
        prov.release.set()
        self.assertTrue(wait_until(lambda: gw.in_flight == 0))

    def test_expired_deadline_never_reaches_the_provider(self):
        prov = BlockingProvider()
        gw = ModelGateway({"mock": prov}, max_concurrent_calls=1)
        with self.assertRaises(SanourError) as ctx:
            gw.generate(profile_for("mock"), call(), time.monotonic() - 1, identity=_rid(profile_for("mock")))
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_TIMEOUT)
        self.assertEqual(prov.calls, 0)
        self.assertEqual(gw.in_flight, 0)

    def test_race_admits_exactly_capacity_and_rejects_the_rest(self):
        prov = BlockingProvider()
        gw = ModelGateway({"mock": prov}, max_concurrent_calls=2)
        results, lock = [], threading.Lock()

        def worker():
            try:
                r = gw.generate(profile_for("mock"), call(), deadline_in(5.0), identity=_rid(profile_for("mock")))
                outcome = r.text
            except SanourError as exc:
                outcome = exc.code.value
            with lock:
                results.append(outcome)

        threads = [threading.Thread(target=worker) for _ in range(8)]
        for th in threads:
            th.start()
        self.assertTrue(wait_until(lambda: prov.calls == 2))
        self.assertTrue(wait_until(lambda: len(results) == 6))
        prov.release.set()
        for th in threads:
            th.join(5)
        self.assertEqual(sorted(results), ["ok", "ok"] + [ErrorCode.PROVIDER_OVERLOADED.value] * 6)
        self.assertEqual(gw.stats().peak_in_flight, 2)
        self.assertEqual(gw.in_flight, 0)


class ShutdownLifecycleTests(unittest.TestCase):
    def test_no_new_calls_after_shutdown_starts_and_close_waits_for_the_worker(self):
        prov = BlockingProvider()
        gw = ModelGateway({"mock": prov}, max_concurrent_calls=2)
        finished = []
        th = threading.Thread(target=lambda: finished.append(
            gw.generate(profile_for("mock"), call(), deadline_in(5.0), identity=_rid(profile_for("mock")))))
        th.start()
        self.assertTrue(prov.started.wait(5))
        self.assertEqual(gw.shutdown(timeout=0.05), 1)  # one worker still running
        self.assertEqual(prov.closed, 0)  # active provider is not closed under its worker
        with self.assertRaises(SanourError) as ctx:
            gw.generate(profile_for("mock"), call(), deadline_in(1.0), identity=_rid(profile_for("mock")))
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_FAILED)
        self.assertEqual(prov.calls, 1)  # the refused call never reached the provider
        prov.release.set()
        th.join(5)
        self.assertEqual(finished[0].text, "ok")  # the in-flight call still completes
        self.assertEqual(gw.shutdown(timeout=1.0), 0)
        self.assertEqual(prov.closed, 1)

    def test_repeated_shutdown_closes_each_provider_once(self):
        prov = BlockingProvider()
        gw = ModelGateway({"mock": prov}, max_concurrent_calls=1)
        gw.shutdown(timeout=0.1)
        gw.shutdown(timeout=0.1)
        gw.shutdown(timeout=0.1)
        self.assertEqual(prov.closed, 1)

    def test_one_failing_close_does_not_block_other_providers(self):
        class Failing(BlockingProvider):
            def close(self):
                with self.lock:
                    self.closed += 1
                raise RuntimeError("SECRET-CLOSE-DETAIL-1029")

        bad, good = Failing("bad"), BlockingProvider("good")
        gw = ModelGateway({"bad": bad, "good": good}, max_concurrent_calls=1)
        logger = logging.getLogger("sanour_ai.gateway.stage1029")
        handler = _Capture()
        with mock.patch("sanour_ai.models.gateway._log", logger):
            logger.addHandler(handler)
            gw.shutdown(timeout=0.1)
        self.assertEqual(good.closed, 1)
        self.assertEqual(bad.closed, 1)
        self.assertNotIn("SECRET-CLOSE-DETAIL-1029", "\n".join(handler.lines))
        gw.shutdown(timeout=0.1)  # no provider is closed a second time
        self.assertEqual((bad.closed, good.closed), (1, 1))


class _Capture(logging.Handler):
    def __init__(self):
        super().__init__()
        self.lines = []

    def emit(self, record):
        self.lines.append(record.getMessage())


# ---------------------------------------------------------------- core: one deadline, no fallback
class CoreDeadlineTests(unittest.TestCase):
    def test_core_creates_one_deadline_and_the_provider_sees_that_same_value(self):
        prov = BlockingProvider()
        prov.release.set()
        core = SanourCore(router=DeterministicRouter([profile_for("mock")]),
                          gateway=ModelGateway({"mock": prov}, max_concurrent_calls=1))
        before = time.monotonic()
        response = core.handle({"profile_alias": "mock_profile", "prompt": "hi", "timeout_seconds": 2})
        self.assertEqual(response.status, "success")
        self.assertEqual(len(prov.deadlines), 1)
        self.assertGreaterEqual(prov.deadlines[0], before + 2 - 0.25)
        self.assertLessEqual(prov.deadlines[0], before + 2 + 0.25)

    def test_timeout_returns_on_time_and_does_not_fall_back(self):
        primary = BlockingProvider("primary")
        backup = _Spy("backup")
        core = SanourCore(
            router=DeterministicRouter([profile_for("primary", priority=0),
                                        profile_for("backup", alias="backup_profile", priority=1)]),
            gateway=ModelGateway({"primary": primary, "backup": backup}, max_concurrent_calls=2),
        )
        started = time.monotonic()
        response = core.handle({"profile_alias": "primary_profile", "prompt": "hi", "timeout_seconds": 0.1})
        elapsed = time.monotonic() - started
        self.assertEqual(response.error.code, ErrorCode.PROVIDER_TIMEOUT.value)
        self.assertLess(elapsed, 0.1 + 0.25)
        self.assertEqual(primary.calls, 1)
        self.assertEqual(backup.calls, 0)  # no retry, no fallback on timeout
        primary.release.set()


if __name__ == "__main__":
    unittest.main()
