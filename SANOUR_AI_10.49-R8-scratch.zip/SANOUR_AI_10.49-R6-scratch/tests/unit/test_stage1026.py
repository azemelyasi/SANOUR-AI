"""Stage 10.26 tests: strict model identity with a per-profile allowlist.

Fake providers only. No network, no real key, no SDK.
"""

from tests.support import request_identity_for as _rid
import json
import logging
import time
import unittest

from pydantic import ValidationError

from sanour_ai.core.sanour_core import SanourCore
from sanour_ai.errors import ErrorCode, SanourError
from sanour_ai.models.base import ModelCall, ModelResult
from sanour_ai.models.capabilities import AllowlistConfigError, ModelCapabilities, ModelProfile
from sanour_ai.models.gateway import IDENTITY_MISMATCH_SCOPE, ModelGateway
from sanour_ai.models.router import DeterministicRouter
from sanour_ai.observability.audit import AUDIT_LOGGER_NAME, AuditLogger
from tests.support import TEST_ALL_CAPS, deadline_in

REQUESTED = "gpt-5.5"
SNAPSHOT = "gpt-5.5-2025-08-07"
SECRET_ECHO = "SECRET-ECHO-XYZ-9"


def profile(accepted=frozenset(), alias="p_primary", model_id=REQUESTED, priority=100):
    return ModelProfile(
        alias=alias,
        provider="fake",
        model_id=model_id,
        capabilities=ModelCapabilities(
            text_generation=True, max_context_tokens=8192, max_output_tokens=4096
        ),
        runs_locally=True,
        priority=priority,
        accepted_reported_model_ids=accepted,
    )


class ReportingProvider:
    """Returns a fixed reported id. Counts calls so tests can assert no second attempt."""

    capabilities = TEST_ALL_CAPS
    name = "fake"

    def __init__(self, reported):
        self.reported = reported
        self.calls = 0

    def generate(self, call: ModelCall) -> ModelResult:
        self.calls += 1
        return ModelResult(text="answer", reported_model_id=self.reported)


def run_gateway(prof, reported):
    provider = ReportingProvider(reported)
    gw = ModelGateway({"fake": provider}, max_concurrent_calls=2)
    call = ModelCall(model_id=prof.model_id, prompt="hi", max_output_tokens=16)
    try:
        return gw.generate(prof, call, deadline_in(2.0), identity=_rid(prof)), gw, provider
    except SanourError as exc:
        return exc, gw, provider


class _Capture(logging.Handler):
    def __init__(self):
        super().__init__()
        self.lines = []

    def emit(self, record):
        self.lines.append(record.getMessage())


def core_with(prof, reported):
    provider = ReportingProvider(reported)
    gw = ModelGateway({"fake": provider}, max_concurrent_calls=2)
    logger = logging.getLogger(AUDIT_LOGGER_NAME + ".stage1026")
    logger.handlers.clear()
    logger.propagate = False
    handler = _Capture()
    logger.addHandler(handler)
    core = SanourCore(
        router=DeterministicRouter([prof]),
        gateway=gw,
        audit=AuditLogger(logger),
    )
    return core, provider, handler


RAW = {"profile_alias": "p_primary", "prompt": "hello there"}


class ExactMatchTests(unittest.TestCase):
    def test_exact_requested_id_is_accepted(self):
        result, _, _ = run_gateway(profile(), REQUESTED)
        self.assertIsInstance(result, ModelResult)
        self.assertEqual(result.reported_model_id, REQUESTED)

    def test_default_allowlist_is_empty(self):
        self.assertEqual(profile().accepted_reported_model_ids, frozenset())


class AllowlistTests(unittest.TestCase):
    def test_allowlisted_snapshot_is_accepted(self):
        result, _, _ = run_gateway(profile(frozenset({SNAPSHOT})), SNAPSHOT)
        self.assertIsInstance(result, ModelResult)

    def test_snapshot_without_allowlist_is_rejected(self):
        result, _, _ = run_gateway(profile(), SNAPSHOT)
        self.assertIsInstance(result, SanourError)
        self.assertEqual(result.code, ErrorCode.PROVIDER_INVALID_RESPONSE)
        self.assertEqual(result.scope, IDENTITY_MISMATCH_SCOPE)

    def test_near_miss_ids_are_rejected(self):
        prof = profile(frozenset({SNAPSHOT}))
        for near in ("gpt-5.5-mini", "gpt-5.5-2025-08-07-x", "gpt-5.5-2025-08-08", "GPT-5.5", "gpt-5.", "gpt-5"):
            with self.subTest(reported=near):
                result, _, _ = run_gateway(prof, near)
                self.assertIsInstance(result, SanourError)
                self.assertEqual(result.code, ErrorCode.PROVIDER_INVALID_RESPONSE)

    def test_prefix_does_not_match(self):
        result, _, _ = run_gateway(profile(frozenset({"gpt-5.5-2025"})), SNAPSHOT)
        self.assertIsInstance(result, SanourError)

    def test_allowlist_is_per_profile(self):
        allowing = profile(frozenset({SNAPSHOT}), alias="p_allow")
        not_allowing = profile(alias="p_plain")
        ok, _, _ = run_gateway(allowing, SNAPSHOT)
        self.assertIsInstance(ok, ModelResult)
        bad, _, _ = run_gateway(not_allowing, SNAPSHOT)
        self.assertIsInstance(bad, SanourError)


class MissingOrEmptyTests(unittest.TestCase):
    def test_empty_reported_id_is_rejected(self):
        result, _, _ = run_gateway(profile(frozenset({SNAPSHOT})), "")
        self.assertIsInstance(result, SanourError)
        self.assertEqual(result.code, ErrorCode.PROVIDER_INVALID_RESPONSE)

    def test_missing_reported_id_is_rejected(self):
        result, _, _ = run_gateway(profile(frozenset({SNAPSHOT})), None)
        self.assertIsInstance(result, SanourError)
        self.assertEqual(result.code, ErrorCode.PROVIDER_INVALID_RESPONSE)


class AllowlistValidationTests(unittest.TestCase):
    def test_nine_entries_rejected(self):
        with self.assertRaises(AllowlistConfigError):
            profile(frozenset(f"m-{i}" for i in range(9)))

    def test_eight_entries_accepted(self):
        self.assertEqual(len(profile(frozenset(f"m-{i}" for i in range(8))).accepted_reported_model_ids), 8)

    def test_invalid_entries_rejected(self):
        for bad in ("gpt-*", "gpt-5.5*", "gpt 5.5", "", "a/b", "abc\n", "x" * 129, "-leading", "gpt-5.5?"):
            with self.subTest(entry=repr(bad)):
                with self.assertRaises(AllowlistConfigError):
                    profile(frozenset({bad}))

    def test_invalid_entry_message_does_not_echo_value(self):
        try:
            profile(frozenset({"leak-me-*"}))
        except AllowlistConfigError as exc:
            self.assertNotIn("leak-me", str(exc))
            self.assertNotIn("leak-me", repr(exc))
        else:
            self.fail("expected AllowlistConfigError")

    def test_count_error_does_not_echo_entries(self):
        with self.assertRaises(AllowlistConfigError) as ctx:
            profile(frozenset(f"leak-{i}-*" for i in range(9)))
        self.assertNotIn("leak", str(ctx.exception))

    def test_allowlist_is_immutable(self):
        prof = profile(frozenset({SNAPSHOT}))
        with self.assertRaises(ValidationError):
            prof.accepted_reported_model_ids = frozenset({"x"})


class AttributionTests(unittest.TestCase):
    def test_answer_is_attributed_to_requested_profile(self):
        core, provider, _ = core_with(profile(frozenset({SNAPSHOT})), SNAPSHOT)
        response = core.handle(RAW)
        self.assertEqual(response.status, "success")
        self.assertEqual(response.model_alias, "p_primary")
        self.assertEqual(response.model_id, REQUESTED)

    def test_no_second_profile_is_selected_on_identity_failure(self):
        primary = profile(alias="p_primary", model_id=REQUESTED, priority=0)
        backup = profile(frozenset({SNAPSHOT}), alias="p_backup", model_id="backup-model", priority=1)
        provider = ReportingProvider("some-other-model")
        gw = ModelGateway({"fake": provider}, max_concurrent_calls=2)
        core = SanourCore(router=DeterministicRouter([primary, backup]), gateway=gw)
        response = core.handle(RAW)
        self.assertEqual(response.status, "error")
        self.assertEqual(response.error.code, ErrorCode.PROVIDER_INVALID_RESPONSE)
        self.assertEqual(provider.calls, 1)  # one attempt only
        self.assertEqual(response.model_alias, None)


class AuditTests(unittest.TestCase):
    def test_identity_mismatch_event_is_logged_with_alias_only(self):
        core, _, handler = core_with(profile(), f"{SECRET_ECHO}")
        response = core.handle(RAW)
        self.assertEqual(response.status, "error")
        mismatch = [line for line in handler.lines if "model.identity.mismatch" in line]  # Stage 10.36 name
        self.assertEqual(len(mismatch), 1)
        self.assertIn('"model_alias": "p_primary"', mismatch[0])
        # Stage 10.36 traceability: identifiers only. The rule that matters is unchanged: no reported value.
        keys = set(json.loads(mismatch[0].split(" ", 1)[1]).keys())
        self.assertIn("model_alias", keys)
        self.assertLessEqual(keys, {"request_id", "model_alias", "provider", "api_surface"})
        self.assertNotIn(SECRET_ECHO, mismatch[0])

    def test_unknown_reported_id_never_appears_in_audit(self):
        core, _, handler = core_with(profile(), SECRET_ECHO)
        core.handle(RAW)
        joined = "\n".join(handler.lines)
        self.assertNotIn(SECRET_ECHO, joined)

    def test_allowed_reported_id_is_not_logged_by_identity_path(self):
        core, _, handler = core_with(profile(frozenset({SNAPSHOT})), SNAPSHOT)
        core.handle(RAW)
        self.assertFalse(any("model.identity.mismatch" in line for line in handler.lines))
        self.assertNotIn(SNAPSHOT, "\n".join(handler.lines))

    def test_response_text_never_logged(self):
        core, _, handler = core_with(profile(frozenset({SNAPSHOT})), SNAPSHOT)
        core.handle(RAW)
        self.assertNotIn("answer", "\n".join(handler.lines))
        self.assertNotIn("hello there", "\n".join(handler.lines))


class DeadlineAndCapacityTests(unittest.TestCase):
    def test_identity_rejection_releases_capacity(self):
        provider = ReportingProvider(SNAPSHOT)
        gw = ModelGateway({"fake": provider}, max_concurrent_calls=1)
        call = ModelCall(model_id=REQUESTED, prompt="hi", max_output_tokens=16)
        for _ in range(3):  # would deadlock on a leaked single slot
            with self.assertRaises(SanourError):
                gw.generate(profile(), call, deadline_in(2.0), identity=_rid(profile()))
        self.assertEqual(gw.in_flight, 0)
        self.assertEqual(provider.calls, 3)

    def test_identity_check_does_not_extend_deadline(self):
        provider = ReportingProvider(SNAPSHOT)
        gw = ModelGateway({"fake": provider}, max_concurrent_calls=1)
        call = ModelCall(model_id=REQUESTED, prompt="hi", max_output_tokens=16)
        start = time.monotonic()
        with self.assertRaises(SanourError):
            gw.generate(profile(), call, deadline_in(1.0), identity=_rid(profile()))
        self.assertLess(time.monotonic() - start, 1.5)


if __name__ == "__main__":
    unittest.main()
