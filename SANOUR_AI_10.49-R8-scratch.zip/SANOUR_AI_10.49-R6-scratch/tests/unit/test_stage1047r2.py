"""Stage 10.47-R2: response.withheld audit event, delivery vs audit status, withheld-usage accounting.

Deterministic, offline, no SDK, no network, no key. Audit failures are injected through the real
AuditLogger failure path (the formatter raises), so the real health counters are exercised.
"""

import json
import logging
import threading
import unittest

from sanour_ai.composition.runtime import Runtime
from sanour_ai.core.usage_accounting import UsageAccountingService
from sanour_ai.errors import ErrorCode, FailureKind
from sanour_ai.models.base import ModelResult, ProviderError
from sanour_ai.models.execution import ExecutionResult
from sanour_ai.models.usage import Usage
from sanour_ai.observability.audit import AuditLogger
from sanour_ai.providers.offline_contract import OfflineTestProvider
from tests.unit.test_stage1047r1 import (
    ALIAS, OUTPUT, PROMPT, Capture, UsageProvider, env, raw, required_core,
)


def logged_audit(handler, fail_events=(), counter=None):
    """A real AuditLogger whose write fails for the named events (the formatter raises)."""
    logger = logging.getLogger(f"test.stage1047r2.{id(handler)}")
    logger.handlers = [handler]
    logger.propagate = False
    logger.setLevel(logging.DEBUG)

    class Injected(AuditLogger):
        def _format(self, event, fields):
            if counter is not None:
                counter.append(event)
            if event in fail_events:
                raise RuntimeError("injected audit write failure")
            return super()._format(event, fields)

    return Injected(logger)


def order(cap):
    return [line.split(" ", 1)[0] for line in cap.lines]


def fields_of(cap, name):
    lines = [line for line in cap.lines if line.startswith(name + " ")]
    return [json.loads(line.split(" ", 1)[1]) for line in lines]


class WithheldAudit(unittest.TestCase):
    def test_1_recorded_usage_and_delivered_response(self):
        cap = Capture()
        core = required_core(UsageProvider(Usage(input_tokens=2, output_tokens=1, total_tokens=3)), logged_audit(cap))
        response, result = core.handle_with_result(raw())
        self.assertEqual(response.status, "success")
        self.assertEqual(order(cap), ["request.received", "request.profile.resolved", "request.identity.created",
                                      "model.identity.validated", "model.succeeded", "usage.recorded",
                                      "request.completed"])
        self.assertEqual(fields_of(cap, "request.completed")[0]["status"], "success")
        self.assertEqual((result.delivery, result.usage_audit), ("delivered", "recorded"))

    def test_2_usage_write_fails_and_response_is_withheld(self):
        cap = Capture()
        counter = []
        core = required_core(UsageProvider(Usage(input_tokens=2, output_tokens=1, total_tokens=3)),
                             logged_audit(cap, fail_events=("usage.recorded",), counter=counter))
        response, result = core.handle_with_result(raw())
        self.assertEqual((response.status, response.error.code), ("error", ErrorCode.INTERNAL_ERROR))
        self.assertNotIn(OUTPUT, repr(response))
        self.assertEqual(order(cap), ["request.received", "request.profile.resolved", "request.identity.created",
                                      "model.identity.validated", "model.succeeded", "response.withheld",
                                      "request.completed"])
        self.assertEqual(fields_of(cap, "response.withheld"), [{"request_id": fields_of(cap, "request.completed")[0]["request_id"],
                                                               "withheld_reason": "usage_audit_unavailable"}])
        self.assertEqual(fields_of(cap, "request.completed")[0]["status"], "error")
        self.assertEqual((result.delivery, result.usage_audit), ("withheld", "failed"))
        self.assertEqual(counter.count("usage.recorded"), 1)

    def test_3_completion_write_fails_after_usage_was_recorded(self):
        cap = Capture()
        core = required_core(UsageProvider(Usage(input_tokens=2)),
                             logged_audit(cap, fail_events=("request.completed",)))
        response, result = core.handle_with_result(raw())
        self.assertEqual(response.status, "error")
        self.assertNotIn(OUTPUT, repr(response))
        self.assertEqual(order(cap), ["request.received", "request.profile.resolved", "request.identity.created",
                                      "model.identity.validated", "model.succeeded", "usage.recorded",
                                      "response.withheld"])
        self.assertEqual(fields_of(cap, "response.withheld")[0]["withheld_reason"], "completion_audit_unavailable")
        self.assertEqual((result.delivery, result.usage_audit), ("withheld", "recorded"))

    def test_4_withheld_event_also_fails_health_counter_is_updated_and_no_retry(self):
        cap = Capture()
        counter = []
        audit = logged_audit(cap, fail_events=("usage.recorded", "response.withheld"), counter=counter)
        core = required_core(UsageProvider(Usage(input_tokens=2)), audit)
        response, _ = core.handle_with_result(raw())
        self.assertEqual((response.status, response.error.code), ("error", ErrorCode.INTERNAL_ERROR))
        self.assertEqual(counter.count("response.withheld"), 1)  # one attempt, no retry loop
        self.assertEqual(counter.count("usage.recorded"), 1)
        self.assertEqual(audit.counters()["failed"], 2)
        self.assertEqual(audit.counters()["health"], "degraded")
        self.assertEqual(fields_of(cap, "request.completed")[0]["status"], "error")

    def test_4b_completion_and_withheld_event_both_fail_is_counted_not_retried(self):
        cap = Capture()
        counter = []
        audit = logged_audit(cap, fail_events=("request.completed", "response.withheld"), counter=counter)
        core = required_core(UsageProvider(Usage(input_tokens=2)), audit)
        response, result = core.handle_with_result(raw())
        self.assertEqual(response.status, "error")
        self.assertEqual(counter.count("response.withheld"), 1)
        self.assertEqual(counter.count("request.completed"), 1)
        self.assertEqual(audit.counters()["failed"], 2)
        self.assertEqual((result.delivery, result.usage_audit), ("withheld", "recorded"))

    def test_withheld_event_carries_only_request_id_and_reason(self):
        cap = Capture()
        core = required_core(UsageProvider(Usage(input_tokens=2)), logged_audit(cap, fail_events=("usage.recorded",)))
        core.handle_with_result(raw())
        (payload,) = fields_of(cap, "response.withheld")
        self.assertEqual(set(payload), {"request_id", "withheld_reason"})
        self.assertNotIn(PROMPT, repr(payload))
        self.assertNotIn(OUTPUT, repr(payload))

    def test_no_withheld_event_on_delivered_success(self):
        cap = Capture()
        rt = Runtime.build_for_tests(env(), provider=UsageProvider(Usage(input_tokens=1)), audit=logged_audit(cap))
        self.assertEqual(rt.handle(raw()).status, "success")
        self.assertEqual(fields_of(cap, "response.withheld"), [])

    def test_no_withheld_event_when_failed_or_refused(self):
        class Failing(OfflineTestProvider):
            def generate(self, call):
                raise ProviderError("boom", kind=FailureKind.REQUEST_REJECTED, retryable=False)

        cap = Capture()
        rt = Runtime.build_for_tests(env(), provider=Failing(), audit=logged_audit(cap))
        rt.handle(raw())
        rt.handle({"profile_alias": "nope", "prompt": PROMPT})
        self.assertEqual(fields_of(cap, "response.withheld"), [])


class StatusSeparation(unittest.TestCase):
    def test_delivery_and_audit_are_counted_separately_in_every_combination(self):
        svc = UsageAccountingService(clock=lambda: 1_790_000_000.0)
        combos = [("delivered", "recorded"), ("delivered", "failed"), ("withheld", "recorded"),
                  ("withheld", "failed"), ("delivered", "unavailable")]
        for i, (delivery, audit) in enumerate(combos):
            svc.record(ExecutionResult(
                request_id=f"{i:032x}", profile_id="p", provider_id="openai", api_surface="openai_responses",
                requested_model_id="m", provider_reported_model_id="m", output="o", finish_status="completed",
                execution_ms=1, usage=Usage(input_tokens=1), usage_audit=audit, delivery=delivery,
            ))
        total = svc.total()
        self.assertEqual(total["delivery"], {"delivered": 3, "withheld": 2})
        self.assertEqual(total["usage_audit"], {"recorded": 2, "failed": 2, "unavailable": 1})
        self.assertEqual(total["requests"], 5)

    def test_unknown_usage_on_withheld_stays_unknown(self):
        svc = UsageAccountingService()
        svc.record(ExecutionResult(
            request_id="a" * 32, profile_id="p", provider_id="openai", api_surface="openai_responses",
            requested_model_id="m", provider_reported_model_id="m", output="o", finish_status="completed",
            execution_ms=1, usage=None, usage_audit="failed", delivery="withheld",
        ))
        total = svc.total()
        self.assertEqual(total["delivery"]["withheld"], 1)
        self.assertIsNone(total["tokens"]["input_tokens"]["sum"])
        self.assertEqual(total["requests_without_usage"], 1)

    def test_invalid_status_values_are_refused(self):
        with self.assertRaises(ValueError):
            ExecutionResult(request_id="a" * 32, profile_id="p", provider_id="openai", api_surface="x",
                            requested_model_id="m", provider_reported_model_id="m", output="o",
                            finish_status="completed", execution_ms=1, delivery="maybe")
        with self.assertRaises(ValueError):
            ExecutionResult(request_id="a" * 32, profile_id="p", provider_id="openai", api_surface="x",
                            requested_model_id="m", provider_reported_model_id="m", output="o",
                            finish_status="completed", execution_ms=1, usage_audit="not_recorded")


class AccountingNoDoubleCount(unittest.TestCase):
    def test_withheld_usage_is_recorded_once_for_the_same_request_id(self):
        cap = Capture()
        core = required_core(UsageProvider(Usage(input_tokens=2)), logged_audit(cap, fail_events=("usage.recorded",)))
        _, result = core.handle_with_result(raw())
        svc = UsageAccountingService()
        self.assertTrue(svc.record(result))
        self.assertFalse(svc.record(result))
        self.assertEqual(svc.total()["requests"], 1)
        self.assertEqual(svc.total()["delivery"]["withheld"], 1)
        self.assertEqual(svc.duplicates_ignored(), 1)

    def test_runtime_path_counts_a_withheld_request_once(self):
        rt = Runtime.build_for_tests(env(), provider=UsageProvider(Usage(input_tokens=2)),
                                     audit=logged_audit(Capture(), fail_events=("usage.recorded",)))
        self.assertEqual(rt.handle(raw()).status, "success")  # test mode: audit not required, delivered
        total = rt.usage_summary()["total"]
        self.assertEqual(total["requests"], 1)
        self.assertEqual(total["delivery"], {"delivered": 1, "withheld": 0})
        self.assertEqual(total["usage_audit"], {"recorded": 0, "failed": 1, "unavailable": 0})


class RuntimePathWithheld(unittest.TestCase):
    """Test factories never require audit, so a withheld response is produced by a required-audit core
    wrapped in a Runtime directly (registry stubbed). This exercises Runtime.handle's recording path."""

    class _StubRegistry:
        def on_provider_settled(self, *args):
            pass

        def add_settlement_listener(self, listener):
            pass

        def states(self):
            return {}

    def test_runtime_handle_records_a_withheld_completion_with_its_status(self):
        cap = Capture()
        core = required_core(UsageProvider(Usage(input_tokens=2)), logged_audit(cap, fail_events=("usage.recorded",)))
        rt = Runtime(None, core, self._StubRegistry(), mode="production")
        self.assertEqual(rt.handle(raw()).status, "error")
        total = rt.usage_summary()["total"]
        self.assertEqual(total["requests"], 1)
        self.assertEqual(total["delivery"], {"delivered": 0, "withheld": 1})
        self.assertEqual(total["usage_audit"], {"recorded": 0, "failed": 1, "unavailable": 0})
        self.assertEqual(total["tokens"]["input_tokens"]["sum"], 2)


class NoRecordForLateFailedOrRefused(unittest.TestCase):
    def test_failed_refused_and_late_requests_are_never_accounted(self):
        class Failing(OfflineTestProvider):
            def generate(self, call):
                raise ProviderError("boom", kind=FailureKind.REQUEST_REJECTED, retryable=False)

        rt = Runtime.build_for_tests(env(), provider=Failing())
        rt.handle(raw())
        rt.handle({"profile_alias": "nope", "prompt": PROMPT})
        self.assertEqual(rt.usage_summary()["total"]["requests"], 0)

    def test_late_response_is_never_accounted(self):
        class Late(OfflineTestProvider):
            def __init__(self):
                self.entered, self.release = threading.Event(), threading.Event()

            def generate(self, call):
                self.entered.set()
                self.release.wait(timeout=30)
                return ModelResult(text=OUTPUT, reported_model_id=call.model_id, usage=Usage(input_tokens=9))

        provider = Late()
        rt = Runtime.build_for_tests(env(), provider=provider)
        outcome = {}
        caller = threading.Thread(target=lambda: outcome.update(pair=rt._core.handle_with_result(raw(timeout_seconds=0.2))))  # noqa: SLF001
        caller.start()
        self.assertTrue(provider.entered.wait(timeout=10))
        caller.join(timeout=10)
        self.assertEqual(outcome["pair"][0].error.code, ErrorCode.PROVIDER_TIMEOUT)
        self.assertIsNone(outcome["pair"][1])
        provider.release.set()
        gateway = rt._core.shutdown_target()  # noqa: SLF001
        with gateway._lock:  # noqa: SLF001
            self.assertTrue(gateway._idle_cv.wait_for(lambda: gateway._in_flight == 0, timeout=10))  # noqa: SLF001
        self.assertEqual(rt.usage_summary()["total"]["requests"], 0)
        rt.shutdown(timeout=5)


if __name__ == "__main__":
    unittest.main()
