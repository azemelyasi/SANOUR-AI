"""Stage 10.49-R6: read-only reconciliation report and end-to-end outcome consistency.

Invariants under test:
- the reconciler never writes: database bytes are identical before and after every run;
- a healthy database produced by real runtime flows reports no error findings;
- each injected inconsistency is reported with its code (and only as a report, never repaired);
- a refused request never reaches the provider and leaves no open reservation;
- a failed provider call leaves an exposure, not a settled amount, and the reconciler reports it as uncertain.
"""

import hashlib
import os
import sqlite3
import tempfile
import unittest
from decimal import Decimal

from sanour_ai.composition.runtime import Runtime
from sanour_ai.errors import FailureKind
from sanour_ai.governance import reconcile as rec
from sanour_ai.governance.store import GovernanceStore
from sanour_ai.models.base import ProviderError
from sanour_ai.models.usage import Usage
from tests.unit.test_stage1047r1 import UsageProvider
from tests.unit.test_stage1048 import env, raw
from tests.unit.test_stage1049 import GovBase, pricing, quiet_audit, BOUNDS, Clock
from sanour_ai.governance.admission import AdmissionController


def digest(path):
    with open(path, "rb") as fh:
        return hashlib.sha256(fh.read()).hexdigest()


class Failing(UsageProvider):
    def generate(self, call):
        self.calls += 1
        raise ProviderError("boom", kind=FailureKind.REQUEST_REJECTED, retryable=False)


class ReconcileBase(GovBase):
    def runtime(self, provider, budget_limit="1.00"):
        s = self.store()
        s.upsert_pricing(pricing())
        s.upsert_budget("global", "", "daily", "USD", budget_limit)
        ctl = self.controller(s)
        rt = Runtime.build_for_tests(env(), provider=provider, usage_ledger_path=self.path, governance=ctl)
        self.addCleanup(lambda: rt.shutdown(1.0))
        return rt, ctl

    def report(self, **kw):
        return rec.reconcile(self.path, now=self.clock.now, **kw)

    def codes(self, report):
        return {item["code"] for item in report["findings"]["items"]}

    def edit(self, sql, *args):
        conn = sqlite3.connect(self.path)
        try:
            conn.execute(sql, args)
            conn.commit()
        finally:
            conn.close()


class HealthyAndReadOnly(ReconcileBase):
    def test_healthy_database_after_success_reports_no_errors(self):
        provider = UsageProvider(Usage(input_tokens=4, output_tokens=2, total_tokens=6))
        rt, _ = self.runtime(provider)
        self.assertEqual(rt.handle(raw(max_output_tokens=512)).status, "success")
        r = self.report()
        self.assertTrue(r["ok"], r["findings"])
        self.assertEqual(r["reservations"]["by_state"], {"settled": 1})
        self.assertEqual(r["reservations"]["pending_count"], 0)

    def test_reconciler_never_writes(self):
        provider = UsageProvider(Usage(input_tokens=4, output_tokens=2, total_tokens=6))
        rt, _ = self.runtime(provider)
        rt.handle(raw(max_output_tokens=512))
        rt.shutdown(1.0)
        before = digest(self.path)
        for _ in range(3):
            self.report()
        self.assertEqual(before, digest(self.path))

    def test_missing_file_is_refused_not_created(self):
        missing = os.path.join(self._dir.name, "absent.db")
        with self.assertRaises(rec.ReconcileError):
            rec.reconcile(missing)
        self.assertFalse(os.path.exists(missing))

    def test_memory_database_is_refused(self):
        with self.assertRaises(rec.ReconcileError):
            rec.reconcile(":memory:")

    def test_read_only_connection_rejects_writes_at_the_engine(self):
        # The guarantee does not rest on the reconciler's own code being careful: the connection itself is read-only.
        self.store().upsert_budget("global", "", "daily", "USD", "1.00")
        before = self.row("SELECT COUNT(*) FROM budgets")[0]
        conn = rec._open_ro(self.path, "governance")  # noqa: SLF001
        try:
            with self.assertRaises(sqlite3.OperationalError):
                conn.execute("INSERT INTO budgets (scope_type, scope_value, period, currency, limit_amount) "
                             "VALUES ('global', 'probe', 'daily', 'USD', '1')")
        finally:
            conn.close()
        self.assertEqual(self.row("SELECT COUNT(*) FROM budgets")[0], before)

    def test_schema_behind_is_reported_and_checks_skipped(self):
        conn = sqlite3.connect(self.path)
        conn.execute("CREATE TABLE IF NOT EXISTS unrelated (x INTEGER)")
        conn.commit()
        conn.close()
        r = self.report()
        self.assertFalse(r["ok"])
        self.assertIn("SCHEMA_BEHIND", self.codes(r))


class OutcomeConsistency(ReconcileBase):
    def test_refused_request_never_calls_provider_and_leaves_no_open_reservation(self):
        provider = UsageProvider(Usage(input_tokens=1, output_tokens=1))
        rt, _ = self.runtime(provider, budget_limit="0.01")
        self.assertNotEqual(rt.handle(raw(max_output_tokens=512)).status, "success")
        self.assertEqual(provider.calls, 0)
        r = self.report()
        self.assertEqual(r["reservations"]["pending_count"], 0)
        self.assertEqual(r["reservations"]["uncertain_exposure_count"], 0)
        self.assertTrue(r["ok"], r["findings"])

    def test_failed_provider_call_is_reported_as_uncertain_exposure(self):
        rt, _ = self.runtime(Failing(Usage()))
        self.assertNotEqual(rt.handle(raw(max_output_tokens=512)).status, "success")
        r = self.report()
        self.assertEqual(r["reservations"]["uncertain_exposure_count"], 1)
        self.assertEqual(self.row("SELECT state FROM reservations")[0], "exposed")
        self.assertTrue(r["ok"], r["findings"])

    def test_shutdown_with_outstanding_reservation_leaves_no_pending_report_items(self):
        provider = UsageProvider(Usage(input_tokens=1, output_tokens=1))
        rt, ctl = self.runtime(provider)
        ctl.admit(self._request(), self._profile())
        rt.shutdown(1.0)
        r = self.report()
        self.assertEqual(r["reservations"]["pending_count"], 0)
        self.assertEqual(r["reservations"]["by_state"], {"exposed": 1})

    def _request(self):
        from tests.unit.test_stage1049 import request
        return request()

    def _profile(self):
        from tests.unit.test_stage1049 import profile
        return profile()


class InjectedInconsistencies(ReconcileBase):
    def healthy(self):
        provider = UsageProvider(Usage(input_tokens=4, output_tokens=2, total_tokens=6))
        rt, _ = self.runtime(provider)
        rt.handle(raw(max_output_tokens=512))
        self.assertTrue(self.report()["ok"])
        return rt

    def test_budget_window_drift_is_reported(self):
        self.healthy()
        self.edit("UPDATE budget_windows SET reserved = reserved + 1")
        self.assertIn("BUDGET_WINDOW_MISMATCH", self.codes(self.report()))

    def test_negative_budget_window_is_reported(self):
        self.healthy()
        self.edit("UPDATE budget_windows SET spent = '-1'")
        self.assertIn("BUDGET_NEGATIVE", self.codes(self.report()))

    def test_settled_reservation_without_cost_record_is_reported(self):
        self.healthy()
        self.edit("DELETE FROM cost_records")
        self.assertIn("COST_RECORD_MISSING", self.codes(self.report()))

    def test_settlement_pending_is_reported_as_pending(self):
        self.healthy()
        self.edit("UPDATE reservations SET state = 'settlement_pending', intent_digest = 'x'")
        r = self.report()
        self.assertEqual(r["reservations"]["pending_settlement_count"], 1)
        self.assertIn("SETTLEMENT_PENDING", self.codes(r))

    def test_settlement_pending_without_intent_is_an_error(self):
        self.healthy()
        self.edit("UPDATE reservations SET state = 'settlement_pending', intent_digest = NULL")
        self.assertIn("SETTLEMENT_NO_INTENT", self.codes(self.report()))

    def test_unresolved_audit_conflict_is_reported(self):
        self.healthy()
        self.edit("INSERT INTO audit_outbox (event_key, log_id, event, fields, status, attempts, created_at) "
                  "SELECT 'k-conflict', log_id, event, fields, 'conflict', 0, 0 FROM audit_outbox LIMIT 1")
        r = self.report()
        self.assertIn("AUDIT_CONFLICT_UNRESOLVED", self.codes(r))
        self.assertIn("error", {i["severity"] for i in r["findings"]["items"] if i["code"] == "AUDIT_CONFLICT_UNRESOLVED"})
        self.assertGreaterEqual(r["audit"]["unresolved_conflict_count"], 1)

    def test_failed_audit_delivery_is_reported_not_hidden(self):
        self.healthy()
        self.edit("UPDATE audit_outbox SET status = 'failed'")
        self.assertIn("AUDIT_FAILED", self.codes(self.report()))

    def test_delivered_event_without_sink_receipt_is_reported(self):
        self.healthy()
        self.edit("UPDATE audit_outbox SET status = 'delivered'")
        sink_path = os.path.join(self._dir.name, "sink.db")
        from sanour_ai.governance.sink import DurableSqliteSink
        sink = DurableSqliteSink(sink_path)
        sink.close()
        r = self.report(sink_path=sink_path)
        self.assertIn("SINK_RECEIPT_MISSING", self.codes(r))

    def test_reconciling_injected_damage_still_writes_nothing(self):
        self.healthy()
        self.edit("UPDATE budget_windows SET reserved = reserved + 1")
        before = digest(self.path)
        self.report()
        self.assertEqual(before, digest(self.path))


if __name__ == "__main__":
    unittest.main()
