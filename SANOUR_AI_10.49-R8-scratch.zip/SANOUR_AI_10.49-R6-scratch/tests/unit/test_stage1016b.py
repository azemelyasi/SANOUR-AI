"""Stage 10.16-B tests: capacity config, internal capacity scope, shutdown, core path. Mock only."""

from tests.support import request_identity_for as _rid
import logging
import pathlib
import threading
import unittest
from tests.support import TEST_ALL_CAPS

from sanour_ai.composition.production import _assemble
from sanour_ai.config.settings import ConfigError, load_settings
from sanour_ai.errors import ErrorCode, SanourError
from sanour_ai.models.base import ModelCall, ModelResult
from sanour_ai.models.capabilities import ModelCapabilities, ModelProfile
from sanour_ai.models.gateway import ModelGateway
from sanour_ai.observability.audit import AUDIT_LOGGER_NAME, AuditLogger
from sanour_ai.providers.openai_provider import OpenAIProvider
from tests.support import GatedProvider, deadline_in, wait_until


def profile(alias, provider):
    return ModelProfile(
        alias=alias,
        provider=provider,
        model_id=f"{alias}-id",
        capabilities=ModelCapabilities(text_generation=True, max_context_tokens=8192, max_output_tokens=4096),
        runs_locally=True,
    )


def call_for(p):
    return ModelCall(model_id=p.model_id, prompt="hi", max_output_tokens=16, deadline=None)


class ClosingProvider:
    capabilities = TEST_ALL_CAPS
    def __init__(self, name, fail_close=False):
        self.name = name
        self.close_calls = 0
        self._fail = fail_close

    def generate(self, call):
        return ModelResult(text="ok", reported_model_id=call.model_id)

    def close(self):
        self.close_calls += 1
        if self._fail:
            raise RuntimeError("secret-bearing close detail")


class GatedClosingProvider(GatedProvider):
    def __init__(self, name):
        super().__init__(name)
        self.close_calls = 0

    def close(self):
        self.close_calls += 1


class SettingsTests(unittest.TestCase):
    def test_provider_limits_parsed_from_environment(self):
        s = load_settings({"SANOUR_PROVIDER_CONCURRENCY": "openai=2, other_name=3"})
        self.assertEqual(s.provider_limits, {"openai": 2, "other_name": 3})

    def test_empty_or_missing_means_no_provider_limits(self):
        self.assertEqual(load_settings({}).provider_limits, {})
        self.assertEqual(load_settings({"SANOUR_PROVIDER_CONCURRENCY": "  "}).provider_limits, {})

    def test_invalid_values_fail_closed_without_echoing_value(self):
        bad = [
            "openai=0", "openai=17", "openai=2x", "openai", "=2", "OpenAI=2",
            "openai=2,openai=3", "a=1", "openai=-1", "openai=+2", "openai= 2 ;x",
        ]
        for raw in bad:
            with self.subTest(raw=raw), self.assertRaises(ConfigError) as ctx:
                load_settings({"SANOUR_PROVIDER_CONCURRENCY": raw})
            self.assertIn("SANOUR_PROVIDER_CONCURRENCY", str(ctx.exception))
            self.assertNotIn(raw.strip(), str(ctx.exception))


class CapacityScopeTests(unittest.TestCase):
    def test_global_and_provider_rejections_carry_internal_scope(self):
        a, b = GatedProvider("alpha"), GatedProvider("beta")
        gw = ModelGateway({"alpha": a, "beta": b}, max_concurrent_calls=2, provider_limits={"alpha": 1})
        pa, pb = profile("alpha_model", "alpha"), profile("beta_model", "beta")
        holder = threading.Thread(
            target=lambda: gw.generate(pa, call_for(pa), deadline_in(5.0), identity=_rid(pa)), daemon=True
        )
        holder.start()
        self.assertTrue(wait_until(lambda: gw.in_flight == 1))
        with self.assertRaises(SanourError) as provider_full:
            gw.generate(pa, call_for(pa), deadline_in(1.0), identity=_rid(pa))
        self.assertEqual(provider_full.exception.scope, "provider")
        self.assertEqual(provider_full.exception.code, ErrorCode.PROVIDER_OVERLOADED)
        self.assertEqual(provider_full.exception.message, "model capacity is full, try again shortly")
        # Fill the second global slot, then the third call hits the global cap.
        holder_b = threading.Thread(
            target=lambda: gw.generate(pb, call_for(pb), deadline_in(5.0), identity=_rid(pb)), daemon=True
        )
        holder_b.start()
        self.assertTrue(wait_until(lambda: gw.in_flight == 2))
        with self.assertRaises(SanourError) as global_full:
            gw.generate(pb, call_for(pb), deadline_in(1.0), identity=_rid(pb))
        self.assertEqual(global_full.exception.scope, "global")
        a.release_all(); b.release_all()
        holder.join(timeout=3); holder_b.join(timeout=3)

    def test_scope_reaches_audit_but_not_the_response(self):
        a = GatedProvider("alpha")
        from sanour_ai.core.sanour_core import SanourCore
        from sanour_ai.models.router import DeterministicRouter

        gw = ModelGateway({"alpha": a}, max_concurrent_calls=1)
        pa = profile("alpha_model", "alpha")
        core = SanourCore(router=DeterministicRouter([pa]), gateway=gw, audit=AuditLogger())
        holder = threading.Thread(
            target=lambda: core.handle({"profile_alias": "alpha_model", "prompt": "hi", "timeout_seconds": 5}),
            daemon=True,
        )
        holder.start()
        self.assertTrue(wait_until(lambda: gw.in_flight == 1))
        records = []

        class Capture(logging.Handler):
            def emit(self, record):
                records.append(record.getMessage())

        handler = Capture()
        logging.getLogger(AUDIT_LOGGER_NAME).addHandler(handler)
        try:
            resp = core.handle({"profile_alias": "alpha_model", "prompt": "hi", "timeout_seconds": 1})
        finally:
            logging.getLogger(AUDIT_LOGGER_NAME).removeHandler(handler)
            a.release_all(); holder.join(timeout=3)
        self.assertEqual(resp.error.code, ErrorCode.PROVIDER_OVERLOADED)
        self.assertNotIn("scope", resp.error.message)
        self.assertTrue(any('"capacity_scope": "global"' in r for r in records))


class ShutdownTests(unittest.TestCase):
    def test_refuses_new_calls_after_shutdown(self):
        p = ClosingProvider("alpha")
        gw = ModelGateway({"alpha": p}, max_concurrent_calls=2)
        gw.shutdown(timeout=0.5)
        with self.assertRaises(SanourError) as ctx:
            gw.generate(profile("alpha_model", "alpha"), call_for(profile("alpha_model", "alpha")), deadline_in(2.0), identity=_rid(profile("alpha_model", "alpha")))
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_FAILED)

    def test_closes_idle_providers_exactly_once(self):
        p, q = ClosingProvider("alpha"), ClosingProvider("beta")
        gw = ModelGateway({"alpha": p, "beta": q}, max_concurrent_calls=2)
        self.assertEqual(gw.shutdown(timeout=0.5), 0)
        self.assertEqual(gw.shutdown(timeout=0.5), 0)
        self.assertEqual((p.close_calls, q.close_calls), (1, 1))

    def test_busy_provider_is_not_closed_until_its_worker_returns(self):
        busy = GatedClosingProvider("alpha")
        idle = ClosingProvider("beta")
        gw = ModelGateway({"alpha": busy, "beta": idle}, max_concurrent_calls=2)
        pa = profile("alpha_model", "alpha")
        holder = threading.Thread(target=lambda: gw.generate(pa, call_for(pa), deadline_in(5.0), identity=_rid(pa)), daemon=True)
        holder.start()
        self.assertTrue(wait_until(lambda: gw.in_flight == 1))
        remaining = gw.shutdown(timeout=0.1)
        self.assertEqual(remaining, 1)
        self.assertEqual((busy.close_calls, idle.close_calls), (0, 1))
        busy.release_all()
        holder.join(timeout=3)
        self.assertTrue(wait_until(lambda: gw.shutdown(timeout=0.1) == 0))
        self.assertEqual(busy.close_calls, 1)

    def test_close_error_is_logged_by_type_only_and_does_not_stop_others(self):
        bad, good = ClosingProvider("alpha", fail_close=True), ClosingProvider("beta")
        gw = ModelGateway({"alpha": bad, "beta": good}, max_concurrent_calls=2)
        self.assertEqual(gw.shutdown(timeout=0.5), 0)
        self.assertEqual(good.close_calls, 1)

    def test_core_shutdown_delegates_to_gateway(self):
        from sanour_ai.core.sanour_core import SanourCore
        from sanour_ai.models.router import DeterministicRouter

        p = ClosingProvider("alpha")
        core = SanourCore(
            router=DeterministicRouter([profile("alpha_model", "alpha")]),
            gateway=ModelGateway({"alpha": p}, max_concurrent_calls=1),
            audit=AuditLogger(),
        )
        self.assertEqual(core.shutdown(timeout=0.5), 0)
        self.assertEqual(p.close_calls, 1)


class OpenAIAdapterCloseTests(unittest.TestCase):
    def test_close_releases_sdk_client_without_network(self):
        class FakeClient:
            closed = 0

            def close(self):
                FakeClient.closed += 1

        adapter = OpenAIProvider.__new__(OpenAIProvider)  # skip __init__: no SDK, no network
        adapter._client = FakeClient()
        adapter.close()
        self.assertEqual(FakeClient.closed, 1)


class ConfigReachesGatewayTests(unittest.TestCase):
    def test_provider_limit_from_settings_applies_to_gateway(self):
        settings = load_settings({"SANOUR_PROVIDER_CONCURRENCY": "openai=2"})
        core = _assemble(
            profile("openai_primary", "openai"),
            {"openai": ClosingProvider("openai")},
            settings.max_concurrent_provider_calls,
            settings.provider_limits,
        )
        self.assertEqual(core._gateway._provider_slots["openai"]._value, 2)


class CoreExecutionPathTests(unittest.TestCase):
    def test_core_resolves_by_alias_and_never_calls_select(self):
        source = pathlib.Path("src/sanour_ai/core/sanour_core.py").read_text(encoding="utf-8")
        self.assertIn("self._router.resolve(request)", source)
        self.assertNotIn(".select(", source)


if __name__ == "__main__":
    unittest.main()
