"""Admission fail-closed end to end, and crash recovery adds no decision or money (Stage 10.49-R3/R4).

The provider is a counting fake. Admission events are required outbox rows; a sink that does not confirm them must
stop the request before any provider call, and must leave no budget or quota reservation behind.
"""

import logging
import os
import sqlite3
import tempfile
import unittest

from sanour_ai.composition.runtime import Runtime
from sanour_ai.errors import ErrorCode
from sanour_ai.governance.admission import AdmissionController
from sanour_ai.governance.store import GovernanceStore
from sanour_ai.models.usage import Usage
from sanour_ai.observability.audit import AuditLogger
from tests.unit.r4_support import ACTOR, RecordingSink
from tests.unit.test_stage1047r1 import UsageProvider
from tests.unit.test_stage1048 import env, raw
from tests.unit.test_stage1049 import BOUNDS, Clock, pricing
from tests.unit.test_stage1049r3_outbox import Base


class AdmissionFailClosed(unittest.TestCase):
    def setUp(self):
        self._dir = tempfile.TemporaryDirectory()
        self.addCleanup(self._dir.cleanup)
        self.path = os.path.join(self._dir.name, "gov.db")
        self.s = GovernanceStore(self.path)
        self.addCleanup(self.s.close)
        self.s.upsert_pricing(pricing())

    def runtime(self, provider, budget=None, quota=None):
        if budget is not None:
            self.s.upsert_budget("global", "", "daily", "USD", budget)
        if quota is not None:
            self.s.upsert_quota("global", "", "daily", "requests", quota)
        self.sink = RecordingSink(self.path + ".sink", self.path)
        self.addCleanup(self.sink.close)
        ctl = AdmissionController(self.s, audit=AuditLogger(logging.getLogger("test.1049r3.verify.admit")),
                                  bounds=BOUNDS, clock=Clock(), required_audit=True,
                                  authorized_actors=frozenset({ACTOR}), sink=self.sink)
        rt = Runtime.build_for_tests(env(), provider=provider, usage_ledger_path=self.path, governance=ctl)
        self.addCleanup(lambda: rt.shutdown(1.0))
        return rt

    def one(self, sql):
        conn = sqlite3.connect(self.path)
        try:
            return conn.execute(sql).fetchall()[0][0]
        finally:
            conn.close()

    def test_required_budget_sink_failure_prevents_the_provider_and_leaks_no_reservation(self):
        provider = UsageProvider(Usage(input_tokens=4, output_tokens=2, total_tokens=6))
        rt = self.runtime(provider, budget="0.025")  # one worst case is 0.02048: a leak would block the retry below
        self.sink.down = True
        response = rt.handle(raw(max_output_tokens=512))
        self.assertEqual(response.status, "error")
        self.assertEqual(response.error.code, ErrorCode.INTERNAL_ERROR)
        self.assertEqual(provider.calls, 0, "no provider call may follow an unconfirmed required admission event")
        self.assertEqual(self.one("SELECT state FROM reservations"), "released")
        self.assertEqual(self.one("SELECT reserved FROM budget_windows"), "0")
        self.assertEqual(self.one("SELECT spent FROM budget_windows"), "0")
        self.assertEqual(self.one("SELECT COUNT(*) FROM cost_records WHERE charged_from = 'exposed'"), 0)
        self.sink.down = False
        second = rt.handle(raw(max_output_tokens=512))
        self.assertEqual(second.status, "success")
        self.assertEqual(provider.calls, 1)

    def test_required_quota_sink_failure_prevents_the_provider_and_leaks_no_quota(self):
        provider = UsageProvider(Usage(input_tokens=4, output_tokens=2, total_tokens=6))
        rt = self.runtime(provider, quota=1)
        self.sink.down = True
        response = rt.handle(raw())
        self.assertEqual(response.status, "error")
        self.assertEqual(provider.calls, 0)
        self.assertEqual(self.one("SELECT reserved FROM quota_windows"), 0)
        self.assertEqual(self.one("SELECT used FROM quota_windows"), 0)
        self.assertEqual(self.one("SELECT state FROM reservations"), "released")
        self.sink.down = False
        second = rt.handle(raw())
        self.assertEqual(second.status, "success")
        self.assertEqual(provider.calls, 1)


class CrashAddsNoDecisionOrMoney(Base):
    """Recovery after a real process crash must not create a second decision and must not move money."""

    def test_crash_before_sink_then_recovery_adds_no_decision_and_no_money(self):
        rid = self.exposed_request()
        code, _ = self.run_crash("crash_before_sink", rid)
        self.assertEqual(code, 3)
        before = self.snapshot()
        self.assertEqual(before["write_off_ok"], 1)
        self.clock.now += 61
        sink, c = self.restart()
        c.sweep()
        c.sweep()
        self.assertEqual(self.snapshot(), before, "recovery must not add a decision, an outbox row or money")
        self.assertEqual(len(sink.accepted_keys("exposure.resolved")), 1)

    def test_crash_after_sink_then_duplicate_delivery_adds_no_decision_and_no_money(self):
        rid = self.exposed_request()
        code, seen = self.run_crash("crash_after_sink", rid)
        self.assertEqual(code, 4)
        before = self.snapshot()
        self.assertEqual(before["write_off_ok"], 1)
        self.clock.now += 61
        sink, c = self.restart()
        c.sweep()
        c.sweep()
        self.assertEqual(self.snapshot(), before)
        self.assertEqual(self.sink_receipts(self.key_for(rid)), 1, "the sink holds one logical receipt for the key")
        self.assertTrue(sink.receipts[-1].duplicate)


if __name__ == "__main__":
    unittest.main()
