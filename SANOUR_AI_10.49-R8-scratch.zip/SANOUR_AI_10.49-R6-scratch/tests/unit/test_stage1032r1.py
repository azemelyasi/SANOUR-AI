"""Stage 10.32-R1 tests: provider state observability and response-validation lifecycle.

Fake providers and fake adapters only. No network, no real key, no SDK. Waits are bounded.
"""

import threading
import unittest
from unittest import mock

from sanour_ai.core import coordinator as coord_mod
from sanour_ai.core.lifecycle import RequestLifecycle, RequestState
from sanour_ai.core.sanour_core import SanourCore
from sanour_ai.errors import ErrorCode
from sanour_ai.models.base import ModelResult, ProviderError
from sanour_ai.models.capabilities import ModelCapabilities, ModelProfile, ProviderCapabilities
from sanour_ai.models.gateway import VALIDATION_OUTCOMES, ModelGateway
from sanour_ai.models.router import DeterministicRouter
from sanour_ai.observability.audit import AuditLogger
from sanour_ai.providers.common import ContentBlockedError, IncompleteResponseError
from sanour_ai.providers.registry import ProviderRegistry
from tests.support import wait_until

R = RequestState
SECRET = "STAGE1032R1-SECRET-QQ"
TEXT = ProviderCapabilities(text_generation=True)


class Adapter:
    """Fake adapter with optional initialize/close failures and a blockable generate()."""

    def __init__(self, name="p1", behavior=None, init_error=None, close_error=None, on_init=None):
        self.name = name
        self.capabilities = TEXT
        self._behavior = behavior or (lambda call: ModelResult(text="ok", reported_model_id=call.model_id))
        self._init_error = init_error
        self._close_error = close_error
        self._on_init = on_init
        self.calls = 0
        self.started = threading.Event()
        self.release = threading.Event()

    def initialize(self):
        if self._on_init is not None:
            self._on_init()
        if self._init_error is not None:
            raise self._init_error

    def generate(self, call):
        self.calls += 1
        self.started.set()
        return self._behavior(call)

    def close(self):
        if self._close_error is not None:
            raise self._close_error


def blocking(adapter):
    def behavior(call):
        adapter.release.wait(5)
        return ModelResult(text="ok", reported_model_id=call.model_id)
    return behavior


def profile(alias="p_one", provider="p1", model_id="m-1032r1"):
    return ModelProfile(alias=alias, provider=provider, model_id=model_id,
                        capabilities=ModelCapabilities(text_generation=True, max_context_tokens=8192,
                                                       max_output_tokens=4096))


def req(timeout=5.0):
    return {"profile_alias": "p_one", "prompt": "hello", "timeout_seconds": timeout}


def core_for(registry, gateway_providers=None):
    gw = ModelGateway(gateway_providers if gateway_providers is not None else registry.ready_providers(),
                      max_concurrent_calls=2)
    core = SanourCore(router=DeterministicRouter([profile()]), gateway=gw, audit=AuditLogger(),
                      provider_states=registry.states)
    return core, gw


# ---------------------------------------------------------------- provider state across the lifecycle
class ProviderStateTests(unittest.TestCase):
    def test_registered_then_initializing_then_ready(self):
        registry = ProviderRegistry()
        holder = {}
        adapter = Adapter(on_init=lambda: seen.update(init=holder["core"].coordinator_stats().provider_states))
        seen = {}
        registry.register("p1", vendor="openai", surface="openai_responses", adapter=adapter)
        core, gw = core_for(registry, gateway_providers={})
        holder["core"] = core
        self.assertEqual(core.coordinator_stats().provider_states, {"p1": "registered"})
        registry.initialize("p1")
        self.assertEqual(seen["init"], {"p1": "initializing"})
        self.assertEqual(core.coordinator_stats().provider_states, {"p1": "ready"})
        gw.shutdown(0.1)

    def test_ready_is_visible_while_a_request_executes(self):
        registry = ProviderRegistry()
        seen = {}
        holder = {}

        def behavior(call):
            seen["during"] = holder["core"].coordinator_stats().provider_states
            return ModelResult(text="ok", reported_model_id=call.model_id)

        adapter = Adapter(behavior=behavior)
        registry.register("p1", vendor="openai", surface="openai_responses", adapter=adapter)
        registry.initialize("p1")
        core, gw = core_for(registry)
        holder["core"] = core
        self.assertEqual(core.handle(req()).status, "success")
        self.assertEqual(seen["during"], {"p1": "ready"})
        gw.shutdown(0.1)

    def test_closing_while_a_worker_is_active_then_closed(self):
        registry = ProviderRegistry()
        adapter = Adapter()
        adapter._behavior = blocking(adapter)
        registry.register("p1", vendor="openai", surface="openai_responses", adapter=adapter)
        registry.initialize("p1")
        core, gw = core_for(registry)
        result = {}
        t = threading.Thread(target=lambda: result.update(r=core.handle(req())))
        t.start()
        self.assertTrue(adapter.started.wait(5))
        self.assertEqual(registry.shutdown(gw, timeout=0.05), {"p1": "closing"})
        self.assertEqual(core.coordinator_stats().provider_states, {"p1": "closing"})
        adapter.release.set()
        t.join(5)
        self.assertEqual(result["r"].status, "success")
        self.assertEqual(registry.shutdown(gw, timeout=1.0), {"p1": "closed"})
        self.assertEqual(core.coordinator_stats().provider_states, {"p1": "closed"})

    def test_failed_initialization_is_visible(self):
        registry = ProviderRegistry()
        registry.register("p1", vendor="openai", surface="openai_responses",
                          adapter=Adapter(init_error=RuntimeError(SECRET)))
        core, gw = core_for(registry, gateway_providers={})
        with self.assertRaises(Exception):
            registry.initialize("p1")
        self.assertEqual(core.coordinator_stats().provider_states, {"p1": "failed"})
        gw.shutdown(0.1)

    def test_failed_close_is_visible_and_the_error_text_is_not(self):
        registry = ProviderRegistry()
        registry.register("p1", vendor="openai", surface="openai_responses",
                          adapter=Adapter(close_error=RuntimeError(SECRET)))
        registry.initialize("p1")
        core, gw = core_for(registry)
        registry.shutdown(gw, timeout=0.05)
        stats = core.coordinator_stats()
        self.assertEqual(stats.provider_states, {"p1": "failed"})
        self.assertNotIn(SECRET, repr(stats))

    def test_states_are_read_live_not_copied(self):
        registry = ProviderRegistry()
        registry.register("p1", vendor="openai", surface="openai_responses", adapter=Adapter())
        core, gw = core_for(registry, gateway_providers={})
        first = core.coordinator_stats().provider_states
        registry.initialize("p1")
        second = core.coordinator_stats().provider_states
        self.assertEqual((first, second), ({"p1": "registered"}, {"p1": "ready"}))
        gw.shutdown(0.1)

    def test_every_lifecycle_state_is_in_the_reporting_vocabulary(self):
        self.assertEqual(coord_mod.PROVIDER_STATE_VALUES,
                         {"registered", "initializing", "ready", "closing", "closed", "failed"})

    def test_reported_states_are_bounded_and_unknown_values_are_dropped(self):
        def fake_states():
            out = {f"p{i:03d}": "ready" for i in range(100)}
            out["p-bad"] = "secret-looking-value"
            return out
        gw = ModelGateway({}, max_concurrent_calls=1)
        core = SanourCore(router=DeterministicRouter([profile()]), gateway=gw, audit=AuditLogger(),
                          provider_states=fake_states)
        states = core.coordinator_stats().provider_states
        self.assertLessEqual(len(states), coord_mod.MAX_PROVIDER_ENTRIES)
        self.assertNotIn("p-bad", states)
        self.assertTrue(all(v in coord_mod.PROVIDER_STATE_VALUES for v in states.values()))
        gw.shutdown(0.1)

    def test_no_provider_states_without_a_registry_reader(self):
        gw = ModelGateway({}, max_concurrent_calls=1)
        core = SanourCore(router=DeterministicRouter([profile()]), gateway=gw, audit=AuditLogger())
        self.assertEqual(core.coordinator_stats().provider_states, {})
        gw.shutdown(0.1)


# ---------------------------------------------------------------- response validation lifecycle
class ValidationLifecycleTests(unittest.TestCase):
    def _core(self, behavior):
        adapter = Adapter(behavior=behavior)
        gw = ModelGateway({"p1": adapter}, max_concurrent_calls=2)
        return SanourCore(router=DeterministicRouter([profile()]), gateway=gw, audit=AuditLogger()), gw, adapter

    def test_validation_start_and_end_are_recorded_in_order(self):
        recorded = []

        class Spy(RequestLifecycle):
            def __init__(self, *a, **k):
                super().__init__(*a, **k)
                recorded.append(self)

        core, gw, _ = self._core(lambda call: ModelResult(text="ok", reported_model_id=call.model_id))
        with mock.patch.object(coord_mod, "RequestLifecycle", Spy):
            self.assertEqual(core.handle(req()).status, "success")
        lc = recorded[0]
        self.assertEqual(lc.history, (R.RECEIVED, R.VALIDATING, R.RESOLVED, R.WAITING_CAPACITY,
                                      R.EXECUTING, R.VALIDATING_RESPONSE, R.COMPLETED))
        self.assertLessEqual(lc.entered_at(R.EXECUTING), lc.entered_at(R.VALIDATING_RESPONSE))
        self.assertLessEqual(lc.entered_at(R.VALIDATING_RESPONSE), lc.entered_at(R.COMPLETED))
        self.assertEqual(lc.validation_outcome, "passed")
        stats = core.coordinator_stats()
        self.assertEqual(stats.validation_counts["passed"], 1)
        self.assertGreaterEqual(stats.validation_ms_total, 0)
        gw.shutdown(0.1)

    def test_each_validation_failure_has_its_own_outcome_and_failed_state(self):
        cases = {
            "incomplete_response": lambda call: (_ for _ in ()).throw(IncompleteResponseError("cut")),
            "content_blocked": lambda call: (_ for _ in ()).throw(ContentBlockedError("blocked")),
            "provider_error": lambda call: (_ for _ in ()).throw(ProviderError("down")),
            "invalid_response": lambda call: ModelResult(text="   ", reported_model_id=call.model_id),
            "identity_mismatch": lambda call: ModelResult(text="ok", reported_model_id="someone-else"),
        }
        for label, behavior in cases.items():
            with self.subTest(outcome=label):
                core, gw, _ = self._core(behavior)
                resp = core.handle(req())
                self.assertEqual(resp.status, "error")
                stats = core.coordinator_stats()
                self.assertEqual(stats.validation_counts[label], 1)
                self.assertEqual(stats.terminal_counts["failed"], 1)
                gw.shutdown(0.1)

    def test_content_blocked_and_identity_mismatch_map_to_their_codes(self):
        core, gw, _ = self._core(lambda call: (_ for _ in ()).throw(ContentBlockedError("blocked")))
        self.assertEqual(core.handle(req()).error.code, ErrorCode.PROVIDER_CONTENT_BLOCKED)
        gw.shutdown(0.1)
        core, gw, _ = self._core(lambda call: ModelResult(text="ok", reported_model_id="other"))
        resp = core.handle(req())
        self.assertEqual(resp.error.code, ErrorCode.PROVIDER_INVALID_RESPONSE)
        self.assertEqual(core.coordinator_stats().validation_counts["identity_mismatch"], 1)
        gw.shutdown(0.1)

    def test_validation_outcome_is_recorded_only_in_validating_response(self):
        lc = RequestLifecycle()
        with self.assertRaises(Exception):
            lc.record_validation("passed")
        lc.move(R.VALIDATING)
        with self.assertRaises(Exception):
            lc.record_validation("passed")

    def test_timeout_during_execution_is_not_counted_as_validation(self):
        adapter = Adapter()
        adapter._behavior = blocking(adapter)
        gw = ModelGateway({"p1": adapter}, max_concurrent_calls=2)
        core = SanourCore(router=DeterministicRouter([profile()]), gateway=gw, audit=AuditLogger())
        resp = core.handle(req(timeout=0.2))
        self.assertEqual(resp.error.code, ErrorCode.PROVIDER_TIMEOUT)
        stats = core.coordinator_stats()
        self.assertEqual(stats.validation_counts["not_reached"], 1)
        self.assertEqual(stats.validation_counts["passed"], 0)
        adapter.release.set()
        self.assertTrue(wait_until(lambda: gw.stats().active_workers == 0, timeout=3.0))
        gw.shutdown(0.1)

    def test_shutdown_refusal_is_not_counted_as_validation(self):
        gw = ModelGateway({"p1": Adapter()}, max_concurrent_calls=2)
        core = SanourCore(router=DeterministicRouter([profile()]), gateway=gw, audit=AuditLogger())
        core.shutdown(0.1)
        self.assertEqual(core.handle(req()).error.code, ErrorCode.PROVIDER_FAILED)
        self.assertEqual(core.coordinator_stats().validation_counts["not_reached"], 1)

    def test_coordinator_holds_no_validation_logic_of_its_own(self):
        with open(coord_mod.__file__, encoding="utf-8") as fh:
            text = fh.read()
        self.assertNotIn("MAX_RESULT_CHARS", text)
        self.assertNotIn("_reported_identity_accepted", text)
        self.assertNotIn(".text.strip(", text)
        self.assertNotIn("isinstance(result", text)

    def test_validation_metrics_stay_bounded_under_traffic(self):
        core, gw, _ = self._core(lambda call: ModelResult(text="ok", reported_model_id=call.model_id))
        before = set(core.coordinator_stats().validation_counts)
        for _ in range(40):
            core.handle(req())
        after = core.coordinator_stats()
        self.assertEqual(set(after.validation_counts), before)
        self.assertEqual(after.validation_counts["passed"], 40)
        gw.shutdown(0.1)

    def test_validation_outcomes_are_a_fixed_set(self):
        self.assertEqual(VALIDATION_OUTCOMES, {"passed", "incomplete_response", "invalid_response",
                                               "identity_mismatch", "content_blocked", "provider_error"})

    def test_secret_in_a_validation_failure_never_reaches_metrics(self):
        core, gw, _ = self._core(lambda call: (_ for _ in ()).throw(ProviderError(f"raw {SECRET}")))
        resp = core.handle(req())
        self.assertNotIn(SECRET, resp.error.message)
        self.assertNotIn(SECRET, repr(core.coordinator_stats()))
        gw.shutdown(0.1)


if __name__ == "__main__":
    unittest.main()
