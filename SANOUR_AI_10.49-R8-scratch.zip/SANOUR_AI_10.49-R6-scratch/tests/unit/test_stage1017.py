"""Stage 10.17 tests: provider contract at registration, lifecycle state, profile/provider wiring.

Mock only. No network, no keys, no new dependencies.
"""

import unittest
from tests.support import TEST_ALL_CAPS

from sanour_ai.composition.production import _assemble
from sanour_ai.config.settings import ConfigError
from sanour_ai.models.base import ModelResult
from sanour_ai.models.capabilities import ModelCapabilities, ModelProfile
from sanour_ai.models.gateway import ModelGateway


class NamedProvider:
    capabilities = TEST_ALL_CAPS
    def __init__(self, name):
        self.name = name

    def generate(self, call):
        return ModelResult(text="ok", reported_model_id=call.model_id)


class NoGenerate:
    name = "alpha"


def profile(provider):
    return ModelProfile(
        alias="alpha_model",
        provider=provider,
        model_id="alpha-id",
        capabilities=ModelCapabilities(text_generation=True, max_context_tokens=8192, max_output_tokens=4096),
        runs_locally=True,
    )


class ProviderContractTests(unittest.TestCase):
    def test_valid_provider_is_accepted(self):
        ModelGateway({"alpha": NamedProvider("alpha")}, max_concurrent_calls=1)

    def test_name_must_match_registry_key(self):
        with self.assertRaises(ValueError):
            ModelGateway({"alpha": NamedProvider("beta")}, max_concurrent_calls=1)

    def test_provider_without_generate_is_rejected(self):
        with self.assertRaises(ValueError):
            ModelGateway({"alpha": NoGenerate()}, max_concurrent_calls=1)

    def test_provider_without_name_is_rejected(self):
        class Nameless:
            def generate(self, call):
                return ModelResult(text="ok", reported_model_id=call.model_id)

        with self.assertRaises(ValueError):
            ModelGateway({"alpha": Nameless()}, max_concurrent_calls=1)


class LifecycleStateTests(unittest.TestCase):
    def test_open_then_shut_down(self):
        gw = ModelGateway({"alpha": NamedProvider("alpha")}, max_concurrent_calls=1)
        self.assertFalse(gw.is_shut_down)
        gw.shutdown(timeout=0.1)
        self.assertTrue(gw.is_shut_down)

    def test_shutdown_is_idempotent(self):
        gw = ModelGateway({"alpha": NamedProvider("alpha")}, max_concurrent_calls=1)
        self.assertEqual(gw.shutdown(timeout=0.1), 0)
        self.assertEqual(gw.shutdown(timeout=0.1), 0)
        self.assertTrue(gw.is_shut_down)


class ProfileWiringTests(unittest.TestCase):
    def test_profile_pointing_at_unregistered_provider_is_rejected(self):
        with self.assertRaises(ConfigError):
            _assemble(profile("beta"), {"alpha": NamedProvider("alpha")}, 2)

    def test_profile_with_registered_provider_is_accepted(self):
        core = _assemble(profile("alpha"), {"alpha": NamedProvider("alpha")}, 2)
        self.assertFalse(core._gateway.is_shut_down)


if __name__ == "__main__":
    unittest.main()
