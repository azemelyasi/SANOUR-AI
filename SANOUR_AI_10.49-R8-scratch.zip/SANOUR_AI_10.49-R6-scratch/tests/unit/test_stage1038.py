"""Stage 10.38: deadline semantics and the four FailureKind decisions.

Offline only. Fake transports and fake SDK error classes. No network, no SDK, no key. Waits are bounded.
"""

import pathlib
import time
import types
import unittest

from pydantic import SecretStr

from sanour_ai.errors import ErrorCode, FailureKind, SanourError
from sanour_ai.models.base import ModelCall, ModelResult, ProviderError
from sanour_ai.models.capabilities import ModelCapabilities, ModelProfile
from sanour_ai.models.error_taxonomy import InternalErrorKind, classify
from sanour_ai.models.gateway import ModelGateway
from sanour_ai.providers.anthropic_provider import AnthropicProvider
from sanour_ai.providers.common import DeadlineExpired, HttpResult
from sanour_ai.providers.openai_provider import OpenAIProvider
from tests.support import TEST_ALL_CAPS, deadline_in, wait_until
from tests.support import request_identity_for as _rid

ROOT = pathlib.Path(__file__).resolve().parents[2]
MODEL = "claude-test-1"
PROFILE = ModelProfile(
    alias="mock_default", provider="mock", model_id="mock-echo-1",
    capabilities=ModelCapabilities(text_generation=True, max_context_tokens=8192, max_output_tokens=4096),
    runs_locally=True,
)
CALL_PROFILE = ModelCall(model_id="mock-echo-1", prompt="hi", max_output_tokens=16)


class SlowTransport:
    """Sleeps, then either raises or returns. Models a slow network without real I/O."""

    def __init__(self, sleep, raise_exc=None, result=None):
        self.sleep, self.raise_exc, self.result = sleep, raise_exc, result

    def __call__(self, url, headers, body, timeout):
        time.sleep(self.sleep)
        if self.raise_exc is not None:
            raise self.raise_exc
        return self.result


def anthropic_call(budget):
    return ModelCall(model_id=MODEL, prompt="hi", max_output_tokens=16, deadline=time.monotonic() + budget)


def provider_error(fn):
    with_raised = None
    try:
        fn()
    except ProviderError as exc:
        with_raised = exc
    if with_raised is None:
        raise AssertionError("expected ProviderError")
    return with_raised


class TransportDeadlineSemantics(unittest.TestCase):
    def test_connection_failure_before_deadline_is_connection(self):
        p = AnthropicProvider(SecretStr("k" * 12), transport=SlowTransport(0.0, raise_exc=OSError("reset")))
        exc = provider_error(lambda: p.generate(anthropic_call(5.0)))
        self.assertIs(exc.kind, FailureKind.CONNECTION)
        self.assertTrue(exc.retryable)

    def test_failure_observed_after_deadline_is_deadline_in_call(self):
        p = AnthropicProvider(SecretStr("k" * 12), transport=SlowTransport(0.15, raise_exc=OSError("timeout")))
        exc = provider_error(lambda: p.generate(anthropic_call(0.05)))
        self.assertIs(exc.kind, FailureKind.DEADLINE_IN_CALL)
        self.assertEqual(str(exc), "deadline expired during provider call")
        self.assertTrue(exc.retryable)

    def test_deadline_expiry_reported_by_transport_is_deadline_in_call(self):
        p = AnthropicProvider(SecretStr("k" * 12), transport=SlowTransport(0.0, raise_exc=DeadlineExpired("x")))
        exc = provider_error(lambda: p.generate(anthropic_call(5.0)))
        self.assertIs(exc.kind, FailureKind.DEADLINE_IN_CALL)

    def test_response_after_deadline_is_late_and_never_parsed_as_success(self):
        result = HttpResult(200, b"not json at all", {})
        p = AnthropicProvider(SecretStr("k" * 12), transport=SlowTransport(0.15, result=result))
        exc = provider_error(lambda: p.generate(anthropic_call(0.05)))
        self.assertIs(exc.kind, FailureKind.DEADLINE_LATE)

    def test_no_deadline_is_refused_before_io(self):
        t = SlowTransport(0.0, raise_exc=OSError("should not run"))
        p = AnthropicProvider(SecretStr("k" * 12), transport=t)
        exc = provider_error(lambda: p.generate(ModelCall(model_id=MODEL, prompt="hi", max_output_tokens=16)))
        self.assertIs(exc.kind, FailureKind.DEADLINE_MISSING)


class _SdkTimeout(Exception):
    pass


class _SdkConnection(Exception):
    pass


class _SdkOther(Exception):
    pass


def _sdk_namespace():
    return types.SimpleNamespace(
        api_timeout=_SdkTimeout, api_connection=_SdkConnection, authentication=_SdkOther,
        permission_denied=_SdkOther, not_found=_SdkOther, rate_limit=_SdkOther,
        api_status=_SdkOther, internal_server=_SdkOther,
    )


class OpenAITransportDeadline(unittest.TestCase):
    def mapper(self):
        provider = OpenAIProvider.__new__(OpenAIProvider)
        provider._errors = _sdk_namespace()
        return provider

    def test_sdk_timeout_before_deadline_is_per_call_timeout(self):
        exc = self.mapper()._map_error(_SdkTimeout(), time.monotonic() + 5.0)
        self.assertIs(exc.kind, FailureKind.CALL_TIMEOUT)

    def test_sdk_timeout_at_or_after_deadline_is_deadline(self):
        exc = self.mapper()._map_error(_SdkTimeout(), time.monotonic() - 0.01)
        self.assertIs(exc.kind, FailureKind.DEADLINE_IN_CALL)
        self.assertEqual(str(exc), "deadline expired during provider call")

    def test_sdk_connection_error_before_and_after_deadline(self):
        self.assertIs(self.mapper()._map_error(_SdkConnection(), time.monotonic() + 5.0).kind,
                      FailureKind.CONNECTION)
        self.assertIs(self.mapper()._map_error(_SdkConnection(), time.monotonic() - 0.01).kind,
                      FailureKind.DEADLINE_IN_CALL)

    def test_mapper_without_deadline_keeps_old_behaviour(self):
        self.assertIs(self.mapper()._map_error(_SdkTimeout()).kind, FailureKind.CALL_TIMEOUT)


class FailureKindDecisions(unittest.TestCase):
    def kind_of(self, kind):
        return classify(SanourError(ErrorCode.PROVIDER_FAILED, "model provider failed", internal_kind=kind))

    def test_limit_reached_is_unconfirmed_not_rate_and_not_quota(self):
        self.assertIs(self.kind_of(FailureKind.LIMIT_REACHED), InternalErrorKind.PROVIDER_LIMIT_UNCONFIRMED)

    def test_payment_required_is_quota_group(self):
        self.assertIs(self.kind_of(FailureKind.PAYMENT_REQUIRED), InternalErrorKind.PROVIDER_QUOTA)

    def test_call_timeout_is_transport(self):
        self.assertIs(self.kind_of(FailureKind.CALL_TIMEOUT), InternalErrorKind.PROVIDER_TRANSPORT)

    def test_response_too_large_is_invalid_response(self):
        self.assertIs(self.kind_of(FailureKind.RESPONSE_TOO_LARGE), InternalErrorKind.PROVIDER_INVALID_RESPONSE)

    def test_deadline_missing_is_internal_fault_not_expiry(self):
        self.assertIs(self.kind_of(FailureKind.DEADLINE_MISSING), InternalErrorKind.INTERNAL_EXECUTION)

    def test_deadline_in_call_is_deadline(self):
        self.assertIs(self.kind_of(FailureKind.DEADLINE_IN_CALL), InternalErrorKind.DEADLINE_EXCEEDED)

    def test_unknown_429_from_adapter_is_unconfirmed_and_not_retryable(self):
        from sanour_ai.providers.common import payment_error, rate_limit_error
        exc = rate_limit_error(None, {})
        self.assertIs(exc.kind, FailureKind.LIMIT_REACHED)
        self.assertFalse(exc.retryable)
        self.assertIs(classify(SanourError(ErrorCode.PROVIDER_FAILED, "model provider failed",
                                           internal_kind=exc.kind)), InternalErrorKind.PROVIDER_LIMIT_UNCONFIRMED)
        self.assertFalse(payment_error(None, {}).retryable)

    def test_decision_record_lists_every_failure_kind(self):
        text = (ROOT / "docs" / "FAILURE_KIND_DECISIONS.md").read_text(encoding="utf-8")
        missing = [k.name for k in FailureKind if k.name not in text]
        self.assertEqual(missing, [])


class CapacityHeldUntilWorkerReturns(unittest.TestCase):
    def test_timed_out_worker_keeps_its_slot_until_it_really_returns(self):
        class Slow:
            name = "mock"
            capabilities = TEST_ALL_CAPS

            def generate(self, call):
                time.sleep(0.4)
                return ModelResult(text="late", reported_model_id="mock-echo-1")

        gw = ModelGateway({"mock": Slow()}, max_concurrent_calls=1)
        try:
            with self.assertRaises(SanourError) as ctx:
                gw.generate(PROFILE, CALL_PROFILE, deadline_in(0.1), identity=_rid(PROFILE))
            self.assertIs(ctx.exception.code, ErrorCode.PROVIDER_TIMEOUT)
            # The caller has been released, but the worker is still running and holds the only slot.
            with self.assertRaises(SanourError) as second:
                gw.generate(PROFILE, CALL_PROFILE, deadline_in(0.1), identity=_rid(PROFILE))
            self.assertIs(second.exception.code, ErrorCode.PROVIDER_OVERLOADED)
            self.assertTrue(wait_until(lambda: gw.stats().in_flight == 0, timeout=3.0))
        finally:
            gw.shutdown(1.0)


if __name__ == "__main__":
    unittest.main()
