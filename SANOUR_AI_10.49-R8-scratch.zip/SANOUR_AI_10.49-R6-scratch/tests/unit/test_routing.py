"""Routing rules, converted from select() to explicit resolve() in Stage 10.36.

Every request names its profile. Filter rules (limits, offline, text generation) still apply to the
named profile. Priority, tie-break and "first eligible" behaviour no longer exist: they were removed
with the automatic selection path, so those tests now assert that an explicit alias never substitutes.
"""

import unittest

from sanour_ai.core.request_manager import accept
from sanour_ai.errors import ErrorCode, SanourError
from sanour_ai.models.capabilities import ModelCapabilities, ModelProfile
from sanour_ai.models.router import DeterministicRouter, estimate_tokens

RID = "b" * 32


def caps(**overrides):
    base = {"text_generation": True, "max_context_tokens": 1000, "max_output_tokens": 1000}
    base.update(overrides)
    return ModelCapabilities(**base)


def profile(alias, priority=100, runs_locally=True, **cap_overrides):
    return ModelProfile(
        alias=alias,
        provider="mock",
        model_id=f"{alias}-id",
        capabilities=caps(**cap_overrides),
        runs_locally=runs_locally,
        priority=priority,
    )


def req(alias, **overrides):
    raw = {"profile_alias": alias, "prompt": "hello world"}
    raw.update(overrides)
    return accept(raw, RID)


class RoutingTests(unittest.TestCase):
    def test_estimate_tokens(self):
        self.assertEqual(estimate_tokens("abcd"), 1)
        self.assertEqual(estimate_tokens("abcde"), 2)
        self.assertEqual(estimate_tokens(""), 0)

    def test_named_profile_wins_regardless_of_priority_or_other_profiles(self):
        router = DeterministicRouter(
            [profile("b_model", 10), profile("a_model", 10), profile("c_model", 5)]
        )
        self.assertEqual(router.resolve(req("b_model")).alias, "b_model")

    def test_unnamed_or_unknown_alias_never_substitutes_another_profile(self):
        router = DeterministicRouter([profile("b_model", 10), profile("a_model", 10)])
        with self.assertRaises(SanourError) as ctx:
            router.resolve(req("z_model"))
        self.assertEqual(ctx.exception.code, ErrorCode.NO_ELIGIBLE_MODEL)

    def test_same_request_gives_same_profile_regardless_of_registration_order(self):
        first = DeterministicRouter([profile("x_model", 1), profile("y_model", 1)])
        second = DeterministicRouter([profile("y_model", 1), profile("x_model", 1)])
        self.assertEqual(first.resolve(req("x_model")).alias, second.resolve(req("x_model")).alias)

    def test_text_generation_is_required(self):
        router = DeterministicRouter([profile("no_text", text_generation=False)])
        with self.assertRaises(SanourError) as ctx:
            router.resolve(req("no_text"))
        self.assertEqual(ctx.exception.code, ErrorCode.NO_ELIGIBLE_MODEL)

    def test_output_limit_refuses_the_named_profile(self):
        router = DeterministicRouter([profile("small_out", max_output_tokens=100)])
        with self.assertRaises(SanourError) as ctx:
            router.resolve(req("small_out", max_output_tokens=200))
        self.assertEqual(ctx.exception.code, ErrorCode.NO_ELIGIBLE_MODEL)

    def test_context_limit_refuses_the_named_profile(self):
        router = DeterministicRouter([profile("small_ctx", max_context_tokens=30)])
        with self.assertRaises(SanourError):
            router.resolve(req("small_ctx", prompt="x" * 100, max_output_tokens=50))

    def test_offline_only_refuses_remote_named_profile_and_accepts_local(self):
        router = DeterministicRouter(
            [profile("remote", priority=1, runs_locally=False), profile("local", priority=2)]
        )
        with self.assertRaises(SanourError):
            router.resolve(req("remote", offline_only=True))
        self.assertEqual(router.resolve(req("local", offline_only=True)).alias, "local")

    def test_remote_allowed_when_not_offline_only(self):
        router = DeterministicRouter([profile("remote", runs_locally=False)])
        self.assertEqual(router.resolve(req("remote")).alias, "remote")

    def test_duplicate_aliases_rejected(self):
        with self.assertRaises(ValueError):
            DeterministicRouter([profile("same_name"), profile("same_name")])

    def test_empty_router_has_no_eligible_model(self):
        with self.assertRaises(SanourError) as ctx:
            DeterministicRouter([]).resolve(req("any_model"))
        self.assertEqual(ctx.exception.code, ErrorCode.NO_ELIGIBLE_MODEL)
