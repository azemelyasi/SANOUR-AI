"""Stage 10.27 tests: Gemini content blocking vs incomplete vs invalid responses.

Fake transport and fixed bodies only. No network, no real key, no SDK.
"""

from tests.support import request_identity_for as _rid
import json
import logging
import time
import unittest

from pydantic import SecretStr

from sanour_ai.core.sanour_core import SanourCore
from sanour_ai.errors import ErrorCode, SanourError
from sanour_ai.models.base import ModelCall, ModelResult, ProviderError
from sanour_ai.models.capabilities import ModelCapabilities, ModelProfile
from sanour_ai.models.gateway import ModelGateway
from sanour_ai.models.router import DeterministicRouter
from sanour_ai.observability.audit import AUDIT_LOGGER_NAME, AuditLogger
from sanour_ai.providers.common import ContentBlockedError, IncompleteResponseError
from sanour_ai.providers.gemini_provider import GeminiProvider
from tests.support import TEST_ALL_CAPS, deadline_in

KEY = "STAGE1027-TESTONLY-KEY"
MODEL = "gemini-test-1"
PROMPT = "SECRET-PROMPT-1027 tell me things"
REPLY = "SECRET-REPLY-1027 the model text"
SAFETY_MSG = "SECRET-BLOCKMSG-1027 explanation"
UNKNOWN = "SECRET-UNKNOWN-1027"

BLOCKING_FINISH = ("SAFETY", "BLOCKLIST", "PROHIBITED_CONTENT", "SPII", "IMAGE_SAFETY")
PROMPT_BLOCK = ("SAFETY", "OTHER", "BLOCKLIST", "PROHIBITED_CONTENT", "IMAGE_SAFETY")


class FakeTransport:
    def __init__(self, body, status=200):
        self.body, self.status, self.calls = body, status, 0

    def __call__(self, url, headers, body, timeout):
        self.calls += 1
        return self.status, self.body


def body(candidates=None, feedback=None, model=MODEL, extra=None):
    doc = {}
    if candidates is not None:
        doc["candidates"] = candidates
    if feedback is not None:
        doc["promptFeedback"] = feedback
    if model is not None:
        doc["modelVersion"] = model
    if extra:
        doc.update(extra)
    return json.dumps(doc).encode()


def stop_candidate(text=REPLY):
    return {"content": {"role": "model", "parts": [{"text": text}]}, "finishReason": "STOP"}


def cand(finish, *, text=REPLY, extra=None):
    c = {"content": {"role": "model", "parts": [{"text": text}]}, "finishReason": finish}
    if finish is None:
        c.pop("finishReason")
    if extra:
        c.update(extra)
    return c


def call(deadline=None):
    return ModelCall(model_id=MODEL, prompt=PROMPT, max_output_tokens=64,
                     deadline=deadline if deadline is not None else time.monotonic() + 5)


def provider_for(raw, status=200):
    t = FakeTransport(raw, status)
    return GeminiProvider(SecretStr(KEY), transport=t), t


def run(raw, status=200):
    p, t = provider_for(raw, status)
    return p.generate(call()), t


def profile(alias="gem_primary", model_id=MODEL, accepted=frozenset(), priority=0, provider="gemini"):
    return ModelProfile(
        alias=alias, provider=provider, model_id=model_id,
        capabilities=ModelCapabilities(text_generation=True, max_context_tokens=8192,
                                       max_output_tokens=4096),
        runs_locally=False, priority=priority, accepted_reported_model_ids=accepted,
    )


class _Capture(logging.Handler):
    def __init__(self):
        super().__init__()
        self.lines = []

    def emit(self, record):
        self.lines.append(record.getMessage())


def core_with(providers, profiles):
    gw = ModelGateway(providers, max_concurrent_calls=2)
    logger = logging.getLogger(AUDIT_LOGGER_NAME + ".stage1027")
    logger.handlers.clear()
    logger.propagate = False
    handler = _Capture()
    logger.addHandler(handler)
    core = SanourCore(router=DeterministicRouter(profiles), gateway=gw, audit=AuditLogger(logger))
    return core, gw, handler


class BlockedPromptTests(unittest.TestCase):
    def test_prompt_block_reason_is_content_blocked_for_each_known_reason(self):
        for reason in PROMPT_BLOCK:
            with self.subTest(reason=reason):
                raw = body(feedback={"blockReason": reason, "safetyRatings": []})
                with self.assertRaises(ContentBlockedError):
                    run(raw)

    def test_prompt_block_is_checked_before_candidates(self):
        raw = body(candidates=[stop_candidate()], feedback={"blockReason": "SAFETY"})
        with self.assertRaises(ContentBlockedError):
            run(raw)

    def test_prompt_block_message_never_leaks(self):
        raw = body(feedback={"blockReason": "SAFETY", "blockReasonMessage": SAFETY_MSG})
        try:
            run(raw)
        except ContentBlockedError as exc:
            self.assertNotIn(SAFETY_MSG, str(exc))
            self.assertNotIn(SAFETY_MSG, repr(exc))
        else:
            self.fail("expected ContentBlockedError")

    def test_empty_block_reason_is_not_a_block(self):
        raw = body(candidates=[stop_candidate()], feedback={"blockReason": ""})
        result, _ = run(raw)
        self.assertEqual(result.text, REPLY)

    def test_unknown_block_reason_is_invalid_not_blocked(self):
        raw = body(feedback={"blockReason": UNKNOWN})
        with self.assertRaises(IncompleteResponseError) as ctx:
            run(raw)
        self.assertNotIsInstance(ctx.exception, ContentBlockedError)

    def test_block_reason_unspecified_is_treated_as_unknown(self):
        raw = body(feedback={"blockReason": "BLOCK_REASON_UNSPECIFIED"})
        with self.assertRaises(IncompleteResponseError):
            run(raw)

    def test_non_string_block_reason_is_invalid(self):
        raw = body(feedback={"blockReason": 7})
        with self.assertRaises(IncompleteResponseError):
            run(raw)

    def test_non_dict_feedback_is_invalid(self):
        with self.assertRaises(IncompleteResponseError):
            run(body(candidates=[stop_candidate()], feedback="SAFETY"))


class CandidateFinishTests(unittest.TestCase):
    def test_each_of_the_five_blocking_finish_reasons_is_content_blocked(self):
        for finish in BLOCKING_FINISH:
            with self.subTest(finish=finish):
                with self.assertRaises(ContentBlockedError) as ctx:
                    run(body(candidates=[cand(finish)]))
                self.assertFalse(ctx.exception.retryable)

    def test_content_blocked_is_not_incomplete_or_invalid(self):
        with self.assertRaises(ContentBlockedError) as ctx:
            run(body(candidates=[cand("SAFETY")]))
        self.assertNotIsInstance(ctx.exception, IncompleteResponseError)

    def test_max_tokens_stays_incomplete_not_blocked(self):
        with self.assertRaises(IncompleteResponseError) as ctx:
            run(body(candidates=[cand("MAX_TOKENS")]))
        self.assertNotIsInstance(ctx.exception, ContentBlockedError)
        self.assertFalse(ctx.exception.retryable)

    def test_stop_with_valid_text_succeeds(self):
        result, _ = run(body(candidates=[stop_candidate()]))
        self.assertEqual(result, ModelResult(text=REPLY, reported_model_id=MODEL))

    def test_stop_with_empty_text_is_invalid(self):
        for text in ("", "   "):
            with self.subTest(text=repr(text)):
                with self.assertRaises(IncompleteResponseError):
                    run(body(candidates=[cand("STOP", text=text)]))

    def test_stop_without_content_is_invalid(self):
        for content in (None, {}, {"parts": []}, {"parts": "x"}):
            with self.subTest(content=content):
                c = {"finishReason": "STOP"}
                if content is not None:
                    c["content"] = content
                with self.assertRaises(IncompleteResponseError):
                    run(body(candidates=[c]))

    def test_unexpected_part_is_invalid_and_thought_signature_is_ignored(self):
        with self.assertRaises(IncompleteResponseError):
            run(body(candidates=[{"content": {"parts": [{"text": "a"}, {"functionCall": {}}]},
                                  "finishReason": "STOP"}]))
        result, _ = run(body(candidates=[{"content": {"parts": [
            {"text": "a"}, {"thoughtSignature": "opaque"}, {"text": "b"}]},
            "finishReason": "STOP"}]))
        self.assertEqual(result.text, "ab")


class InvalidShapeTests(unittest.TestCase):
    def test_missing_candidate_without_block_is_invalid(self):
        for raw in (body(candidates=[]), body(candidates=None), body(candidates="x")):
            with self.subTest(raw=raw[:40]):
                with self.assertRaises(IncompleteResponseError):
                    run(raw)

    def test_missing_finish_reason_is_invalid(self):
        with self.assertRaises(IncompleteResponseError):
            run(body(candidates=[cand(None)]))

    def test_empty_or_non_string_finish_reason_is_invalid(self):
        for finish in ("", 3):
            with self.subTest(finish=finish):
                with self.assertRaises(IncompleteResponseError):
                    run(body(candidates=[cand(finish)]))

    def test_unknown_finish_reasons_are_invalid_not_blocked(self):
        for finish in (UNKNOWN, "OTHER", "RECITATION", "LANGUAGE", "MALFORMED_FUNCTION_CALL",
                       "FINISH_REASON_UNSPECIFIED"):
            with self.subTest(finish=finish):
                with self.assertRaises(IncompleteResponseError) as ctx:
                    run(body(candidates=[cand(finish)]))
                self.assertNotIsInstance(ctx.exception, ContentBlockedError)

    def test_malformed_or_non_object_bodies_are_invalid(self):
        for raw in (b"not json", b"[]", b"", b"null", b'"text"', b"\xff\xfe"):
            with self.subTest(raw=raw):
                with self.assertRaises(IncompleteResponseError):
                    run(raw)

    def test_candidate_not_an_object_is_invalid(self):
        with self.assertRaises(IncompleteResponseError):
            run(body(candidates=["STOP"]))

    def test_oversized_body_refused_without_parsing(self):
        from sanour_ai.providers.common import MAX_RESPONSE_BYTES
        with self.assertRaises(ProviderError) as ctx:
            run(b" " * (MAX_RESPONSE_BYTES + 1))
        self.assertNotIsInstance(ctx.exception, IncompleteResponseError)


class GatewayMappingTests(unittest.TestCase):
    def _gw(self, raw, status=200):
        p, t = provider_for(raw, status)
        gw = ModelGateway({"gemini": p}, max_concurrent_calls=1)
        return gw, t

    def test_content_blocked_maps_to_public_code_not_retryable(self):
        gw, _ = self._gw(body(candidates=[cand("PROHIBITED_CONTENT")]))
        with self.assertRaises(SanourError) as ctx:
            gw.generate(profile(), call(), deadline_in(2.0), identity=_rid(profile()))
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_CONTENT_BLOCKED)
        self.assertFalse(ctx.exception.retryable)
        self.assertEqual(ctx.exception.message, "model provider failed")
        self.assertIsNone(ctx.exception.scope)

    def test_content_blocked_is_counted_once_and_not_as_invalid(self):
        gw, _ = self._gw(body(candidates=[cand("SAFETY")]))
        with self.assertRaises(SanourError):
            gw.generate(profile(), call(), deadline_in(2.0), identity=_rid(profile()))
        stats = gw.stats()
        self.assertEqual(stats.content_blocked, 1)
        self.assertEqual(stats.invalid_responses, 0)
        self.assertEqual(stats.successful_calls, 0)

    def test_invalid_shapes_map_to_invalid_response_and_are_counted(self):
        gw, _ = self._gw(body(candidates=[cand(UNKNOWN)]))
        with self.assertRaises(SanourError) as ctx:
            gw.generate(profile(), call(), deadline_in(2.0), identity=_rid(profile()))
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_INVALID_RESPONSE)
        self.assertIsNone(ctx.exception.scope)  # never mistaken for an identity mismatch
        self.assertEqual(gw.stats().invalid_responses, 1)
        self.assertEqual(gw.stats().content_blocked, 0)

    def test_incomplete_maps_to_invalid_response_not_content_blocked(self):
        gw, _ = self._gw(body(candidates=[cand("MAX_TOKENS")]))
        with self.assertRaises(SanourError) as ctx:
            gw.generate(profile(), call(), deadline_in(2.0), identity=_rid(profile()))
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_INVALID_RESPONSE)
        self.assertEqual(gw.stats().content_blocked, 0)

    def test_success_is_not_reported_for_unknown_or_missing_status(self):
        for raw in (body(candidates=[cand(UNKNOWN)]), body(candidates=[cand(None)]),
                    body(candidates=[cand("STOP", text="")])):
            with self.subTest(raw=raw[:60]):
                gw, _ = self._gw(raw)
                with self.assertRaises(SanourError):
                    gw.generate(profile(), call(), deadline_in(2.0), identity=_rid(profile()))
                self.assertEqual(gw.stats().successful_calls, 0)


class IdentityPreservedTests(unittest.TestCase):
    def test_valid_stop_with_mismatched_model_version_is_identity_rejected(self):
        p, _ = provider_for(body(candidates=[stop_candidate()], model="gemini-other-9"))
        gw = ModelGateway({"gemini": p}, max_concurrent_calls=1)
        with self.assertRaises(SanourError) as ctx:
            gw.generate(profile(), call(), deadline_in(2.0), identity=_rid(profile()))
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_INVALID_RESPONSE)
        self.assertEqual(ctx.exception.scope, "model_identity")

    def test_allowlisted_snapshot_still_accepted(self):
        snap = "gemini-test-1-001"
        p, _ = provider_for(body(candidates=[stop_candidate()], model=snap))
        gw = ModelGateway({"gemini": p}, max_concurrent_calls=1)
        result = gw.generate(profile(accepted=frozenset({snap})), call(), deadline_in(2.0), identity=_rid(profile(accepted=frozenset({snap}))))
        self.assertEqual(result.reported_model_id, snap)

    def test_blocked_response_with_wrong_model_is_still_content_blocked(self):
        p, _ = provider_for(body(candidates=[cand("SAFETY")], model="gemini-other-9"))
        gw = ModelGateway({"gemini": p}, max_concurrent_calls=1)
        with self.assertRaises(SanourError) as ctx:
            gw.generate(profile(), call(), deadline_in(2.0), identity=_rid(profile()))
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_CONTENT_BLOCKED)


class NoRetryNoFallbackTests(unittest.TestCase):
    def test_blocked_call_is_attempted_exactly_once(self):
        p, t = provider_for(body(candidates=[cand("SAFETY")]))
        gw = ModelGateway({"gemini": p}, max_concurrent_calls=1)
        with self.assertRaises(SanourError):
            gw.generate(profile(), call(), deadline_in(2.0), identity=_rid(profile()))
        self.assertEqual(t.calls, 1)

    def test_no_second_profile_is_used_after_content_block(self):
        class Spy:
            capabilities = TEST_ALL_CAPS
            name = "other"
            calls = 0

            def generate(self, c):
                Spy.calls += 1
                return ModelResult(text="other", reported_model_id=c.model_id)

        gem, t = provider_for(body(candidates=[cand("PROHIBITED_CONTENT")]))
        primary = profile(alias="gem_primary", priority=0)
        backup = profile(alias="other_backup", model_id="other-model", priority=1, provider="other")
        core, _, _ = core_with({"gemini": gem, "other": Spy()}, [primary, backup])
        response = core.handle({"profile_alias": "gem_primary", "prompt": "hello"})
        self.assertEqual(response.status, "error")
        self.assertEqual(response.error.code, ErrorCode.PROVIDER_CONTENT_BLOCKED.value)
        self.assertEqual(t.calls, 1)
        self.assertEqual(Spy.calls, 0)

    def test_blocked_response_has_no_retry_flag_at_public_boundary(self):
        p, _ = provider_for(body(candidates=[cand("SAFETY")]))
        core, _, _ = core_with({"gemini": p}, [profile()])
        response = core.handle({"profile_alias": "gem_primary", "prompt": "hello"})
        self.assertFalse(response.error.retryable)


class DeadlineAndCapacityTests(unittest.TestCase):
    def test_blocked_calls_release_capacity(self):
        p, t = provider_for(body(candidates=[cand("SAFETY")]))
        gw = ModelGateway({"gemini": p}, max_concurrent_calls=1)
        for _ in range(3):  # would starve on a leaked single slot
            with self.assertRaises(SanourError):
                gw.generate(profile(), call(), deadline_in(2.0), identity=_rid(profile()))
        self.assertEqual(gw.in_flight, 0)
        self.assertEqual(t.calls, 3)

    def test_expired_deadline_still_refuses_before_io(self):
        p, t = provider_for(body(candidates=[cand("SAFETY")]))
        gw = ModelGateway({"gemini": p}, max_concurrent_calls=1)
        with self.assertRaises(SanourError) as ctx:
            gw.generate(profile(), call(), time.monotonic() - 1, identity=_rid(profile()))
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_TIMEOUT)
        self.assertEqual(t.calls, 0)


class AuditAndExceptionSafetyTests(unittest.TestCase):
    def _run_and_capture(self, raw):
        p, _ = provider_for(raw)
        core, gw, handler = core_with({"gemini": p}, [profile()])
        response = core.handle({"profile_alias": "gem_primary", "prompt": PROMPT})
        return response, handler.lines

    def test_nothing_sensitive_reaches_audit_or_response_on_block(self):
        raw = body(feedback={"blockReason": "SAFETY", "blockReasonMessage": SAFETY_MSG,
                             "safetyRatings": [{"category": "HARM_CATEGORY_DANGEROUS_CONTENT",
                                                "probability": "HIGH"}]},
                   candidates=[cand("SAFETY", text=REPLY)])
        response, lines = self._run_and_capture(raw)
        blob = "\n".join(lines) + response.model_dump_json()
        for secret in (PROMPT, REPLY, SAFETY_MSG, "HARM_CATEGORY", "HIGH", KEY):
            self.assertNotIn(secret, blob)
        self.assertIn("model.failed", "\n".join(lines))

    def test_unknown_raw_values_never_reach_audit_or_response(self):
        raw = body(candidates=[cand(UNKNOWN, text=REPLY)])
        response, lines = self._run_and_capture(raw)
        blob = "\n".join(lines) + response.model_dump_json()
        for secret in (UNKNOWN, REPLY, PROMPT, KEY):
            self.assertNotIn(secret, blob)
        self.assertEqual(response.error.code, ErrorCode.PROVIDER_INVALID_RESPONSE.value)

    def test_blocked_response_text_never_logged_even_on_success_path_neighbour(self):
        response, lines = self._run_and_capture(body(candidates=[cand("BLOCKLIST", text=REPLY)]))
        self.assertNotIn(REPLY, "\n".join(lines))
        self.assertEqual(response.error.code, ErrorCode.PROVIDER_CONTENT_BLOCKED.value)

    def test_content_blocked_error_text_is_fixed(self):
        try:
            run(body(candidates=[cand("SAFETY", text=REPLY)], feedback=None))
        except ContentBlockedError as exc:
            self.assertEqual(str(exc), "provider blocked content")
            self.assertNotIn(REPLY, repr(exc))
        else:
            self.fail("expected ContentBlockedError")


if __name__ == "__main__":
    unittest.main()
