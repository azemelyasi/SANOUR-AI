"""Stage 10.40: event-driven provider settlement.

Offline only: fake adapters, no SDK, no network, no key. Waits are bounded. There is no polling:
the tests wait on events (Event.wait, condition checks with a deadline).
"""

import json
import threading
import unittest
from unittest import mock

from sanour_ai.providers.offline_contract import OfflineTestProvider
from sanour_ai.composition import production
from sanour_ai.composition.runtime import Runtime, RuntimeState
from sanour_ai.models.base import ModelResult
from sanour_ai.models.gateway import ModelGateway
from tests.support import TEST_ALL_CAPS, deadline_in, wait_until
from tests.support import request_identity_for as _rid
from tests.unit import test_gateway as gw_tests
from tests.unit import test_stage1039 as base

SECRET_TEXT = "STAGE1040-SECRET-VALUE-JK"


class BadClose(base.LifeOpenAI):
    def close(self):
        with base.LifeOpenAI.lock:
            base.LifeOpenAI.events.append(("close", None))
            self.close_count += 1
        raise OSError(SECRET_TEXT)


class Base(unittest.TestCase):
    adapter_class = base.LifeOpenAI

    def setUp(self):
        base.LifeOpenAI.instances = []
        base.LifeOpenAI.events = []
        base.LifeOpenAI.gate = None
        base.LifeOpenAI.fail_init = False
        self._patches = [
            mock.patch.object(production, "OpenAIProvider", self.adapter_class), mock.patch.object(production, "_default_test_provider", lambda: self.adapter_class("test")),
            mock.patch.object(production, "_sdk_present", return_value=True),
        ]
        for p in self._patches:
            p.start()

    def tearDown(self):
        base.LifeOpenAI.gate = None
        for p in self._patches:
            p.stop()

    def build(self):
        return Runtime.build_for_tests(base.env())

    def ask(self, rt, text="hi"):
        return rt.handle({"profile_alias": "openai_primary", "prompt": text})

    def start_live_request(self, rt):
        base.LifeOpenAI.gate = threading.Event()
        result = {}
        t = threading.Thread(target=lambda: result.setdefault("r", self.ask(rt)))
        t.start()
        self.assertTrue(wait_until(lambda: ("start", None) in base.LifeOpenAI.events, timeout=2.0))
        return t, result

    @property
    def adapter(self):
        return base.LifeOpenAI.instances[-1]


class SettlementWithoutSecondShutdown(Base):
    def test_last_worker_ending_completes_shutdown_without_another_shutdown_call(self):  # req 1
        rt = self.build()
        t, result = self.start_live_request(rt)
        self.assertEqual(rt.shutdown(0.05), {"openai": "closing"})
        self.assertIs(rt.state, RuntimeState.DRAINING)
        base.LifeOpenAI.gate.set()
        t.join(3.0)
        self.assertEqual(result["r"].status, "success")
        self.assertTrue(rt.wait_stopped(2.0))
        self.assertIs(rt.state, RuntimeState.SHUTDOWN)
        self.assertEqual(rt.stats()["providers"], {"openai": "closed"})
        self.assertEqual(self.adapter.close_count, 1)

    def test_idle_shutdown_stops_immediately(self):
        rt = self.build()
        rt.shutdown(1.0)
        self.assertTrue(rt.wait_stopped(0.0))
        self.assertEqual(self.adapter.close_count, 1)


class ProviderClosedExactlyOnce(Base):
    def test_completion_and_repeated_shutdown_close_once(self):  # req 2
        rt = self.build()
        t, _ = self.start_live_request(rt)
        for _ in range(3):
            rt.shutdown(0.02)
        base.LifeOpenAI.gate.set()
        t.join(3.0)
        self.assertTrue(rt.wait_stopped(2.0))
        for _ in range(3):
            rt.shutdown(1.0)
        self.assertEqual(self.adapter.close_count, 1)
        self.assertEqual(sum(1 for e in base.LifeOpenAI.events if e[0] == "close"), 1)


class CloseFailureSettles(Base):
    adapter_class = BadClose

    def test_close_failure_in_worker_path_reaches_failed_and_runtime_stops(self):  # req 3
        rt = self.build()
        t, _ = self.start_live_request(rt)
        rt.shutdown(0.02)
        base.LifeOpenAI.gate.set()
        t.join(3.0)
        self.assertTrue(rt.wait_stopped(2.0))
        self.assertIs(rt.state, RuntimeState.SHUTDOWN)
        self.assertEqual(rt.stats()["providers"], {"openai": "failed"})
        self.assertEqual(rt.stats()["provider_close_failures"], 1)

    def test_close_failure_in_idle_path_reaches_failed_and_runtime_stops(self):
        rt = self.build()
        self.assertEqual(rt.shutdown(1.0), {"openai": "failed"})
        self.assertTrue(rt.wait_stopped(0.0))
        self.assertEqual(rt.stats()["provider_close_failures"], 1)

    def test_secret_text_never_reaches_stats_or_logs(self):  # req 10
        rt = self.build()
        with self.assertLogs(level="WARNING") as captured:
            rt.shutdown(1.0)
        text = "\n".join(captured.output) + json.dumps(rt.stats(), default=str)
        self.assertNotIn(SECRET_TEXT, text)
        self.assertIn("OSError", "\n".join(captured.output))  # type name only


class WaitStopped(Base):
    def test_wait_stopped_times_out_while_worker_runs_then_succeeds(self):  # req 8
        rt = self.build()
        t, _ = self.start_live_request(rt)
        rt.shutdown(0.02)
        self.assertFalse(rt.wait_stopped(0.05))
        base.LifeOpenAI.gate.set()
        t.join(3.0)
        self.assertTrue(rt.wait_stopped(2.0))


class NoCloseUnderLiveWorker(Base):
    def test_provider_stays_open_while_its_worker_is_active(self):  # req 9
        rt = self.build()
        t, _ = self.start_live_request(rt)
        for _ in range(3):
            rt.shutdown(0.02)
        self.assertEqual(self.adapter.close_count, 0)
        self.assertEqual(rt.stats()["providers"], {"openai": "closing"})
        base.LifeOpenAI.gate.set()
        t.join(3.0)
        rt.wait_stopped(2.0)


class GatewayLevel(unittest.TestCase):
    def make(self, provider):
        return ModelGateway({"mock": provider}, max_concurrent_calls=1)

    def test_observer_runs_after_capacity_is_returned_and_once_per_provider(self):  # req 6, 4
        gate = threading.Event()

        class Gated:
            name = "mock"
            capabilities = TEST_ALL_CAPS

            def generate(self, call):
                gate.wait(3.0)
                return ModelResult(text="x", reported_model_id=call.model_id)

        gw = self.make(Gated())
        seen = []
        gw.add_settlement_observer(lambda name, outcome: seen.append((name, outcome, gw._slots._value)))
        t = threading.Thread(target=lambda: gw.generate(gw_tests.PROFILE, gw_tests.CALL,
                                                        deadline_in(3.0), identity=_rid(gw_tests.PROFILE)))
        t.start()
        self.assertTrue(wait_until(lambda: gw.in_flight == 1, timeout=2.0))
        gw.shutdown(0.01)
        self.assertEqual(seen, [])  # busy provider: no settlement yet
        gate.set()
        t.join(3.0)
        self.assertTrue(wait_until(lambda: len(seen) == 1, timeout=2.0))
        self.assertEqual(seen, [("mock", "closed", 1)])  # observer ran with the global slot already back
        gw.shutdown(0.01)
        self.assertEqual(len(seen), 1)  # never a second event for the same provider

    def test_failing_observer_does_not_block_other_observers(self):
        class Plain:
            name = "mock"
            capabilities = TEST_ALL_CAPS

            def generate(self, call):
                return ModelResult(text="x", reported_model_id=call.model_id)

        gw = self.make(Plain())
        seen = []

        def bad(name, outcome):
            raise RuntimeError("observer broke")

        gw.add_settlement_observer(bad)
        gw.add_settlement_observer(lambda name, outcome: seen.append(outcome))
        with self.assertLogs(level="WARNING") as captured:
            gw.shutdown(1.0)
        self.assertEqual(seen, ["closed"])
        self.assertIn("RuntimeError", "\n".join(captured.output))
        self.assertNotIn("observer broke", "\n".join(captured.output))

    def test_cancelled_call_on_a_shut_down_gateway_settles_the_provider(self):
        class Plain:
            name = "mock"
            capabilities = TEST_ALL_CAPS
            closes = 0

            def generate(self, call):
                return ModelResult(text="x", reported_model_id=call.model_id)

            def close(self):
                Plain.closes += 1

        gw = self.make(Plain())
        seen = []
        gw.add_settlement_observer(lambda name, outcome: seen.append(outcome))
        gw.shutdown(0.5)
        self.assertEqual(seen, ["closed"])
        self.assertEqual(Plain.closes, 1)


class ConcurrencyRaces(Base):
    def test_callback_and_shutdown_racing_never_close_twice(self):  # req 4
        for _ in range(15):
            base.LifeOpenAI.instances = []
            base.LifeOpenAI.events = []
            rt = self.build()
            t, _ = self.start_live_request(rt)
            shutdowns = [threading.Thread(target=lambda: rt.shutdown(0.01)) for _ in range(4)]
            for s in shutdowns:
                s.start()
            base.LifeOpenAI.gate.set()
            t.join(3.0)
            for s in shutdowns:
                s.join(3.0)
            self.assertTrue(rt.wait_stopped(2.0))
            rt.shutdown(1.0)
            self.assertEqual(self.adapter.close_count, 1)
            self.assertIs(rt.state, RuntimeState.SHUTDOWN)
            base.LifeOpenAI.gate = None


class ReturnValuesAreSafe(Base):
    def test_unknown_or_repeated_settlement_events_change_nothing(self):
        rt = self.build()
        rt.shutdown(1.0)
        before = rt.stats()["providers"]
        rt._registry.on_provider_settled("openai", "bogus")
        rt._registry.on_provider_settled("openai", "closed")
        rt._registry.on_provider_settled("no_such_provider", "failed")
        self.assertEqual(rt.stats()["providers"], before)
        self.assertIs(rt.state, RuntimeState.SHUTDOWN)


if __name__ == "__main__":
    unittest.main()
