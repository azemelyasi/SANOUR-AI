"""Stage 10.49-R6: end-to-end state transitions and distinct financial outcomes.

Each outcome has one reservation state, one cost status and one budget effect. The table below is the executable
form of docs/GOVERNANCE_STATE_MACHINE.md; a change to either must change both.

outcome                         provider_started  usage        state          charged_from  budget spent
completed, priced               yes               yes          settled        actual        priced amount
completed, usage unavailable    yes               none         exposed        exposed       0 (exposure)
failed                          yes               none         exposed        exposed       0 (exposure)
timed_out                       yes               none         exposed        exposed       0 (exposure)
refused before provider         no                -            released       none          0
gate closed, expired            no                -            released       none          0
gate open, expired              yes               none         exposed        exposed       0 (exposure)
exposure written off            yes               none         written_off    -             written_off
"""

import logging
import sqlite3
import unittest
from decimal import Decimal

from sanour_ai.governance.admission import AdmissionController
from sanour_ai.governance.reconcile import reconcile
from sanour_ai.governance.sink import DurableSqliteSink
from sanour_ai.governance.store import GovernanceStore
from sanour_ai.governance.types import Settlement
from sanour_ai.models.usage import Usage
from sanour_ai.observability.audit import AuditLogger
from tests.unit.r5_support import RaiseOn
from tests.unit.test_stage1049 import BOUNDS, Clock, GovBase, pricing, profile, request

USAGE = Usage(input_tokens=4, output_tokens=2, total_tokens=6)


class Transitions(GovBase):
    def setUp(self):
        super().setUp()
        s = self.store()
        s.upsert_pricing(pricing())
        s.upsert_budget("global", "", "daily", "USD", "1.00")

    def ctl(self, store=None, authorized=frozenset()):
        return AdmissionController(store or self.store(), audit=AuditLogger(logging.getLogger("t6.states")),
                                   bounds=BOUNDS, clock=self.clock, authorized_actors=authorized,
                                   sink=DurableSqliteSink(self.path + ".sink", clock=self.clock))

    def admit(self, ctl=None):
        ctl = ctl or self.ctl()
        return ctl, ctl.admit(request(), profile()).request_id

    def state(self, rid):
        return self.row("SELECT state FROM reservations WHERE request_id = ?", rid)[0]

    def cost(self, rid):
        return self.row("SELECT cost_status, charged_from FROM cost_records WHERE request_id = ?", rid)

    def assert_consistent(self):
        r = reconcile(self.path, now=self.clock.now)
        errors = [i for i in r["findings"]["items"] if i["severity"] == "error"]
        self.assertEqual(errors, [], errors)
        return r

    def test_completed_priced_settles_actual_and_budget(self):
        ctl, rid = self.admit()
        res = ctl.settle_by_id(rid, Settlement("completed", True, USAGE))
        self.assertTrue(res.applied)
        self.assertEqual(self.state(rid), "settled")
        self.assertEqual(self.cost(rid)[1], "actual")
        self.assertEqual(Decimal(self.row("SELECT spent FROM budget_windows")[0]), Decimal("0.000024"))
        self.assert_consistent()

    def test_completed_without_usage_is_exposed_not_settled(self):
        ctl, rid = self.admit()
        ctl.settle_by_id(rid, Settlement("completed", True, None))
        self.assertEqual(self.state(rid), "exposed")
        self.assertEqual(self.cost(rid)[1], "exposed")
        self.assertEqual(Decimal(self.row("SELECT spent FROM budget_windows")[0]), Decimal(0))
        self.assertGreater(Decimal(self.row("SELECT exposed FROM budget_windows")[0]), 0)
        self.assert_consistent()

    def test_failed_and_timed_out_are_both_exposures_with_distinct_settlement_kinds(self):
        for kind in ("failed", "timed_out"):
            ctl, rid = self.admit()
            ctl.settle_by_id(rid, Settlement(kind, True, None))
            self.assertEqual(self.state(rid), "exposed", kind)
            self.assertEqual(self.row("SELECT settlement FROM reservations WHERE request_id = ?", rid)[0], kind)
        self.assert_consistent()

    def test_refused_before_provider_releases_and_bills_nothing(self):
        ctl, rid = self.admit()
        ctl.settle_by_id(rid, Settlement("failed", provider_started=False))
        self.assertEqual(self.state(rid), "released")
        self.assertEqual(self.cost(rid), ("not_billed", "none"))
        self.assertEqual(Decimal(self.row("SELECT reserved FROM budget_windows")[0]), Decimal(0))
        self.assertEqual(Decimal(self.row("SELECT spent FROM budget_windows")[0]), Decimal(0))
        self.assert_consistent()

    def test_second_settlement_of_same_request_is_refused_not_double_charged(self):
        ctl, rid = self.admit()
        ctl.settle_by_id(rid, Settlement("completed", True, USAGE))
        again = ctl.settle_by_id(rid, Settlement("completed", True, USAGE))
        self.assertFalse(again.applied)
        self.assertEqual(again.reason, "already_settled")
        self.assertEqual(self.row("SELECT COUNT(*) FROM cost_records")[0], 1)
        self.assertEqual(Decimal(self.row("SELECT spent FROM budget_windows")[0]), Decimal("0.000024"))

    def test_conflicting_second_outcome_is_refused_while_intent_pending(self):
        store = self.store()
        store._conn = RaiseOn(store._conn, "INSERT INTO cost_records")  # noqa: SLF001
        ctl = self.ctl(store)
        rid = ctl.admit(request(), profile()).request_id
        first = ctl.settle_by_id(rid, Settlement("completed", True, USAGE))
        self.assertFalse(first.applied)
        self.assertEqual(self.state(rid), "settlement_pending")
        conflict = ctl.settle_by_id(rid, Settlement("failed", True, None))
        self.assertFalse(conflict.applied)
        self.assertEqual(conflict.reason, "intent_conflict")

    def test_late_result_after_expiry_with_gate_open_is_exposed_by_sweep_once(self):
        ctl, rid = self.admit()
        self.clock.now += 3600  # past the reservation expiry
        self.assertEqual(ctl.sweep(), 1)
        self.assertEqual(ctl.sweep(), 0)
        self.assertEqual(self.state(rid), "exposed")
        self.assertEqual(self.cost(rid)[1], "exposed")
        self.assert_consistent()

    def test_gate_closed_expiry_is_released_never_exposed(self):
        ctl, rid = self.admit()
        conn = sqlite3.connect(self.path)
        conn.execute("UPDATE reservations SET admission_gate = 'closed' WHERE request_id = ?", (rid,))
        conn.commit()
        conn.close()
        self.clock.now += 3600
        self.assertEqual(ctl.sweep(), 1)
        self.assertEqual(self.state(rid), "released")
        self.assertEqual(self.cost(rid), ("not_billed", "none"))
        self.assert_consistent()

    def test_write_off_moves_exposure_to_written_off_consistently(self):
        ctl = self.ctl(authorized=frozenset({"ops.alice"}))
        rid = ctl.admit(request(), profile()).request_id
        ctl.settle_by_id(rid, Settlement("timed_out", True, None))
        self.assertEqual(self.state(rid), "exposed")
        result = ctl.write_off(rid, actor="ops.alice", reason="provider confirmed no charge")
        self.assertTrue(result.applied, result)
        self.assertEqual(self.state(rid), "written_off")
        self.assertEqual(Decimal(self.row("SELECT exposed FROM budget_windows")[0]), Decimal(0))
        self.assertGreater(Decimal(self.row("SELECT written_off FROM budget_windows")[0]), 0)
        self.assert_consistent()


if __name__ == "__main__":
    unittest.main()
