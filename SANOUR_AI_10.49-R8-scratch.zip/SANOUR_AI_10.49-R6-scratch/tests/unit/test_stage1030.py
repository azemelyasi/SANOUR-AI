"""Stage 10.30 tests: Anthropic version and stop reasons, Anthropic 429 split, header allowlist,
xAI Responses adapter, and the provider capability matrix.

Fake transports and fixed bodies only. No network, no real key, no SDK.
"""

from tests.support import request_identity_for as _rid
import inspect
import json
import logging
import time
import unittest
import urllib.error
from types import SimpleNamespace
from unittest import mock

from pydantic import SecretStr

from sanour_ai.core.sanour_core import SanourCore
from sanour_ai.errors import ErrorCode, SanourError
from sanour_ai.models import provider_matrix as pm
from sanour_ai.models.base import ModelCall, ModelResult, ProviderError
from sanour_ai.models.capabilities import ModelCapabilities, ModelProfile
from sanour_ai.models.gateway import ModelGateway
from sanour_ai.models.router import DeterministicRouter
from sanour_ai.observability.audit import AUDIT_LOGGER_NAME, AuditLogger
from sanour_ai.providers import common
from sanour_ai.providers import anthropic_provider as anth
from sanour_ai.providers import grok_provider as grok_chat
from sanour_ai.providers import xai_responses_provider as xr
from sanour_ai.providers.anthropic_provider import ANTHROPIC_VERSION, AnthropicProvider
from sanour_ai.providers.common import (
    ALLOWED_RESPONSE_HEADERS,
    HttpResult,
    IncompleteResponseError,
    RateLimitedError,
    default_transport,
    parse_retry_after,
)
from sanour_ai.providers.xai_responses_provider import XaiResponsesProvider
from tests.support import TEST_ALL_CAPS, deadline_in

KEY = "STAGE1030-TESTONLY-KEY-ZYX"
MODEL = "claude-test-1030"
XMODEL = "grok-test-1030"
PROMPT = "SECRET-PROMPT-1030 hi"
SECRET_MSG = f"bad key {KEY} SECRET-MSG-1030"


class Transport:
    def __init__(self, status=200, body=b"", headers=None):
        self.status, self.body, self.headers = status, body, headers or {}
        self.calls = []

    def __call__(self, url, headers, body, timeout):
        self.calls.append({"url": url, "headers": headers, "body": body, "timeout": timeout})
        return HttpResult(self.status, self.body, self.headers)


def call(model=MODEL, budget=5.0):
    return ModelCall(model_id=model, prompt=PROMPT, max_output_tokens=32, deadline=time.monotonic() + budget)


def ok_message(stop="end_turn", text="hello", model=MODEL):
    return json.dumps({"type": "message", "role": "assistant",
                       "content": [{"type": "text", "text": text}],
                       "stop_reason": stop, "model": model}).encode()


def anth_err(type_="rate_limit_error", details=None, message=SECRET_MSG):
    inner = {"type": type_, "message": message}
    if details is not None:
        inner["details"] = details
    return json.dumps({"type": "error", "error": inner}).encode()


def expect(provider, model=MODEL):
    try:
        provider.generate(call(model))
    except ProviderError as exc:
        return exc
    raise AssertionError("expected ProviderError")


# ---------------------------------------------------------------- Anthropic: version and request shape
class AnthropicVersionAndRequestTests(unittest.TestCase):
    def test_version_is_the_current_documented_one(self):
        self.assertEqual(ANTHROPIC_VERSION, "2026-10-21")

    def test_request_sends_version_and_no_removed_parameters(self):
        t = Transport(200, ok_message())
        AnthropicProvider(SecretStr(KEY), transport=t).generate(call())
        sent = t.calls[0]
        self.assertEqual(sent["headers"]["anthropic-version"], "2026-10-21")
        body = json.loads(sent["body"])
        for removed in ("temperature", "top_p", "top_k", "system"):
            self.assertNotIn(removed, body)
        self.assertEqual(body["messages"], [{"role": "user", "content": PROMPT}])  # no document/citations
        self.assertEqual(sorted(body), ["max_tokens", "messages", "model"])


# ---------------------------------------------------------------- Anthropic: stop reasons
class AnthropicStopReasonTests(unittest.TestCase):
    def test_complete_stop_reasons_succeed(self):
        for stop in ("end_turn", "stop_sequence"):
            with self.subTest(stop=stop):
                result = AnthropicProvider(SecretStr(KEY), transport=Transport(200, ok_message(stop))).generate(call())
                self.assertEqual(result.text, "hello")

    def test_max_tokens_is_truncation_not_success(self):
        with self.assertRaises(IncompleteResponseError) as ctx:
            AnthropicProvider(SecretStr(KEY), transport=Transport(200, ok_message("max_tokens"))).generate(call())
        self.assertFalse(ctx.exception.retryable)

    def test_documented_non_complete_and_unknown_stop_reasons_fail_closed(self):
        for stop in ("tool_use", "pause_turn", "refusal", "model_context_window_exceeded", "SECRET-STOP-1030"):
            with self.subTest(stop=stop):
                with self.assertRaises(IncompleteResponseError):
                    AnthropicProvider(SecretStr(KEY), transport=Transport(200, ok_message(stop))).generate(call())

    def test_missing_stop_reason_fails_closed(self):
        body = json.dumps({"content": [{"type": "text", "text": "x"}], "model": MODEL}).encode()
        with self.assertRaises(IncompleteResponseError):
            AnthropicProvider(SecretStr(KEY), transport=Transport(200, body)).generate(call())


# ---------------------------------------------------------------- Anthropic: 429 split
class AnthropicRateLimitTests(unittest.TestCase):
    SPEND = {"error_code": "enforced_spend_limit_reached"}

    def test_spend_cap_is_billing_and_not_retryable_even_with_retry_after(self):
        # Documented: the spend-cap 429 never carries retry-after; a stray header must not make it retryable.
        for headers in ({}, {"retry-after": "30"}):
            with self.subTest(headers=headers):
                exc = expect(AnthropicProvider(SecretStr(KEY),
                             transport=Transport(429, anth_err(details=self.SPEND), headers)))
                self.assertEqual(exc.failure_reason, "billing")
                self.assertFalse(exc.retryable)
                self.assertNotIsInstance(exc, RateLimitedError)

    def test_transient_rate_limit_needs_rate_limit_type_no_spend_marker_and_valid_retry_after(self):
        exc = expect(AnthropicProvider(SecretStr(KEY),
                     transport=Transport(429, anth_err(), {"retry-after": "7"})))
        self.assertIsInstance(exc, RateLimitedError)
        self.assertTrue(exc.retryable)
        self.assertEqual(exc.retry_after_seconds, 7)  # metadata only

    def test_rate_limit_without_retry_after_is_unknown(self):
        exc = expect(AnthropicProvider(SecretStr(KEY), transport=Transport(429, anth_err())))
        self.assertNotIsInstance(exc, RateLimitedError)
        self.assertEqual(exc.failure_reason, "unknown")
        self.assertFalse(exc.retryable)

    def test_invalid_retry_after_is_unknown(self):
        for bad in ("soon", "-1", "1.5", ""):
            with self.subTest(retry_after=bad):
                exc = expect(AnthropicProvider(SecretStr(KEY),
                             transport=Transport(429, anth_err(), {"retry-after": bad})))
                self.assertNotIsInstance(exc, RateLimitedError)

    def test_unknown_details_code_is_unknown_not_transient(self):
        exc = expect(AnthropicProvider(SecretStr(KEY),
                     transport=Transport(429, anth_err(details={"error_code": "SECRET-CODE-1030"}),
                                         {"retry-after": "5"})))
        self.assertNotIsInstance(exc, RateLimitedError)
        self.assertEqual(exc.failure_reason, "unknown")
        self.assertNotIn("SECRET-CODE-1030", str(exc))

    def test_billing_error_402_is_billing(self):
        exc = expect(AnthropicProvider(SecretStr(KEY), transport=Transport(402, anth_err("billing_error"))))
        self.assertEqual((exc.status_code, exc.failure_reason, exc.retryable), (402, "billing", False))

    def test_spend_cap_at_gateway_is_provider_failed_not_retryable_one_attempt(self):
        t = Transport(429, anth_err(details=self.SPEND))
        gw = ModelGateway({"anthropic": AnthropicProvider(SecretStr(KEY), transport=t)}, max_concurrent_calls=1)
        profile = ModelProfile(alias="a_profile", provider="anthropic", model_id=MODEL,
                               capabilities=ModelCapabilities(text_generation=True, max_context_tokens=8192,
                                                              max_output_tokens=4096))
        with self.assertRaises(SanourError) as ctx:
            gw.generate(profile, call(), deadline_in(2.0), identity=_rid(profile))
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_FAILED)
        self.assertFalse(ctx.exception.retryable)
        self.assertEqual(len(t.calls), 1)


# ---------------------------------------------------------------- transport: header allowlist
class _Msg:
    """Stands in for an HTTPMessage: case-insensitive get, plus extra headers that must never be copied."""

    def __init__(self, data):
        self._data = {k.lower(): v for k, v in data.items()}

    def get(self, name, default=None):
        return self._data.get(name.lower(), default)


class _Resp:
    def __init__(self, status, headers):
        self.status, self.headers, self.fp = status, _Msg(headers), None

    def read1(self, n):
        return b""

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


class _Opener:
    def __init__(self, outcome):
        self.outcome = outcome

    def open(self, request, timeout):
        if isinstance(self.outcome, BaseException):
            raise self.outcome
        return self.outcome


class HeaderExtractionTests(unittest.TestCase):
    def test_only_allowlisted_headers_leave_the_transport(self):
        resp = _Resp(200, {"Retry-After": "9", "Content-Type": "application/json",
                           "Authorization": f"Bearer {KEY}", "Set-Cookie": "session=SECRET-COOKIE-1030",
                           "X-Request-Id": "req_1"})
        with mock.patch.object(common, "OPENER", _Opener(resp)):
            result = default_transport("https://example.invalid/x", {}, b"{}", common.RequestTimeout(5, time.monotonic() + 5))
        self.assertEqual(set(result.headers), set(ALLOWED_RESPONSE_HEADERS))
        self.assertEqual(result.headers["retry-after"], "9")
        blob = repr(result.headers)
        self.assertNotIn(KEY, blob)
        self.assertNotIn("SECRET-COOKIE-1030", blob)

    def test_http_result_still_unpacks_like_a_plain_tuple(self):
        status, raw = HttpResult(429, b"x", {"retry-after": "1"})
        self.assertEqual((status, raw), (429, b"x"))

    def test_oversized_header_value_is_dropped(self):
        resp = _Resp(200, {"Retry-After": "9" * 300})
        with mock.patch.object(common, "OPENER", _Opener(resp)):
            result = default_transport("https://example.invalid/x", {}, b"{}", common.RequestTimeout(5, time.monotonic() + 5))
        self.assertNotIn("retry-after", result.headers)

    def test_error_response_headers_are_extracted_too(self):
        err = urllib.error.HTTPError("https://example.invalid/x", 429, "x", _Msg({"Retry-After": "4"}), None)
        with mock.patch.object(common, "OPENER", _Opener(err)):
            result = default_transport("https://example.invalid/x", {}, b"{}", common.RequestTimeout(5, time.monotonic() + 5))
        self.assertEqual(result, (429, b""))
        self.assertEqual(result.headers.get("retry-after"), "4")


class RetryAfterMetadataTests(unittest.TestCase):
    def test_parse_is_bounded_and_never_sleeps(self):
        with mock.patch("time.sleep", side_effect=AssertionError("must not sleep")):
            self.assertEqual(parse_retry_after("5"), 5)
            self.assertEqual(parse_retry_after("999999"), 3600)
            self.assertIsNone(parse_retry_after("Wed, 21 Oct 2026 07:28:00 GMT"))

    def test_adapter_never_retries_on_retry_after(self):
        t = Transport(429, anth_err(), {"retry-after": "1"})
        with mock.patch("time.sleep", side_effect=AssertionError("must not sleep")):
            exc = expect(AnthropicProvider(SecretStr(KEY), transport=t))
        self.assertIsInstance(exc, RateLimitedError)
        self.assertEqual(len(t.calls), 1)


# ---------------------------------------------------------------- xAI Responses adapter
def xr_ok(text="hello", model=XMODEL, extra_items=()):
    doc = {"object": "response", "status": "completed", "model": model,
           "output": [*extra_items,
                      {"type": "message", "role": "assistant", "status": "completed",
                       "content": [{"type": "output_text", "text": text, "annotations": []}]}]}
    return json.dumps(doc).encode()


def xr_provider(status=200, body=None, headers=None):
    t = Transport(status, body if body is not None else xr_ok(), headers)
    return XaiResponsesProvider(SecretStr(KEY), transport=t), t


class XaiResponsesRequestTests(unittest.TestCase):
    def test_endpoint_method_auth_and_body(self):
        p, t = xr_provider()
        p.generate(call(XMODEL))
        sent = t["calls"][0] if isinstance(t, dict) else t.calls[0]
        self.assertEqual(sent["url"], "https://api.x.ai/v1/responses")
        self.assertEqual(sent["headers"]["authorization"], f"Bearer {KEY}")
        self.assertNotIn(KEY, sent["url"])
        body = json.loads(sent["body"])
        self.assertEqual(body, {"model": XMODEL, "input": PROMPT, "max_output_tokens": 32, "store": False})
        self.assertNotIn(KEY, sent["body"].decode())

    def test_store_is_always_explicitly_false(self):
        p, t = xr_provider()
        p.generate(call(XMODEL))
        self.assertIs(json.loads(t.calls[0]["body"])["store"], False)

    def test_legacy_chat_fields_are_not_sent(self):
        p, t = xr_provider()
        p.generate(call(XMODEL))
        body = json.loads(t.calls[0]["body"])
        self.assertNotIn("messages", body)
        self.assertNotIn("max_tokens", body)
        self.assertNotIn("stream", body)

    def test_invalid_model_id_is_refused_before_io(self):
        p, t = xr_provider()
        exc = expect(p, model="../bad")
        self.assertFalse(exc.retryable)
        self.assertEqual(t.calls, [])


class XaiResponsesResponseTests(unittest.TestCase):
    def test_completed_message_is_success_and_reports_model(self):
        p, _ = xr_provider()
        result = p.generate(call(XMODEL))
        self.assertEqual(result, ModelResult(text="hello", reported_model_id=XMODEL))

    def test_reasoning_items_are_skipped(self):
        reasoning = {"type": "reasoning", "status": "completed", "summary": []}
        p, _ = xr_provider(body=xr_ok(extra_items=[reasoning]))
        self.assertEqual(p.generate(call(XMODEL)).text, "hello")

    def test_incomplete_status_is_refused(self):
        body = json.dumps({"status": "incomplete", "model": XMODEL,
                           "incomplete_details": {"reason": "max_output_tokens"},
                           "output": [{"type": "message", "status": "incomplete",
                                       "content": [{"type": "output_text", "text": "cut"}]}]}).encode()
        p, _ = xr_provider(body=body)
        with self.assertRaises(IncompleteResponseError):
            p.generate(call(XMODEL))

    def test_other_or_missing_status_is_refused(self):
        for status in ("in_progress", "failed", "queued", None, "SECRET-STATUS-1030"):
            with self.subTest(status=status):
                doc = {"model": XMODEL, "output": [{"type": "message", "content": [
                    {"type": "output_text", "text": "x"}]}]}
                if status is not None:
                    doc["status"] = status
                p, _ = xr_provider(body=json.dumps(doc).encode())
                with self.assertRaises(IncompleteResponseError):
                    p.generate(call(XMODEL))

    def test_error_field_refuses_even_with_completed_status(self):
        doc = json.loads(xr_ok())
        doc["error"] = {"message": "SECRET-ERR-1030"}
        p, _ = xr_provider(body=json.dumps(doc).encode())
        with self.assertRaises(IncompleteResponseError):
            p.generate(call(XMODEL))

    def test_refusal_or_unknown_content_is_refused(self):
        for part in ({"type": "refusal", "refusal": "no"}, {"type": "output_text"}):
            with self.subTest(part=part):
                doc = {"status": "completed", "model": XMODEL, "output": [
                    {"type": "message", "content": [part]}]}
                p, _ = xr_provider(body=json.dumps(doc).encode())
                with self.assertRaises(IncompleteResponseError):
                    p.generate(call(XMODEL))

    def test_unknown_output_item_type_is_refused(self):
        p, _ = xr_provider(body=xr_ok(extra_items=[{"type": "web_search_call", "status": "completed"}]))
        with self.assertRaises(IncompleteResponseError):
            p.generate(call(XMODEL))

    def test_empty_text_and_malformed_bodies_are_refused(self):
        bodies = [xr_ok(text="   "), b"not json", b"[]", b"", json.dumps({"status": "completed", "output": []}).encode()]
        for body in bodies:
            with self.subTest(body=body[:20]):
                p, _ = xr_provider(body=body)
                with self.assertRaises(IncompleteResponseError):
                    p.generate(call(XMODEL))

    def test_oversized_body_is_refused(self):
        p, _ = xr_provider(body=b" " * (common.MAX_RESPONSE_BYTES + 1))
        exc = expect(p, model=XMODEL)
        self.assertNotIsInstance(exc, IncompleteResponseError)
        self.assertIn("too large", str(exc))


class XaiResponsesErrorTests(unittest.TestCase):
    def test_documented_statuses_map_to_fixed_failures(self):
        for status in (400, 401, 403, 404):
            with self.subTest(status=status):
                p, _ = xr_provider(status=status, body=b'{"error":{"message":"SECRET-MSG-1030"}}')
                exc = expect(p, model=XMODEL)
                self.assertFalse(exc.retryable)
                self.assertNotIn("SECRET-MSG-1030", str(exc))

    def test_429_is_unknown_and_not_retryable(self):
        p, _ = xr_provider(status=429, body=b"", headers={"retry-after": "3"})
        exc = expect(p, model=XMODEL)
        self.assertNotIsInstance(exc, RateLimitedError)
        self.assertEqual(exc.failure_reason, "unknown")
        self.assertFalse(exc.retryable)

    def test_undocumented_5xx_fails_closed(self):
        for status in (500, 503):
            with self.subTest(status=status):
                p, _ = xr_provider(status=status, body=b"")
                self.assertFalse(expect(p, model=XMODEL).retryable)

    def test_key_never_appears_in_errors(self):
        p, _ = xr_provider(status=401, body=f'{{"error":{{"message":"{KEY}"}}}}'.encode())
        exc = expect(p, model=XMODEL)
        self.assertNotIn(KEY, str(exc))
        self.assertNotIn(KEY, repr(exc))


class XaiResponsesGatewayTests(unittest.TestCase):
    def _gw(self, provider, max_calls=1):
        return ModelGateway({"grok_responses": provider}, max_concurrent_calls=max_calls)

    def _profile(self, accepted=frozenset()):
        return ModelProfile(alias="x_profile", provider="grok_responses", model_id=XMODEL,
                            capabilities=ModelCapabilities(text_generation=True, max_context_tokens=8192,
                                                           max_output_tokens=4096),
                            accepted_reported_model_ids=accepted)

    def test_identity_snapshot_is_rejected_without_allowlist_and_accepted_with_it(self):
        snapshot = "grok-test-1030-0309"  # shape of the official response example (dated snapshot)
        p, _ = xr_provider(body=xr_ok(model=snapshot))
        with self.assertRaises(SanourError) as ctx:
            self._gw(p).generate(self._profile(), call(XMODEL), deadline_in(2.0), identity=_rid(self._profile()))
        self.assertEqual(ctx.exception.scope, "model_identity")
        p2, _ = xr_provider(body=xr_ok(model=snapshot))
        result = self._gw(p2).generate(self._profile(frozenset({snapshot})), call(XMODEL), deadline_in(2.0), identity=_rid(self._profile(frozenset({snapshot}))))
        self.assertEqual(result.reported_model_id, snapshot)

    def test_single_attempt_and_capacity_is_released(self):
        p, t = xr_provider(status=429, body=b"")
        gw = self._gw(p, max_calls=1)
        for _ in range(3):
            with self.assertRaises(SanourError):
                gw.generate(self._profile(), call(XMODEL), deadline_in(2.0), identity=_rid(self._profile()))
        self.assertEqual(len(t.calls), 3)  # one attempt per request, never a retry
        self.assertEqual(gw.in_flight, 0)

    def test_expired_deadline_sends_nothing(self):
        p, t = xr_provider()
        with self.assertRaises(SanourError) as ctx:
            self._gw(p).generate(self._profile(), call(XMODEL), time.monotonic() - 1, identity=_rid(self._profile()))
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_TIMEOUT)
        self.assertEqual(t.calls, [])

    def test_no_fallback_to_another_profile(self):
        primary, t = xr_provider(status=500, body=b"")
        backup = _Spy("grok")
        router = DeterministicRouter([
            ModelProfile(alias="x_profile", provider="grok_responses", model_id=XMODEL, priority=0,
                         capabilities=ModelCapabilities(text_generation=True, max_context_tokens=8192,
                                                        max_output_tokens=4096)),
            ModelProfile(alias="b_profile", provider="grok", model_id="grok-b", priority=1,
                         capabilities=ModelCapabilities(text_generation=True, max_context_tokens=8192,
                                                        max_output_tokens=4096)),
        ])
        core = SanourCore(router=router, gateway=ModelGateway({"grok_responses": primary, "grok": backup},
                                                              max_concurrent_calls=2))
        response = core.handle({"profile_alias": "x_profile", "prompt": "hi"})
        self.assertEqual(response.status, "error")
        self.assertEqual(len(t.calls), 1)
        self.assertEqual(backup.calls, 0)


class _Spy:
    capabilities = TEST_ALL_CAPS

    def __init__(self, name):
        self.name, self.calls = name, 0

    def generate(self, c):
        self.calls += 1
        return ModelResult(text="b", reported_model_id=c.model_id)


class ChatAdapterAndProductionTests(unittest.TestCase):
    def test_chat_completions_adapter_is_kept_and_unchanged_in_contract(self):
        self.assertEqual(grok_chat.PINNED_URL, "https://api.x.ai/v1/chat/completions")
        self.assertEqual(grok_chat.GROK_PROVIDER_NAME, "grok")
        self.assertIsNot(grok_chat.GrokProvider, xr.XaiResponsesProvider)

    def test_responses_adapter_is_not_wired_into_production(self):
        import sanour_ai.composition.production as production
        source = inspect.getsource(production)
        self.assertNotIn("xai_responses", source)
        self.assertNotIn("XaiResponses", source)
        self.assertNotIn("grok", source.lower())


# ---------------------------------------------------------------- capability matrix
class CapabilityMatrixTests(unittest.TestCase):
    def test_every_cell_has_a_valid_status_and_a_note(self):
        for surface, row in pm.MATRIX.items():
            self.assertEqual(set(row), set(pm.CAPABILITIES), surface)
            for cap, cell in row.items():
                with self.subTest(surface=surface, cap=cap):
                    self.assertIn(cell.status, pm.STATUSES)
                    self.assertTrue(cell.note)

    def test_every_adapter_declared_flag_is_verified_on_its_surface(self):
        adapters = {
            "openai": None,  # SDK adapter: declares text_generation only; checked in its own module
            "anthropic": AnthropicProvider(SecretStr(KEY), transport=Transport()),
            "grok_responses": XaiResponsesProvider(SecretStr(KEY), transport=Transport()),
        }
        for name, provider in adapters.items():
            if provider is None:
                continue
            with self.subTest(adapter=name):
                declared = provider.capabilities.model_dump()
                self.assertEqual(pm.declared_flags_are_verified(pm.ADAPTER_SURFACE[name], declared), [])

    def test_unverified_and_unsupported_cells_are_never_declared(self):
        for surface in pm.MATRIX:
            for cap in pm.CAPABILITIES:
                if pm.status(surface, cap) != pm.VERIFIED:
                    self.assertEqual(pm.declared_flags_are_verified(surface, {cap: True}), [cap])

    def test_reasoning_is_unsupported_on_chat_completions_and_verified_on_responses(self):
        self.assertEqual(pm.status("grok_chat_completions", "reasoning"), pm.UNSUPPORTED)
        self.assertEqual(pm.status("grok_responses", "reasoning"), pm.VERIFIED)

    def test_names_alone_do_not_verify_capabilities(self):
        self.assertEqual(pm.status("gemini_generate_content", "tools"), pm.UNVERIFIED)
        self.assertEqual(pm.status("openai_responses", "structured_output"), pm.UNVERIFIED)

    def test_provider_capabilities_shape_is_unchanged(self):
        from sanour_ai.models.capabilities import ProviderCapabilities
        self.assertEqual(set(ProviderCapabilities.model_fields), {
            "text_generation", "structured_output", "tool_calling", "image_input",
            "image_output", "video_output", "streaming"})


# ---------------------------------------------------------------- audit: no header or secret leakage
class _Capture(logging.Handler):
    def __init__(self):
        super().__init__()
        self.lines = []

    def emit(self, record):
        self.lines.append(record.getMessage())


class AuditSafetyTests(unittest.TestCase):
    def test_audit_never_contains_headers_keys_or_bodies(self):
        logger = logging.getLogger(AUDIT_LOGGER_NAME + ".stage1030")
        logger.handlers.clear()
        logger.propagate = False
        handler = _Capture()
        logger.addHandler(handler)
        p, _ = xr_provider(status=401, body=f'{{"error":{{"message":"{KEY}"}}}}'.encode(),
                           headers={"Set-Cookie": "SECRET-COOKIE-1030"})
        gw = ModelGateway({"grok_responses": p}, max_concurrent_calls=1)
        profile = ModelProfile(alias="x_profile", provider="grok_responses", model_id=XMODEL,
                               capabilities=ModelCapabilities(text_generation=True, max_context_tokens=8192,
                                                              max_output_tokens=4096))
        core = SanourCore(router=DeterministicRouter([profile]), gateway=gw, audit=AuditLogger(logger))
        response = core.handle({"profile_alias": "x_profile", "prompt": PROMPT})
        blob = "\n".join(handler.lines) + response.model_dump_json()
        for secret in (KEY, PROMPT, "SECRET-COOKIE-1030", "Authorization", "Bearer"):
            self.assertNotIn(secret, blob)


if __name__ == "__main__":
    unittest.main()
