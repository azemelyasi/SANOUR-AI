"""Stage 10.47: model governance. Deterministic, offline. Evidence and gate decisions only."""

import os
import unittest
from unittest import mock

from sanour_ai.composition import production
from sanour_ai.composition.runtime import Runtime
from sanour_ai.config.settings import ConfigError
from sanour_ai.models import capability_intelligence as ci
from sanour_ai.models import production_gate
from sanour_ai.models.base import ModelResult
from sanour_ai.models.capabilities import ProviderCapabilities
from sanour_ai.providers import readiness
from sanour_ai.providers.offline_contract import OfflineTestProvider
from sanour_ai.providers.openai_provider import OpenAIProvider
from tests.support import production_ledger_path

MODEL = "gpt-gov-1047"
TRIPLE = ("openai", "openai_responses", MODEL)
GOOD = dict(source="approved_live_verification", method="live_provider_test", verified_at="2026-11-07T12:00:00Z")


def proof(**overrides):
    base = dict(provider_id="openai", surface="openai_responses", category="text_generation",
                test_reference="tests/live/test_openai.py::test_text", model_id=MODEL, status="VERIFIED", **GOOD)
    base.update(overrides)
    return ci.RuntimeEvidence(**base)


def env():
    return {
        "SANOUR_PROVIDER": "openai",
        "SANOUR_OPENAI_MODEL_ID": MODEL,
        "SANOUR_OPENAI_MAX_CONTEXT_TOKENS": "8192",
        "SANOUR_OPENAI_MAX_OUTPUT_TOKENS": "1024",
        "OPENAI_API_KEY": "STAGE1047-GOV-SECRET-QQ",
    }


class EvidenceProvenance(unittest.TestCase):
    def test_fake_transport_cannot_create_evidence(self):
        with self.assertRaises(ValueError):
            proof(source="fake_transport")
        with self.assertRaises(ValueError):
            proof(method="fake_transport")

    def test_mock_and_environment_sources_are_refused(self):
        for source in ("mock", "environment", "documentation", "test_double"):
            with self.subTest(source=source):
                with self.assertRaises(ValueError):
                    proof(source=source)

    def test_malformed_timestamp_is_refused(self):
        for value in ("2026-11-07", "2026-11-07 12:00:00", "not-a-date"):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    proof(verified_at=value)

    def test_blank_timestamp_is_inert_not_verified(self):
        self.assertFalse(proof(verified_at="").is_verified_eligible())

    def test_non_verified_status_is_refused(self):
        with self.assertRaises(ValueError):
            proof(status="DOCUMENTED_ONLY")

    def test_missing_model_identity_is_inert(self):
        self.assertFalse(proof(model_id="  ").is_verified_eligible())

    def test_fake_transport_double_cannot_produce_verified_capability(self):
        class Double(OfflineTestProvider):
            capabilities = ProviderCapabilities(text_generation=True)

        status = ci.runtime_status("openai", "openai_responses", "text_generation",
                                   Double.capabilities, (), model_id=MODEL)
        self.assertNotEqual(status, ci.Status.VERIFIED)


class CapabilityLevels(unittest.TestCase):
    def test_documentation_alone_never_yields_verified(self):
        for surface in readiness_surfaces():
            for category in ci.CATEGORY_SOURCES:
                with self.subTest(surface=surface, category=category):
                    status = ci.runtime_status("openai", surface, category,
                                               OpenAIProvider.capabilities, (), model_id=MODEL)
                    self.assertNotEqual(status, ci.Status.VERIFIED)
        self.assertEqual(ci.production_ready("openai", "openai_responses", OpenAIProvider.capabilities, (),
                                             model_id=MODEL), ())

    def test_documented_only_capability_is_not_adapter_declared(self):
        # structured_output is documented on the surface but this adapter does not declare it.
        status = ci.adapter_status("openai_responses", "structured_output", OpenAIProvider.capabilities)
        self.assertIn(status, (ci.Status.DOCUMENTED_ONLY, ci.Status.UNKNOWN))

    def test_evidence_for_undeclared_capability_is_capability_mismatch_not_verified(self):
        proof_for_vision = proof(category="vision", test_reference="t::v")
        status = ci.runtime_status("openai", "openai_responses", "vision", OpenAIProvider.capabilities,
                                   (proof_for_vision,), model_id=MODEL)
        self.assertNotEqual(status, ci.Status.VERIFIED)

    def test_evidence_for_other_provider_or_surface_never_applies(self):
        self.assertNotEqual(ci.runtime_status("anthropic", "openai_responses", "text_generation",
                                              OpenAIProvider.capabilities, (proof(),), model_id=MODEL),
                            ci.Status.VERIFIED)
        self.assertNotEqual(ci.runtime_status("openai", "grok_responses", "text_generation",
                                              OpenAIProvider.capabilities, (proof(),), model_id=MODEL),
                            ci.Status.VERIFIED)


def readiness_surfaces():
    from sanour_ai.models import provider_matrix as pm
    return tuple(pm.MATRIX)


class GateEligibility(unittest.TestCase):
    def check(self, **kw):
        args = dict(provider_id="openai", surface="openai_responses", adapter_caps=OpenAIProvider.capabilities,
                    required_categories=("text_generation",), model_id=MODEL)
        args.update(kw)
        return production_gate.check(**args)

    def test_unapproved_model_is_refused(self):
        with self.assertRaises(production_gate.ProductionGateRefused):
            self.check()

    def test_approved_model_without_verified_capability_is_refused(self):
        with self.assertRaises(production_gate.ProductionGateRefused):
            self.check(approved=frozenset({TRIPLE}))

    def test_unknown_provider_is_refused_even_with_approval_for_another(self):
        with self.assertRaises(production_gate.ProductionGateRefused):
            self.check(provider_id="anthropic", approved=frozenset({TRIPLE}))

    def test_unsupported_surface_is_refused(self):
        with self.assertRaises(production_gate.ProductionGateRefused):
            self.check(surface="grok_responses", approved=frozenset({("openai", "grok_responses", MODEL)}))

    def test_exact_triple_with_matching_verified_evidence_passes(self):
        with mock.patch.object(ci, "RUNTIME_EVIDENCE", (proof(),)):
            self.check(approved=frozenset({TRIPLE}))  # no exception

    def test_verified_evidence_for_another_model_does_not_open_the_gate(self):
        with mock.patch.object(ci, "RUNTIME_EVIDENCE", (proof(model_id="gpt-other"),)):
            with self.assertRaises(production_gate.ProductionGateRefused):
                self.check(approved=frozenset({TRIPLE}))

    def test_approved_set_for_another_model_does_not_open_the_gate(self):
        with mock.patch.object(ci, "RUNTIME_EVIDENCE", (proof(),)):
            with self.assertRaises(production_gate.ProductionGateRefused):
                self.check(approved=frozenset({("openai", "openai_responses", "gpt-other")}))

    def test_environment_cannot_bypass_approval(self):
        hostile = dict(env(), SANOUR_APPROVED_PRODUCTION_MODELS=MODEL, SANOUR_RUNTIME_EVIDENCE="text_generation")
        with mock.patch.dict(os.environ, hostile, clear=True):
            with self.assertRaises(ConfigError):
                Runtime.build()

    def test_production_construction_refuses_with_empty_approval(self):
        with mock.patch.object(production, "_sdk_present", return_value=True):
            with self.assertRaises(ConfigError):
                Runtime.build(env(), usage_ledger_path=production_ledger_path())
        self.assertEqual(production_gate.APPROVED_PRODUCTION_MODELS, frozenset())
        self.assertEqual(ci.RUNTIME_EVIDENCE, ())


class ExactlyOneProfile(unittest.TestCase):
    def test_test_runtime_has_exactly_one_profile_and_no_auto_selection(self):
        rt = Runtime.build_for_tests(env())
        self.assertEqual(set(rt._registry.states()), {"openai"})  # noqa: SLF001
        self.assertEqual(rt.handle({"profile_alias": "not_a_profile", "prompt": "x"}).status, "error")
        self.assertEqual(rt.handle({"prompt": "x"}).status, "error")

    def test_a_model_is_never_substituted(self):
        class Other(OfflineTestProvider):
            def generate(self, call):
                return ModelResult(text="ok", reported_model_id="gpt-substitute")

        rt = Runtime.build_for_tests(env(), provider=Other())
        out = rt.handle({"profile_alias": "openai_primary", "prompt": "x"})
        self.assertEqual(out.status, "error")  # reported identity not allowlisted: refused, not swapped


if __name__ == "__main__":
    unittest.main()
