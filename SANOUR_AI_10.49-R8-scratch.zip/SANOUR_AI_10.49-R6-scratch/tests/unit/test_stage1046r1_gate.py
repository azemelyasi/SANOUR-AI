"""Stage 10.46-R1: offline production gate bypass audit.

Offline only: a spy stands in for the OpenAI adapter, no SDK, no network, no key.
The expectedFailure test documents a confirmed bypass that is NOT fixed in this stage.
"""

import inspect
import unittest
from unittest import mock

from sanour_ai.providers.offline_contract import OfflineTestProvider
from sanour_ai.composition import production
from sanour_ai.composition.runtime import Runtime
from sanour_ai.config.governance import load_runtime_config
from sanour_ai.config.settings import ConfigError
from sanour_ai.models import capability_intelligence, production_gate
from sanour_ai.models.base import ModelResult
from sanour_ai.models.capabilities import ProviderCapabilities
from tests.support import production_ledger_path

MODEL = "gpt-audit-1046"
SECRET = "AUDIT1046-SECRET-QQ"


def env():
    return {
        "SANOUR_PROVIDER": "openai",
        "SANOUR_OPENAI_MODEL_ID": MODEL,
        "SANOUR_OPENAI_MAX_CONTEXT_TOKENS": "8192",
        "SANOUR_OPENAI_MAX_OUTPUT_TOKENS": "1024",
        "OPENAI_API_KEY": SECRET,
    }


class SpyOpenAI(OfflineTestProvider):
    name = "openai"
    vendor = "openai"
    surface = "openai_responses"
    auth_method = "sdk_bearer_client"
    capabilities = ProviderCapabilities(text_generation=True)
    instances: list = []
    calls: list = []

    def __init__(self, api_key):
        SpyOpenAI.instances.append(self)

    def initialize(self):
        pass

    def generate(self, call):
        SpyOpenAI.calls.append(call)
        return ModelResult(text="ok", reported_model_id=call.model_id)

    def close(self):
        pass


class _Base(unittest.TestCase):
    def setUp(self):
        SpyOpenAI.instances = []
        SpyOpenAI.calls = []
        for p in (
            mock.patch.object(production, "OpenAIProvider", SpyOpenAI), mock.patch.object(production, "_default_test_provider", lambda: SpyOpenAI("test")),
            mock.patch.object(production, "_sdk_present", return_value=True),
        ):
            p.start()
            self.addCleanup(p.stop)


class ProductionGateReachability(_Base):
    """Every production entry point must stop at the gate before any adapter exists."""

    def test_runtime_build_refused_before_adapter(self):
        with self.assertRaises(ConfigError):
            Runtime.build(env(), usage_ledger_path=production_ledger_path())
        self.assertEqual(SpyOpenAI.instances, [])

    def test_build_core_and_registry_refused_before_adapter(self):
        with self.assertRaises(ConfigError):
            production.build_core_and_registry(load_runtime_config(env()))
        self.assertEqual(SpyOpenAI.instances, [])

    def test_build_production_core_refused_before_adapter(self):
        with self.assertRaises(ConfigError):
            production.build_production_core(env())
        self.assertEqual(SpyOpenAI.instances, [])

    def test_core_from_config_refused_before_adapter(self):
        with self.assertRaises(ConfigError):
            production.core_from_config(load_runtime_config(env()))
        self.assertEqual(SpyOpenAI.instances, [])

    def test_gate_is_consulted_on_production_path(self):
        spy = mock.patch.object(production_gate, "check", wraps=production_gate.check)
        mocked = spy.start()
        self.addCleanup(spy.stop)
        with self.assertRaises(ConfigError):
            Runtime.build(env(), usage_ledger_path=production_ledger_path())
        mocked.assert_called_once()
        self.assertEqual(mocked.call_args.args[4], MODEL)

    def test_production_entry_points_never_reference_test_builders(self):
        for fn in (Runtime.build, production.build_core_and_registry,
                   production.build_production_core, production.core_from_config):
            source = inspect.getsource(fn)
            self.assertNotIn("_for_tests", source, fn.__qualname__)
            self.assertNotIn("gated=False", source, fn.__qualname__)
            self.assertNotIn("build_test_core", source, fn.__qualname__)

    def test_gate_refusal_names_no_model_or_secret(self):
        with self.assertRaises(ConfigError) as ctx:
            Runtime.build(env(), usage_ledger_path=production_ledger_path())
        message = str(ctx.exception)
        self.assertNotIn(MODEL, message)
        self.assertNotIn(SECRET, message)


class ProductionGateInputs(unittest.TestCase):
    def test_approved_models_empty_by_default(self):
        self.assertIsInstance(production_gate.APPROVED_PRODUCTION_MODELS, frozenset)
        self.assertEqual(production_gate.APPROVED_PRODUCTION_MODELS, frozenset())

    def test_runtime_evidence_empty_by_default(self):
        self.assertEqual(capability_intelligence.RUNTIME_EVIDENCE, ())


class TestFactoryIsolation(unittest.TestCase):
    """Stage 10.46-R2: the test factories never construct the real adapter (formerly expectedFailure)."""

    def setUp(self):
        SpyOpenAI.instances = []
        patcher = mock.patch.object(production, "_sdk_present", return_value=True)
        patcher.start()
        self.addCleanup(patcher.stop)
        real = mock.patch(
            "sanour_ai.providers.openai_provider._build_default_client",
            side_effect=AssertionError("real adapter constructed"),
        )
        real.start()
        self.addCleanup(real.stop)

    def test_build_for_tests_does_not_construct_real_adapter(self):
        Runtime.build_for_tests(env())
        self.assertEqual(SpyOpenAI.instances, [])

    def test_build_test_core_does_not_construct_real_adapter(self):
        production.build_test_core(env())
        self.assertEqual(SpyOpenAI.instances, [])


class StaticSourceGuards(unittest.TestCase):
    """Offline text guards on the adapter source. They catch literal flips only, not behaviour;
    the behavioural SDK tests that check these at runtime stay skipped until the SDK is installed."""

    @classmethod
    def setUpClass(cls):
        from sanour_ai.providers import openai_provider
        cls.src = inspect.getsource(openai_provider)

    def test_store_is_literally_false(self):
        self.assertIn("store=False,", self.src)
        self.assertNotIn("store=True", self.src)

    def test_sdk_client_built_with_trust_env_false(self):
        self.assertIn("httpx2.Client(trust_env=False)", self.src)
        self.assertNotIn("trust_env=True", self.src)

    def test_sdk_retries_literally_disabled(self):
        self.assertIn("max_retries=0,", self.src)
        self.assertNotIn("max_retries=2", self.src)
