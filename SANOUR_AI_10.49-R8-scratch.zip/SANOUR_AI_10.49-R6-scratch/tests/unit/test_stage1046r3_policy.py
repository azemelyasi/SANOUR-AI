"""Stage 10.46-R3: test-provider isolation policy, production adapter rejection, boundary checks.

Offline only. Every production adapter is refused by both test factories, whether injected, supplied
through the patched default seam, renamed, or selected by SANOUR_PROVIDER. Network and SDK-client
construction are guarded, so any leak fails the test.
"""

import ast
import os
import socket
import unittest
from pathlib import Path
from unittest import mock

from sanour_ai.composition import production
from sanour_ai.composition.runtime import Runtime
from sanour_ai.config import governance
from sanour_ai.config.settings import ConfigError
from sanour_ai.models import production_gate
from sanour_ai.models.base import ModelResult
from sanour_ai.providers import common, openai_provider, readiness
from sanour_ai.providers.offline_contract import PRODUCTION_ADAPTERS, OfflineTestProvider
from tests.support import production_ledger_path

SRC = Path(__file__).resolve().parents[2] / "src" / "sanour_ai"
SECRET = "R3-SECRET-KEY-DO-NOT-USE-YY"
MODEL = "gpt-r3-test"
ALIAS = "openai_primary"
REGISTRY_KEY = {v: k for k, v in readiness.ADAPTERS.items()}  # adapter class -> readiness key


def env(**extra):
    base = {
        "SANOUR_PROVIDER": "openai",
        "SANOUR_OPENAI_MODEL_ID": MODEL,
        "SANOUR_OPENAI_MAX_CONTEXT_TOKENS": "8192",
        "SANOUR_OPENAI_MAX_OUTPUT_TOKENS": "1024",
        "OPENAI_API_KEY": SECRET,
    }
    base.update(extra)
    return base


class Double(OfflineTestProvider):
    """A legitimate test double: subclasses the explicit contract, offline only."""

    def __init__(self, text="double"):
        self.text = text
        self.calls = []

    def generate(self, call):
        self.calls.append(call.model_id)
        return ModelResult(text=self.text, reported_model_id=call.model_id)


class Guarded(unittest.TestCase):
    """Blocks sockets, the shared HTTP opener, and SDK client construction. Records every attempt."""

    def setUp(self):
        self.attempts = []

        def boom(what):
            def _raise(*a, **k):
                self.attempts.append(what)
                raise AssertionError(f"blocked: {what}")
            return _raise

        for p in (
            mock.patch.object(socket.socket, "connect", boom("socket")),
            mock.patch.object(common.OPENER, "open", boom("http")),
            mock.patch.object(openai_provider, "_build_default_client", boom("sdk client")),
            mock.patch.object(openai_provider.OpenAIProvider, "__init__", boom("openai init")),
            mock.patch.object(production, "_sdk_present", return_value=True),
            mock.patch.dict(os.environ, {}, clear=False),
        ):
            p.start()
            self.addCleanup(p.stop)

    def assert_clean(self):
        self.assertEqual(self.attempts, [])


def make_production(cls):
    """A production adapter instance built without __init__: no key, no client, no network."""
    return cls.__new__(cls)


class ProductionAdaptersRejected(Guarded):
    def test_every_production_adapter_rejected_when_injected(self):
        for cls in PRODUCTION_ADAPTERS:
            with self.subTest(adapter=cls.__name__):
                inst = make_production(cls)
                with self.assertRaises(ConfigError):
                    Runtime.build_for_tests(env(), provider=inst)
                with self.assertRaises(ConfigError):
                    production.build_test_core(env(), provider=inst)
        self.assert_clean()

    def test_renamed_production_adapter_still_rejected(self):
        for cls in PRODUCTION_ADAPTERS:
            with self.subTest(adapter=cls.__name__):
                inst = make_production(cls)
                inst.name = "openai"
                inst.vendor = "openai"
                with self.assertRaises(ConfigError):
                    Runtime.build_for_tests(env(), provider=inst)
                with self.assertRaises(ConfigError):
                    production.build_test_core(env(), provider=inst)
        self.assert_clean()

    def test_patched_default_seam_cannot_introduce_production_adapter(self):
        for cls in PRODUCTION_ADAPTERS:
            with self.subTest(adapter=cls.__name__):
                inst = make_production(cls)
                with mock.patch.object(production, "_default_test_provider", lambda: inst):
                    with self.assertRaises(ConfigError):
                        Runtime.build_for_tests(env())
                    with self.assertRaises(ConfigError):
                        production.build_test_core(env())
        self.assert_clean()

    def test_sanour_provider_naming_a_production_adapter_changes_nothing(self):
        for cls in PRODUCTION_ADAPTERS:
            key = REGISTRY_KEY[cls]
            with self.subTest(adapter=cls.__name__, selector=key):
                with mock.patch.dict(os.environ, env(SANOUR_PROVIDER=key), clear=True):
                    if key == "openai":
                        # The normal value is accepted, and the factory still uses only the offline fake.
                        out = Runtime.build_for_tests().handle({"profile_alias": ALIAS, "prompt": "x"})
                        self.assertEqual(out.status, "success")
                    else:
                        # Non-openai values are refused by the shared loader, before any factory work.
                        with self.assertRaises(ConfigError):
                            Runtime.build_for_tests()
                        with self.assertRaises(ConfigError):
                            production.build_test_core()
        self.assert_clean()

    def test_sdk_presence_does_not_change_rejection(self):
        for present in (True, False):
            with mock.patch.object(production, "_sdk_present", return_value=present):
                for cls in PRODUCTION_ADAPTERS:
                    with self.subTest(sdk=present, adapter=cls.__name__):
                        with self.assertRaises(ConfigError):
                            Runtime.build_for_tests(env(), provider=make_production(cls))
        self.assert_clean()


class AllowlistContract(Guarded):
    def test_default_offline_fake_works_through_both_factories(self):
        with mock.patch.dict(os.environ, env(), clear=True):
            rt_out = Runtime.build_for_tests().handle({"profile_alias": ALIAS, "prompt": "x"})
        core_out = production.build_test_core(env()).handle({"profile_alias": ALIAS, "prompt": "x"})
        self.assertEqual(rt_out.status, "success")
        self.assertEqual(core_out.status, "success")
        self.assert_clean()

    def test_legitimate_injected_double_works_through_both_factories(self):
        rt = Runtime.build_for_tests(env(), provider=Double("rt double"))
        self.assertEqual(rt.handle({"profile_alias": ALIAS, "prompt": "x"}).output, "rt double")
        core = production.build_test_core(env(), provider=Double("core double"))
        self.assertEqual(core.handle({"profile_alias": ALIAS, "prompt": "x"}).output, "core double")
        self.assert_clean()

    def test_plain_duck_typed_object_is_refused(self):
        class Duck:
            name = "openai"
            vendor = "openai"
            surface = "openai_responses"
            auth_method = "sdk_bearer_client"

            def generate(self, call):
                return ModelResult(text="x", reported_model_id=call.model_id)

        with self.assertRaises(ConfigError):
            Runtime.build_for_tests(env(), provider=Duck())
        self.assert_clean()


class AdapterInventory(unittest.TestCase):
    def test_policy_lists_exactly_the_five_network_adapters(self):
        self.assertEqual(
            {c.__name__ for c in PRODUCTION_ADAPTERS},
            {"OpenAIProvider", "AnthropicProvider", "GeminiProvider", "GrokProvider", "XaiResponsesProvider"},
        )

    def test_readiness_registry_is_covered_by_policy(self):
        self.assertTrue(set(readiness.ADAPTERS.values()) <= set(PRODUCTION_ADAPTERS))

    def test_every_class_defining_generate_is_reviewed(self):
        found = set()
        for path in SRC.rglob("*.py"):
            tree = ast.parse(path.read_text(encoding="utf-8"))
            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef) and any(
                    isinstance(f, ast.FunctionDef) and f.name == "generate" for f in node.body
                ):
                    found.add((path.name, node.name))
        self.assertEqual(found, {
            ("anthropic_provider.py", "AnthropicProvider"),
            ("gemini_provider.py", "GeminiProvider"),
            ("grok_provider.py", "GrokProvider"),
            ("openai_provider.py", "OpenAIProvider"),
            ("xai_responses_provider.py", "XaiResponsesProvider"),
            ("offline_contract.py", "OfflineTestProvider"),
            ("base.py", "ModelProvider"),
            ("gateway.py", "ModelGateway"),
        })


class CredentialAndBoundary(Guarded):
    def test_test_factory_never_reads_the_real_key(self):
        class Recording(dict):
            reads: list = []

            def __getitem__(self, key):
                Recording.reads.append(key)
                return super().__getitem__(key)

            def get(self, key, default=None):
                Recording.reads.append(key)
                return super().get(key, default)

        Recording.reads = []
        config = governance.load_offline_test_config(Recording(env()))
        self.assertNotIn("OPENAI_API_KEY", Recording.reads)
        self.assertNotEqual(config.api_key.get_secret_value(), SECRET)
        self.assertNotIn(SECRET, repr(config))
        self.assert_clean()

    def test_production_loader_rejects_missing_and_blank_key(self):
        with self.assertRaises(ConfigError):
            governance.load_runtime_config(env(OPENAI_API_KEY=None))
        with self.assertRaises(ConfigError):
            governance.load_runtime_config(env(OPENAI_API_KEY="   "))
        with mock.patch.dict(os.environ, env(OPENAI_API_KEY="   "), clear=True):
            with self.assertRaises(ConfigError):
                Runtime.build()
        self.assert_clean()

    def test_test_factory_accepts_blank_key_but_still_requires_key_presence(self):
        # Test factories never read the key value, so a blank value is not policed there.
        Runtime.build_for_tests(env(OPENAI_API_KEY="   "))
        # Presence is still required by the shared loader; this is the unchanged status quo.
        without_key = {k: v for k, v in env().items() if k != "OPENAI_API_KEY"}
        with self.assertRaises(ConfigError):
            Runtime.build_for_tests(without_key)
        self.assert_clean()

    def test_gate_still_enforced_for_official_construction(self):
        with mock.patch.object(production_gate, "check",
                               side_effect=production_gate.ProductionGateRefused("x")):
            with self.assertRaises(ConfigError):
                Runtime.build(env(), usage_ledger_path=production_ledger_path())
        with self.assertRaises(ConfigError):
            Runtime.build(env(), usage_ledger_path=production_ledger_path())  # no approval: refused by the real gate
        self.assert_clean()

    def test_test_mode_reload_builds_nothing_and_never_reports_the_key(self):
        rt = Runtime.build_for_tests(env())
        report = rt.check_reload(env(OPENAI_API_KEY="R3-OTHER-KEY-XX"))
        self.assertNotIn("security.openai_api_key", report.changed)
        self.assertNotIn(SECRET, repr(report))
        self.assert_clean()
