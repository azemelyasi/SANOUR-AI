"""Stage 10.47: unified usage accounting. Deterministic, offline, no SDK, no network, no key."""

import json
import os
import time
import unittest
from types import SimpleNamespace
from unittest import mock

from pydantic import SecretStr

from sanour_ai.composition import production
from sanour_ai.composition.runtime import Runtime
from sanour_ai.core.usage_accounting import UsageAccountingService
from sanour_ai.errors import FailureKind
from sanour_ai.models.base import ModelCall, ModelResult, ProviderError
from sanour_ai.models.execution import ExecutionResult
from sanour_ai.models.usage import (
    Usage,
    usage_from_anthropic,
    usage_from_chat_completions,
    usage_from_gemini,
    usage_from_openai_style,
)
from sanour_ai.providers.anthropic_provider import AnthropicProvider
from sanour_ai.providers.common import HttpResult
from sanour_ai.providers.gemini_provider import GeminiProvider
from sanour_ai.providers.grok_provider import GrokProvider
from sanour_ai.providers.offline_contract import OfflineTestProvider
from sanour_ai.providers.openai_provider import OpenAIProvider
from sanour_ai.providers.xai_responses_provider import XaiResponsesProvider
from tests.unit.test_stage1038 import SlowTransport

SECRET = "STAGE1047-SECRET-KEY-USAGE-QQ"
PROMPT = "STAGE1047-PROMPT-TEXT-USAGE"
OUTPUT = "STAGE1047-OUTPUT-TEXT-USAGE"
MODEL = "gpt-usage-1047"
ALIAS = "openai_primary"


def env():
    return {
        "SANOUR_PROVIDER": "openai",
        "SANOUR_OPENAI_MODEL_ID": MODEL,
        "SANOUR_OPENAI_MAX_CONTEXT_TOKENS": "8192",
        "SANOUR_OPENAI_MAX_OUTPUT_TOKENS": "1024",
        "OPENAI_API_KEY": SECRET,
    }


class UsageFixtureProvider(OfflineTestProvider):
    """Offline test double that reports a fixed usage record."""

    def __init__(self, usage):
        self._usage = usage

    def generate(self, call):
        return ModelResult(text=OUTPUT, reported_model_id=call.model_id, usage=self._usage)


def execution(usage=None, *, provider="openai", profile="p", model="m", request="r1"):
    return ExecutionResult(
        request_id=request, profile_id=profile, provider_id=provider, api_surface="openai_responses",
        requested_model_id=model, provider_reported_model_id=model, output="out", finish_status="completed",
        execution_ms=1, usage=usage,
    )


class UsageModelValidation(unittest.TestCase):
    def test_valid_complete_usage(self):
        u = Usage(input_tokens=10, output_tokens=4, total_tokens=14, cached_input_tokens=3, reasoning_tokens=1)
        self.assertEqual(u.as_dict(), {"input_tokens": 10, "output_tokens": 4, "total_tokens": 14,
                                       "cached_input_tokens": 3, "reasoning_tokens": 1})

    def test_missing_usage_is_none_never_zero(self):
        u = Usage()
        self.assertEqual(set(u.as_dict().values()), {None})

    def test_partial_usage_keeps_unknown_fields_unknown(self):
        u = Usage(input_tokens=7)
        self.assertEqual(u.output_tokens, None)
        self.assertEqual(u.total_tokens, None)

    def test_negative_bool_float_and_text_are_refused(self):
        for bad in (-1, True, 1.5, "3"):
            with self.subTest(value=bad):
                with self.assertRaises(ValueError):
                    Usage(input_tokens=bad)

    def test_inconsistent_total_is_refused(self):
        with self.assertRaises(ValueError):
            Usage(input_tokens=5, output_tokens=3, total_tokens=9)

    def test_total_not_validated_without_both_parts(self):
        Usage(input_tokens=5, total_tokens=9)  # cannot be checked, so accepted as reported
        Usage(output_tokens=3, total_tokens=9)

    def test_cached_cannot_exceed_input_and_reasoning_cannot_exceed_output(self):
        with self.assertRaises(ValueError):
            Usage(input_tokens=2, cached_input_tokens=3)
        with self.assertRaises(ValueError):
            Usage(output_tokens=2, reasoning_tokens=3)

    def test_cached_and_reasoning_are_not_added_to_total(self):
        Usage(input_tokens=10, output_tokens=4, total_tokens=14, cached_input_tokens=6, reasoning_tokens=2)
        with self.assertRaises(ValueError):
            Usage(input_tokens=10, output_tokens=4, total_tokens=18, cached_input_tokens=6, reasoning_tokens=2)


class ProviderNormalization(unittest.TestCase):
    def test_openai_style_maps_cached_and_reasoning_inside_their_parents(self):
        u = usage_from_openai_style({
            "input_tokens": 20, "output_tokens": 9, "total_tokens": 29,
            "input_tokens_details": {"cached_tokens": 8}, "output_tokens_details": {"reasoning_tokens": 5},
        })
        self.assertEqual((u.input_tokens, u.output_tokens, u.total_tokens, u.cached_input_tokens, u.reasoning_tokens),
                         (20, 9, 29, 8, 5))

    def test_openai_style_accepts_sdk_objects(self):
        obj = SimpleNamespace(input_tokens=4, output_tokens=2, total_tokens=6,
                              input_tokens_details=SimpleNamespace(cached_tokens=1),
                              output_tokens_details=None)
        u = usage_from_openai_style(obj)
        self.assertEqual((u.input_tokens, u.cached_input_tokens, u.reasoning_tokens), (4, 1, None))

    def test_missing_usage_block_is_none(self):
        self.assertIsNone(usage_from_openai_style(None))
        self.assertIsNone(usage_from_chat_completions(None))
        self.assertIsNone(usage_from_anthropic(None))
        self.assertIsNone(usage_from_gemini(None))

    def test_partial_openai_block_has_unknown_detail_fields(self):
        u = usage_from_openai_style({"input_tokens": 3, "output_tokens": 1})
        self.assertEqual((u.total_tokens, u.cached_input_tokens, u.reasoning_tokens), (None, None, None))

    def test_chat_completions_shape(self):
        u = usage_from_chat_completions({
            "prompt_tokens": 12, "completion_tokens": 6, "total_tokens": 18,
            "prompt_tokens_details": {"cached_tokens": 4}, "completion_tokens_details": {"reasoning_tokens": 2},
        })
        self.assertEqual((u.input_tokens, u.output_tokens, u.total_tokens, u.cached_input_tokens, u.reasoning_tokens),
                         (12, 6, 18, 4, 2))

    def test_anthropic_input_is_normalized_to_include_cache_without_double_counting(self):
        u = usage_from_anthropic({"input_tokens": 3, "cache_read_input_tokens": 2,
                                  "cache_creation_input_tokens": 1, "output_tokens": 4})
        self.assertEqual((u.input_tokens, u.cached_input_tokens, u.output_tokens, u.total_tokens),
                         (6, 2, 4, None))

    def test_anthropic_without_cache_fields_leaves_input_unknown(self):
        u = usage_from_anthropic({"input_tokens": 3, "output_tokens": 4})
        self.assertEqual((u.input_tokens, u.cached_input_tokens, u.output_tokens), (None, None, 4))

    def test_gemini_adds_thoughts_to_output_and_keeps_total_only_when_complete(self):
        full = usage_from_gemini({"promptTokenCount": 4, "candidatesTokenCount": 2, "thoughtsTokenCount": 3,
                                  "totalTokenCount": 9, "cachedContentTokenCount": 1})
        self.assertEqual((full.input_tokens, full.output_tokens, full.total_tokens,
                          full.cached_input_tokens, full.reasoning_tokens), (4, 5, 9, 1, 3))
        no_thoughts = usage_from_gemini({"promptTokenCount": 4, "candidatesTokenCount": 2, "totalTokenCount": 9})
        self.assertEqual((no_thoughts.output_tokens, no_thoughts.reasoning_tokens, no_thoughts.total_tokens),
                         (2, None, None))

    def test_invalid_payload_is_dropped_not_guessed(self):
        self.assertIsNone(usage_from_openai_style({"input_tokens": 5, "output_tokens": 3, "total_tokens": 99}))
        self.assertIsNone(usage_from_chat_completions({"prompt_tokens": -1}))


def anthropic_body(usage):
    body = {"stop_reason": "end_turn", "model": MODEL,
            "content": [{"type": "text", "text": OUTPUT}]}
    if usage is not None:
        body["usage"] = usage
    return json.dumps(body).encode()


class AdapterExtraction(unittest.TestCase):
    def test_anthropic_result_carries_normalized_usage(self):
        from sanour_ai.providers.anthropic_provider import _parse_result
        result = _parse_result(anthropic_body({"input_tokens": 3, "cache_read_input_tokens": 0,
                                               "cache_creation_input_tokens": 0, "output_tokens": 2}))
        self.assertEqual(result.usage.input_tokens, 3)
        self.assertEqual(result.usage.output_tokens, 2)

    def test_anthropic_result_without_usage_is_none(self):
        from sanour_ai.providers.anthropic_provider import _parse_result
        self.assertIsNone(_parse_result(anthropic_body(None)).usage)

    def test_gemini_result_carries_usage_from_usage_metadata(self):
        from sanour_ai.providers import gemini_provider as g
        body = {"candidates": [{"content": {"parts": [{"text": OUTPUT}]}, "finishReason": "STOP"}],
                "modelVersion": MODEL,
                "usageMetadata": {"promptTokenCount": 4, "candidatesTokenCount": 2, "totalTokenCount": 6}}
        result = g._parse_result(json.dumps(body).encode(), MODEL)
        self.assertEqual((result.usage.input_tokens, result.usage.output_tokens), (4, 2))

    def test_xai_responses_result_carries_usage(self):
        from sanour_ai.providers import xai_responses_provider as x
        body = {"status": "completed", "model": MODEL,
                "output": [{"type": "message", "status": "completed", "content": [
                    {"type": "output_text", "text": OUTPUT}]}],
                "usage": {"input_tokens": 5, "output_tokens": 1, "total_tokens": 6}}
        result = x._parse_result(json.dumps(body).encode())
        self.assertEqual((result.usage.input_tokens, result.usage.total_tokens), (5, 6))

    def test_openai_sdk_style_response_carries_usage(self):
        response = SimpleNamespace(status="completed", output_text=OUTPUT, model=MODEL,
                                   usage=SimpleNamespace(input_tokens=7, output_tokens=3, total_tokens=10,
                                                         input_tokens_details=None, output_tokens_details=None))
        result = OpenAIProvider._to_result(response)
        self.assertEqual((result.usage.input_tokens, result.usage.total_tokens), (7, 10))

    def test_openai_response_without_usage_is_none(self):
        response = SimpleNamespace(status="completed", output_text=OUTPUT, model=MODEL)
        self.assertIsNone(OpenAIProvider._to_result(response).usage)


class LateResponseCarriesNoUsage(unittest.TestCase):
    def test_late_anthropic_response_with_usage_is_never_accepted(self):
        body = anthropic_body({"input_tokens": 3, "cache_read_input_tokens": 0,
                               "cache_creation_input_tokens": 0, "output_tokens": 2})
        provider = AnthropicProvider(SecretStr("k" * 12),
                                     transport=SlowTransport(0.15, result=HttpResult(200, body, {})))
        call = ModelCall(model_id=MODEL, prompt="hi", max_output_tokens=16,
                         deadline=time.monotonic() + 0.05)
        with self.assertRaises(ProviderError) as ctx:
            provider.generate(call)
        self.assertIs(ctx.exception.kind, FailureKind.DEADLINE_LATE)


class AccountingService(unittest.TestCase):
    def setUp(self):
        self.svc = UsageAccountingService(clock=lambda: 1_790_000_000.0)

    def test_known_and_unknown_are_never_mixed_into_zero(self):
        self.svc.record(execution(None, request="a"))
        self.svc.record(execution(Usage(input_tokens=5), request="b"))
        total = self.svc.total()
        self.assertEqual(total["requests"], 2)
        self.assertEqual(total["requests_with_usage"], 1)
        self.assertEqual(total["requests_without_usage"], 1)
        self.assertEqual(total["tokens"]["input_tokens"], {"sum": 5, "known_count": 1, "unknown_count": 1})
        self.assertEqual(total["tokens"]["output_tokens"], {"sum": None, "known_count": 0, "unknown_count": 2})

    def test_all_unknown_stays_none_not_zero(self):
        self.svc.record(execution(None))
        self.assertIsNone(self.svc.total()["tokens"]["total_tokens"]["sum"])

    def test_aggregates_by_provider_profile_model_and_period(self):
        self.svc.record(execution(Usage(input_tokens=1, output_tokens=1, total_tokens=2),
                                  provider="openai", profile="p1", model="m1", request="x"))
        self.svc.record(execution(Usage(input_tokens=4, output_tokens=2, total_tokens=6),
                                  provider="anthropic", profile="p2", model="m2", request="y"))
        self.assertEqual(set(self.svc.aggregate("provider")), {"openai", "anthropic"})
        self.assertEqual(set(self.svc.aggregate("profile")), {"p1", "p2"})
        self.assertEqual(set(self.svc.aggregate("model")), {"m1", "m2"})
        self.assertEqual(list(self.svc.aggregate("period")), ["2026-09-21"])
        self.assertEqual(self.svc.aggregate("provider")["anthropic"]["tokens"]["total_tokens"]["sum"], 6)

    def test_period_bucketing_separates_days(self):
        svc = UsageAccountingService()
        svc.record(execution(Usage(input_tokens=1), request="d1"), recorded_at=1_790_000_000.0)
        svc.record(execution(Usage(input_tokens=1), request="d2"), recorded_at=1_790_000_000.0 + 86400)
        self.assertEqual(len(svc.aggregate("period")), 2)

    def test_only_completed_results_are_recorded(self):
        with self.assertRaises(ValueError):
            self.svc.record(object())

    def test_summary_contains_no_prompt_output_or_key(self):
        self.svc.record(execution(Usage(input_tokens=1)))
        text = repr(self.svc.summary())
        for secret in (PROMPT, OUTPUT, SECRET, "Authorization"):
            self.assertNotIn(secret, text)


class RuntimeIntegration(unittest.TestCase):
    def test_runtime_records_normalized_usage_for_successful_requests(self):
        provider = UsageFixtureProvider(Usage(input_tokens=10, output_tokens=5, total_tokens=15))
        rt = Runtime.build_for_tests(env(), provider=provider)
        out = rt.handle({"profile_alias": ALIAS, "prompt": PROMPT})
        self.assertEqual(out.status, "success")
        summary = rt.usage_summary()
        self.assertEqual(summary["total"]["requests_with_usage"], 1)
        self.assertEqual(summary["total"]["tokens"]["total_tokens"]["sum"], 15)
        self.assertNotIn(PROMPT, repr(summary))
        self.assertNotIn(OUTPUT, repr(summary))

    def test_offline_fake_without_usage_is_unavailable_not_zero(self):
        rt = Runtime.build_for_tests(env())
        self.assertEqual(rt.handle({"profile_alias": ALIAS, "prompt": PROMPT}).status, "success")
        total = rt.usage_summary()["total"]
        self.assertEqual((total["requests"], total["requests_with_usage"]), (1, 0))
        self.assertIsNone(total["tokens"]["input_tokens"]["sum"])

    def test_failed_requests_record_nothing(self):
        class Failing(OfflineTestProvider):
            def generate(self, call):
                raise ProviderError("boom", kind=FailureKind.REQUEST_REJECTED, retryable=False)

        rt = Runtime.build_for_tests(env(), provider=Failing())
        self.assertEqual(rt.handle({"profile_alias": ALIAS, "prompt": PROMPT}).status, "error")
        self.assertEqual(rt.usage_summary()["total"]["requests"], 0)

    def test_request_without_explicit_profile_is_refused_not_auto_selected(self):
        rt = Runtime.build_for_tests(env())
        out = rt.handle({"prompt": PROMPT})
        self.assertEqual(out.status, "error")
        self.assertEqual(rt.usage_summary()["total"]["requests"], 0)

    def test_usage_summary_is_bounded_identifiers_and_counts(self):
        rt = Runtime.build_for_tests(env())
        summary = rt.usage_summary()
        self.assertEqual(set(summary), {"total", "provider", "profile", "model", "period", "delivery", "audit", "health"})


if __name__ == "__main__":
    unittest.main()
