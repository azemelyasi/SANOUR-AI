"""Stage 10.48: persistent usage ledger. Deterministic and offline: no SDK, no network, no real key.

Process-level tests start child Python processes that use only the local SQLite file.
"""

import json
import os
import sqlite3
import subprocess
import sys
import tempfile
import threading
import unittest
from pathlib import Path
from unittest import mock

from sanour_ai.composition.runtime import Runtime
from sanour_ai.core.usage_accounting import UsageAccountingService, build_report
from sanour_ai.errors import ErrorCode, FailureKind
from sanour_ai.ledger.record import LedgerRecord
from sanour_ai.ledger.repository import (
    InMemoryUsageRepository, LedgerConflictError, LedgerStorageError,
)
from sanour_ai.ledger.sqlite_repository import SCHEMA_VERSION, SqliteUsageRepository, _COLUMNS
from sanour_ai.models.base import ModelResult, ProviderError
from sanour_ai.models.execution import ExecutionResult
from sanour_ai.models.usage import Usage
from sanour_ai.providers.offline_contract import OfflineTestProvider
from tests.unit.test_stage1047r1 import UsageProvider

SRC = Path(__file__).resolve().parents[2] / "src"
SECRET = "STAGE1048-SECRET-KEY-DO-NOT-STORE"
PROMPT = "STAGE1048-PROMPT-DO-NOT-STORE"
OUTPUT = "STAGE1048-OUTPUT-DO-NOT-STORE"
ALIAS = "openai_primary"
MODEL = "gpt-1048-test"
STAMP = "2026-11-07T12:00:00+00:00"


def env():
    return {
        "SANOUR_PROVIDER": "openai",
        "SANOUR_OPENAI_MODEL_ID": MODEL,
        "SANOUR_OPENAI_MAX_CONTEXT_TOKENS": "8192",
        "SANOUR_OPENAI_MAX_OUTPUT_TOKENS": "1024",
        "OPENAI_API_KEY": SECRET,
    }


def raw(**extra):
    body = {"profile_alias": ALIAS, "prompt": PROMPT, "timeout_seconds": 5}
    body.update(extra)
    return body


def rec(request_id="r-0001", *, stamp=STAMP, provider="openai", profile="p", model="m", surface="openai_responses",
        delivery="delivered", audit="recorded", counts=None):
    counts = counts if counts is not None else {"input_tokens": 3, "output_tokens": None, "total_tokens": None,
                                                "cached_input_tokens": None, "reasoning_tokens": None}
    return LedgerRecord(
        request_id=request_id, utc_day=stamp[:10], recorded_at=stamp, provider_id=provider, profile_id=profile,
        model_id=model, api_surface=surface, delivery=delivery, audit_status=audit,
        usage_status="reported", **counts,
    )


def execution(request_id="x-1", usage=None, *, delivery="delivered", audit="recorded"):
    return ExecutionResult(
        request_id=request_id, profile_id="p", provider_id="openai", api_surface="openai_responses",
        requested_model_id="m", provider_reported_model_id="m", output="o", finish_status="completed",
        execution_ms=1, usage=usage, usage_audit=audit, delivery=delivery,
    )


class TempLedger(unittest.TestCase):
    def setUp(self):
        self._dir = tempfile.TemporaryDirectory()
        self.path = os.path.join(self._dir.name, "usage.db")
        self.addCleanup(self._dir.cleanup)

    def open(self):
        repo = SqliteUsageRepository(self.path)
        self.addCleanup(repo.close)
        return repo


# ---------------------------------------------------------------- repository contract, both engines
class RepositoryContract:
    def make(self):
        raise NotImplementedError

    def test_append_then_read_back_identical(self):
        repo = self.make()
        r = rec("a-1")
        self.assertTrue(repo.append(r))
        self.assertEqual(repo.records(), [r])

    def test_identical_retry_is_a_duplicate_and_stores_nothing_new(self):
        repo = self.make()
        self.assertTrue(repo.append(rec("a-1")))
        self.assertFalse(repo.append(rec("a-1", stamp="2026-11-07T12:00:05+00:00")))  # other time, same identity
        self.assertEqual(len(repo.records()), 1)

    def test_different_content_for_same_request_is_a_conflict(self):
        repo = self.make()
        repo.append(rec("a-1", provider="openai"))
        with self.assertRaises(LedgerConflictError):
            repo.append(rec("a-1", provider="anthropic"))
        self.assertEqual(repo.records()[0].provider_id, "openai")

    def test_unknown_counters_remain_none(self):
        repo = self.make()
        repo.append(rec("u-1"))
        stored = repo.records()[0]
        self.assertEqual(stored.output_tokens, None)
        self.assertEqual(stored.input_tokens, 3)

    def test_records_come_back_in_deterministic_order(self):
        repo = self.make()
        repo.append(rec("z-2", stamp="2026-11-07T12:00:02+00:00"))
        repo.append(rec("a-1", stamp="2026-11-07T12:00:01+00:00"))
        self.assertEqual([r.request_id for r in repo.records()], ["a-1", "z-2"])


class InMemoryConformance(RepositoryContract, unittest.TestCase):
    def make(self):
        return InMemoryUsageRepository()


class SqliteConformance(RepositoryContract, TempLedger):
    def make(self):
        return self.open()


# ------------------------------------------------------------- 1. restart and recovery
class RestartRecovery(TempLedger):
    def test_records_survive_restart_and_reports_match(self):
        repo = self.open()
        acct = UsageAccountingService(repository=repo)
        acct.record(execution("s-1", Usage(input_tokens=5, output_tokens=2, total_tokens=7)))
        acct.record(execution("s-2", None, delivery="withheld", audit="failed"))
        before = acct.summary()
        repo.close()
        reopened = UsageAccountingService(repository=SqliteUsageRepository(self.path))
        self.addCleanup(reopened.close)
        after = reopened.summary()
        for key in ("total", "provider", "profile", "model", "period", "delivery", "audit"):
            self.assertEqual(after[key], before[key], key)
        self.assertEqual(len(reopened.records()), 2)

    def test_runtime_usage_survives_a_restart(self):
        provider = UsageProvider(Usage(input_tokens=4, output_tokens=1, total_tokens=5))
        rt = Runtime.build_for_tests(env(), provider=provider, usage_ledger_path=self.path)
        self.assertEqual(rt.handle(raw()).status, "success")
        self.assertEqual(rt.handle(raw()).status, "success")
        rt.close_usage_ledger()
        again = Runtime.build_for_tests(env(), usage_ledger_path=self.path)
        self.addCleanup(again.close_usage_ledger)
        total = again.usage_summary()["total"]
        self.assertEqual(total["requests"], 2)
        self.assertEqual(total["tokens"]["input_tokens"]["sum"], 8)

    def test_schema_version_is_recorded_and_a_wrong_version_is_refused(self):
        self.open().close()
        conn = sqlite3.connect(self.path)
        self.assertEqual(conn.execute("PRAGMA user_version").fetchone()[0], SCHEMA_VERSION)
        conn.execute(f"PRAGMA user_version={SCHEMA_VERSION + 7}")
        conn.commit()
        conn.close()
        with self.assertRaises(LedgerStorageError):
            SqliteUsageRepository(self.path)


# -------------------------------------------------------------------- 2. duplicates
class Duplicates(TempLedger):
    def test_same_request_recorded_twice_counts_once_across_restart(self):
        repo = self.open()
        acct = UsageAccountingService(repository=repo)
        result = execution("d-1", Usage(input_tokens=2))
        self.assertTrue(acct.record(result))
        self.assertFalse(acct.record(result))
        repo.close()
        again = UsageAccountingService(repository=SqliteUsageRepository(self.path))
        self.addCleanup(again.close)
        self.assertFalse(again.record(result))  # the retry after a restart is still a duplicate
        self.assertEqual(again.total()["requests"], 1)


# ------------------------------------------------------------ 3. concurrent recording
class Concurrency(TempLedger):
    def test_threads_sharing_one_ledger_neither_lose_nor_duplicate(self):
        repo = self.open()
        acct = UsageAccountingService(repository=repo)
        barrier = threading.Barrier(8)
        results = []

        def run(w):
            barrier.wait(timeout=10)
            for i in range(25):
                results.append(acct.record(execution(f"t{w}-{i:03d}", Usage(input_tokens=1))))
            results.append(acct.record(execution("shared-0", Usage(input_tokens=1))))

        threads = [threading.Thread(target=run, args=(w,)) for w in range(8)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=60)
        self.assertEqual(results.count(True), 8 * 25 + 1)
        self.assertEqual(results.count(False), 7)
        self.assertEqual(acct.total()["requests"], 8 * 25 + 1)
        self.assertEqual(acct.total()["tokens"]["input_tokens"]["sum"], 8 * 25 + 1)

    def test_processes_sharing_one_file_neither_lose_nor_duplicate(self):
        child = (
            "import sys, json\n"
            f"sys.path.insert(0, {str(SRC)!r})\n"
            "from sanour_ai.ledger.sqlite_repository import SqliteUsageRepository\n"
            "from tests.unit.test_stage1048 import rec\n"
            "repo = SqliteUsageRepository(sys.argv[1])\n"
            "w = sys.argv[2]\n"
            "true = false = 0\n"
            "for i in range(40):\n"
            "    if repo.append(rec(f'p{w}-{i:03d}')): true += 1\n"
            "    else: false += 1\n"
            "for i in range(10):\n"
            "    if repo.append(rec(f'common-{i}')): true += 1\n"
            "    else: false += 1\n"
            "print(json.dumps({'true': true, 'false': false}))\n"
        )
        procs = [subprocess.Popen([sys.executable, "-c", child, self.path, str(w)],
                                  stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True) for w in range(4)]
        outputs = []
        for p in procs:
            out, err = p.communicate(timeout=120)
            self.assertEqual(p.returncode, 0, err)
            outputs.append(json.loads(out.strip().splitlines()[-1]))
        self.assertEqual(sum(o["true"] for o in outputs), 4 * 40 + 10)
        self.assertEqual(sum(o["false"] for o in outputs), 3 * 10)
        self.assertEqual(len(self.open().records()), 4 * 40 + 10)


# ----------------------------------------------------------------- 4. sudden stop, 6. crash
class CrashRecovery(TempLedger):
    def _crash(self, *, commit_first: bool):
        child = (
            "import sys, os\n"
            f"sys.path.insert(0, {str(SRC)!r})\n"
            "from sanour_ai.ledger.sqlite_repository import SqliteUsageRepository, _COLUMNS\n"
            "from tests.unit.test_stage1048 import rec\n"
            "repo = SqliteUsageRepository(sys.argv[1])\n"
            "if sys.argv[2] == 'commit':\n"
            "    repo.append(rec('kept-1'))\n"
            "repo._conn.execute('BEGIN IMMEDIATE')\n"
            "b = rec('lost-1')\n"
            "from sanour_ai.ledger.sqlite_repository import _to_row\n"
            "repo._conn.execute('INSERT INTO usage_records (' + ', '.join(_COLUMNS) + ') VALUES (' + ', '.join('?' for _ in _COLUMNS) + ')', _to_row(b))\n"
            "os._exit(9)\n"  # sudden stop: no COMMIT, no cleanup
        )
        proc = subprocess.run([sys.executable, "-c", child, self.path, "commit" if commit_first else "none"],
                              capture_output=True, text=True, timeout=120)
        self.assertEqual(proc.returncode, 9, proc.stderr)

    def test_sudden_stop_before_commit_leaves_no_partial_row(self):
        self._crash(commit_first=False)
        repo = self.open()
        self.assertEqual(repo.records(), [])
        conn = sqlite3.connect(self.path)
        self.assertEqual(conn.execute("PRAGMA integrity_check").fetchone()[0], "ok")
        conn.close()

    def test_committed_row_survives_sudden_stop_while_uncommitted_one_does_not(self):
        self._crash(commit_first=True)
        ids = [r.request_id for r in self.open().records()]
        self.assertEqual(ids, ["kept-1"])
        self.assertTrue(self.open().append(rec("after-crash")))  # the ledger keeps working after recovery
        self.assertEqual(len(self.open().records()), 2)


# -------------------------------------------------------------- 5. storage failure, 6. recovery
class FaultyConnection:
    def __init__(self, real, fail_on):
        self._real = real
        self._fail_on = fail_on

    def execute(self, sql, *args):
        if sql.startswith(self._fail_on):
            raise sqlite3.OperationalError("disk I/O error")
        return self._real.execute(sql, *args)


class StorageFailure(TempLedger):
    def test_storage_error_is_raised_not_reported_as_success(self):
        repo = self.open()
        real = repo._conn
        repo._conn = FaultyConnection(real, "INSERT")
        with self.assertRaises(LedgerStorageError):
            repo.append(rec("f-1"))
        repo._conn = real
        self.assertEqual(repo.records(), [])

    def test_accounting_counts_the_failure_and_keeps_totals_unchanged(self):
        repo = self.open()
        acct = UsageAccountingService(repository=repo)
        acct.record(execution("ok-1", Usage(input_tokens=1)))
        real = repo._conn
        repo._conn = FaultyConnection(real, "INSERT")
        with self.assertRaises(LedgerStorageError):
            acct.record(execution("bad-1", Usage(input_tokens=9)))
        repo._conn = real
        self.assertEqual(acct.total()["requests"], 1)
        self.assertEqual(acct.total()["tokens"]["input_tokens"]["sum"], 1)
        self.assertEqual(acct.health()["storage_failures"], 1)

    def test_runtime_never_claims_success_on_ledger_failure_and_recovers(self):
        provider = UsageProvider(Usage(input_tokens=2))
        rt = Runtime.build_for_tests(env(), provider=provider, usage_ledger_path=self.path)
        self.addCleanup(rt.close_usage_ledger)
        repo = rt._usage._repo  # noqa: SLF001
        real = repo._conn  # noqa: SLF001
        repo._conn = FaultyConnection(real, "INSERT")  # noqa: SLF001
        self.assertEqual(rt.handle(raw()).status, "success")  # the answer was already decided
        repo._conn = real  # noqa: SLF001
        self.assertEqual(rt.usage_summary()["total"]["requests"], 0)  # nothing claimed as recorded
        self.assertEqual(rt.usage_summary()["health"]["storage_failures"], 1)
        self.assertEqual(rt.handle(raw()).status, "success")
        self.assertEqual(rt.usage_summary()["total"]["requests"], 1)

    def test_unusable_path_fails_explicitly_without_leaking_it(self):
        with self.assertRaises(LedgerStorageError) as ctx:
            SqliteUsageRepository(self._dir.name)  # a directory is not a database file
        self.assertNotIn(self._dir.name, str(ctx.exception))

    def test_closed_ledger_refuses_writes(self):
        repo = self.open()
        repo.close()
        with self.assertRaises(LedgerStorageError):
            repo.append(rec("c-1"))


# -------------------------------------------------------- 7. partial usage, 8/9. status split
class NullableAndStatus(TempLedger):
    def test_partial_and_absent_usage_stay_null_in_storage_and_reports(self):
        repo = self.open()
        acct = UsageAccountingService(repository=repo)
        acct.record(execution("n-1", Usage(input_tokens=3)))
        acct.record(execution("n-2", None))
        total = acct.total()
        self.assertEqual(total["tokens"]["input_tokens"], {"sum": 3, "known_count": 1, "unknown_count": 1})
        self.assertIsNone(total["tokens"]["output_tokens"]["sum"])
        conn = sqlite3.connect(self.path)
        nulls = conn.execute("SELECT COUNT(*) FROM usage_records WHERE output_tokens IS NULL").fetchone()[0]
        conn.close()
        self.assertEqual(nulls, 2)

    def test_delivered_and_withheld_are_reported_separately(self):
        repo = self.open()
        acct = UsageAccountingService(repository=repo)
        acct.record(execution("v-1", Usage(input_tokens=1), delivery="delivered"))
        acct.record(execution("v-2", Usage(input_tokens=1), delivery="withheld"))
        self.assertEqual(acct.total()["delivery"], {"delivered": 1, "withheld": 1})
        self.assertEqual(acct.aggregate("delivery")["withheld"]["requests"], 1)

    def test_audit_status_is_reported_separately_from_delivery(self):
        repo = self.open()
        acct = UsageAccountingService(repository=repo)
        acct.record(execution("w-1", Usage(input_tokens=1), delivery="withheld", audit="failed"))
        acct.record(execution("w-2", Usage(input_tokens=1), delivery="withheld", audit="recorded"))
        acct.record(execution("w-3", Usage(input_tokens=1), delivery="delivered", audit="unavailable"))
        self.assertEqual(acct.total()["usage_audit"], {"recorded": 1, "failed": 1, "unavailable": 1})
        self.assertEqual(acct.total()["delivery"], {"delivered": 1, "withheld": 2})

    def test_storage_refuses_inconsistent_rows_even_if_written_directly(self):
        self.open()
        conn = sqlite3.connect(self.path)
        with self.assertRaises(sqlite3.IntegrityError):
            conn.execute("INSERT INTO usage_records (request_id, utc_day, recorded_at, provider_id, profile_id, "
                         "model_id, api_surface, delivery, audit_status, usage_status, input_tokens) "
                         "VALUES ('bad', '2026-11-07', 'x', 'openai', 'p', 'm', NULL, 'maybe', 'recorded', 'reported', 1)")
        conn.close()

    def test_record_rules_refuse_negative_bool_and_inconsistent_totals(self):
        with self.assertRaises(ValueError):
            rec("v", counts={"input_tokens": -1, "output_tokens": None, "total_tokens": None,
                             "cached_input_tokens": None, "reasoning_tokens": None})
        with self.assertRaises(ValueError):
            rec("v", counts={"input_tokens": True, "output_tokens": None, "total_tokens": None,
                             "cached_input_tokens": None, "reasoning_tokens": None})
        with self.assertRaises(ValueError):
            rec("v", counts={"input_tokens": 2, "output_tokens": 2, "total_tokens": 9,
                             "cached_input_tokens": None, "reasoning_tokens": None})


# ------------------------------------------------------ 10/11. no ledger row for non-accepted
class OnlyAcceptedCompletions(TempLedger):
    def test_failed_and_refused_requests_write_no_row(self):
        class Failing(OfflineTestProvider):
            def generate(self, call):
                raise ProviderError("boom", kind=FailureKind.REQUEST_REJECTED, retryable=False)

        rt = Runtime.build_for_tests(env(), provider=Failing(), usage_ledger_path=self.path)
        self.addCleanup(rt.close_usage_ledger)
        rt.handle(raw())
        rt.handle({"profile_alias": "nope", "prompt": PROMPT})
        self.assertEqual(self.open().records(), [])

    def test_late_response_writes_no_row(self):
        class Late(OfflineTestProvider):
            def __init__(self):
                self.entered, self.release = threading.Event(), threading.Event()

            def generate(self, call):
                self.entered.set()
                self.release.wait(timeout=30)
                return ModelResult(text=OUTPUT, reported_model_id=call.model_id, usage=Usage(input_tokens=9))

        provider = Late()
        rt = Runtime.build_for_tests(env(), provider=provider, usage_ledger_path=self.path)
        outcome = {}
        caller = threading.Thread(target=lambda: outcome.update(pair=rt._core.handle_with_result(raw(timeout_seconds=0.2))))  # noqa: SLF001
        caller.start()
        self.assertTrue(provider.entered.wait(timeout=10))
        caller.join(timeout=10)
        self.assertEqual(outcome["pair"][0].error.code, ErrorCode.PROVIDER_TIMEOUT)
        provider.release.set()
        gateway = rt._core.shutdown_target()  # noqa: SLF001
        with gateway._lock:  # noqa: SLF001
            self.assertTrue(gateway._idle_cv.wait_for(lambda: gateway._in_flight == 0, timeout=10))  # noqa: SLF001
        self.assertEqual(self.open().records(), [])
        rt.shutdown(timeout=5)
        rt.close_usage_ledger()


# -------------------------------------------------------------------- 12. no secrets stored
class NoSecretsStored(TempLedger):
    def test_database_files_contain_no_key_prompt_or_response(self):
        rt = Runtime.build_for_tests(env(), provider=UsageProvider(Usage(input_tokens=2)),
                                     usage_ledger_path=self.path)
        rt.handle(raw())
        rt.close_usage_ledger()
        blobs = b""
        for suffix in ("", "-wal", "-shm"):
            candidate = self.path + suffix
            if os.path.exists(candidate):
                blobs += Path(candidate).read_bytes()
        self.assertTrue(blobs)  # the ledger was actually written
        for secret in (SECRET.encode(), PROMPT.encode(), OUTPUT.encode(), b"Authorization", b"Bearer "):
            self.assertNotIn(secret, blobs)

    def test_schema_has_only_the_approved_columns(self):
        self.open()
        conn = sqlite3.connect(self.path)
        columns = [row[1] for row in conn.execute("PRAGMA table_info(usage_records)")]
        conn.close()
        self.assertEqual(set(columns), set(_COLUMNS))
        self.assertFalse({"prompt", "output", "text", "api_key", "authorization"} & set(columns))


# ------------------------------------------------------- 13. reports match restored records
class ReportsMatchRestoredData(TempLedger):
    def test_every_dimension_is_identical_before_and_after_restart(self):
        acct = UsageAccountingService(repository=self.open(), clock=lambda: 1_789_430_399.0)
        acct.record(execution("q-1", Usage(input_tokens=1, output_tokens=2, total_tokens=3)))
        acct.record(execution("q-2", None, delivery="withheld", audit="failed"))
        acct.record(execution("q-3", Usage(input_tokens=4, cached_input_tokens=1)), recorded_at=1_789_430_400.0)
        before = build_report(acct.records())
        restored = build_report(self.open().records())
        self.assertEqual(restored, before)
        self.assertEqual(set(before["period"]), {"2026-09-14", "2026-09-15"})  # UTC day boundary
        self.assertIsNone(before["total"]["tokens"]["reasoning_tokens"]["sum"])


# ---------------------------------------------------------------- engine-level faults
class EngineLevel(TempLedger):
    def test_pragmas_and_schema_are_durable_settings(self):
        self.open()
        conn = sqlite3.connect(self.path)
        self.assertEqual(conn.execute("PRAGMA journal_mode").fetchone()[0].lower(), "wal")
        conn.close()

    def test_sudden_stop_during_recording_path_has_no_network_dependency(self):
        with mock.patch("socket.socket.connect", side_effect=AssertionError("network")):
            repo = self.open()
            self.assertTrue(repo.append(rec("net-1")))


if __name__ == "__main__":
    unittest.main()
