"""Stage 10.42: settlement observability.

Counters and phases are read-only and count-only. A permanently blocked close stays visibly unsettled,
the runtime stays DRAINING, and wait_stopped times out. One settler per busy provider, never more.
Offline only: fake providers, no SDK, no network, no key. Every wait is bounded or event-driven.
"""

import threading
import time
import unittest
from unittest import mock

from sanour_ai.providers.offline_contract import OfflineTestProvider
from sanour_ai.composition import production
from sanour_ai.composition.runtime import Runtime, RuntimeState
from sanour_ai.errors import ErrorCode, SanourError
from sanour_ai.models.base import ModelResult, ProviderError
from sanour_ai.models.gateway import ModelGateway
from tests.support import TEST_ALL_CAPS, deadline_in, wait_until
from tests.support import request_identity_for as _rid
from tests.unit import test_gateway as gw_tests
from tests.unit import test_stage1039 as base
from tests.unit.test_stage1041 import Probe, make, start_call, settler_threads

SECRET = "STAGE1042-SECRET-VALUE-PL"


def ok_call(gw, deadline_s=3.0):
    return gw.generate(gw_tests.PROFILE, gw_tests.CALL, deadline_in(deadline_s), identity=_rid(gw_tests.PROFILE))


class FailingClose(Probe):
    def close(self):
        super().close()
        raise OSError(SECRET)


class RaisingCall(Probe):
    def generate(self, call):
        raise ProviderError("provider call failed", retryable=False)


class Counters(unittest.TestCase):
    def test_successful_call(self):
        probe = Probe()
        probe.gate.set()
        gw = make(probe)
        ok_call(gw)
        s = gw.stats()
        self.assertEqual((s.successful_calls, s.in_flight, s.active_workers, s.timeouts), (1, 0, 0, 0))
        self.assertEqual(s.settler_threads_started, 0)

    def test_provider_exception(self):
        gw = make(RaisingCall())
        with self.assertRaises(SanourError):
            ok_call(gw)
        self.assertTrue(wait_until(lambda: gw.stats().in_flight == 0, timeout=2.0))
        s = gw.stats()
        self.assertEqual((s.provider_failures, s.successful_calls, s.in_flight), (1, 0, 0))

    def test_caller_timeout_while_worker_continues(self):
        probe = Probe()
        gw = make(probe)
        with self.assertRaises(SanourError) as ctx:
            ok_call(gw, deadline_s=0.05)
        self.assertIs(ctx.exception.code, ErrorCode.PROVIDER_TIMEOUT)
        s = gw.stats()
        self.assertEqual((s.timeouts, s.abandoned_in_flight, s.in_flight, s.active_workers), (1, 1, 1, 1))
        probe.gate.set()
        self.assertTrue(wait_until(lambda: gw.stats().in_flight == 0, timeout=2.0))
        s = gw.stats()
        self.assertEqual((s.abandoned_in_flight, s.active_workers), (0, 0))
        self.assertEqual(s.successful_calls, 0)  # the late result is discarded, not counted as success

    def test_cancellation_before_worker_start(self):
        gw = make(Probe())
        with mock.patch("threading.Thread.start", side_effect=RuntimeError("no thread")):
            with self.assertRaises(SanourError):
                ok_call(gw)
        s = gw.stats()
        self.assertEqual((s.cancelled_before_start, s.in_flight, s.active_workers), (1, 0, 0))
        self.assertEqual(gw._slots._value, 1)  # the caller's capacity came back

    def test_close_success_settles_cleanly(self):
        probe = Probe()
        gw = make(probe)
        t, _ = start_call(gw)
        gw.shutdown(0.01)
        probe.gate.set()
        t.join(3.0)
        self.assertTrue(probe.settled.wait(2.0))
        s = gw.stats()
        self.assertEqual((s.provider_close_failures, s.providers_closing, s.active_settlers), (0, 0, 0))
        self.assertEqual(gw.settlement_snapshot()["phases"], {"mock": "closed"})

    def test_close_failure_is_counted_and_settles_as_failed(self):
        probe = FailingClose()
        gw = make(probe)
        t, _ = start_call(gw)
        gw.shutdown(0.01)
        probe.gate.set()
        t.join(3.0)
        self.assertTrue(probe.settled.wait(2.0))
        s = gw.stats()
        self.assertEqual((s.provider_close_failures, s.active_settlers, s.providers_closing), (1, 0, 0))
        self.assertEqual(gw.settlement_snapshot()["phases"], {"mock": "failed"})


class PhasesAndSettlers(unittest.TestCase):
    def test_busy_provider_is_waiting_for_its_worker(self):
        probe = Probe()
        gw = make(probe)
        t, _ = start_call(gw)
        gw.shutdown(0.01)
        snap = gw.settlement_snapshot()
        self.assertEqual(snap["phases"], {"mock": "waiting"})
        s = gw.stats()
        self.assertEqual((s.providers_waiting_for_workers, s.active_settlers, s.providers_closing), (1, 1, 0))
        probe.gate.set()
        t.join(3.0)
        self.assertTrue(probe.settled.wait(2.0))
        self.assertEqual(gw.settlement_snapshot()["active_settlers"], 0)

    def test_concurrent_shutdowns_create_exactly_one_settler(self):  # req 3
        probe = Probe()
        gw = make(probe)
        t, _ = start_call(gw)
        threads = [threading.Thread(target=lambda: gw.shutdown(0.01)) for _ in range(12)]
        for th in threads:
            th.start()
        for th in threads:
            th.join(3.0)
        self.assertEqual(gw.stats().settler_threads_started, 1)
        self.assertEqual(gw.stats().active_settlers, 1)
        self.assertLessEqual(len(settler_threads()), 1)
        probe.gate.set()
        t.join(3.0)
        self.assertTrue(probe.settled.wait(2.0))
        self.assertEqual(probe.close_calls, 1)


class PermanentlyBlockedClose(base.Base if hasattr(base, "Base") else unittest.TestCase):
    """Runtime level: a close that never returns keeps the runtime DRAINING, and it stays visible."""

    def setUp(self):
        super().setUp()

    def test_blocked_close_stays_unsettled_and_runtime_drains(self):  # req 2 and 4
        never = threading.Event()

        class BlockingClose(base.LifeOpenAI):
            def close(self):
                never.wait(10.0)  # bounded so a broken test cannot hang the run
                self.close_count += 1

        with mock.patch.object(production, "OpenAIProvider", BlockingClose), mock.patch.object(production, "_default_test_provider", lambda: BlockingClose("test")):
            rt = Runtime.build_for_tests(base.env())
            base.LifeOpenAI.gate = threading.Event()
            result = {}
            t = threading.Thread(target=lambda: result.setdefault(
                "r", rt.handle({"profile_alias": "openai_primary", "prompt": "hi"})))
            t.start()
            self.assertTrue(wait_until(lambda: ("start", None) in base.LifeOpenAI.events, timeout=2.0))
            rt.shutdown(0.01)
            base.LifeOpenAI.gate.set()
            t.join(3.0)
            self.assertTrue(wait_until(lambda: rt.stats()["settlement"]["providers_closing"] == 1, timeout=2.0))
            self.assertIs(rt.state, RuntimeState.DRAINING)
            self.assertFalse(rt.wait_stopped(0.05))  # timeout expires: never report SHUTDOWN early
            for _ in range(5):
                rt.shutdown(0.01)
            stats = rt.stats()
            self.assertEqual(stats["providers"], {"openai": "closing"})
            self.assertEqual(stats["settlement"]["active_settlers"], 1)
            self.assertEqual(stats["settlement"]["providers_closing"], 1)
            self.assertEqual(stats["settlement"]["providers_waiting_for_workers"], 0)
            self.assertEqual(stats["settlement"]["phases"], {"openai": "closing"})
            self.assertIs(rt.state, RuntimeState.DRAINING)
            self.assertIs(rt.state, RuntimeState.DRAINING)
            self.assertLessEqual(sum(1 for th in threading.enumerate()
                                     if th.name.startswith("sanour-settle-")), 1)
            never.set()  # unblock so the settler can finish
            self.assertTrue(rt.wait_stopped(2.0))
            self.assertIs(rt.state, RuntimeState.SHUTDOWN)
            self.assertEqual(rt.stats()["settlement"]["active_settlers"], 0)


class SecretFreeStats(unittest.TestCase):
    def test_close_failure_text_never_appears_in_stats_or_logs(self):  # req 5
        probe = FailingClose()
        gw = make(probe)
        t, _ = start_call(gw)
        gw.shutdown(0.01)
        with self.assertLogs(level="WARNING") as captured:
            probe.gate.set()
            t.join(3.0)
            self.assertTrue(probe.settled.wait(2.0))
        text = "\n".join(captured.output) + repr(gw.stats()) + repr(gw.settlement_snapshot())
        self.assertNotIn(SECRET, text)
        self.assertIn("OSError", "\n".join(captured.output))


if __name__ == "__main__":
    unittest.main()
