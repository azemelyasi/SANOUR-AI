"""Stage 10.34 tests: shared provider contract, lifecycle, authentication, readiness.

Fake transports and fake adapters only. No SDK, no network, no real key. Waits are bounded.
"""

from tests.support import request_identity_for as _rid
import pathlib
import re
import threading
import time
import unittest
from unittest import mock

from pydantic import SecretStr

from sanour_ai.providers.offline_contract import OfflineTestProvider
from sanour_ai.composition import production
from sanour_ai.config import governance
from sanour_ai.config.settings import ConfigError
from sanour_ai.models import provider_matrix as pm
from sanour_ai.models.base import ModelCall, ModelResult, ProviderError
from sanour_ai.models.capabilities import ProviderCapabilities
from sanour_ai.errors import SanourError
from sanour_ai.models.gateway import ModelGateway
from sanour_ai.providers import anthropic_provider as anth
from sanour_ai.providers import contract
from sanour_ai.providers import gemini_provider as gem
from sanour_ai.providers import grok_provider as grok
from sanour_ai.providers import openai_provider as op
from sanour_ai.providers import readiness
from sanour_ai.providers import xai_responses_provider as xr
from sanour_ai.providers.common import (
    ContentBlockedError,
    HttpResult,
    IncompleteResponseError,
)
from sanour_ai.providers.registry import TRANSITIONS, ProviderRegistry, ProviderState, RegistryError

SRC = pathlib.Path(__file__).resolve().parents[2] / "src" / "sanour_ai"
SECRET = "STAGE1034-SECRET-KEY-WV"  # fake, test-only
TEXT = ProviderCapabilities(text_generation=True)
HTTP_ADAPTERS = {"anthropic": anth, "gemini": gem, "grok": grok, "grok_responses": xr}
ALL_CLASSES = {
    "openai": op.OpenAIProvider,
    "anthropic": anth.AnthropicProvider,
    "gemini": gem.GeminiProvider,
    "grok": grok.GrokProvider,
    "grok_responses": xr.XaiResponsesProvider,
}


def call(budget=5.0, model="model-1034"):
    return ModelCall(model_id=model, prompt="hi", max_output_tokens=16, deadline=time.monotonic() + budget)


class RecordingTransport:
    """Records every request. Returns one canned HttpResult, or raises a canned exception."""

    def __init__(self, status=200, body=b"", headers=None, raise_exc=None):
        self.status, self.body, self.headers = status, body, headers or {}
        self.raise_exc = raise_exc
        self.requests = []

    def __call__(self, url, headers, body, timeout):
        self.requests.append((url, dict(headers), body, timeout))
        if self.raise_exc is not None:
            raise self.raise_exc
        return HttpResult(self.status, self.body, self.headers)


class _Conforming:
    """Minimal adapter used by registry tests. Declares full identity unless told otherwise."""

    name = "alpha"
    vendor = "openai"
    surface = "openai_responses"
    auth_method = "sdk_bearer_client"
    capabilities = TEXT

    def __init__(self, name="alpha", *, close_error=None, init_error=None, block=None, log=None):
        self.name = name
        self.close_error, self.init_error, self.block = close_error, init_error, block
        self.log = log if log is not None else []
        self.inits = 0
        self.entered = threading.Event()

    def initialize(self):
        self.inits += 1
        if self.init_error is not None:
            raise self.init_error

    def generate(self, call_):
        self.entered.set()
        if self.block is not None:
            self.block.wait(5.0)
        return ModelResult(text="ok", reported_model_id=call_.model_id)

    def close(self):
        self.log.append(self.name)
        if self.close_error is not None:
            raise self.close_error


# ---------------------------------------------------------------- 1. shared contract
class SharedContractTests(unittest.TestCase):
    def test_every_adapter_follows_the_contract(self):
        for pid, cls in ALL_CLASSES.items():
            with self.subTest(provider=pid):
                self.assertEqual(contract.contract_violations(cls), [])

    def test_every_adapter_declares_an_identity_its_surface_allows(self):
        from sanour_ai.providers.registry import VENDOR_SURFACES
        for pid, cls in ALL_CLASSES.items():
            with self.subTest(provider=pid):
                ident = contract.identity_of(cls)
                self.assertEqual(ident.provider_id, pid)
                self.assertIn(ident.surface, VENDOR_SURFACES[ident.vendor])
                self.assertIn(ident.auth_method, contract.AUTH_METHODS)

    def test_every_declared_capability_is_verified_on_its_surface(self):
        for pid, cls in ALL_CLASSES.items():
            with self.subTest(provider=pid):
                ident = contract.identity_of(cls)
                flags = cls.capabilities.model_dump()
                self.assertEqual(pm.provider_flags_are_verified(ident.surface, flags), [])

    def test_contract_checker_names_each_broken_rule(self):
        class Broken:
            name = "x"
            capabilities = TEXT
            auth_method = "plaintext_in_url"  # not in the fixed set
            vendor = "openai"
            surface = "openai_responses"
            close = "not callable"

            def generate(self, c):
                return None

        problems = contract.contract_violations(Broken())
        self.assertIn("auth_method is not in the fixed set", problems)
        self.assertIn("close must be callable when present", problems)

    def test_missing_identity_is_reported(self):
        class Bare:
            name = "x"
            capabilities = TEXT

            def generate(self, c):
                return None

        self.assertIn("missing vendor", contract.contract_violations(Bare()))

    def test_the_fixed_auth_method_set_is_exactly_the_documented_one(self):
        self.assertEqual(contract.AUTH_METHODS, frozenset({
            "sdk_bearer_client", "bearer_header", "x_api_key_header", "x_goog_api_key_header"}))


# ---------------------------------------------------------------- 2. registration
class RegistrationTests(unittest.TestCase):
    def test_a_matching_declared_identity_is_accepted(self):
        reg = ProviderRegistry()
        reg.register("alpha", vendor="openai", surface="openai_responses", adapter=_Conforming())
        self.assertEqual(reg.states(), {"alpha": "registered"})

    def test_a_declared_vendor_that_disagrees_is_refused(self):
        with self.assertRaises(RegistryError):
            ProviderRegistry().register("alpha", vendor="anthropic", surface="anthropic_messages",
                                        adapter=_Conforming())

    def test_a_declared_surface_that_disagrees_is_refused(self):
        adapter = _Conforming()
        adapter.surface = "openai_responses"
        with self.assertRaises(RegistryError):
            ProviderRegistry().register("alpha", vendor="openai", surface="grok_responses", adapter=adapter)

    def test_an_unknown_declared_auth_method_is_refused(self):
        adapter = _Conforming()
        adapter.auth_method = "token_in_query_string"
        with self.assertRaises(RegistryError):
            ProviderRegistry().register("alpha", vendor="openai", surface="openai_responses", adapter=adapter)

    def test_unverified_capability_is_refused_at_registration(self):
        adapter = _Conforming()
        adapter.capabilities = ProviderCapabilities(text_generation=True, tool_calling=True)
        adapter.surface = "gemini_generate_content"
        with self.assertRaises(RegistryError):
            ProviderRegistry().register("alpha", vendor="google", surface="gemini_generate_content",
                                        adapter=adapter)

    def test_registration_never_selects_a_model(self):
        reg = ProviderRegistry()
        reg.register("alpha", vendor="openai", surface="openai_responses", adapter=_Conforming())
        reg.initialize("alpha")
        self.assertEqual(set(reg.ready_providers()), {"alpha"})  # ready is not a model choice


# ---------------------------------------------------------------- 3. lifecycle transitions
class LifecycleTransitionTests(unittest.TestCase):
    def test_transition_table_covers_every_state_and_closed_is_terminal(self):
        self.assertEqual(set(TRANSITIONS), set(ProviderState))
        self.assertEqual(TRANSITIONS[ProviderState.CLOSED], frozenset())

    def test_every_pair_is_allowed_only_if_the_table_says_so(self):
        for src in ProviderState:
            for dst in ProviderState:
                with self.subTest(src=src.value, dst=dst.value):
                    reg = ProviderRegistry()
                    entry = mock.Mock()
                    entry.state = src
                    if dst in TRANSITIONS[src]:
                        reg._move(entry, dst)
                        self.assertIs(entry.state, dst)
                    else:
                        with self.assertRaises(RegistryError):
                            reg._move(entry, dst)
                        self.assertIs(entry.state, src)  # a refused move changes nothing

    def test_ready_to_closed_directly_is_refused(self):
        reg = ProviderRegistry()
        reg.register("alpha", vendor="openai", surface="openai_responses", adapter=_Conforming())
        reg.initialize("alpha")
        entry = reg._entries["alpha"]  # noqa: SLF001 - transition-level test
        with self.assertRaises(RegistryError):
            reg._move(entry, ProviderState.CLOSED)  # noqa: SLF001
        self.assertEqual(reg.state("alpha"), ProviderState.READY)

    def test_closed_provider_is_never_ready_again(self):
        reg = ProviderRegistry()
        reg.register("alpha", vendor="openai", surface="openai_responses", adapter=_Conforming())
        reg.initialize("alpha")
        gw = ModelGateway(reg.ready_providers(), max_concurrent_calls=1)
        reg.shutdown(gw, 0.1)
        with self.assertRaises(RegistryError):
            reg.initialize("alpha")
        self.assertEqual(reg.state("alpha"), ProviderState.CLOSED)


# ---------------------------------------------------------------- 4. isolation and shutdown
class IsolationAndShutdownTests(unittest.TestCase):
    def test_failed_initialization_does_not_disturb_other_providers(self):
        reg = ProviderRegistry()
        reg.register("alpha", vendor="openai", surface="openai_responses",
                     adapter=_Conforming("alpha", init_error=RuntimeError("boom")))
        reg.register("beta", vendor="openai", surface="openai_responses", adapter=_Conforming("beta"))
        with self.assertRaises(RegistryError):
            reg.initialize("alpha")
        reg.initialize("beta")
        self.assertEqual(reg.states(), {"alpha": "failed", "beta": "ready"})
        self.assertEqual(set(reg.ready_providers()), {"beta"})  # the failed one never becomes ready

    def test_failed_provider_is_closed_on_shutdown_and_others_follow_their_own_path(self):
        log = []
        reg = ProviderRegistry()
        reg.register("alpha", vendor="openai", surface="openai_responses",
                     adapter=_Conforming("alpha", init_error=RuntimeError("x"), log=log))
        reg.register("beta", vendor="openai", surface="openai_responses", adapter=_Conforming("beta", log=log))
        with self.assertRaises(RegistryError):
            reg.initialize("alpha")
        reg.initialize("beta")
        states = reg.shutdown(ModelGateway(reg.ready_providers(), max_concurrent_calls=2), 0.1)
        self.assertEqual(states, {"alpha": "closed", "beta": "closed"})
        self.assertEqual(sorted(log), ["alpha", "beta"])

    def test_busy_worker_keeps_its_provider_closing_and_its_slot_held(self):
        log = []
        block = threading.Event()
        adapter = _Conforming("alpha", block=block, log=log)
        reg = ProviderRegistry()
        reg.register("alpha", vendor="openai", surface="openai_responses", adapter=adapter)
        reg.initialize("alpha")
        gw = ModelGateway(reg.ready_providers(), max_concurrent_calls=1)
        profile = _profile("alpha")
        with self.assertRaises(SanourError):
            gw.generate(profile, call(0.05), time.monotonic() + 0.05, identity=_rid(profile))  # times out, worker keeps running
        self.assertTrue(adapter.entered.wait(2.0))
        self.assertEqual(reg.shutdown(gw, 0.05), {"alpha": "closing"})
        self.assertEqual(log, [])  # not closed under a live worker
        self.assertEqual(gw.in_flight, 1)  # capacity still held until the worker really ends
        block.set()
        deadline = time.monotonic() + 3.0
        while time.monotonic() < deadline and gw.in_flight:
            time.sleep(0.01)
        self.assertEqual(reg.shutdown(gw, 0.1), {"alpha": "closed"})
        self.assertEqual(log, ["alpha"])

    def test_repeated_shutdown_is_idempotent(self):
        log = []
        reg = ProviderRegistry()
        reg.register("alpha", vendor="openai", surface="openai_responses", adapter=_Conforming("alpha", log=log))
        reg.initialize("alpha")
        gw = ModelGateway(reg.ready_providers(), max_concurrent_calls=1)
        first = reg.shutdown(gw, 0.1)
        second = reg.shutdown(gw, 0.1)
        self.assertEqual(first, second)
        self.assertEqual(log, ["alpha"])

    def test_one_failing_close_does_not_stop_others_and_is_logged_without_detail(self):
        log = []
        reg = ProviderRegistry()
        secret_error = RuntimeError("token " + SECRET)
        reg.register("alpha", vendor="openai", surface="openai_responses",
                     adapter=_Conforming("alpha", close_error=secret_error, log=log))
        reg.register("beta", vendor="openai", surface="openai_responses", adapter=_Conforming("beta", log=log))
        reg.initialize("alpha")
        reg.initialize("beta")
        gw = ModelGateway(reg.ready_providers(), max_concurrent_calls=2)
        with self.assertLogs("sanour_ai.gateway", level="WARNING") as logs:
            states = reg.shutdown(gw, 0.1)
        self.assertEqual(states, {"alpha": "failed", "beta": "closed"})
        self.assertEqual(sorted(log), ["alpha", "beta"])
        self.assertNotIn(SECRET, "\n".join(logs.output))
        self.assertIn("RuntimeError", "\n".join(logs.output))  # only the type name is logged


def _profile(provider):
    from sanour_ai.models.capabilities import ModelCapabilities, ModelProfile
    return ModelProfile(alias="a_" + provider, provider=provider, model_id="model-1034",
                        capabilities=ModelCapabilities(text_generation=True, max_context_tokens=64,
                                                       max_output_tokens=16))


# ---------------------------------------------------------------- 5. authentication and secrets
class AuthenticationTests(unittest.TestCase):
    def test_every_provider_secret_has_one_declared_variable(self):
        self.assertEqual(governance.PROVIDER_SECRET_ENV, {
            "openai": "OPENAI_API_KEY",
            "anthropic": "ANTHROPIC_API_KEY",
            "gemini": "GEMINI_API_KEY",
            "grok": "XAI_API_KEY",
            "grok_responses": "XAI_API_KEY",
        })

    def test_adapter_loaders_delegate_to_governance(self):
        # The adapter modules import the governance function by name, so patch those names.
        with mock.patch.object(anth, "load_provider_secret", return_value=SecretStr(SECRET)) as a, \
                mock.patch.object(gem, "load_provider_secret", return_value=SecretStr(SECRET)) as g, \
                mock.patch.object(grok, "load_provider_secret", return_value=SecretStr(SECRET)) as x:
            anth.load_anthropic_api_key({})
            gem.load_gemini_api_key({})
            grok.load_xai_api_key({})
        self.assertEqual(a.call_args.args[0], "anthropic")
        self.assertEqual(g.call_args.args[0], "gemini")
        self.assertEqual(x.call_args.args[0], "grok")

    def test_missing_secret_names_the_variable_never_the_value(self):
        with self.assertRaises(ConfigError) as ctx:
            governance.load_provider_secret("gemini", {"GEMINI_API_KEY": "   "})
        self.assertIn("GEMINI_API_KEY", str(ctx.exception))
        self.assertNotIn("   ", str(ctx.exception).replace("must", ""))

    def test_unknown_provider_has_no_secret_source(self):
        with self.assertRaises(ConfigError):
            governance.load_provider_secret("not_a_provider", {"X": SECRET})

    def test_no_provider_package_reads_the_environment(self):
        for path in (SRC / "providers").rglob("*.py"):
            text = path.read_text(encoding="utf-8")
            with self.subTest(file=path.name):
                self.assertIsNone(re.search(r"os\.environ|os\.getenv", text))

    def test_only_governance_and_settings_read_the_environment_anywhere(self):
        readers = set()
        for path in SRC.rglob("*.py"):
            if re.search(r"os\.environ|os\.getenv", path.read_text(encoding="utf-8")):
                readers.add(path.relative_to(SRC).as_posix())
        self.assertEqual(readers, {"config/governance.py", "config/settings.py"})

    def test_key_is_not_part_of_adapter_repr(self):
        for pid, cls in ALL_CLASSES.items():
            if pid == "openai":
                continue  # the SDK client path is covered by the 10.33-R1 tests
            with self.subTest(provider=pid):
                adapter = cls(SecretStr(SECRET), transport=RecordingTransport())
                self.assertNotIn(SECRET, repr(adapter))
                self.assertNotIn(SECRET, repr(vars(adapter)))

    def test_secret_is_sent_only_in_the_auth_header_and_never_in_the_url(self):
        expect = {
            "anthropic": ("x-api-key", SECRET),
            "gemini": ("x-goog-api-key", SECRET),
            "grok": ("authorization", "Bearer " + SECRET),
            "grok_responses": ("authorization", "Bearer " + SECRET),
        }
        for pid, (header, value) in expect.items():
            with self.subTest(provider=pid):
                t = RecordingTransport(status=500, body=b"{}")
                module = HTTP_ADAPTERS[pid]
                adapter = ALL_CLASSES[pid](SecretStr(SECRET), transport=t)
                with self.assertRaises(ProviderError):
                    adapter.generate(call())
                url, headers, body, _ = t.requests[0]
                self.assertEqual(headers[header], value)
                self.assertNotIn(SECRET, url)
                self.assertNotIn(SECRET, body.decode("utf-8"))
                self.assertIsNotNone(module)

    def test_provider_error_text_never_carries_the_secret(self):
        leaky = [
            RecordingTransport(status=401, body=("bad key " + SECRET).encode()),
            RecordingTransport(status=500, body=SECRET.encode()),
            RecordingTransport(raise_exc=OSError("net " + SECRET)),
        ]
        for pid, cls in ALL_CLASSES.items():
            if pid == "openai":
                continue  # the SDK path maps its own errors; covered by the 10.33-R1 tests
            for t in leaky:
                with self.subTest(provider=pid, status=t.status if t.raise_exc is None else "os"):
                    adapter = cls(SecretStr(SECRET), transport=t)
                    with self.assertRaises(ProviderError) as ctx:
                        adapter.generate(call())
                    exc = ctx.exception
                    self.assertNotIn(SECRET, str(exc))
                    self.assertNotIn(SECRET, repr(vars(exc)))

    def test_running_adapter_never_picks_up_a_changed_environment(self):
        import os
        t = RecordingTransport(status=500, body=b"{}")
        adapter = anth.AnthropicProvider(SecretStr("OLD-" + SECRET), transport=t)
        with mock.patch.dict(os.environ, {"ANTHROPIC_API_KEY": "NEW-" + SECRET}):
            with self.assertRaises(ProviderError):
                adapter.generate(call())
        self.assertEqual(t.requests[0][1]["x-api-key"], "OLD-" + SECRET)


# ---------------------------------------------------------------- 6. deadline, retry, classification
class DeadlineRetryAndClassificationTests(unittest.TestCase):
    def test_expired_deadline_sends_nothing_for_every_http_adapter(self):
        for pid, cls in ALL_CLASSES.items():
            if pid == "openai":
                continue
            with self.subTest(provider=pid):
                t = RecordingTransport()
                expired = ModelCall(model_id="model-1034", prompt="p", max_output_tokens=8,
                                    deadline=time.monotonic() - 1)
                with self.assertRaises(ProviderError) as ctx:
                    cls(SecretStr(SECRET), transport=t).generate(expired)
                self.assertTrue(ctx.exception.retryable)
                self.assertEqual(t.requests, [])

    def test_one_deadline_is_passed_to_the_transport_for_every_http_adapter(self):
        for pid, cls in ALL_CLASSES.items():
            if pid == "openai":
                continue
            with self.subTest(provider=pid):
                t = RecordingTransport(status=500, body=b"{}")
                c = call(30.0)
                with self.assertRaises(ProviderError):
                    cls(SecretStr(SECRET), transport=t).generate(c)
                timeout = t.requests[0][3]
                self.assertEqual(timeout.deadline, c.deadline)  # the one shared deadline travels with it
                self.assertLessEqual(float(timeout), 30.0)

    def test_no_adapter_retries_after_a_server_error(self):
        # 5xx is documented as retryable for Anthropic, Gemini and Grok Chat; for xAI Responses 5xx
        # is NOT VERIFIED and fails closed (not retryable). Either way the adapter sends one request.
        documented_retryable = {"anthropic": True, "gemini": True, "grok": True, "grok_responses": False}
        for pid, cls in ALL_CLASSES.items():
            if pid == "openai":
                continue
            with self.subTest(provider=pid):
                t = RecordingTransport(status=503, body=b"{}")
                with self.assertRaises(ProviderError) as ctx:
                    cls(SecretStr(SECRET), transport=t).generate(call())
                self.assertEqual(len(t.requests), 1)
                self.assertEqual(ctx.exception.retryable, documented_retryable[pid])

    def test_transport_failure_is_one_retryable_connection_error(self):
        t = RecordingTransport(raise_exc=OSError("reset"))
        with self.assertRaises(ProviderError) as ctx:
            anth.AnthropicProvider(SecretStr(SECRET), transport=t).generate(call())
        self.assertEqual(str(ctx.exception), "provider connection failed")
        self.assertTrue(ctx.exception.retryable)

    def test_status_classification_is_fixed_per_status(self):
        cases = [
            (401, "provider rejected credentials", False),
            (403, "provider denied permission", False),
            (404, "provider model or endpoint not found", False),
        ]
        for pid, cls in ALL_CLASSES.items():
            if pid == "openai":
                continue
            for status, message, retryable in cases:
                with self.subTest(provider=pid, status=status):
                    t = RecordingTransport(status=status, body=b"{}")
                    with self.assertRaises(ProviderError) as ctx:
                        cls(SecretStr(SECRET), transport=t).generate(call())
                    self.assertEqual(str(ctx.exception), message)
                    self.assertEqual(ctx.exception.retryable, retryable)

    def test_unlisted_429_is_unknown_and_not_retryable_for_grok(self):
        t = RecordingTransport(status=429, body=b'{"error":{"code":"slow_down"}}')
        with self.assertRaises(ProviderError) as ctx:
            grok.GrokProvider(SecretStr(SECRET), transport=t).generate(call())
        self.assertFalse(ctx.exception.retryable)  # no structural 429 code is confirmed for this provider

    def test_grok_response_validation_refuses_truncation_and_unknown_finish(self):
        for finish in ("length", "tool_calls", None):
            with self.subTest(finish=finish):
                body = ('{"choices":[{"finish_reason":%s,"message":{"content":"x"}}],"model":"m"}'
                        % ("null" if finish is None else '"%s"' % finish)).encode()
                with self.assertRaises(IncompleteResponseError):
                    grok._parse_result(body)

    def test_gemini_blocked_content_is_a_separate_error_class(self):
        body = b'{"candidates":[{"finishReason":"SAFETY","content":{"parts":[]}}],"modelVersion":"m"}'
        with self.assertRaises(ContentBlockedError):
            gem._parse_result(body, "m")

    def test_responses_incomplete_and_empty_output_are_refused(self):
        with self.assertRaises(IncompleteResponseError):
            xr._parse_result(b'{"status":"incomplete","output":[]}')
        with self.assertRaises(IncompleteResponseError):
            xr._parse_result(b'{"status":"completed","output":[{"type":"message","content":[]}]}')


# ---------------------------------------------------------------- 7. production registration
class ProductionRegistrationTests(unittest.TestCase):
    def _env(self):
        return {
            "SANOUR_PROVIDER": "openai",
            "SANOUR_OPENAI_MODEL_ID": "gpt-test-1034",
            "SANOUR_OPENAI_MAX_CONTEXT_TOKENS": "8192",
            "SANOUR_OPENAI_MAX_OUTPUT_TOKENS": "1024",
            "OPENAI_API_KEY": SECRET,
        }

    def test_production_registers_only_openai(self):
        from sanour_ai.composition.runtime import Runtime
        from tests.unit.test_stage1033r1 import FakeOpenAI

        with mock.patch.object(production, "OpenAIProvider", FakeOpenAI), mock.patch.object(production, "_default_test_provider", lambda: FakeOpenAI("test")), \
                mock.patch.object(production, "_sdk_present", return_value=True):
            rt = Runtime.build_for_tests(self._env())
        self.assertEqual(set(rt._registry.states()), {"openai"})  # noqa: SLF001

    def test_production_refuses_an_adapter_that_breaks_the_contract(self):
        class NoIdentity:
            name = "openai"
            capabilities = TEXT

            def __init__(self, api_key):
                pass

            def generate(self, c):
                return None

        from sanour_ai.composition.runtime import Runtime
        with mock.patch.object(production, "OpenAIProvider", NoIdentity), mock.patch.object(production, "_default_test_provider", lambda: NoIdentity("test")), \
                mock.patch.object(production, "_sdk_present", return_value=True):
            with self.assertRaises(ConfigError):
                Runtime.build_for_tests(self._env())

    def test_xai_responses_is_never_wired_into_production(self):
        text = ""
        for path in (SRC / "composition").rglob("*.py"):
            text += path.read_text(encoding="utf-8")
        self.assertNotIn("xai_responses", text)
        self.assertNotIn("grok_responses", text)


# ---------------------------------------------------------------- 8. readiness matrix
class ReadinessMatrixTests(unittest.TestCase):
    def test_matrix_lists_every_adapter_module_exactly_once(self):
        modules = {p.stem.replace("_provider", "") for p in (SRC / "providers").glob("*_provider.py")}
        self.assertEqual(modules, {"openai", "anthropic", "gemini", "grok", "xai_responses"})
        self.assertEqual(len(readiness.rows()), len(readiness.ADAPTERS))

    def test_no_row_is_production_ready_without_live_verification(self):
        for row in readiness.rows():
            with self.subTest(provider=row.provider_id):
                self.assertFalse(row.production_ready)
                self.assertTrue(row.contract_ok)

    def test_verified_column_only_lists_verified_matrix_cells(self):
        for row in readiness.rows():
            for cap in row.verified:
                self.assertEqual(pm.status(row.surface, cap), pm.VERIFIED)
            for cap in row.unverified:
                self.assertEqual(pm.status(row.surface, cap), pm.UNVERIFIED)

    def test_declared_capabilities_are_listed_as_verified(self):
        for row in readiness.rows():
            for cap in row.declared:
                with self.subTest(provider=row.provider_id, cap=cap):
                    self.assertIn(cap, row.verified)

    def test_grok_chat_reasoning_is_recorded_as_unsupported(self):
        row = next(r for r in readiness.rows() if r.provider_id == "grok")
        self.assertIn("reasoning", row.unsupported)

    def test_committed_document_matches_the_generator(self):
        doc = (SRC.parents[1] / "docs" / "PROVIDER_READINESS_MATRIX.md").read_text(encoding="utf-8")
        self.assertEqual(doc, readiness.render_markdown())

    def test_document_states_the_fake_evidence_limit(self):
        doc = readiness.render_markdown()
        self.assertIn("No test in this repository has contacted any", doc)
        self.assertIn("no adapter is", doc)


if __name__ == "__main__":
    unittest.main()
