"""Stage 10.47-R1: usage audit, end-to-end late response, evidence compatibility, profile lifecycle,
and concurrent accounting. Deterministic, offline, no SDK, no network, no key.
"""

import logging
import threading
import unittest
from unittest import mock

from sanour_ai.core.usage_accounting import UsageAccountingService
from sanour_ai.composition import production
from sanour_ai.composition.runtime import Runtime
from sanour_ai.config.governance import load_offline_test_config
from sanour_ai.errors import ErrorCode
from sanour_ai.models import capability_intelligence as ci
from sanour_ai.models.base import ModelResult
from sanour_ai.models.capabilities import ModelCapabilities
from sanour_ai.models.execution import ExecutionResult
from sanour_ai.models.model_catalog import ModelCatalog, blank_capabilities, build_model_record
from sanour_ai.models.profile_management import (
    ProfileError,
    ProfileRecord,
    ProfileRegistry,
    ProviderBinding,
    RequestLimits,
    TimeoutPolicy,
)
from sanour_ai.models.usage import Usage
from sanour_ai.observability.audit import AuditLogger
from sanour_ai.providers.offline_contract import OfflineTestProvider
from sanour_ai.providers.openai_provider import OpenAIProvider

SECRET = "R1-SECRET-KEY-DO-NOT-LOG-QQ"
PROMPT = "R1-PROMPT-TEXT-DO-NOT-LOG"
OUTPUT = "R1-OUTPUT-TEXT-DO-NOT-LOG"
MODEL = "gpt-r1-test"
ALIAS = "openai_primary"


def env():
    return {
        "SANOUR_PROVIDER": "openai",
        "SANOUR_OPENAI_MODEL_ID": MODEL,
        "SANOUR_OPENAI_MAX_CONTEXT_TOKENS": "8192",
        "SANOUR_OPENAI_MAX_OUTPUT_TOKENS": "1024",
        "OPENAI_API_KEY": SECRET,
    }


class Capture(logging.Handler):
    def __init__(self):
        super().__init__(level=logging.DEBUG)
        self.lines = []

    def emit(self, record):
        self.lines.append(record.getMessage())

    def events(self, name):
        return [line for line in self.lines if line.startswith(name + " ")]


def capture_audit(handler):
    logger = logging.getLogger(f"test.stage1047r1.{id(handler)}")
    logger.handlers = [handler]
    logger.propagate = False
    logger.setLevel(logging.DEBUG)
    return AuditLogger(logger)


class UsageProvider(OfflineTestProvider):
    def __init__(self, usage, text=OUTPUT):
        self.usage = usage
        self.text = text
        self.calls = 0

    def generate(self, call):
        self.calls += 1
        return ModelResult(text=self.text, reported_model_id=call.model_id, usage=self.usage)


class FailingUsageAudit(AuditLogger):
    """Fault injection: the usage record write fails, every other write succeeds."""

    def emit(self, event, **fields):
        if event == "usage.recorded":
            return False
        return super().emit(event, **fields)


def required_core(provider, audit):
    """A core with required audit, as in production. Built through the assembler, offline only."""
    from sanour_ai.config.governance import load_runtime_config
    config = load_offline_test_config(env())
    profile = production._governed_profile(config)
    return production._assemble(
        profile, {"openai": provider}, config.max_concurrent_provider_calls,
        dict(config.provider_limits), audit=audit, required_audit=True,
    )


def raw(**extra):
    body = {"profile_alias": ALIAS, "prompt": PROMPT, "timeout_seconds": 5}
    body.update(extra)
    return body


# ----------------------------------------------------------------------------- 1. usage audit
class UsageAudit(unittest.TestCase):
    def test_accepted_completion_emits_exactly_one_usage_event(self):
        cap = Capture()
        rt = Runtime.build_for_tests(env(), provider=UsageProvider(Usage(input_tokens=10, output_tokens=4, total_tokens=14)),
                                     audit=capture_audit(cap))
        self.assertEqual(rt.handle(raw()).status, "success")
        events = cap.events("usage.recorded")
        self.assertEqual(len(events), 1)
        self.assertIn('"input_tokens": 10', events[0])
        self.assertIn('"total_tokens": 14', events[0])
        self.assertIn('"usage_status": "reported"', events[0])

    def test_unknown_usage_is_null_not_zero(self):
        cap = Capture()
        rt = Runtime.build_for_tests(env(), audit=capture_audit(cap))
        rt.handle(raw())
        event = cap.events("usage.recorded")[0]
        self.assertIn('"usage_status": "unavailable"', event)
        self.assertIn('"input_tokens": null', event)
        self.assertNotIn('"input_tokens": 0', event)

    def test_partial_usage_keeps_missing_fields_null(self):
        cap = Capture()
        rt = Runtime.build_for_tests(env(), provider=UsageProvider(Usage(input_tokens=3)), audit=capture_audit(cap))
        rt.handle(raw())
        event = cap.events("usage.recorded")[0]
        self.assertIn('"input_tokens": 3', event)
        self.assertIn('"output_tokens": null', event)

    def test_failed_request_emits_no_usage_event(self):
        from sanour_ai.errors import FailureKind
        from sanour_ai.models.base import ProviderError

        class Failing(OfflineTestProvider):
            def generate(self, call):
                raise ProviderError("boom", kind=FailureKind.REQUEST_REJECTED, retryable=False)

        cap = Capture()
        rt = Runtime.build_for_tests(env(), provider=Failing(), audit=capture_audit(cap))
        self.assertEqual(rt.handle(raw()).status, "error")
        self.assertEqual(cap.events("usage.recorded"), [])

    def test_refused_request_emits_no_usage_event(self):
        cap = Capture()
        rt = Runtime.build_for_tests(env(), audit=capture_audit(cap))
        self.assertEqual(rt.handle({"profile_alias": "nope", "prompt": PROMPT}).status, "error")
        self.assertEqual(cap.events("usage.recorded"), [])

    def test_usage_event_contains_no_prompt_output_key_or_authorization(self):
        cap = Capture()
        rt = Runtime.build_for_tests(env(), provider=UsageProvider(Usage(input_tokens=1)), audit=capture_audit(cap))
        rt.handle(raw())
        text = "\n".join(cap.events("usage.recorded"))
        for secret in (PROMPT, OUTPUT, SECRET, "Authorization", "authorization"):
            self.assertNotIn(secret, text)

    def test_required_audit_failure_withholds_output_and_records_nothing(self):
        provider = UsageProvider(Usage(input_tokens=2, output_tokens=1, total_tokens=3))
        core = required_core(provider, FailingUsageAudit())
        response, result = core.handle_with_result(raw())
        self.assertEqual(response.status, "error")
        self.assertEqual(response.error.code, ErrorCode.INTERNAL_ERROR)
        self.assertNotIn(OUTPUT, repr(response))
        # R2: the output was withheld, but the provider usage is kept with delivery "withheld" and the
        # usage audit is reported as failed (never recorded).
        self.assertIsNotNone(result)
        self.assertEqual((result.delivery, result.usage_audit), ("withheld", "failed"))
        self.assertEqual(result.usage.input_tokens, 2)

    def test_non_required_audit_failure_is_reported_as_failed_not_recorded(self):
        rt = Runtime.build_for_tests(env(), provider=UsageProvider(Usage(input_tokens=2)),
                                     audit=FailingUsageAudit())
        self.assertEqual(rt.handle(raw()).status, "success")
        total = rt.usage_summary()["total"]
        self.assertEqual(total["usage_audit"], {"recorded": 0, "failed": 1, "unavailable": 0})
        self.assertEqual(total["requests"], 1)

    def test_recorded_audit_status_is_reported_as_recorded(self):
        rt = Runtime.build_for_tests(env(), provider=UsageProvider(Usage(input_tokens=2)))
        rt.handle(raw())
        self.assertEqual(rt.usage_summary()["total"]["usage_audit"], {"recorded": 1, "failed": 0, "unavailable": 0})


# ------------------------------------------------------------ 2. end-to-end late response
class LateProvider(OfflineTestProvider):
    """Blocks inside the worker until the test releases it. Fully synchronized, no sleeps."""

    def __init__(self):
        self.entered = threading.Event()
        self.release = threading.Event()
        self.returned = threading.Event()
        self.closes = 0

    def generate(self, call):
        self.entered.set()
        self.release.wait(timeout=30)
        result = ModelResult(text=OUTPUT, reported_model_id=call.model_id,
                             usage=Usage(input_tokens=9, output_tokens=9, total_tokens=18))
        self.returned.set()
        return result

    def close(self):
        self.closes += 1


class LateResponseEndToEnd(unittest.TestCase):
    def test_late_response_is_not_accepted_recorded_or_audited_and_capacity_holds(self):
        provider = LateProvider()
        cap = Capture()
        rt = Runtime.build_for_tests(env(), provider=provider, audit=capture_audit(cap))
        gateway = rt._core.shutdown_target()  # noqa: SLF001 - the gateway, for capacity observation

        outcome = {}

        def call():
            outcome["pair"] = rt._core.handle_with_result(raw(timeout_seconds=0.2))  # noqa: SLF001

        caller = threading.Thread(target=call)
        caller.start()
        self.assertTrue(provider.entered.wait(timeout=10))  # the worker is inside the provider now
        caller.join(timeout=10)  # returns when the central deadline passes; the worker is still blocked
        self.assertFalse(caller.is_alive())
        response, result = outcome["pair"]
        self.assertEqual(response.status, "error")
        self.assertEqual(response.error.code, ErrorCode.PROVIDER_TIMEOUT)
        self.assertIsNone(result)

        # Capacity is still occupied by the live worker.
        stats = rt._core.gateway_stats()  # noqa: SLF001
        self.assertEqual(stats.in_flight, 1)
        self.assertEqual(stats.active_workers, 1)

        provider.release.set()  # the late response is produced now
        self.assertTrue(provider.returned.wait(timeout=10))
        with gateway._lock:  # noqa: SLF001 - wait for the worker to finish releasing its slot
            self.assertTrue(gateway._idle_cv.wait_for(lambda: gateway._in_flight == 0, timeout=10))  # noqa: SLF001

        # The late answer never became a success anywhere.
        total = rt.usage_summary()["total"]
        self.assertEqual(total["requests"], 0)
        self.assertEqual(cap.events("usage.recorded"), [])
        self.assertEqual(cap.events("model.succeeded"), [])
        self.assertNotIn(OUTPUT, repr(response))

        # Existing settlement and shutdown are unchanged: exactly one close, runtime reaches shutdown.
        states = rt.shutdown(timeout=5)
        self.assertEqual(states.get("openai"), "closed")
        self.assertEqual(provider.closes, 1)


# ------------------------------------------------------------- 3. evidence compatibility
class EvidenceCompatibility(unittest.TestCase):
    def test_legacy_four_argument_form_still_constructs_and_is_inert(self):
        legacy = ci.RuntimeEvidence("openai", "openai_responses", "text_generation", "tests/live/t.py::x")
        self.assertIsNone(legacy.source)
        self.assertIsNone(legacy.status)
        self.assertFalse(legacy.is_verified_eligible())
        self.assertNotEqual(
            ci.runtime_status("openai", "openai_responses", "text_generation", OpenAIProvider.capabilities,
                              (legacy,), model_id=MODEL),
            ci.Status.VERIFIED,
        )

    def test_legacy_record_with_matching_model_but_no_provenance_is_never_verified(self):
        for kw in ({"model_id": MODEL}, {"model_id": MODEL, "status": "VERIFIED"},
                   {"model_id": MODEL, "source": "approved_live_verification", "method": "live_provider_test"}):
            with self.subTest(kw=kw):
                rec = ci.RuntimeEvidence("openai", "openai_responses", "text_generation", "t::x", **kw)
                self.assertFalse(rec.is_verified_eligible())
                self.assertNotEqual(
                    ci.runtime_status("openai", "openai_responses", "text_generation",
                                      OpenAIProvider.capabilities, (rec,), model_id=MODEL),
                    ci.Status.VERIFIED,
                )

    def test_provided_unapproved_sources_and_methods_are_refused_outright(self):
        for kw in ({"source": "documentation"}, {"source": "environment"}, {"source": "fake_transport"},
                   {"method": "fake_transport"}, {"method": "mock"}, {"status": "DOCUMENTED_ONLY"}):
            with self.subTest(kw=kw):
                with self.assertRaises(ValueError):
                    ci.RuntimeEvidence("openai", "openai_responses", "text_generation", "t::x", **kw)

    def test_missing_provenance_is_never_inferred(self):
        legacy = ci.RuntimeEvidence("openai", "openai_responses", "text_generation", "t::x")
        self.assertEqual((legacy.model_id, legacy.source, legacy.method, legacy.verified_at), (None, None, None, None))

    def test_full_provenance_still_verifies(self):
        rec = ci.RuntimeEvidence("openai", "openai_responses", "text_generation", "t::x", MODEL,
                                 "approved_live_verification", "live_provider_test", "2026-11-07T12:00:00Z",
                                 "VERIFIED")
        self.assertTrue(rec.is_verified_eligible())
        self.assertEqual(
            ci.runtime_status("openai", "openai_responses", "text_generation", OpenAIProvider.capabilities,
                              (rec,), model_id=MODEL),
            ci.Status.VERIFIED,
        )

    def test_default_registry_is_still_empty(self):
        self.assertEqual(ci.RUNTIME_EVIDENCE, ())


# ----------------------------------------------------------------- 4. profile lifecycle
def make_registry(model_provider="openai", model_surface="openai_responses", model_caps=None, lifecycle="active"):
    catalog = ModelCatalog()
    catalog.register_model(build_model_record(
        model_id=MODEL, provider_id=model_provider, vendor="openai", api_surface=model_surface,
        display_name=MODEL, capabilities=model_caps or blank_capabilities(),
        lifecycle_status=lifecycle, verification_status="unverified", source="operator_configuration",
    ))
    return ProfileRegistry(catalog)


def record(**overrides):
    base = dict(
        profile_id=ALIAS, provider_id="openai", model_id=MODEL, api_surface="openai_responses",
        capability_requirements=("text_generation",),
        request_limits=RequestLimits(max_output_tokens=512, max_context_tokens=8192),
        timeout_policy=TimeoutPolicy(default_seconds=10.0, max_seconds=60.0),
    )
    base.update(overrides)
    return ProfileRecord(**base)


BINDING = ProviderBinding(provider_id="openai", surface="openai_responses",
                          capabilities=OpenAIProvider.capabilities)


class ProfileLifecycle(unittest.TestCase):
    def test_invalid_profile_limits_are_rejected(self):
        with self.assertRaises(ValueError):
            RequestLimits(max_output_tokens=9000, max_context_tokens=100)

    def test_provider_model_incompatibility_is_rejected(self):
        reg = make_registry(model_provider="anthropic")
        with self.assertRaises(ProfileError):
            reg.register_profile(record(), BINDING)

    def test_profile_naming_another_provider_than_its_adapter_is_rejected(self):
        # The model is linked under BOTH providers, so only the binding rule can refuse this profile.
        catalog = ModelCatalog()
        for provider in ("openai", "anthropic"):
            catalog.register_model(build_model_record(
                model_id=MODEL, provider_id=provider, vendor=provider, api_surface="openai_responses",
                display_name=MODEL, capabilities=blank_capabilities(),
                lifecycle_status="active", verification_status="unverified", source="operator_configuration",
            ))
        reg = ProfileRegistry(catalog)
        with self.assertRaises(ProfileError) as ctx:
            reg.register_profile(record(provider_id="anthropic"), BINDING)
        self.assertIn("does not match the adapter", str(ctx.exception))

    def test_surface_incompatibility_is_rejected(self):
        reg = make_registry(model_surface="grok_responses")
        with self.assertRaises(ProfileError):
            reg.register_profile(record(), BINDING)

    def test_unsupported_capability_declaration_is_rejected(self):
        reg = make_registry()
        with self.assertRaises(ProfileError):
            reg.register_profile(record(capability_requirements=("text_generation", "vision")), BINDING)

    def test_disabled_lifecycle_model_cannot_back_an_enabled_profile(self):
        reg = make_registry(lifecycle="removed")
        with self.assertRaises(ProfileError):
            reg.register_profile(record(), BINDING)

    def test_frozen_registry_refuses_changes_so_admitted_requests_are_stable(self):
        reg = make_registry()
        reg.register_profile(record(), BINDING)
        reg.freeze()
        with self.assertRaises(ProfileError):
            reg.deactivate_profile(ALIAS, authorized=True, reason="change during run")
        self.assertIsNotNone(reg.model_profile(ALIAS, BINDING))

    def test_profile_change_is_logged_before_freeze(self):
        reg = make_registry()
        reg.register_profile(record(), BINDING)
        reg.deactivate_profile(ALIAS, authorized=True, reason="operator change")
        self.assertTrue(reg.change_log)

    def test_deactivation_requires_explicit_authorization(self):
        reg = make_registry()
        reg.register_profile(record(), BINDING)
        with self.assertRaises(ProfileError):
            reg.deactivate_profile(ALIAS, authorized=False, reason="x")

    def test_exactly_one_explicit_profile_and_no_auto_selection_at_runtime(self):
        rt = Runtime.build_for_tests(env())
        self.assertEqual(rt.handle({"prompt": PROMPT}).status, "error")
        self.assertEqual(rt.handle({"profile_alias": "other", "prompt": PROMPT}).status, "error")
        self.assertEqual(rt.usage_summary()["total"]["requests"], 0)


# ------------------------------------------------------------ 5. concurrent accounting
def completed(request_id, usage, audit="recorded", provider="openai", profile="p", model="m"):
    return ExecutionResult(
        request_id=request_id, profile_id=profile, provider_id=provider, api_surface="openai_responses",
        requested_model_id=model, provider_reported_model_id=model, output="out", finish_status="completed",
        execution_ms=1, usage=usage, usage_audit=audit,
    )


class ConcurrentAccounting(unittest.TestCase):
    def test_concurrent_records_are_neither_lost_nor_double_counted(self):
        svc = UsageAccountingService(clock=lambda: 1_790_000_000.0)
        workers, each = 8, 200
        barrier = threading.Barrier(workers)

        def run(w):
            barrier.wait(timeout=10)
            for i in range(each):
                svc.record(completed(f"{w:02d}-{i:04d}".ljust(32, "0"), Usage(input_tokens=1, output_tokens=2)))

        threads = [threading.Thread(target=run, args=(w,)) for w in range(workers)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=30)
        total = svc.total()
        self.assertEqual(total["requests"], workers * each)
        self.assertEqual(total["tokens"]["input_tokens"]["sum"], workers * each)
        self.assertEqual(total["tokens"]["output_tokens"]["sum"], 2 * workers * each)
        self.assertEqual(total["tokens"]["total_tokens"]["sum"], None)  # never reported: unknown, not zero

    def test_same_request_from_many_threads_is_counted_once(self):
        svc = UsageAccountingService()
        results = []
        barrier = threading.Barrier(8)

        def run():
            barrier.wait(timeout=10)
            results.append(svc.record(completed("d" * 32, Usage(input_tokens=5))))

        threads = [threading.Thread(target=run) for _ in range(8)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=10)
        self.assertEqual(results.count(True), 1)
        self.assertEqual(svc.total()["requests"], 1)
        self.assertEqual(svc.duplicates_ignored(), 7)

    def test_unknown_values_stay_unknown_under_mixed_load(self):
        svc = UsageAccountingService()
        svc.record(completed("a" * 32, None))
        svc.record(completed("b" * 32, Usage(input_tokens=4)))
        total = svc.total()
        self.assertEqual(total["tokens"]["input_tokens"], {"sum": 4, "known_count": 1, "unknown_count": 1})
        self.assertEqual(total["requests_with_usage"], 1)
        self.assertEqual(total["requests_without_usage"], 1)

    def test_request_counts_are_separate_from_token_counts(self):
        svc = UsageAccountingService()
        svc.record(completed("c" * 32, None))
        self.assertEqual(svc.total()["requests"], 1)
        self.assertIsNone(svc.total()["tokens"]["input_tokens"]["sum"])

    def test_utc_day_aggregation_is_deterministic_at_the_boundary(self):
        svc = UsageAccountingService()
        svc.record(completed("e" * 32, Usage(input_tokens=1)), recorded_at=1_789_430_399.0)  # 23:59:59 UTC
        svc.record(completed("f" * 32, Usage(input_tokens=1)), recorded_at=1_789_430_400.0)  # 00:00:00 UTC
        self.assertEqual(set(svc.aggregate("period")), {"2026-09-14", "2026-09-15"})
        self.assertEqual(UsageAccountingService.period_of(1_789_430_400.0), "2026-09-15")

    def test_invalid_input_cannot_corrupt_accumulated_totals(self):
        svc = UsageAccountingService()
        svc.record(completed("1" * 32, Usage(input_tokens=3)))
        before = svc.total()
        forged = Usage(input_tokens=3)
        object.__setattr__(forged, "input_tokens", -5)  # bypass of the frozen dataclass: must be refused
        with self.assertRaises(ValueError):
            svc.record(completed("2" * 32, forged))
        with self.assertRaises(ValueError):
            svc.record(object())
        self.assertEqual(svc.total(), before)

    def test_failed_audit_is_never_counted_as_recorded(self):
        svc = UsageAccountingService()
        svc.record(completed("3" * 32, Usage(input_tokens=1), audit="failed"))
        self.assertEqual(svc.total()["usage_audit"], {"recorded": 0, "failed": 1, "unavailable": 0})


if __name__ == "__main__":
    unittest.main()
