"""Stage 10.49-R4: leased outbox claims, stale-worker safety, conflicts, unknown outcomes, concurrent delivery
processes, and required admission events. Deterministic; real child processes where a process death or a second
process matters. Governance decisions are checked before and after every delivery path."""

import json
import logging
import os
import sqlite3
import tempfile
import time
import unittest
from decimal import Decimal

from sanour_ai.governance.admission import AdmissionController
from sanour_ai.governance.sink import DurableSqliteSink, SinkOutcomeUnknown
from sanour_ai.governance.store import GovernanceStore
from sanour_ai.governance.types import Settlement
from sanour_ai.observability.audit import AuditLogger
from tests.unit.r4_support import ACTOR, DELIVER_CHILD, DownSink, spawn_child
from tests.unit.test_stage1049 import BOUNDS, profile, request
from tests.unit.test_stage1049r3_outbox import Base, _FailOn


class Claims(Base):
    def failed_write_off(self):
        rid = self.exposed_request()
        self.sink.down = True
        self.c.write_off(rid, actor=ACTOR, reason="needs delivery")
        self.sink.down = False
        return rid, self.key_for(rid)

    def outbox_row(self, key):
        return self.q("SELECT status, attempts, lease_token IS NULL, receipt_id FROM audit_outbox WHERE event_key = ?",
                      key)[0]

    def test_a_leased_event_is_not_claimed_by_a_second_worker(self):
        _, key = self.failed_write_off()
        claimed = self.c._claim([key], self.clock.now)  # worker A holds the lease  # noqa: SLF001
        self.assertEqual(len(claimed), 1)
        self.assertEqual(self.c.delivery_states([key]), {key: "attempted"})
        before = len(self.sink.attempts)
        self.assertEqual(self.c.deliver_outbox(keys=[key]), 0, "worker B must not claim a leased event")
        self.assertEqual(len(self.sink.attempts), before, "no second sink attempt while the lease is live")

    def test_lease_expiry_lets_another_worker_reclaim_and_deliver(self):
        rid, key = self.failed_write_off()
        self.c._claim([key], self.clock.now)  # noqa: SLF001 worker A dies holding the lease
        self.clock.now += 61
        self.assertEqual(self.c.deliver_outbox(keys=[key]), 1)
        status, attempts, lease_free, receipt_id = self.outbox_row(key)
        self.assertEqual((status, attempts, lease_free), ("delivered", 3, 1))
        self.assertEqual(self.c.delivery_states([key]), {key: "confirmed"})
        self.assertEqual(self.sink_receipts(key), 1)

    def test_a_stale_worker_cannot_overwrite_a_newer_confirmed_result(self):
        _, key = self.failed_write_off()
        stale = self.c._claim([key], self.clock.now)[0]  # noqa: SLF001
        outbox_id, token = stale[0], stale[4]
        self.clock.now += 61
        self.assertEqual(self.c.deliver_outbox(keys=[key]), 1)
        status, _, _, receipt_id = self.outbox_row(key)
        self.assertEqual(status, "delivered")
        # The stale worker finally reports a failure and then an unknown outcome. Both must be refused.
        self.assertFalse(self.c._settle_attempt(outbox_id, token, "failed", None, "sink_failed", self.clock.now))  # noqa: SLF001
        self.assertFalse(self.c._settle_attempt(outbox_id, token, "unknown", None, "sink_outcome_unknown", self.clock.now))  # noqa: SLF001
        self.assertEqual(self.outbox_row(key)[0], "delivered")
        self.assertEqual(self.outbox_row(key)[3], receipt_id)

    def test_a_stale_worker_cannot_settle_a_row_that_was_reclaimed_by_another_worker(self):
        _, key = self.failed_write_off()
        stale = self.c._claim([key], self.clock.now)[0]  # noqa: SLF001
        self.clock.now += 61
        newer = self.c._claim([key], self.clock.now)[0]  # noqa: SLF001 worker B holds the new lease
        self.assertFalse(self.c._settle_attempt(stale[0], stale[4], "delivered", 999, None, self.clock.now))  # noqa: SLF001
        status, _, lease_free, receipt_id = self.outbox_row(key)
        self.assertEqual((status, lease_free, receipt_id), ("failed", 0, None), "B's lease is still the live one")
        self.assertFalse(self.c._settle_attempt(newer[0], newer[4], "failed", None, "sink_failed", self.clock.now))  # noqa: SLF001
        self.assertEqual(self.outbox_row(key)[0], "failed")
        self.assertEqual(self.outbox_row(key)[2], 1, "B's failed result releases the lease")

    def test_conflicting_payload_under_the_same_key_fails_closed_and_is_not_retried(self):
        rid, key = self.failed_write_off()
        DurableSqliteSink.deliver(self.sink, key, "exposure.resolved", {"request_id": rid, "tampered": True})
        original_fields = self.sink_row("SELECT fields FROM audit_receipts WHERE outbox_key = ?", key)
        self.sink.down = False
        self.assertEqual(self.c.deliver_outbox(keys=[key]), 0)
        self.assertEqual(self.outbox_row(key)[0], "conflict")
        self.assertEqual(self.c.delivery_states([key]), {key: "conflict"})
        attempts = len(self.sink.attempts)
        self.assertEqual(self.c.deliver_outbox(), 0)
        self.assertEqual(len(self.sink.attempts), attempts, "a conflict is terminal: never retried automatically")
        self.assertEqual(self.sink_row("SELECT fields FROM audit_receipts WHERE outbox_key = ?", key), original_fields)
        self.assertEqual(self.sink_receipts(key), 1)

    def test_unknown_outcome_where_the_sink_did_commit_is_resolved_by_dedupe(self):
        class CommitThenLose(DurableSqliteSink):
            def deliver(self, outbox_key, event, fields):
                super().deliver(outbox_key, event, fields)  # the sink commits
                raise SinkOutcomeUnknown("response lost after commit")

        lossy = CommitThenLose(self.path + ".sink")
        self.addCleanup(lossy.close)
        c2 = AdmissionController(self.s, audit=AuditLogger(logging.getLogger("test.r4.lossy")), bounds=BOUNDS,
                                 clock=self.clock, authorized_actors=frozenset({ACTOR}), sink=lossy)
        rid = self.exposed_request()
        c2.write_off(rid, actor=ACTOR, reason="lost response")
        key = self.key_for(rid)
        self.assertEqual(c2.delivery_states([key]), {key: "unknown"})
        self.clock.now += 61
        self.assertEqual(self.c.deliver_outbox(keys=[key]), 1)
        self.assertEqual(self.c.delivery_states([key]), {key: "confirmed"})
        self.assertEqual(self.sink_receipts(key), 1, "the retry was a duplicate of the committed receipt")
        self.assertTrue(self.sink.receipts[-1].duplicate)

    def test_sink_failure_then_recovery_confirms_once(self):
        rid, key = self.failed_write_off()
        self.assertEqual(self.c.delivery_states([key]), {key: "failed"})
        self.assertEqual(self.c.deliver_outbox(keys=[key]), 1)
        self.assertEqual(self.c.delivery_states([key]), {key: "confirmed"})
        self.assertEqual(self.sink_receipts(key), 1)


class Restart(Base):
    def test_process_restart_after_a_successful_receipt_neither_redelivers_nor_duplicates(self):
        rid = self.exposed_request()
        self.c.write_off(rid, actor=ACTOR, reason="restart after receipt")
        key = self.key_for(rid)
        receipt_id = self.one("SELECT receipt_id FROM audit_outbox WHERE event_key = ?", key)
        before = self.snapshot()
        sink, c2 = self.restart()
        c2.sweep()
        self.assertEqual(sink.attempts, [], "a confirmed event is never sent again")
        self.assertEqual(self.sink_receipts(key), 1)
        self.assertEqual(self.one("SELECT receipt_id FROM audit_outbox WHERE event_key = ?", key), receipt_id)
        self.assertEqual(self.snapshot(), before)


class ConcurrentDelivery(Base):
    def test_two_delivery_processes_claim_the_backlog_exactly_once_each(self):
        keys = []
        for _ in range(12):
            rid = self.exposed_request()
            self.sink.down = True
            self.c.write_off(rid, actor=ACTOR, reason="backlog")
            self.sink.down = False
            keys.append(self.key_for(rid))
        before = self.snapshot()
        go = os.path.join(self._dir.name, "go")
        procs, outs = [], []
        for i in range(3):
            out = os.path.join(self._dir.name, f"deliver{i}.json")
            outs.append(out)
            procs.append(spawn_child(DELIVER_CHILD, [self.path, self.path + ".sink", out, go]))
        time.sleep(0.3)
        open(go, "w").close()
        for p in procs:
            _, err = p.communicate(timeout=120)
            self.assertEqual(p.returncode, 0, err.decode()[-400:])
        confirmed = sum(json.load(open(out))["confirmed"] for out in outs)
        self.assertEqual(confirmed, 12, "every event is confirmed by exactly one worker")
        rows = self.q("SELECT status, attempts FROM audit_outbox WHERE event = 'exposure.resolved'")
        self.assertTrue(all(status == "delivered" for status, _ in rows))
        self.assertTrue(all(attempts == 2 for _, attempts in rows),
                        "one failed write-off attempt plus exactly one concurrent claim per event")
        self.assertEqual(self.sink_receipts_total("exposure.resolved"), 12)
        self.assertEqual(self.snapshot(), before, "concurrent delivery adds no decision and moves no money")


class RequiredAdmission(Base):
    def test_unknown_sink_outcome_on_a_required_admission_event_refuses_and_releases(self):
        class LoseAfterCommit(DurableSqliteSink):
            def deliver(self, outbox_key, event, fields):
                super().deliver(outbox_key, event, fields)
                raise SinkOutcomeUnknown("lost")

        ctl = AdmissionController(self.s, audit=AuditLogger(logging.getLogger("test.r4.adm")), bounds=BOUNDS,
                                  clock=self.clock, authorized_actors=frozenset({ACTOR}),
                                  sink=LoseAfterCommit(self.path + ".sink"))
        from sanour_ai.errors import SanourError
        with self.assertRaises(SanourError):
            ctl.admit(request(), profile())
        self.assertEqual(self.one("SELECT state FROM reservations"), "released")
        self.assertEqual(self.one("SELECT reserved FROM budget_windows"), "0")
        self.assertEqual(self.one("SELECT spent FROM budget_windows"), "0")

    def test_down_sink_on_a_required_admission_event_refuses_with_no_leftover_reservation(self):
        ctl = AdmissionController(self.s, audit=AuditLogger(logging.getLogger("test.r4.adm2")), bounds=BOUNDS,
                                  clock=self.clock, authorized_actors=frozenset({ACTOR}), sink=DownSink())
        from sanour_ai.errors import SanourError
        with self.assertRaises(SanourError):
            ctl.admit(request(), profile())
        self.assertEqual(self.one("SELECT reserved FROM budget_windows"), "0")
        self.assertEqual(self.one("SELECT state FROM reservations"), "released")

    def test_optional_admission_mode_still_records_the_decision_and_leaves_the_event_pending(self):
        ctl = AdmissionController(self.s, audit=AuditLogger(logging.getLogger("test.r4.opt")), bounds=BOUNDS,
                                  clock=self.clock, authorized_actors=frozenset({ACTOR}), sink=DownSink(),
                                  required_audit=False)
        ticket = ctl.admit(request(), profile())
        self.assertEqual(self.one("SELECT state FROM reservations"), "reserved")
        key = f"gov:{self.one('SELECT log_id FROM governance_log WHERE request_id = ? AND operation = ?', ticket.request_id, 'admit')}:budget.reserved"
        self.assertEqual(ctl.delivery_states([key]), {key: "failed"})
        ctl.settle(ticket, Settlement("released", provider_started=False))


if __name__ == "__main__":
    unittest.main()
