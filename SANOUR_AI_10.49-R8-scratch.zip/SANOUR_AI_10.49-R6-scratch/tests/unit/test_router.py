"""Required-capability routing, converted from select() to explicit resolve() in Stage 10.36.

The capability rules are unchanged. The named profile must satisfy every requirement, or the request
is refused. No other profile is ever tried.
"""

import unittest

from sanour_ai.core.request_manager import accept
from sanour_ai.errors import ErrorCode, SanourError
from sanour_ai.models.capabilities import ModelCapabilities, ModelProfile
from sanour_ai.models.router import DeterministicRouter

RID = "c" * 32


def profile(alias, priority=100, runs_locally=True, text=True, max_output=1000, **flags):
    capabilities = ModelCapabilities(
        text_generation=text,
        max_context_tokens=1000,
        max_output_tokens=max_output,
        **flags,
    )
    return ModelProfile(
        alias=alias,
        provider="mock",
        model_id=f"{alias}-id",
        capabilities=capabilities,
        runs_locally=runs_locally,
        priority=priority,
    )


def req(alias, **overrides):
    raw = {"profile_alias": alias, "prompt": "hello world"}
    raw.update(overrides)
    return accept(raw, RID)


class RequiredCapabilityRoutingTests(unittest.TestCase):
    def test_named_profile_satisfying_all_requirements_is_resolved(self):
        router = DeterministicRouter(
            [profile("streaming_only", 1, streaming=True), profile("both", 50, streaming=True, tool_calling=True)]
        )
        chosen = router.resolve(req("both", required_capabilities=["streaming", "tool_calling"]))
        self.assertEqual(chosen.alias, "both")

    def test_named_profile_missing_one_requirement_is_refused(self):
        router = DeterministicRouter([profile("streaming_only", streaming=True)])
        with self.assertRaises(SanourError) as ctx:
            router.resolve(req("streaming_only", required_capabilities=["streaming", "tool_calling"]))
        self.assertEqual(ctx.exception.code, ErrorCode.NO_ELIGIBLE_MODEL)

    def test_compatible_profile_is_not_substituted_for_the_named_one(self):
        router = DeterministicRouter([profile("plain", 1), profile("streamer", 2, streaming=True)])
        with self.assertRaises(SanourError):
            router.resolve(req("plain", required_capabilities=["streaming"]))
        self.assertEqual(router.resolve(req("streamer", required_capabilities=["streaming"])).alias, "streamer")

    def test_no_compatible_model_returns_existing_safe_error(self):
        router = DeterministicRouter([profile("plain", 1)])
        with self.assertRaises(SanourError) as ctx:
            router.resolve(req("plain", required_capabilities=["image_input"]))
        self.assertEqual(ctx.exception.code, ErrorCode.NO_ELIGIBLE_MODEL)
        self.assertEqual(ctx.exception.message, "the requested model cannot handle this request")
        self.assertFalse(ctx.exception.retryable)

    def test_same_named_profile_gives_same_result_in_any_registration_order(self):
        first = DeterministicRouter([profile("b_model", 10, streaming=True), profile("a_model", 10, streaming=True)])
        second = DeterministicRouter([profile("a_model", 10, streaming=True), profile("b_model", 10, streaming=True)])
        request = req("a_model", required_capabilities=["streaming"])
        self.assertEqual(first.resolve(request).alias, "a_model")
        self.assertEqual(second.resolve(request).alias, "a_model")

    def test_repeated_calls_return_the_same_profile(self):
        router = DeterministicRouter([profile("x_model", 5, streaming=True), profile("y_model", 1, streaming=True)])
        request = req("y_model", required_capabilities=["streaming"])
        self.assertEqual({router.resolve(request).alias for _ in range(20)}, {"y_model"})

    def test_text_generation_still_required_with_requirements(self):
        router = DeterministicRouter([profile("no_text", text=False, streaming=True)])
        with self.assertRaises(SanourError) as ctx:
            router.resolve(req("no_text", required_capabilities=["streaming"]))
        self.assertEqual(ctx.exception.code, ErrorCode.NO_ELIGIBLE_MODEL)

    def test_fit_rules_still_apply_with_requirements(self):
        router = DeterministicRouter([profile("tiny", max_output=100, streaming=True)])
        with self.assertRaises(SanourError):
            router.resolve(req("tiny", required_capabilities=["streaming"]))

    def test_offline_rule_still_applies_with_requirements(self):
        router = DeterministicRouter([profile("remote", runs_locally=False, streaming=True)])
        with self.assertRaises(SanourError):
            router.resolve(req("remote", required_capabilities=["streaming"], offline_only=True))


class LegacyRoutingConversionTests(unittest.TestCase):
    """Converted from test_legacy_routing_without_requirements_is_unchanged (Stage 10.36).

    The old test expected select() to pick among candidates. Now every candidate is named explicitly,
    and the same filter rules decide which named profiles are served.
    """

    def test_each_named_profile_is_served_only_if_it_passes_the_filters(self):
        router = DeterministicRouter(
            [
                profile("zeta", 2),
                profile("alpha", 1, streaming=True),
                profile("beta", 1),
                profile("no_text", 0, text=False),
                profile("tiny", 0, max_output=100),
            ]
        )
        self.assertEqual(router.resolve(req("alpha")).alias, "alpha")
        self.assertEqual(router.resolve(req("beta")).alias, "beta")
        for refused in ("no_text", "tiny"):
            with self.subTest(profile=refused):
                with self.assertRaises(SanourError) as ctx:
                    router.resolve(req(refused))
                self.assertEqual(ctx.exception.code, ErrorCode.NO_ELIGIBLE_MODEL)
