"""Stage 10.18 tests: shared provider/model capability contract. Mock only, no network, no keys."""

from tests.support import request_identity_for as _rid
import unittest

from pydantic import ValidationError

from sanour_ai.composition.production import _assemble
from sanour_ai.config.settings import ConfigError
from sanour_ai.core.sanour_core import SanourCore
from sanour_ai.errors import ErrorCode, SanourError
from sanour_ai.models.base import ModelCall, ModelResult
from sanour_ai.models.capabilities import (
    CAPABILITY_FLAGS,
    ModelCapabilities,
    ModelProfile,
    ProviderCapabilities,
    missing_flags,
    unsupported_flags,
)
from sanour_ai.models.gateway import ModelGateway
from sanour_ai.models.router import DeterministicRouter
from sanour_ai.observability.audit import AuditLogger
from sanour_ai.providers.openai_provider import OpenAIProvider
from tests.support import deadline_in

TEXT_ONLY = ProviderCapabilities(text_generation=True)


def model(alias, provider, **flags):
    base = {"text_generation": True, "max_context_tokens": 8192, "max_output_tokens": 4096}
    base.update(flags)
    return ModelProfile(
        alias=alias,
        provider=provider,
        model_id=f"{alias}-id",
        capabilities=ModelCapabilities(**base),
        runs_locally=True,
    )


class CountingProvider:
    def __init__(self, name, caps=TEXT_ONLY):
        self.name = name
        self.capabilities = caps
        self.calls = 0

    def generate(self, call):
        self.calls += 1
        return ModelResult(text="ok", reported_model_id=call.model_id)


def call_for(p):
    return ModelCall(model_id=p.model_id, prompt="hi", max_output_tokens=16, deadline=None)


class ProviderCapabilitiesTests(unittest.TestCase):
    def test_defaults_are_all_unsupported_and_frozen(self):
        caps = ProviderCapabilities()
        self.assertFalse(any(getattr(caps, f) for f in CAPABILITY_FLAGS))
        with self.assertRaises(ValidationError):
            caps.streaming = True

    def test_unknown_flag_is_rejected(self):
        with self.assertRaises(ValidationError):
            ProviderCapabilities(audio_input=True)

    def test_shared_helpers_report_exact_flags(self):
        m = ModelCapabilities(text_generation=True, streaming=True, max_context_tokens=1, max_output_tokens=1)
        self.assertEqual(unsupported_flags(m, TEXT_ONLY), ("streaming",))
        self.assertEqual(unsupported_flags(m, ProviderCapabilities(text_generation=True, streaming=True)), ())
        self.assertEqual(missing_flags(m, ("streaming", "tool_calling")), ("tool_calling",))
        self.assertEqual(missing_flags(m, ()), ())


class GatewayContractTests(unittest.TestCase):
    def test_provider_without_declared_capabilities_is_rejected(self):
        class Undeclared:
            name = "alpha"

            def generate(self, call):
                return ModelResult(text="ok", reported_model_id=call.model_id)

        with self.assertRaises(ValueError):
            ModelGateway({"alpha": Undeclared()}, max_concurrent_calls=1)

    def test_capabilities_must_be_the_typed_contract(self):
        class DictCaps:
            name = "alpha"
            capabilities = {"text_generation": True}

            def generate(self, call):
                return ModelResult(text="ok", reported_model_id=call.model_id)

        with self.assertRaises(ValueError):
            ModelGateway({"alpha": DictCaps()}, max_concurrent_calls=1)

    def test_unsupported_model_flag_makes_no_provider_call(self):
        p = CountingProvider("alpha")
        gw = ModelGateway({"alpha": p}, max_concurrent_calls=1)
        streaming_model = model("stream_model", "alpha", streaming=True)
        with self.assertRaises(SanourError) as ctx:
            gw.generate(streaming_model, call_for(streaming_model), deadline_in(2.0), identity=_rid(streaming_model))
        self.assertEqual(ctx.exception.code, ErrorCode.NO_ELIGIBLE_MODEL)
        self.assertEqual(p.calls, 0)

    def test_supported_model_flag_is_called(self):
        p = CountingProvider("alpha", ProviderCapabilities(text_generation=True, streaming=True))
        gw = ModelGateway({"alpha": p}, max_concurrent_calls=1)
        streaming_model = model("stream_model", "alpha", streaming=True)
        self.assertEqual(gw.generate(streaming_model, call_for(streaming_model), deadline_in(2.0), identity=_rid(streaming_model)).reported_model_id, "stream_model-id")
        self.assertEqual(p.calls, 1)


class PerModelCapabilityTests(unittest.TestCase):
    def _core(self):
        p = CountingProvider("alpha", ProviderCapabilities(text_generation=True, streaming=True))
        plain = model("plain_model", "alpha")
        streaming = model("stream_model", "alpha", streaming=True)
        core = SanourCore(
            router=DeterministicRouter([plain, streaming]),
            gateway=ModelGateway({"alpha": p}, max_concurrent_calls=2),
            audit=AuditLogger(),
        )
        return core, p

    def test_requirement_unmet_by_named_model_is_refused_without_switching(self):
        core, p = self._core()
        resp = core.handle({"profile_alias": "plain_model", "prompt": "hi", "required_capabilities": ["streaming"]})
        self.assertEqual(resp.error.code, ErrorCode.NO_ELIGIBLE_MODEL)
        self.assertEqual(p.calls, 0)

    def test_requirement_met_by_named_model_is_served_by_that_model(self):
        core, p = self._core()
        resp = core.handle({"profile_alias": "stream_model", "prompt": "hi", "required_capabilities": ["streaming"]})
        self.assertEqual(resp.status, "success")
        self.assertEqual(resp.model_alias, "stream_model")
        self.assertEqual(p.calls, 1)

    def test_unknown_requirement_name_is_invalid_input(self):
        core, p = self._core()
        resp = core.handle({"profile_alias": "stream_model", "prompt": "hi", "required_capabilities": ["audio_input"]})
        self.assertEqual(resp.error.code, ErrorCode.INVALID_REQUEST)
        self.assertEqual(p.calls, 0)


class CompositionContractTests(unittest.TestCase):
    def test_profile_claiming_more_than_provider_offers_is_a_config_error(self):
        with self.assertRaises(ConfigError):
            _assemble(model("stream_model", "alpha", streaming=True), {"alpha": CountingProvider("alpha")}, 2)

    def test_profile_within_provider_capabilities_is_accepted(self):
        core = _assemble(model("plain_model", "alpha"), {"alpha": CountingProvider("alpha")}, 2)
        self.assertIsInstance(core, SanourCore)


class OpenAIAdapterDeclarationTests(unittest.TestCase):
    def test_openai_adapter_declares_only_text_generation(self):
        self.assertEqual(OpenAIProvider.capabilities, ProviderCapabilities(text_generation=True))


if __name__ == "__main__":
    unittest.main()
