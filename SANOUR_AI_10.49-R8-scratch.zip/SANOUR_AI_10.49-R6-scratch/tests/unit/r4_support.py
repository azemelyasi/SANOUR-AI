"""Shared test support for Stage 10.49-R4: a recording durable sink, a failing sink, and child-process scripts.

Child processes touch only temporary SQLite files and exit with os._exit where a process death must be simulated.
"""

import os
import sqlite3
import subprocess
import sys
from pathlib import Path

from sanour_ai.governance.sink import DurableSqliteSink, SinkFailed

REPO = Path(__file__).resolve().parents[2]
SRC = REPO / "src"
ACTOR = "ops.alice"


def committed_outbox(gov_path, key) -> bool:
    conn = sqlite3.connect(gov_path, timeout=10)
    try:
        return conn.execute("SELECT COUNT(*) FROM audit_outbox WHERE event_key = ?", (key,)).fetchone()[0] == 1
    finally:
        conn.close()


class RecordingSink(DurableSqliteSink):
    """A real DurableSqliteSink that also records every attempt, and whether the governance decision was already
    committed (visible to another connection) when the sink was called."""

    def __init__(self, sink_path, gov_path):
        super().__init__(sink_path)
        self.gov_path = gov_path
        self.attempts = []
        self.accepted = []
        self.receipts = []
        self.down = False

    def deliver(self, outbox_key, event, fields):
        self.attempts.append((event, outbox_key, committed_outbox(self.gov_path, outbox_key)))
        if self.down:
            raise SinkFailed("test sink down")
        receipt = super().deliver(outbox_key, event, fields)
        self.accepted.append((event, outbox_key))
        self.receipts.append(receipt)
        return receipt

    def accepted_keys(self, event=None):
        return [k for e, k in self.accepted if event is None or e == event]


class DownSink:
    """A sink that always fails and records nothing."""

    def __init__(self):
        self.attempts = 0

    def deliver(self, outbox_key, event, fields):
        self.attempts += 1
        raise SinkFailed("sink down")

    def close(self):
        pass


CRASH_CHILD = r'''
import logging, os, sys
from sanour_ai.governance.store import GovernanceStore
from sanour_ai.governance.admission import AdmissionController
from sanour_ai.governance.sink import DurableSqliteSink
from sanour_ai.observability.audit import AuditLogger
from tests.unit.test_stage1049 import BOUNDS, Clock
gov, sinkp, mode, receipts, rid = sys.argv[1:6]

class CrashSink(DurableSqliteSink):
    def deliver(self, outbox_key, event, fields):
        if mode == "crash_before_sink":
            os._exit(3)                       # decision committed, row leased, sink never saw it
        receipt = super().deliver(outbox_key, event, fields)   # sink commit returned
        with open(receipts, "a") as fh:
            fh.write(f"{outbox_key} {receipt.receipt_id}\n")
        if mode == "crash_after_sink":
            os._exit(4)                       # sink committed; the outbox row is not yet marked delivered
        return receipt

s = GovernanceStore(gov)
c = AdmissionController(s, audit=AuditLogger(logging.getLogger("child")), bounds=BOUNDS, clock=Clock(),
                        authorized_actors=frozenset({"ops.alice"}), sink=CrashSink(sinkp))
c.write_off(rid, actor="ops.alice", reason="crash test")
'''

DELIVER_CHILD = r'''
import json, logging, os, sys, time
from sanour_ai.governance.store import GovernanceStore
from sanour_ai.governance.admission import AdmissionController
from sanour_ai.governance.sink import DurableSqliteSink
from sanour_ai.observability.audit import AuditLogger
from tests.unit.test_stage1049 import BOUNDS
gov, sinkp, out, go = sys.argv[1:5]
while not os.path.exists(go):
    time.sleep(0.002)
s = GovernanceStore(gov)
c = AdmissionController(s, audit=AuditLogger(logging.getLogger("child")), bounds=BOUNDS,
                        authorized_actors=frozenset({"ops.alice"}), sink=DurableSqliteSink(sinkp))
confirmed = c.deliver_outbox()
json.dump({"confirmed": confirmed}, open(out, "w"))
'''


def run_child(script, args, receipts=None):
    env = dict(os.environ, PYTHONPATH=f"{SRC}{os.pathsep}{REPO}")
    done = subprocess.run([sys.executable, "-c", script, *args], env=env, cwd=REPO, timeout=90, capture_output=True)
    return done


def spawn_child(script, args):
    env = dict(os.environ, PYTHONPATH=f"{SRC}{os.pathsep}{REPO}")
    return subprocess.Popen([sys.executable, "-c", script, *args], env=env, cwd=REPO,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
