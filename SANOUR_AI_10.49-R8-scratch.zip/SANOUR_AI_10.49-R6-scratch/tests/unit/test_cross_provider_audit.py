"""Stage 10.22 cross-provider audit tests. Fake transport only: no network, no real key, no SDK.

Covers the three urllib-based adapters (Anthropic, Gemini, Grok). The OpenAI adapter needs the SDK,
which is not installed here, so it is checked by source assertions only.
"""

from tests.support import request_identity_for as _rid
import json
import pathlib
import time
import unittest
import urllib.error
import urllib.request

from pydantic import SecretStr

from sanour_ai.errors import ErrorCode, SanourError
from sanour_ai.models.base import ModelCall, ProviderError
from sanour_ai.models.capabilities import ModelCapabilities, ModelProfile, ProviderCapabilities
from sanour_ai.models.gateway import ModelGateway
from sanour_ai.providers import anthropic_provider as anth
from sanour_ai.providers import gemini_provider as gem
from sanour_ai.providers import grok_provider as grok

SRC = pathlib.Path(__file__).resolve().parents[2] / "src" / "sanour_ai" / "providers"
FAKE_KEY = "AUDIT-TESTONLY-KEY-0001"
MODEL = "audit-model-1"

# (module, class, key-setting env name, expected fixed URL)
ADAPTERS = [
    (anth, anth.AnthropicProvider, "ANTHROPIC_API_KEY", anth.PINNED_URL),
    (gem, gem.GeminiProvider, "GEMINI_API_KEY", None),
    (grok, grok.GrokProvider, "XAI_API_KEY", grok.PINNED_URL),
]


def _ok_body(name, model=MODEL, text="hello"):
    if name == "anthropic":
        return json.dumps({"content": [{"type": "text", "text": text}], "model": model,
                           "stop_reason": "end_turn"}).encode()
    if name == "gemini":
        return json.dumps({"candidates": [{"content": {"parts": [{"text": text}]}, "finishReason": "STOP"}],
                           "modelVersion": model}).encode()
    return json.dumps({"choices": [{"message": {"content": text}, "finish_reason": "stop"}],
                       "model": model}).encode()


class FakeTransport:
    def __init__(self, status=200, body=b"", raise_exc=None):
        self.status, self.body, self.raise_exc, self.calls = status, body, raise_exc, []

    def __call__(self, url, headers, body, timeout):
        self.calls.append({"url": url, "headers": headers, "body": body, "timeout": timeout})
        if self.raise_exc is not None:
            raise self.raise_exc
        return self.status, self.body


def _call(deadline_in=5.0, model=MODEL):
    return ModelCall(model_id=model, prompt="hi", max_output_tokens=16, deadline=time.monotonic() + deadline_in)


def _proxy_is_used(opener):
    """True if a request goes through an environment proxy. Uses a local socket, no network."""
    import os
    import socket
    import threading
    from unittest import mock

    server = socket.socket()
    server.bind(("127.0.0.1", 0))
    server.listen(1)
    server.settimeout(2)
    hit = []

    def accept_once():
        try:
            conn, _ = server.accept()
            hit.append(True)
            conn.close()
        except OSError:
            pass

    thread = threading.Thread(target=accept_once, daemon=True)
    thread.start()
    port = server.getsockname()[1]
    target = urllib.request.Request("http://127.0.0.1:9/x")  # closed port: fails fast, direct or via proxy
    with mock.patch.dict(os.environ, {"http_proxy": f"http://127.0.0.1:{port}"}):
        try:
            opener.open(target, timeout=1)
        except OSError:
            pass
    thread.join(timeout=3)
    server.close()
    return bool(hit)


class SharedContractTests(unittest.TestCase):
    def test_all_three_declare_text_only_and_pass_gateway_registration(self):
        for name, cls, _env, _url in ADAPTERS:
            with self.subTest(provider=cls.__name__):
                self.assertEqual(cls.capabilities, ProviderCapabilities(text_generation=True))
                ModelGateway({cls.name: cls(SecretStr(FAKE_KEY), transport=FakeTransport())}, max_concurrent_calls=1)

    def test_key_setting_names_match_documented_environment_variables(self):
        self.assertEqual(anth.ENV_ANTHROPIC_API_KEY, "ANTHROPIC_API_KEY")
        self.assertEqual(gem.ENV_GEMINI_API_KEY, "GEMINI_API_KEY")
        self.assertEqual(grok.ENV_XAI_API_KEY, "XAI_API_KEY")


class DeadlineAndNoRetryTests(unittest.TestCase):
    def test_every_adapter_refuses_missing_or_expired_deadline_before_io(self):
        for name, cls, _env, _url in ADAPTERS:
            t = FakeTransport(body=_ok_body(cls.name))
            p = cls(SecretStr(FAKE_KEY), transport=t)
            with self.subTest(provider=cls.name, case="none"), self.assertRaises(ProviderError):
                p.generate(ModelCall(model_id=MODEL, prompt="p", max_output_tokens=8, deadline=None))
            with self.subTest(provider=cls.name, case="expired"), self.assertRaises(ProviderError):
                p.generate(ModelCall(model_id=MODEL, prompt="p", max_output_tokens=8,
                                     deadline=time.monotonic() - 1))
            self.assertEqual(t.calls, [])

    def test_every_adapter_timeout_is_capped_and_within_remaining_budget(self):
        for name, cls, _env, _url in ADAPTERS:
            t = FakeTransport(body=_ok_body(cls.name))
            cls(SecretStr(FAKE_KEY), transport=t).generate(_call(deadline_in=2.0))
            with self.subTest(provider=cls.name):
                self.assertLessEqual(t.calls[0]["timeout"], 2.0)
                self.assertLessEqual(t.calls[0]["timeout"], 30.0)

    def test_rate_limit_and_server_error_are_one_attempt_through_gateway(self):
        for name, cls, _env, _url in ADAPTERS:
            for status, code in ((429, ErrorCode.PROVIDER_FAILED), (500, ErrorCode.PROVIDER_FAILED)):  # 429 unknown, 10.28
                t = FakeTransport(status=status, body=b"")
                gw = ModelGateway({cls.name: cls(SecretStr(FAKE_KEY), transport=t)}, max_concurrent_calls=1)
                profile = ModelProfile(
                    alias="audit_profile", provider=cls.name, model_id=MODEL,
                    capabilities=ModelCapabilities(text_generation=True, max_context_tokens=8192,
                                                   max_output_tokens=4096),
                )
                with self.subTest(provider=cls.name, status=status):
                    with self.assertRaises(SanourError) as ctx:
                        gw.generate(profile, _call(), time.monotonic() + 5, identity=_rid(profile))
                    self.assertEqual(ctx.exception.code, code)
                    self.assertEqual(len(t.calls), 1)


class SecretAndEndpointTests(unittest.TestCase):
    def test_key_absent_from_url_and_error_text_for_every_adapter(self):
        for name, cls, _env, _url in ADAPTERS:
            t = FakeTransport(status=401, body=('{"error": "echo ' + FAKE_KEY + '"}').encode())
            with self.subTest(provider=cls.name), self.assertRaises(ProviderError) as ctx:
                cls(SecretStr(FAKE_KEY), transport=t).generate(_call())
            self.assertNotIn(FAKE_KEY, str(ctx.exception) + repr(ctx.exception))
            self.assertNotIn(FAKE_KEY, t.calls[0]["url"])

    def test_fixed_https_endpoint_and_no_redirect_or_proxy_path(self):
        for name, cls, _env, url in ADAPTERS:
            t = FakeTransport(body=_ok_body(cls.name))
            cls(SecretStr(FAKE_KEY), transport=t).generate(_call())
            with self.subTest(provider=cls.name):
                self.assertTrue(t.calls[0]["url"].startswith("https://"))
                if url is not None:
                    self.assertEqual(t.calls[0]["url"], url)
                else:
                    self.assertTrue(t.calls[0]["url"].startswith(gem.PINNED_BASE))

    def test_each_module_refuses_redirects_and_ignores_environment_proxies(self):
        for name, cls, _env, _url in ADAPTERS:
            with self.subTest(provider=cls.name), self.assertRaises(urllib.error.HTTPError):
                _mod = __import__(cls.__module__, fromlist=["_RefuseRedirects"])
                _mod._RefuseRedirects().redirect_request(urllib.request.Request("https://x.invalid/"),
                                                         None, 302, "Found", {}, "https://evil.invalid/")
            self.assertTrue(any(isinstance(h, _mod._RefuseRedirects) for h in _mod._OPENER.handlers))
            self.assertFalse(_proxy_is_used(_mod._OPENER))
            for h in _mod._OPENER.handlers:
                if isinstance(h, urllib.request.ProxyHandler):
                    self.assertEqual(h.proxies, {})


class ResponseValidationTests(unittest.TestCase):
    def test_wrong_model_echo_rejected_by_gateway_for_every_adapter(self):
        for name, cls, _env, _url in ADAPTERS:
            t = FakeTransport(body=_ok_body(cls.name, model="other-model-9"))
            gw = ModelGateway({cls.name: cls(SecretStr(FAKE_KEY), transport=t)}, max_concurrent_calls=1)
            profile = ModelProfile(
                alias="audit_profile", provider=cls.name, model_id=MODEL,
                capabilities=ModelCapabilities(text_generation=True, max_context_tokens=8192,
                                               max_output_tokens=4096),
            )
            with self.subTest(provider=cls.name), self.assertRaises(SanourError) as ctx:
                gw.generate(profile, _call(), time.monotonic() + 5, identity=_rid(profile))
            self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_INVALID_RESPONSE)


class OpenAISourceTests(unittest.TestCase):
    """OpenAI needs the SDK, so only static properties are checked here."""

    def test_openai_source_pins_endpoint_and_disables_sdk_retries(self):
        text = (SRC / "openai_provider.py").read_text(encoding="utf-8")
        self.assertIn('PINNED_BASE_URL = "https://api.openai.com/v1"', text)
        self.assertIn("max_retries=0", text)


if __name__ == "__main__":
    unittest.main()
