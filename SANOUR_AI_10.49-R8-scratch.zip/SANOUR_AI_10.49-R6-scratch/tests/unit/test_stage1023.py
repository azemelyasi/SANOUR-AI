"""Stage 10.23 tests: shared error/transport location, end-of-response status, model id rule.

Fake transport and SimpleNamespace stand-ins only. No network, no real key, no SDK.
"""

from tests.support import request_identity_for as _rid
import json
import pathlib
import time
import unittest
import urllib.error
import urllib.request
from types import SimpleNamespace

from pydantic import SecretStr

from sanour_ai.errors import ErrorCode, SanourError
from sanour_ai.models.base import ModelCall, ProviderError
from sanour_ai.models.capabilities import ModelCapabilities, ModelProfile
from sanour_ai.models.gateway import ModelGateway
from sanour_ai.providers import anthropic_provider as anth
from sanour_ai.providers import common
from sanour_ai.providers import gemini_provider as gem
from sanour_ai.providers import grok_provider as grok
from sanour_ai.providers import openai_provider as oai
from sanour_ai.providers.common import IncompleteResponseError, RateLimitedError

PROVIDERS = pathlib.Path(__file__).resolve().parents[2] / "src" / "sanour_ai" / "providers"
MODEL = "stage-model-1"
KEY = "STAGE1023-TESTONLY-KEY"


class FakeTransport:
    def __init__(self, body, status=200):
        self.body, self.status, self.calls = body, status, []

    def __call__(self, url, headers, body, timeout):
        self.calls.append(url)
        return self.status, self.body


def _body(name, *, finish="ok", model=MODEL, text="hi"):
    """A well-formed body for each adapter. finish='ok' gives the complete status."""
    if name == "anthropic":
        return json.dumps({"model": model, "content": [{"type": "text", "text": text}],
                           "stop_reason": "end_turn" if finish == "ok" else finish}).encode()
    if name == "gemini":
        return json.dumps({"modelVersion": model, "candidates": [
            {"content": {"parts": [{"text": text}]}, "finishReason": "STOP" if finish == "ok" else finish}]}).encode()
    return json.dumps({"model": model, "choices": [
        {"message": {"content": text}, "finish_reason": "stop" if finish == "ok" else finish}]}).encode()


ADAPTERS = {
    "anthropic": (anth.AnthropicProvider, "max_tokens", "end_turn"),
    "gemini": (gem.GeminiProvider, "MAX_TOKENS", "STOP"),
    "grok": (grok.GrokProvider, "length", "stop"),
}


def _make(name, transport):
    cls = ADAPTERS[name][0]
    return cls(SecretStr(KEY), transport=transport)


def _call(model=MODEL):
    return ModelCall(model_id=model, prompt="p", max_output_tokens=16, deadline=time.monotonic() + 5)


def _profile(name):
    return ModelProfile(alias="stage_profile", provider=name, model_id=MODEL,
                        capabilities=ModelCapabilities(text_generation=True, max_context_tokens=8192,
                                                       max_output_tokens=4096))


class SharedLocationTests(unittest.TestCase):
    def test_rate_limit_error_is_the_shared_class_and_openai_reexports_it(self):
        self.assertIs(oai.RateLimitedError, common.RateLimitedError)
        self.assertIs(RateLimitedError, common.RateLimitedError)
        self.assertEqual(common.RateLimitedError.error_code, "provider_rate_limited")

    def test_urllib_adapters_do_not_import_the_openai_module(self):
        for f in ("anthropic_provider.py", "gemini_provider.py", "grok_provider.py"):
            with self.subTest(file=f):
                text = (PROVIDERS / f).read_text(encoding="utf-8")
                self.assertNotIn("from sanour_ai.providers.openai_provider", text)

    def test_all_three_share_one_opener_and_one_transport(self):
        for name, (cls, _m, _c) in ADAPTERS.items():
            mod = __import__(cls.__module__, fromlist=["x"])
            with self.subTest(provider=name):
                self.assertIs(mod._OPENER, common.OPENER)
                self.assertIs(mod._RefuseRedirects, common.RefuseRedirects)
                self.assertIs(mod.default_transport, common.default_transport)

    def test_shared_opener_refuses_redirects_and_has_no_env_proxy(self):
        with self.assertRaises(urllib.error.HTTPError):
            common.RefuseRedirects().redirect_request(urllib.request.Request("https://x.invalid/"),
                                                      None, 301, "Moved", {}, "https://evil.invalid/")
        proxies = [h for h in common.OPENER.handlers if isinstance(h, urllib.request.ProxyHandler)]
        self.assertTrue(all(h.proxies == {} for h in proxies))


class EndOfResponseTests(unittest.TestCase):
    def test_complete_response_is_success_for_each_adapter(self):
        for name, (_cls, _trunc, complete) in ADAPTERS.items():
            with self.subTest(provider=name):
                result = _make(name, FakeTransport(_body(name))).generate(_call())
                self.assertEqual(result.text, "hi")
                self.assertEqual(result.reported_model_id, MODEL)

    def test_token_limit_cut_off_is_refused_for_each_adapter(self):
        for name, (_cls, truncated, _c) in ADAPTERS.items():
            with self.subTest(provider=name):
                t = FakeTransport(_body(name, finish=truncated))
                with self.assertRaises(IncompleteResponseError) as ctx:
                    _make(name, t).generate(_call())
                self.assertFalse(ctx.exception.retryable)
                self.assertEqual(len(t.calls), 1)

    def test_unknown_or_missing_status_is_refused_for_each_adapter(self):
        for name in ADAPTERS:
            for finish in ("refusal-or-other", "tool_use"):
                with self.subTest(provider=name, finish=finish), self.assertRaises(IncompleteResponseError):
                    _make(name, FakeTransport(_body(name, finish=finish))).generate(_call())
            if name != "gemini":  # Gemini SAFETY is a content block since Stage 10.27
                with self.subTest(provider=name, finish="SAFETY"), self.assertRaises(IncompleteResponseError):
                    _make(name, FakeTransport(_body(name, finish="SAFETY"))).generate(_call())
        for name in ADAPTERS:
            body = json.dumps({"model": MODEL, "content": [{"type": "text", "text": "x"}]}).encode()
            if name == "gemini":
                body = json.dumps({"modelVersion": MODEL, "candidates": [
                    {"content": {"parts": [{"text": "x"}]}}]}).encode()
            if name == "grok":
                body = json.dumps({"model": MODEL, "choices": [{"message": {"content": "x"}}]}).encode()
            with self.subTest(provider=name, case="missing"), self.assertRaises(IncompleteResponseError):
                _make(name, FakeTransport(body)).generate(_call())

    def test_gemini_candidate_without_finish_reason_is_refused_not_empty(self):
        body = json.dumps({"candidates": [{"content": 1}]}).encode()
        with self.assertRaises(IncompleteResponseError):
            _make("gemini", FakeTransport(body)).generate(_call())

    def test_gateway_reports_truncated_and_unknown_as_invalid_response_not_success(self):
        for name, (_cls, truncated, _c) in ADAPTERS.items():
            for finish in (truncated, "unknown-status"):
                with self.subTest(provider=name, finish=finish):
                    t = FakeTransport(_body(name, finish=finish))
                    gw = ModelGateway({name: _make(name, t)}, max_concurrent_calls=1)
                    with self.assertRaises(SanourError) as ctx:
                        gw.generate(_profile(name), _call(), time.monotonic() + 5, identity=_rid(_profile(name)))
                    self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_INVALID_RESPONSE)
                    self.assertFalse(ctx.exception.retryable)
                    self.assertEqual(len(t.calls), 1)
                    stats = gw.stats()
                    self.assertEqual(stats.successful_calls, 0)
                    self.assertEqual(stats.invalid_responses, 1)


class ModelIdInvariantTests(unittest.TestCase):
    def test_anthropic_rejects_invalid_model_id_before_io(self):
        for bad in ("../x", "a/b", "", "name with space", "m" * 129):
            with self.subTest(bad=bad):
                t = FakeTransport(_body("anthropic"))
                with self.assertRaises(ProviderError) as ctx:
                    _make("anthropic", t).generate(_call(model=bad))
                self.assertFalse(ctx.exception.retryable)
                self.assertEqual(t.calls, [])

    def test_wrong_model_echo_is_rejected_by_gateway_for_each_adapter(self):
        for name in ADAPTERS:
            with self.subTest(provider=name):
                t = FakeTransport(_body(name, model="other-model-9"))
                gw = ModelGateway({name: _make(name, t)}, max_concurrent_calls=1)
                with self.assertRaises(SanourError) as ctx:
                    gw.generate(_profile(name), _call(), time.monotonic() + 5, identity=_rid(_profile(name)))
                self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_INVALID_RESPONSE)


class OpenAIResponseStatusTests(unittest.TestCase):
    """_to_result is a static method, so it is checked without the SDK."""

    def test_completed_response_is_success(self):
        r = oai.OpenAIProvider._to_result(SimpleNamespace(status="completed", output_text="hi", model=MODEL))
        self.assertEqual((r.text, r.reported_model_id), ("hi", MODEL))

    def test_incomplete_response_is_refused(self):
        resp = SimpleNamespace(status="incomplete", output_text="partial", model=MODEL,
                               incomplete_details=SimpleNamespace(reason="max_output_tokens"))
        with self.assertRaises(IncompleteResponseError):
            oai.OpenAIProvider._to_result(resp)

    def test_missing_or_unknown_status_is_refused(self):
        for resp in (SimpleNamespace(output_text="hi", model=MODEL),
                     SimpleNamespace(status="in_progress", output_text="hi", model=MODEL),
                     SimpleNamespace(status="failed", output_text="", model=MODEL)):
            with self.subTest(status=getattr(resp, "status", None)), self.assertRaises(IncompleteResponseError):
                oai.OpenAIProvider._to_result(resp)


class DeadlineAndNoRetryUnchangedTests(unittest.TestCase):
    def test_expired_deadline_still_refuses_before_io(self):
        for name in ADAPTERS:
            t = FakeTransport(_body(name))
            with self.subTest(provider=name), self.assertRaises(ProviderError):
                _make(name, t).generate(ModelCall(model_id=MODEL, prompt="p", max_output_tokens=8,
                                                  deadline=time.monotonic() - 1))
            self.assertEqual(t.calls, [])

    def test_unknown_429_still_single_attempt_and_not_retryable(self):
        # Stage 10.28: an empty 429 body is unknown, so it maps to PROVIDER_FAILED, not retryable.
        for name in ADAPTERS:
            t = FakeTransport(b"", status=429)
            gw = ModelGateway({name: _make(name, t)}, max_concurrent_calls=1)
            with self.subTest(provider=name), self.assertRaises(SanourError) as ctx:
                gw.generate(_profile(name), _call(), time.monotonic() + 5, identity=_rid(_profile(name)))
            self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_FAILED)
            self.assertFalse(ctx.exception.retryable)
            self.assertEqual(len(t.calls), 1)


if __name__ == "__main__":
    unittest.main()
