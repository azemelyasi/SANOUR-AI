"""Stage 10.49-R6: crash/restart at settlement boundaries, concurrent recovery, and audit-failure independence.

Invariants under test:
- a process that dies after the settlement intent is committed but before the apply commits leaves the intent
  pending (no cost record, no budget movement); a restarted process applies it exactly once;
- concurrent recovery workers apply each pending intent exactly once (one cost record per request);
- an audit sink failure after a committed settlement never changes the financial outcome;
- a failed recovery read is visible (counter and audit event), never a silent zero.
"""

import json
import logging
import os
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from decimal import Decimal

from sanour_ai.governance.admission import AdmissionController
from sanour_ai.governance.reconcile import reconcile
from sanour_ai.governance.sink import DurableSqliteSink
from sanour_ai.governance.sink_contract import SinkFailed
from sanour_ai.governance.store import GovernanceStore
from sanour_ai.governance.types import Settlement
from sanour_ai.models.usage import Usage
from sanour_ai.observability.audit import AuditLogger
from tests.unit.r5_support import RaiseOn
from tests.unit.test_stage1049 import BOUNDS, Clock, GovBase, pricing, request, profile

REPO = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
SRC = os.path.join(REPO, "src")
USAGE = Usage(input_tokens=4, output_tokens=2, total_tokens=6)
PRICED = Decimal("0.000024")

# The child admits nothing itself: the parent creates reservations, then the child settles one and dies at a point.
SETTLE_CHILD = r'''
import logging, sys
from sanour_ai.governance.admission import AdmissionController
from sanour_ai.governance.store import GovernanceStore
from sanour_ai.governance.sink import DurableSqliteSink
from sanour_ai.governance.types import Settlement
from sanour_ai.models.usage import Usage
from sanour_ai.observability.audit import AuditLogger
from tests.unit.r5_support import DieBefore
from tests.unit.test_stage1049 import BOUNDS, Clock
gov, rid = sys.argv[1:3]
store = GovernanceStore(gov)
store._conn = DieBefore(store._conn, "INSERT INTO cost_records", 7)  # noqa: SLF001
ctl = AdmissionController(store, audit=AuditLogger(logging.getLogger("child")), bounds=BOUNDS, clock=Clock(),
                          sink=DurableSqliteSink(gov + ".sink"))
ctl.settle_by_id(rid, Settlement("completed", provider_started=True,
                                 usage=Usage(input_tokens=4, output_tokens=2, total_tokens=6)))
raise SystemExit(0)
'''

SWEEP_CHILD = r'''
import json, logging, sys
from sanour_ai.governance.admission import AdmissionController
from sanour_ai.governance.store import GovernanceStore
from sanour_ai.governance.sink import DurableSqliteSink
from sanour_ai.observability.audit import AuditLogger
from tests.unit.test_stage1049 import BOUNDS, Clock
gov, out = sys.argv[1:3]
store = GovernanceStore(gov)
ctl = AdmissionController(store, audit=AuditLogger(logging.getLogger("child")), bounds=BOUNDS, clock=Clock(),
                          sink=DurableSqliteSink(gov + ".sink"))
applied = ctl.sweep()
store.close()
json.dump({"applied": applied}, open(out, "w"))
'''


def run(script, *args):
    env = dict(os.environ, PYTHONPATH=f"{SRC}{os.pathsep}{REPO}")
    return subprocess.run([sys.executable, "-c", script, *args], env=env, cwd=REPO, timeout=120,
                          capture_output=True)


class DownSink(DurableSqliteSink):
    """Healthy until `down` is set. Admission events are fail-closed (a sink failure there refuses the request), so
    the tests bring the sink down only after admission, which is the case under test: settlement-time audit."""

    down = False

    def deliver(self, *args, **kwargs):
        if self.down:
            raise SinkFailed("sink down")
        return super().deliver(*args, **kwargs)


class RecoveryBase(GovBase):
    def setUp(self):
        super().setUp()
        s = self.store()
        s.upsert_pricing(pricing())
        s.upsert_budget("global", "", "daily", "USD", "1.00")

    def controller(self, store=None, clock=None, bounds=BOUNDS, audit=None, sink=None):
        return AdmissionController(store or self.store(), audit=audit or AuditLogger(logging.getLogger("t6")),
                                   bounds=bounds, clock=clock or self.clock,
                                   sink=sink or DurableSqliteSink(self.path + ".sink", clock=self.clock))

    def admit_one(self):
        ctl = self.controller()
        ticket = ctl.admit(request(), profile())
        return ctl, ticket.request_id

    def cost_rows(self):
        return self.row_all("SELECT request_id, actual_cost FROM cost_records")

    def spent_global(self):
        return Decimal(self.row("SELECT spent FROM budget_windows LIMIT 1")[0])


class CrashBetweenIntentAndApply(RecoveryBase):
    def test_death_after_intent_commit_leaves_intent_pending_and_unapplied(self):
        _, rid = self.admit_one()
        done = run(SETTLE_CHILD, self.path, rid)
        self.assertEqual(done.returncode, 7, done.stderr.decode())
        self.assertEqual(self.row("SELECT state FROM reservations WHERE request_id = ?", rid)[0],
                         "settlement_pending")
        self.assertIsNotNone(self.row("SELECT intent_digest FROM reservations WHERE request_id = ?", rid)[0])
        self.assertEqual(self.cost_rows(), [])
        self.assertEqual(self.spent_global(), Decimal(0))

    def test_restart_recovery_applies_the_intent_exactly_once(self):
        _, rid = self.admit_one()
        self.assertEqual(run(SETTLE_CHILD, self.path, rid).returncode, 7)
        restarted = self.controller()  # a fresh process would do the same: new store, new controller
        self.assertEqual(restarted.sweep(), 1)
        self.assertEqual(restarted.sweep(), 0)  # second recovery pass finds nothing
        self.assertEqual(self.row("SELECT state FROM reservations WHERE request_id = ?", rid)[0], "settled")
        self.assertEqual(self.cost_rows(), [(rid, "0.000024")])
        self.assertEqual(self.spent_global(), PRICED)

    def test_reconciler_reports_the_pending_settlement_before_recovery(self):
        _, rid = self.admit_one()
        self.assertEqual(run(SETTLE_CHILD, self.path, rid).returncode, 7)
        r = reconcile(self.path, now=self.clock.now)
        self.assertEqual(r["reservations"]["pending_settlement_count"], 1)
        self.assertTrue(r["ok"], r["findings"])  # pending is a warning, not an inconsistency
        self.assertEqual(self.row("SELECT state FROM reservations WHERE request_id = ?", rid)[0],
                         "settlement_pending")  # the reconciler did not repair anything

    def test_restart_recovery_is_idempotent_across_repeated_crashes(self):
        _, rid = self.admit_one()
        self.assertEqual(run(SETTLE_CHILD, self.path, rid).returncode, 7)
        self.assertEqual(self.controller().sweep(), 1)
        self.assertEqual(self.controller().sweep(), 0)
        self.assertEqual(len(self.cost_rows()), 1)


class ConcurrentRecovery(RecoveryBase):
    def test_concurrent_sweep_workers_apply_each_intent_once(self):
        rids = []
        for _ in range(4):
            _, rid = self.admit_one()
            self.assertEqual(run(SETTLE_CHILD, self.path, rid).returncode, 7)
            rids.append(rid)
        outs = [os.path.join(self._dir.name, f"out{i}.json") for i in range(3)]
        procs = [subprocess.Popen([sys.executable, "-c", SWEEP_CHILD, self.path, out],
                                  env=dict(os.environ, PYTHONPATH=f"{SRC}{os.pathsep}{REPO}"), cwd=REPO,
                                  stdout=subprocess.PIPE, stderr=subprocess.PIPE) for out in outs]
        for p in procs:
            _, err = p.communicate(timeout=120)
            self.assertEqual(p.returncode, 0, err.decode())
        self.assertEqual(sorted(r for r, _ in self.cost_rows()), sorted(rids))  # one cost row per request
        self.assertEqual(self.spent_global(), PRICED * len(rids))
        applied = 0
        for o in outs:
            with open(o) as fh:
                applied += json.load(fh)["applied"]
        self.assertEqual(applied, len(rids))  # every intent applied by exactly one worker

    def test_overlapping_recovery_passes_do_not_double_count_budget(self):
        _, rid = self.admit_one()
        self.assertEqual(run(SETTLE_CHILD, self.path, rid).returncode, 7)
        out = os.path.join(self._dir.name, "sweep.json")
        p = subprocess.Popen([sys.executable, "-c", SWEEP_CHILD, self.path, out],
                             env=dict(os.environ, PYTHONPATH=f"{SRC}{os.pathsep}{REPO}"), cwd=REPO,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        self.controller().sweep()
        _, err = p.communicate(timeout=120)
        self.assertEqual(p.returncode, 0, err.decode())
        self.assertEqual(len(self.cost_rows()), 1)
        self.assertEqual(self.spent_global(), PRICED)


class AuditFailureIsIndependent(RecoveryBase):
    def test_sink_failure_after_commit_never_changes_the_financial_decision(self):
        sink = DownSink(self.path + ".sink", clock=self.clock)
        ctl = self.controller(sink=sink)
        ticket = ctl.admit(request(), profile())
        sink.down = True
        result = ctl.settle(ticket, Settlement("completed", provider_started=True, usage=USAGE))
        self.assertTrue(result.applied)
        self.assertEqual(self.row("SELECT state FROM reservations WHERE request_id = ?", ticket.request_id)[0],
                         "settled")
        self.assertEqual(self.cost_rows(), [(ticket.request_id, "0.000024")])
        self.assertEqual(self.spent_global(), PRICED)
        # The admission event was delivered before the sink went down; the settlement events are failed, never
        # reported as delivered, and the committed financial state above is unchanged.
        self.assertGreaterEqual(self.row("SELECT COUNT(*) FROM audit_outbox WHERE status = 'failed'")[0], 1)
        self.assertEqual(self.row("SELECT COUNT(*) FROM audit_outbox WHERE status = 'pending'")[0], 0)
        r = reconcile(self.path, now=self.clock.now)
        self.assertTrue(r["ok"], r["findings"])
        self.assertIn("AUDIT_FAILED", {i["code"] for i in r["findings"]["items"]})

    def test_later_sink_recovery_delivers_without_touching_money(self):
        sink = DownSink(self.path + ".sink", clock=self.clock)
        ctl = self.controller(sink=sink)
        ticket = ctl.admit(request(), profile())
        sink.down = True
        ctl.settle(ticket, Settlement("completed", provider_started=True, usage=USAGE))
        sink.down = False
        healthy = self.controller()
        healthy.deliver_outbox()
        self.assertEqual({r[0] for r in self.row_all("SELECT status FROM audit_outbox")}, {"delivered"})
        self.assertEqual(self.spent_global(), PRICED)
        self.assertEqual(len(self.cost_rows()), 1)


class VisibleRecoveryFailure(RecoveryBase):
    def test_failed_recovery_read_is_counted_and_audited_not_silent(self):
        _, rid = self.admit_one()
        self.assertEqual(run(SETTLE_CHILD, self.path, rid).returncode, 7)
        store = self.store()
        store._conn = RaiseOn(store._conn, "SELECT request_id FROM reservations WHERE state = 'settlement_pending'")  # noqa: SLF001
        ctl = self.controller(store=store)
        self.assertEqual(ctl.sweep(), 0)
        self.assertGreaterEqual(ctl.recovery_read_failures, 1)
        self.assertEqual(self.row("SELECT state FROM reservations WHERE request_id = ?", rid)[0],
                         "settlement_pending")  # nothing applied, nothing lost
        self.assertEqual(self.cost_rows(), [])
        self.assertEqual(self.controller().sweep(), 1)  # the next healthy pass recovers it


if __name__ == "__main__":
    unittest.main()
