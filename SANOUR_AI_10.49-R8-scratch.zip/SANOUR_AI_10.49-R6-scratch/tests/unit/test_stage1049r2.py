"""Stage 10.49-R2: durable usage intent, exposure resolution, governance reporting, audit and security.

Deterministic and offline. Crash and concurrency tests use child processes that touch only a temporary SQLite file.
"""

import contextlib
import datetime as _dt
import logging
import os
import subprocess
import sys
import tempfile
import threading
import unittest
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

from sanour_ai.errors import ErrorCode, SanourError
from sanour_ai.governance import budget, quota
from sanour_ai.governance.admission import AdmissionController
from sanour_ai.governance.reporting import _money_sum, governance_report
from sanour_ai.governance.store import _MIGRATIONS, GovernanceStore
from sanour_ai.governance.types import Bounds, Settlement
from sanour_ai.governance.cost import PricingVersion
from sanour_ai.models.usage import Usage
from sanour_ai.observability.audit import AUDIT_LOGGER_NAME, AuditLogger
from tests.unit.r4_support import DownSink
from tests.unit.test_stage1049 import ALIAS, BOUNDS, MODEL, PROVIDER, WORST_512, Clock, T0, pricing, profile, request

SRC = Path(__file__).resolve().parents[2] / "src"
DAY = "2026-11-07"
ACTUAL_24 = Decimal("0.000024")
VALID = Usage(input_tokens=4, output_tokens=2)
ACTOR = "ops.alice"
PHASE2 = "UPDATE reservations SET state = ?, settled_at"
PHASE1 = "UPDATE reservations SET state = 'settlement_pending'"


class _FailOn:
    def __init__(self, real, prefix):
        self._real, self._prefix = real, prefix

    def execute(self, sql, *args):
        if sql.startswith(self._prefix):
            raise sqlite3_error()
        return self._real.execute(sql, *args)

    def close(self):
        self._real.close()


def sqlite3_error():
    import sqlite3
    return sqlite3.OperationalError("disk I/O error")


class R2(unittest.TestCase):
    def setUp(self):
        self._dir = tempfile.TemporaryDirectory()
        self.addCleanup(self._dir.cleanup)
        self.path = os.path.join(self._dir.name, "gov.db")
        self.clock = Clock()
        self.s = self.store()
        self.s.upsert_pricing(pricing())
        self.bid = self.s.upsert_budget("global", "", "daily", "USD", "1.00")
        self.c = self.controller(self.s)

    def controller_with_bounds(self, store, aliases):
        bounds = dict(BOUNDS)
        for alias in aliases:
            bounds[alias] = Bounds(max_input_tokens=8192, max_output_tokens=1024)
        return AdmissionController(store, audit=AuditLogger(logging.getLogger("test.1049r2")), bounds=bounds,
                                   clock=self.clock, authorized_actors=frozenset({ACTOR}))

    def store(self):
        s = GovernanceStore(self.path)
        self.addCleanup(s.close)
        return s

    def controller(self, store=None, audit=None, actors=frozenset({ACTOR})):
        return AdmissionController(store or self.s, audit=audit or AuditLogger(logging.getLogger("test.1049r2")),
                                   bounds=BOUNDS, clock=self.clock, authorized_actors=actors)

    def row(self, sql, *args):
        import sqlite3
        conn = sqlite3.connect(self.path)
        try:
            return conn.execute(sql, args).fetchone()
        finally:
            conn.close()

    def win(self, column, table="budget_windows", key="budget_id", key_value=None):
        key_value = self.bid if key_value is None else key_value
        r = self.row(f"SELECT {column} FROM {table} WHERE {key} = ?", key_value)
        return Decimal(r[0]) if r else Decimal(0)

    def state(self, rid=None):
        if rid is None:
            return self.row("SELECT state FROM reservations")[0]
        return self.row("SELECT state FROM reservations WHERE request_id = ?", rid)[0]

    def fail_next(self, prefix):
        real = self.s._conn  # noqa: SLF001
        self.s._conn = _FailOn(real, prefix)  # noqa: SLF001
        return real

    def restore(self, real):
        self.s._conn = real  # noqa: SLF001


# ------------------------------------------------------------ 1. durable usage intent
class DurableIntent(R2):
    def test_crash_after_intent_persistence_before_settlement_completion(self):
        """A real child process records the usage intent, then dies inside the final settlement write."""
        t = self.c.admit(request(), profile())
        self.s.close()
        child = (
            "import os, sys, logging\n"
            f"sys.path.insert(0, {str(SRC)!r})\n"
            "import datetime\n"
            "from sanour_ai.governance.store import GovernanceStore\n"
            "from sanour_ai.governance.admission import AdmissionController\n"
            "from sanour_ai.governance.types import Bounds, Settlement\n"
            "from sanour_ai.models.usage import Usage\n"
            "from sanour_ai.observability.audit import AuditLogger\n"
            "store = GovernanceStore(sys.argv[1])\n"
            "clock = lambda: datetime.datetime(2026, 11, 7, 12, tzinfo=datetime.timezone.utc).timestamp()\n"
            "c = AdmissionController(store, audit=AuditLogger(logging.getLogger('child')), "
            "bounds={'openai_primary': Bounds(8192, 1024)}, clock=clock)\n"
            "real = store._conn\n"
            "class Crash:\n"
            "    def execute(self, sql, *args):\n"
            "        if sql.startswith(\"UPDATE reservations SET state = ?, settled_at\"):\n"
            "            os._exit(9)  # crash after the intent is durable, before the apply commits\n"
            "        return real.execute(sql, *args)\n"
            "store._conn = Crash()\n"
            "c.settle_by_id(sys.argv[2], Settlement('completed', True, Usage(input_tokens=4, output_tokens=2)))\n"
        )
        proc = subprocess.run([sys.executable, "-c", child, self.path, t.request_id], capture_output=True,
                              text=True, timeout=120)
        self.assertEqual(proc.returncode, 9, proc.stderr)
        self.assertEqual(self.state(), "settlement_pending")  # the usage survived the crash
        self.assertEqual(self.row("SELECT intent_input, intent_output FROM reservations")[:2], (4, 2))
        self.s = self.store()
        recovered = self.controller(self.s)
        self.assertEqual(recovered.sweep(), 1)
        self.assertEqual(self.state(), "settled")
        self.assertEqual(self.win("spent"), ACTUAL_24)

    def test_failed_later_phase_keeps_the_only_copy_of_the_usage(self):
        t = self.c.admit(request(), profile())
        real = self.fail_next(PHASE2)
        self.c.settle(t, Settlement("completed", True, VALID))
        self.restore(real)
        self.assertEqual(self.row("SELECT intent_input, intent_output, intent_kind FROM reservations")[:3],
                         (4, 2, "completed"))
        self.assertEqual(self.state(), "settlement_pending")

    def test_duplicate_usage_intent_is_a_no_op_and_never_double_counts(self):
        t = self.c.admit(request(), profile())
        self.assertTrue(self.c.settle(t, Settlement("completed", True, VALID)).applied)
        again = self.c.settle(t, Settlement("completed", True, VALID))
        self.assertFalse(again.applied)
        self.assertEqual(again.reason, "already_settled")
        self.assertEqual(self.win("spent"), ACTUAL_24)

    def test_different_usage_for_a_pending_intent_is_a_conflict_and_the_first_one_is_kept(self):
        t = self.c.admit(request(), profile())
        real = self.fail_next(PHASE2)
        self.c.settle(t, Settlement("completed", True, VALID))  # first intent stored, apply fails
        self.restore(real)
        conflicting = self.c.settle(t, Settlement("completed", True, Usage(input_tokens=1, output_tokens=1)))
        self.assertEqual(conflicting.reason, "intent_conflict")
        # the stored first digest must survive the conflict: the original outcome is still a duplicate, not a conflict
        retry = self.c.settle(t, Settlement("completed", True, VALID))
        self.assertNotEqual(retry.reason, "intent_conflict")
        self.assertEqual(self.win("spent"), ACTUAL_24)
        self.c.sweep()
        self.assertEqual(self.win("spent"), ACTUAL_24)  # the stored first intent, not the conflicting one

    def test_partial_usage_is_unknown_cost_and_exposure_never_zero(self):
        t = self.c.admit(request(), profile())
        self.c.settle(t, Settlement("completed", True, Usage(input_tokens=4, output_tokens=None)))
        self.assertEqual(self.state(), "exposed")
        self.assertEqual(self.win("spent"), Decimal(0))
        self.assertEqual(self.win("exposed"), WORST_512)
        self.assertEqual(self.row("SELECT cost_status, actual_cost FROM cost_records")[:2], ("unknown_usage", None))


# ------------------------------------------------------- restart and concurrent recovery
class RecoveryPaths(R2):
    def test_restart_after_failed_recovery_keeps_the_exposure_reserved(self):
        t = self.c.admit(request(), profile())
        real = self.fail_next(PHASE2)
        self.c.settle(t, Settlement("completed", True, VALID))
        self.c.sweep()  # recovery attempt fails too
        self.restore(real)
        self.s.close()
        self.s = self.store()
        self.s.upsert_budget("global", "", "daily", "USD", "0.03")  # room for one more worst case only
        c2 = self.controller(self.s)
        self.assertEqual(self.state(), "settlement_pending")
        self.assertEqual(self.win("reserved"), WORST_512)  # still held against the budget
        self.assertEqual(self.win("spent"), Decimal(0))
        with self.assertRaises(SanourError):
            c2.admit(request(), profile())  # availability already includes the unresolved reservation

    def test_concurrent_recovery_applies_the_stored_intent_exactly_once(self):
        t = self.c.admit(request(), profile())
        real = self.fail_next(PHASE2)
        self.c.settle(t, Settlement("completed", True, VALID))
        self.restore(real)
        self.s.close()
        script = (
            "import sys, logging\n"
            f"sys.path.insert(0, {str(SRC)!r})\n"
            "from sanour_ai.governance.store import GovernanceStore\n"
            "from sanour_ai.governance.admission import AdmissionController\n"
            "from sanour_ai.observability.audit import AuditLogger\n"
            "from tests.unit.test_stage1049 import BOUNDS, T0, Clock\n"
            "store = GovernanceStore(sys.argv[1])\n"
            "c = AdmissionController(store, audit=AuditLogger(logging.getLogger('child')), bounds=BOUNDS, "
            "clock=Clock(T0))\n"
            "print(c.sweep())\n"
        )
        procs = [subprocess.Popen([sys.executable, "-c", script, self.path], stdout=subprocess.PIPE,
                                  stderr=subprocess.PIPE, text=True, cwd=str(SRC.parent)) for _ in range(3)]
        applied = 0
        for p in procs:
            out, err = p.communicate(timeout=120)
            self.assertEqual(p.returncode, 0, err)
            applied += int(out.strip().splitlines()[-1])
        self.assertEqual(applied, 1)
        self.s = self.store()
        self.assertEqual(self.win("spent"), ACTUAL_24)
        self.assertEqual(self.row("SELECT COUNT(*) FROM cost_records")[0], 1)

    def test_expired_reservation_becomes_exposure_not_spending_across_restart(self):
        self.c.admit(request(timeout=5), profile())
        self.s.close()
        self.s = self.store()
        later = AdmissionController(self.s, audit=AuditLogger(logging.getLogger("t")), bounds=BOUNDS,
                                    clock=Clock(T0 + 100_000))
        self.assertEqual(later.sweep(), 1)
        self.assertEqual(self.state(), "exposed")
        self.assertEqual(self.win("spent"), Decimal(0))
        self.assertEqual(self.win("exposed"), WORST_512)


# -------------------------------------------------------- 2. explicit exposure resolution
class ExposureResolution(R2):
    def exposed_request(self):
        t = self.c.admit(request(), profile())
        self.c.settle(t, Settlement("failed", True))
        self.assertEqual(self.state(), "exposed")
        return t.request_id

    def test_verified_usage_reconciliation_is_recorded_with_evidence(self):
        rid = self.exposed_request()
        result = self.c.resolve_exposure(rid, VALID, actor=ACTOR, evidence_ref="billing-export-2026-11-07")
        self.assertTrue(result.applied)
        self.assertEqual(self.win("spent"), ACTUAL_24)
        self.assertEqual(self.win("exposed"), Decimal(0))
        self.assertEqual(self.row("SELECT resolution, actor, evidence_ref FROM exposure_resolutions")[:3],
                         ("verified_usage", ACTOR, "billing-export-2026-11-07"))

    def test_authorized_write_off_is_recorded_and_never_actual_cost(self):
        rid = self.exposed_request()
        result = self.c.write_off(rid, actor=ACTOR, reason="provider could not confirm usage",
                                  evidence_ref="ticket-42")
        self.assertTrue(result.applied)
        self.assertEqual(self.win("spent"), Decimal(0))  # no fabricated spending
        self.assertEqual(self.win("exposed"), Decimal(0))
        self.assertEqual(self.win("written_off"), WORST_512)
        self.assertEqual(self.state(rid), "written_off")
        self.assertIsNone(self.row("SELECT actual_cost FROM cost_records")[0])
        self.assertEqual(self.row("SELECT actor, reason FROM exposure_resolutions")[:2],
                         (ACTOR, "provider could not confirm usage"))

    def test_write_off_releases_availability_but_is_not_spending(self):
        rid = self.exposed_request()
        self.c.write_off(rid, actor=ACTOR, reason="reviewed")
        report = self.c.report(DAY)["budgets"][0]
        self.assertEqual(report["actual_spent"], "0")
        self.assertEqual(report["written_off"], "0.02048")
        self.assertEqual(report["available"], "1.00")  # the limit again; the write-off is not spending

    def test_retain_keeps_exposure_and_changes_no_money(self):
        rid = self.exposed_request()
        result = self.c.retain(rid, actor=ACTOR, reason="awaiting provider statement")
        self.assertTrue(result.applied)
        self.assertEqual(self.state(rid), "exposed")
        self.assertEqual(self.win("exposed"), WORST_512)

    def test_exposure_is_never_cleared_silently_by_recovery(self):
        rid = self.exposed_request()
        self.s.close()
        self.s = self.store()
        self.controller(self.s).sweep(everything=True)
        self.assertEqual(self.state(rid), "exposed")
        self.assertEqual(self.win("exposed"), WORST_512)


# ------------------------------------------------------- 4. authorization and audit
class ManualSecurity(R2):
    def exposed_request(self):
        t = self.c.admit(request(), profile())
        self.c.settle(t, Settlement("failed", True))
        return t.request_id

    def test_unauthorized_write_off_is_refused_and_changes_nothing(self):
        rid = self.exposed_request()
        result = self.c.write_off(rid, actor="intruder", reason="I want it gone")
        self.assertFalse(result.applied)
        self.assertEqual(result.reason, "unauthorized")
        self.assertEqual(self.state(rid), "exposed")
        self.assertEqual(self.win("exposed"), WORST_512)
        self.assertEqual(self.row("SELECT COUNT(*) FROM exposure_resolutions")[0], 0)
        self.assertEqual(self.row("SELECT outcome FROM governance_log WHERE operation = 'write_off'")[0], "refused")

    def test_duplicate_manual_resolution_is_refused(self):
        rid = self.exposed_request()
        self.assertTrue(self.c.write_off(rid, actor=ACTOR, reason="first").applied)
        second = self.c.write_off(rid, actor=ACTOR, reason="second")
        self.assertFalse(second.applied)
        self.assertEqual(second.reason, "already_resolved")
        self.assertEqual(self.win("written_off"), WORST_512)  # counted once
        self.assertFalse(self.c.retain(rid, actor=ACTOR, reason="late review").applied)

    def test_invalid_manual_input_is_refused_without_echoing_it(self):
        rid = self.exposed_request()
        result = self.c.write_off(rid, actor=ACTOR, reason="x" * 501)
        self.assertEqual(result.reason, "invalid_input")
        bad_actor = self.c.write_off(rid, actor="a b c", reason="ok")
        self.assertEqual(bad_actor.reason, "invalid_input")

    def test_audit_failure_after_commit_keeps_the_committed_write_off(self):
        # Stage 10.49-R3: the decision is committed before delivery. A failed sink does not roll it back.
        rid = self.exposed_request()
        audit = AuditLogger(logging.getLogger("test.1049r2.fail"))
        c = AdmissionController(self.s, audit=audit, bounds=BOUNDS, clock=self.clock,
                                authorized_actors=frozenset({ACTOR}), sink=DownSink())
        with contextlib.nullcontext():
            result = c.write_off(rid, actor=ACTOR, reason="needs audit")
        self.assertTrue(result.applied)
        self.assertEqual(result.reason, "written_off")
        self.assertEqual(result.audit_status, "failed")
        self.assertEqual(self.state(rid), "written_off")
        self.assertEqual(self.win("exposed"), Decimal(0))
        self.assertEqual(self.win("written_off"), WORST_512)
        self.assertEqual(self.row("SELECT COUNT(*) FROM exposure_resolutions")[0], 1)
        self.assertEqual(self.row("SELECT status FROM audit_outbox WHERE event = 'exposure.resolved'")[0], "failed")

    def test_manual_resolution_audit_is_written_and_secret_free(self):
        rid = self.exposed_request()
        audit = AuditLogger()
        c = self.controller(self.s, audit=audit)
        c.write_off(rid, actor=ACTOR, reason="SECRET-REASON-TEXT", evidence_ref="SECRET-EVIDENCE-REF")
        # Stage 10.49-R4: the event lives in the outbox (delivered to the sink), not in the logger.
        text = self.row("SELECT event || ' ' || fields FROM audit_outbox WHERE event = 'exposure.resolved'")[0]
        self.assertIn("exposure.resolved", text)
        self.assertIn(ACTOR, text)
        self.assertNotIn("SECRET-REASON-TEXT", text)
        self.assertNotIn("SECRET-EVIDENCE-REF", text)
        self.assertNotIn(self.path, text)

    def test_failed_recovery_is_recorded_in_the_governance_log(self):
        t = self.c.admit(request(), profile())
        real = self.fail_next(PHASE2)
        self.c.settle(t, Settlement("completed", True, VALID))
        self.c.sweep()
        self.restore(real)
        self.assertGreaterEqual(self.row("SELECT COUNT(*) FROM governance_log WHERE outcome = 'failed'")[0], 1)
        # one failed apply at settlement, one at recovery: two attempts, each recorded
        self.assertEqual(self.row("SELECT recovery_attempts, last_failure FROM reservations")[:2], (2, "apply_write"))


# ------------------------------------------------------ 3. reporting, currency, consistency

class MoneySumRuleTests(unittest.TestCase):
    def test_money_sum_never_turns_an_unknown_amount_into_zero(self):
        # direct check of the report's sum rule (a private helper, exercised here on purpose)
        self.assertEqual(_money_sum([None]), (None, 1))
        self.assertEqual(_money_sum([None, None]), (None, 2))
        self.assertEqual(_money_sum(["1.50000000", None]), ("1.50000000", 1))
        self.assertEqual(_money_sum(["0"]), ("0", 0))

class Reporting(R2):
    def scenario(self):
        t1 = self.c.admit(request(), profile())
        self.c.settle(t1, Settlement("completed", True, VALID))  # actual
        t2 = self.c.admit(request(), profile())
        self.c.settle(t2, Settlement("failed", True))  # exposed
        t3 = self.c.admit(request(), profile())  # in flight
        t4 = self.c.admit(request(), profile())
        real = self.fail_next(PHASE2)
        self.c.settle(t4, Settlement("completed", True, VALID))  # pending
        self.restore(real)
        return t1, t2, t3, t4

    def test_report_separates_actual_reserved_exposed_pending_and_unknown(self):
        self.scenario()
        usd = self.c.governance_report()["currencies"]["USD"]
        self.assertEqual(usd["actual_cost"], "0.000024")
        self.assertEqual(usd["uncertain_exposure"], 1)
        self.assertEqual(usd["uncertain_exposure_amount"], "0.02048")
        self.assertEqual(usd["active_reservations"], 1)
        self.assertEqual(usd["pending_settlement_intents"], 1)
        self.assertEqual(usd["unknown_cost_requests"], 1)
        self.assertEqual(usd["unresolved_exposure"], 1)
        self.assertEqual(usd["failed_settlement_operations"], 1)

    def test_report_is_identical_before_and_after_restart(self):
        self.scenario()
        before = self.c.governance_report()
        self.s.close()
        self.s = self.store()
        after = self.controller(self.s).governance_report()
        self.assertEqual(before, after)

    def test_currencies_are_never_aggregated_together(self):
        self.s = GovernanceStore(os.path.join(tempfile.mkdtemp(), "currencies.db"))
        self.addCleanup(self.s.close)
        self.c = self.controller_with_bounds(self.s, ("eur_profile",))
        self.s.upsert_pricing(pricing())
        self.s.upsert_budget("profile", ALIAS, "daily", "USD", "1.00")
        self.s.upsert_pricing(PricingVersion.build(provider_id=PROVIDER, model_id="gpt-eur-test", currency="EUR",
                                                   effective_from="2026-01-01", input_per_million="2.00",
                                                   output_per_million="8.00"))
        eur_profile = SimpleNamespace(alias="eur_profile", provider=PROVIDER, model_id="gpt-eur-test")
        self.s.upsert_budget("profile", "eur_profile", "daily", "EUR", "1.00")
        t1 = self.c.admit(request(), profile())
        self.c.settle(t1, Settlement("completed", True, VALID))
        t2 = self.c.admit(request(), eur_profile)
        self.c.settle(t2, Settlement("completed", True, VALID))
        report = self.c.governance_report()["currencies"]
        self.assertEqual(set(report), {"USD", "EUR"})
        self.assertEqual(report["USD"]["actual_cost"], "0.000024")
        self.assertEqual(report["EUR"]["actual_cost"], "0.000024")
        self.assertEqual(self.c.governance_report(currency="EUR")["currencies"].keys(), {"EUR"})

    def test_unpriced_requests_stay_in_their_own_bucket_with_unknown_amounts(self):
        self.s = GovernanceStore(os.path.join(tempfile.mkdtemp(), "unpriced.db"))
        self.addCleanup(self.s.close)
        self.c = self.controller_with_bounds(self.s, ("no_price",))
        unpriced = SimpleNamespace(alias="no_price", provider=PROVIDER, model_id="gpt-unpriced")
        self.s.upsert_quota("global", "", "daily", "requests", 100)
        c = self.c
        t = c.admit(request(), unpriced)
        c.settle(t, Settlement("failed", True))
        report = c.governance_report()["currencies"]
        self.assertIn("unpriced", report)
        # the request count is known (a quota request), so nothing is exposed; the cost is unknown and says so
        self.assertEqual(report["unpriced"]["uncertain_exposure"], 0)
        self.assertEqual(report["unpriced"]["unknown_cost_requests"], 1)
        self.assertIsNone(report["unpriced"]["actual_cost"])
        self.assertEqual(report["unpriced"]["requests"], 1)

    def test_filters_are_exact_validated_and_bound(self):
        self.scenario()
        self.assertEqual(self.c.governance_report(provider="openai")["currencies"]["USD"]["requests"], 4)
        self.assertEqual(self.c.governance_report(provider="nobody")["currencies"], {})
        for bad in ({"provider": "openai' OR '1'='1"}, {"utc_day": "2026-13-40"}, {"currency": "usd"},
                    {"model": 5}):
            with self.subTest(bad=bad):
                with self.assertRaises(ValueError):
                    governance_report(self.s, **bad)
        self.assertEqual(self.row("SELECT COUNT(*) FROM reservations")[0], 4)  # table intact

    def test_report_is_read_only(self):
        self.scenario()
        before = self.row("SELECT COUNT(*) FROM governance_log")[0]
        self.c.governance_report()
        self.assertEqual(self.row("SELECT COUNT(*) FROM governance_log")[0], before)


# ----------------------------------------------------------------- migration 3 upgrade
class MigrationThree(unittest.TestCase):
    def test_v2_database_upgrades_and_keeps_exposure_lines(self):
        import sqlite3
        path = os.path.join(tempfile.mkdtemp(), "v2.db")
        conn = sqlite3.connect(path, isolation_level=None)
        for version in (1, 2):
            for statement in _MIGRATIONS[version].split(";\n"):
                if statement.strip():
                    conn.execute(statement)
        conn.execute("CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, applied_at INTEGER)")
        conn.execute("INSERT INTO schema_migrations VALUES (1, 0), (2, 0)")
        conn.execute("INSERT INTO reservations (request_id, state, provider_id, model_id, profile_id, utc_day, "
                     "created_at, expires_at) VALUES ('v2-exp', 'exposed', 'openai', 'm', 'p', '2026-11-07', 0, 0)")
        conn.execute("INSERT INTO budgets (budget_id, scope_type, scope_value, period, currency, limit_amount) "
                     "VALUES (1, 'global', '', 'daily', 'USD', '1')")
        conn.execute("INSERT INTO reservation_lines (request_id, line_kind, line_id, window_start, amount, outcome) "
                     "VALUES ('v2-exp', 'budget', 1, '2026-11-07', '0.02048', 'exposed')")
        conn.close()
        store = GovernanceStore(path)
        self.addCleanup(store.close)
        self.assertEqual(store.schema_version(), 6)
        self.assertEqual(store.read(lambda c: c.execute(
            "SELECT outcome FROM reservation_lines WHERE request_id = 'v2-exp'").fetchone())[0], "exposed")
        self.assertEqual(store.read(lambda c: c.execute(
            "SELECT state FROM reservations WHERE request_id = 'v2-exp'").fetchone())[0], "exposed")
        self.assertTrue(store.integrity_ok())


# ------------------------------------------------- 10.49-R2 review: targeted correction tests
class ReviewCorrections(R2):
    def exposed_request(self, timeout=None):
        t = self.c.admit(request(timeout=timeout) if timeout else request(), profile())
        self.c.settle(t, Settlement("failed", True))
        self.assertEqual(self.state(), "exposed")
        return t.request_id

    def test_resolve_exposure_refuses_unauthorized_actor_and_fabricates_nothing(self):
        rid = self.exposed_request()
        result = self.c.resolve_exposure(rid, VALID, actor="intruder")
        self.assertEqual(result.reason, "unauthorized")
        self.assertEqual(self.win("spent"), Decimal(0))
        self.assertEqual(self.win("exposed"), WORST_512)
        self.assertEqual(self.state(rid), "exposed")
        self.assertEqual(self.row("SELECT COUNT(*) FROM exposure_resolutions")[0], 0)
        self.assertIsNone(self.row("SELECT actual_cost FROM cost_records")[0])

    def test_first_intent_write_failure_keeps_reservation_conservative(self):
        t = self.c.admit(request(timeout=5), profile())
        real = self.fail_next("UPDATE reservations SET state = 'settlement_pending'")
        result = self.c.settle(t, Settlement("completed", True, VALID))
        self.restore(real)
        self.assertFalse(result.applied)
        self.assertEqual(result.reason, "settlement_failed")
        self.assertEqual(self.state(), "reserved")  # no intent, no state change, usage was never persisted
        self.assertEqual(self.win("reserved"), WORST_512)
        self.assertEqual(self.win("spent"), Decimal(0))
        self.assertEqual(self.row("SELECT COUNT(*) FROM cost_records")[0], 0)
        # budget is never released automatically: after expiry the reservation becomes exposure, not release
        later = AdmissionController(self.s, audit=AuditLogger(logging.getLogger("t")), bounds=BOUNDS,
                                    clock=Clock(T0 + 100_000))
        self.assertEqual(later.sweep(), 1)
        self.assertEqual(self.state(), "exposed")
        self.assertEqual(self.win("spent"), Decimal(0))
        self.assertEqual(self.win("exposed"), WORST_512)
        self.assertEqual(self.win("reserved"), Decimal(0))

    def test_write_off_transaction_failure_rolls_back_every_line(self):
        rid = self.exposed_request()
        real = self.fail_next("INSERT INTO exposure_resolutions")  # after the budget and state writes ran
        result = self.c.write_off(rid, actor=ACTOR, reason="partial failure test")
        self.restore(real)
        self.assertFalse(result.applied)
        self.assertEqual(result.reason, "storage_error")
        self.assertEqual(self.state(rid), "exposed")
        self.assertEqual(self.win("exposed"), WORST_512)
        self.assertEqual(self.win("written_off"), Decimal(0))
        self.assertEqual(self.row("SELECT outcome FROM reservation_lines")[0], "exposed")

    def test_verified_usage_audit_failure_after_commit_keeps_the_decision(self):
        rid = self.exposed_request()
        audit = AuditLogger(logging.getLogger("test.review.audit"))
        c = AdmissionController(self.s, audit=audit, bounds=BOUNDS, clock=self.clock,
                                authorized_actors=frozenset({ACTOR}), sink=DownSink())
        with contextlib.nullcontext():
            result = c.resolve_exposure(rid, VALID, actor=ACTOR)
        self.assertTrue(result.applied)
        self.assertEqual(result.audit_status, "failed")
        self.assertEqual(self.win("exposed"), Decimal(0))
        self.assertEqual(self.win("spent"), ACTUAL_24)
        self.assertEqual(self.state(rid), "settled")
        self.assertEqual(self.row("SELECT COUNT(*) FROM exposure_resolutions")[0], 1)

    def test_no_automatic_path_calls_write_off(self):
        self.exposed_request(timeout=5)  # expiry path
        t = self.c.admit(request(), profile())
        real = self.fail_next("UPDATE reservations SET state = 'settlement_pending'")
        self.c.settle(t, Settlement("completed", True, VALID))  # pending path
        self.restore(real)
        later = AdmissionController(self.s, audit=AuditLogger(logging.getLogger("t")), bounds=BOUNDS,
                                    clock=Clock(T0 + 100_000))
        with mock.patch.object(budget, "write_off") as b_wo, mock.patch.object(quota, "write_off") as q_wo:
            later.sweep(everything=True)
            later.sweep()
        b_wo.assert_not_called()
        q_wo.assert_not_called()
        self.assertEqual(self.row("SELECT COUNT(*) FROM exposure_resolutions")[0], 0)

    def test_write_off_fields_are_durable_and_history_is_kept(self):
        rid = self.exposed_request()
        self.assertTrue(self.c.write_off(rid, actor=ACTOR, reason="reviewed by ops", evidence_ref="ticket-7").applied)
        row = self.row("SELECT actor, reason, evidence_ref, decided_at, resolution FROM exposure_resolutions")
        self.assertEqual(row[:3], (ACTOR, "reviewed by ops", "ticket-7"))
        self.assertEqual(row[3], int(T0))
        self.assertEqual(row[4], "write_off")
        # history is kept: the line keeps its amount, only its outcome changes
        self.assertEqual(self.row("SELECT outcome, amount FROM reservation_lines WHERE line_kind = 'budget'"),
                         ("written_off", "0.02048"))

    def test_write_off_is_separate_in_reports_and_never_actual(self):
        rid = self.exposed_request()
        self.c.write_off(rid, actor=ACTOR, reason="reviewed")
        usd = self.c.governance_report()["currencies"]["USD"]
        self.assertIsNone(usd["actual_cost"])
        self.assertEqual(usd["written_off"], 1)
        self.assertEqual(usd["written_off_amount"], "0.02048")
        self.assertEqual(usd["uncertain_exposure"], 0)
        self.assertEqual(usd["unresolved_exposure"], 0)
        self.assertEqual(usd["resolved_by_write_off"], 1)
        self.assertEqual(usd["unknown_cost_requests"], 1)  # still unknown: a write-off does not price usage

    def test_report_filters_reject_trailing_newline_lookalikes(self):
        for bad in ({"provider": "openai\n"}, {"currency": "USD\n"}, {"utc_day": "2026-11-07\n"}):
            with self.subTest(bad=bad):
                with self.assertRaises(ValueError):
                    governance_report(self.s, **bad)

    def test_constructor_rejects_malformed_authorized_actor(self):
        with self.assertRaises(ValueError):
            AdmissionController(self.s, audit=AuditLogger(logging.getLogger("t")), bounds=BOUNDS,
                                clock=self.clock, authorized_actors=frozenset({"ops alice"}))

    def test_actor_with_trailing_newline_is_not_the_authorized_actor(self):
        rid = self.exposed_request()
        result = self.c.write_off(rid, actor=ACTOR + "\n", reason="lookalike actor")
        self.assertFalse(result.applied)
        self.assertEqual(result.reason, "invalid_input")  # rejected by the full-match pattern, before authorization
        self.assertEqual(self.state(rid), "exposed")
        self.assertEqual(self.row("SELECT COUNT(*) FROM exposure_resolutions")[0], 0)
        self.assertEqual(self.row("SELECT COUNT(*) FROM governance_log WHERE actor LIKE 'ops.alice%' AND "
                                  "outcome = 'ok'")[0], 0)


if __name__ == "__main__":
    unittest.main()
