"""Stage 10.45: production model verification gate, audit completeness, and audit-failure policy.

Offline only: fake OpenAI adapter, no SDK, no network, no key. Audit checks read the real logger
output, so a secret or prompt that reaches the log fails the test.
"""

import logging
import unittest
from unittest import mock

from sanour_ai.providers.offline_contract import OfflineTestProvider
from sanour_ai.composition import production
from sanour_ai.composition.runtime import Runtime
from sanour_ai.config.settings import ConfigError
from sanour_ai.core.coordinator import AUDIT_UNAVAILABLE_MESSAGE, RESPONSE_WITHHELD_MESSAGE
from sanour_ai.errors import ErrorCode
from sanour_ai.models import production_gate
from sanour_ai.models.base import ModelResult
from sanour_ai.models.capabilities import ProviderCapabilities
from sanour_ai.observability.audit import AUDIT_LOGGER_NAME, AuditLogger
from tests.support import production_ledger_path

SECRET = "STAGE1045-SECRET-KEY-ZX"
MODEL = "gpt-test-1045"
PROMPT = "STAGE1045-PROMPT-TEXT-QQ"
TRIPLE = ("openai", "openai_responses", MODEL)


def env(**extra):
    base = {
        "SANOUR_PROVIDER": "openai",
        "SANOUR_OPENAI_MODEL_ID": MODEL,
        "SANOUR_OPENAI_MAX_CONTEXT_TOKENS": "8192",
        "SANOUR_OPENAI_MAX_OUTPUT_TOKENS": "1024",
        "OPENAI_API_KEY": SECRET,
    }
    base.update(extra)
    return base


class FakeOpenAI(OfflineTestProvider):
    name = "openai"
    vendor = "openai"
    surface = "openai_responses"
    auth_method = "sdk_bearer_client"
    capabilities = ProviderCapabilities(text_generation=True)
    instances: list = []
    calls: list = []

    def __init__(self, api_key):
        FakeOpenAI.instances.append(self)

    def initialize(self):
        pass

    def generate(self, call):
        FakeOpenAI.calls.append(call)
        return ModelResult(text="ok", reported_model_id=call.model_id)

    def close(self):
        pass


class Base(unittest.TestCase):
    def setUp(self):
        FakeOpenAI.instances = []
        FakeOpenAI.calls = []
        for p in (
            mock.patch.object(production, "OpenAIProvider", FakeOpenAI), mock.patch.object(production, "_default_test_provider", lambda: FakeOpenAI("test")),
            mock.patch.object(production, "_sdk_present", return_value=True),
        ):
            p.start()
            self.addCleanup(p.stop)

    def open_gate(self):
        """Code-level approval only. Used to exercise the approved path; env cannot do this."""
        for p in (
            mock.patch.object(production_gate, "APPROVED_PRODUCTION_MODELS", frozenset({TRIPLE})),
            mock.patch.object(production_gate.capability_intelligence, "production_ready",
                              return_value={"text_generation"}),
        ):
            p.start()
            self.addCleanup(p.stop)

    def ask(self, rt, text=PROMPT):
        return rt.handle({"profile_alias": "openai_primary", "prompt": text})

    def audit_logger(self, name):
        return AuditLogger(logging.getLogger(f"test.stage1045.{name}"))


class ProductionGate(Base):
    def test_unverified_model_cannot_build_production_runtime(self):
        with self.assertRaises(ConfigError):
            Runtime.build(env(), usage_ledger_path=production_ledger_path())
        self.assertEqual(FakeOpenAI.instances, [])  # refused before any adapter existed

    def test_capability_verified_but_model_not_approved_is_refused(self):
        with mock.patch.object(production_gate.capability_intelligence, "production_ready",
                               return_value={"text_generation"}):
            with self.assertRaises(ConfigError):
                Runtime.build(env(), usage_ledger_path=production_ledger_path())
        self.assertEqual(FakeOpenAI.instances, [])

    def test_model_approved_but_capability_unverified_is_refused(self):
        with mock.patch.object(production_gate, "APPROVED_PRODUCTION_MODELS", frozenset({TRIPLE})):
            with self.assertRaises(ConfigError):
                Runtime.build(env(), usage_ledger_path=production_ledger_path())
        self.assertEqual(FakeOpenAI.instances, [])

    def test_patching_production_ready_alone_does_not_open_gate(self):
        with mock.patch.object(production_gate.capability_intelligence, "production_ready",
                               return_value={"text_generation"}):
            with self.assertRaises(ConfigError) as ctx:
                Runtime.build(env(), usage_ledger_path=production_ledger_path())
        self.assertIn("gate refused", str(ctx.exception))
        self.assertEqual(FakeOpenAI.instances, [])

    def test_environment_cannot_bypass_gate(self):
        hostile = env(
            SANOUR_PRODUCTION_GATE="off",
            SANOUR_APPROVED_PRODUCTION_MODELS=MODEL,
            SANOUR_RUNTIME_EVIDENCE="text_generation",
            SANOUR_OPENAI_MODEL_ID="gpt-verified-by-operator",
        )
        with self.assertRaises(ConfigError):
            Runtime.build(hostile)
        self.assertEqual(FakeOpenAI.instances, [])

    def test_gate_message_names_no_value(self):
        with self.assertRaises(ConfigError) as ctx:
            Runtime.build(env(), usage_ledger_path=production_ledger_path())
        self.assertNotIn(MODEL, str(ctx.exception))
        self.assertNotIn(SECRET, str(ctx.exception))

    def test_gate_refusal_messages_are_fixed(self):
        cases = ((frozenset(), {"text_generation"}), (frozenset({TRIPLE}), set()))
        for approved, caps in cases:
            with mock.patch.object(production_gate, "APPROVED_PRODUCTION_MODELS", approved), \
                 mock.patch.object(production_gate.capability_intelligence, "production_ready",
                                   return_value=caps):
                with self.assertRaises(production_gate.ProductionGateRefused) as ctx:
                    production_gate.check("openai", "openai_responses", FakeOpenAI.capabilities,
                                          ("text_generation",), MODEL)
                self.assertIn(str(ctx.exception), {"model not verified", "capability not verified"})
                self.assertNotIn(MODEL, str(ctx.exception))

    def test_approved_model_opens_gate_only_by_code_level_approval(self):
        self.open_gate()
        rt = Runtime.build(env(), usage_ledger_path=production_ledger_path())
        self.assertEqual(rt.mode, "production")
        self.assertEqual(len(FakeOpenAI.instances), 1)
        rt.shutdown(1.0)


class BuilderSeparation(Base):
    def test_test_builder_works_without_gate(self):
        rt = Runtime.build_for_tests(env())
        self.assertEqual(rt.mode, "test")
        self.assertEqual(len(FakeOpenAI.instances), 1)
        self.assertEqual(self.ask(rt).status, "success")
        rt.shutdown(1.0)

    def test_production_mode_is_reported(self):
        self.open_gate()
        rt = Runtime.build(env(), usage_ledger_path=production_ledger_path())
        self.assertEqual(rt.stats()["mode"], "production")
        rt.shutdown(1.0)


class AuditCompleteness(Base):
    def test_refused_request_after_shutdown_is_audited_without_content(self):
        rt = Runtime.build_for_tests(env(), audit=self.audit_logger("refused"))
        rt.shutdown(1.0)
        with self.assertLogs("test.stage1045.refused", level="INFO") as captured:
            response = self.ask(rt)
        text = "\n".join(captured.output)
        self.assertIn("runtime.request_refused", text)
        self.assertIn("runtime_not_ready", text)
        self.assertNotIn(PROMPT, text)
        self.assertNotIn(SECRET, text)
        self.assertNotEqual(response.status, "success")

    def test_refusal_stays_refusal_when_audit_fails(self):
        audit = self.audit_logger("refused_fail")
        rt = Runtime.build_for_tests(env(), audit=audit)
        rt.shutdown(1.0)
        with mock.patch.object(audit._logger, "info", side_effect=OSError(SECRET)), \
             mock.patch.object(rt._core, "handle", wraps=rt._core.handle) as core_handle:
            response = self.ask(rt)
        core_handle.assert_not_called()  # a refusal never reaches the core, whatever audit does
        self.assertNotEqual(response.status, "success")
        self.assertEqual(FakeOpenAI.calls, [])
        self.assertGreaterEqual(rt.stats()["audit"]["failed"], 1)

    def test_no_secret_or_prompt_in_normal_audit(self):
        rt = Runtime.build_for_tests(env())
        with self.assertLogs(AUDIT_LOGGER_NAME, level="INFO") as captured:
            self.assertEqual(self.ask(rt).status, "success")
        text = "\n".join(captured.output)
        self.assertIn("request.received", text)
        self.assertNotIn(PROMPT, text)
        self.assertNotIn(SECRET, text)
        rt.shutdown(1.0)

    def test_production_admission_audit_failure_fails_closed(self):
        self.open_gate()
        rt = Runtime.build(env(), usage_ledger_path=production_ledger_path())
        with mock.patch.object(logging.getLogger(AUDIT_LOGGER_NAME), "info", side_effect=OSError(SECRET)):
            response = self.ask(rt)
        self.assertEqual(response.status, "error")
        self.assertEqual(response.error.code, ErrorCode.INTERNAL_ERROR)
        self.assertEqual(response.error.message, AUDIT_UNAVAILABLE_MESSAGE)
        self.assertEqual(FakeOpenAI.calls, [])  # no provider call without a recorded admission
        self.assertNotIn(SECRET, repr(response))
        rt.shutdown(1.0)

    def test_production_completion_audit_failure_withholds_output(self):
        self.open_gate()
        rt = Runtime.build(env(), usage_ledger_path=production_ledger_path())

        def fail_completed(msg, *args, **kwargs):
            if args and args[0] == "request.completed":
                raise OSError(SECRET)

        with mock.patch.object(logging.getLogger(AUDIT_LOGGER_NAME), "info", side_effect=fail_completed):
            response = self.ask(rt)
        self.assertEqual(response.status, "error")
        self.assertEqual(response.error.message, RESPONSE_WITHHELD_MESSAGE)
        self.assertEqual(len(FakeOpenAI.calls), 1)  # the call happened, the output did not leave
        rt.shutdown(1.0)

    def test_test_mode_audit_failure_is_counted_and_request_proceeds(self):
        audit = self.audit_logger("tolerant")
        rt = Runtime.build_for_tests(env(), audit=audit)
        with mock.patch.object(audit._logger, "info", side_effect=OSError(SECRET)):
            response = self.ask(rt)
        self.assertEqual(response.status, "success")
        counters = rt.stats()["audit"]
        self.assertGreaterEqual(counters["failed"], 2)
        self.assertEqual(counters["health"], "degraded")
        rt.shutdown(1.0)


class AuditPrimitives(unittest.TestCase):
    def test_emit_returns_false_on_failure_and_keeps_no_text(self):
        audit = AuditLogger(logging.getLogger("test.stage1045.prim"))
        with mock.patch.object(audit._logger, "info", side_effect=OSError(SECRET)):
            self.assertFalse(audit.emit("request.received", request_id="r1"))
        counters = audit.counters()
        self.assertEqual(counters["failed"], 1)
        self.assertEqual(counters["health"], "degraded")
        self.assertNotIn(SECRET, repr(counters))

    def test_emit_returns_true_only_when_written(self):
        audit = AuditLogger(logging.getLogger("test.stage1045.ok"))
        with self.assertLogs("test.stage1045.ok", level="INFO"):
            self.assertTrue(audit.emit("request.received", request_id="r2"))
        self.assertEqual(audit.counters(), {"emitted": 1, "failed": 0, "health": "ok"})

    def test_refusal_field_accepts_only_fixed_reason(self):
        audit = AuditLogger(logging.getLogger("test.stage1045.refusal"))
        with self.assertLogs("test.stage1045.refusal", level="INFO") as captured:
            audit.emit("runtime.request_refused", refusal=PROMPT)
            audit.emit("runtime.request_refused", refusal="runtime_not_ready")
        text = "\n".join(captured.output)
        self.assertNotIn(PROMPT, text)
        self.assertIn("runtime_not_ready", text)

    def test_unknown_fields_are_dropped(self):
        audit = AuditLogger(logging.getLogger("test.stage1045.fields"))
        with self.assertLogs("test.stage1045.fields", level="INFO") as captured:
            audit.emit("request.received", prompt=PROMPT, api_key=SECRET, request_id="r3")
        text = "\n".join(captured.output)
        self.assertNotIn(PROMPT, text)
        self.assertNotIn(SECRET, text)
        self.assertIn("r3", text)
