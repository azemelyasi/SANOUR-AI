"""Stage 10.28 tests: HTTP error classification, bounded error bodies, 429 safety.

Fake transports, fake SDK exceptions, and fixed bodies only. No network, no real key, no SDK.
"""

from tests.support import request_identity_for as _rid
import io
import json
import logging
import time
import unittest
import urllib.error
from types import SimpleNamespace
from unittest import mock

from pydantic import SecretStr

from sanour_ai.core.sanour_core import SanourCore
from sanour_ai.errors import FAILURE_REASONS, ErrorCode, SanourError
from sanour_ai.models.base import ModelCall, ProviderError
from sanour_ai.models.capabilities import ModelCapabilities, ModelProfile
from sanour_ai.models.gateway import ModelGateway
from sanour_ai.models.router import DeterministicRouter
from sanour_ai.observability.audit import AUDIT_LOGGER_NAME, AuditLogger
from sanour_ai.providers import common
from sanour_ai.providers.anthropic_provider import AnthropicProvider
from sanour_ai.providers.common import (
    MAX_ERROR_BODY_BYTES,
    RateLimitedError,
    fields_from_body,
    parse_retry_after,
    payment_error,
    rate_limit_error,
)
from sanour_ai.providers.gemini_provider import GeminiProvider
from sanour_ai.providers.grok_provider import GrokProvider
from sanour_ai.providers import openai_provider as oai
from tests.support import TEST_ALL_CAPS, deadline_in

KEY = "STAGE1028-TESTONLY-KEY-ABCDEF"
MODEL = "model-1028"
PROMPT = "SECRET-PROMPT-1028 hello"
SECRET_MSG = f"invalid key {KEY} SECRET-MSG-1028"


class FakeTransport:
    def __init__(self, status, body=b""):
        self.status, self.body, self.calls = status, body, 0

    def __call__(self, url, headers, body, timeout):
        self.calls += 1
        return self.status, self.body


def call():
    return ModelCall(model_id=MODEL, prompt=PROMPT, max_output_tokens=16,
                     deadline=time.monotonic() + 5)


def err(type_=None, code=None, status=None, message=SECRET_MSG, extra=None):
    inner = {"message": message}
    if type_ is not None:
        inner["type"] = type_
    if code is not None:
        inner["code"] = code
    if status is not None:
        inner["status"] = status
    if extra:
        inner.update(extra)
    return json.dumps({"error": inner}).encode()


def gemini(status, body=b""):
    t = FakeTransport(status, body)
    return GeminiProvider(SecretStr(KEY), transport=t), t


def anthropic(status, body=b""):
    t = FakeTransport(status, body)
    return AnthropicProvider(SecretStr(KEY), transport=t), t


def grok(status, body=b""):
    t = FakeTransport(status, body)
    return GrokProvider(SecretStr(KEY), transport=t), t


def expect_error(provider):
    try:
        provider.generate(call())
    except ProviderError as exc:
        return exc
    raise AssertionError("expected a ProviderError")


def assert_unknown_429(testcase, exc):
    testcase.assertNotIsInstance(exc, RateLimitedError)
    testcase.assertEqual(exc.status_code, 429)
    testcase.assertEqual(exc.failure_reason, "unknown")
    testcase.assertFalse(exc.retryable)


# ---------------------------------------------------------------- shared classifier
class BodyParsingTests(unittest.TestCase):
    def test_structural_fields_are_read(self):
        self.assertEqual(fields_from_body(err("rate_limit_error", "slow_down", "X")),
                         {"type": "rate_limit_error", "code": "slow_down", "status": "X"})

    def test_message_is_never_read(self):
        fields = fields_from_body(err(message=f"{KEY} secret"))
        self.assertEqual(fields, {})
        self.assertNotIn("message", fields)

    def test_unusable_bodies_are_none_fail_closed(self):
        bad = [None, b"", b"not json", b"[]", b"null", b'"x"', b'{"error": "str"}', b'{"x": 1}',
               b"\xff\xfe", b"[" * 5000, b"{" * 3000]
        for raw in bad:
            with self.subTest(raw=repr(raw)[:20]):
                self.assertIsNone(fields_from_body(raw))

    def test_oversized_body_is_refused_before_parsing(self):
        big = json.dumps({"error": {"type": "rate_limit_error", "message": "x" * MAX_ERROR_BODY_BYTES}}).encode()
        self.assertGreater(len(big), MAX_ERROR_BODY_BYTES)
        self.assertIsNone(fields_from_body(big))

    def test_non_string_fields_are_dropped(self):
        fields = fields_from_body(json.dumps({"error": {"type": 7, "code": None, "status": "S"}}).encode())
        self.assertEqual(fields, {"status": "S"})


class ParseRetryAfterTests(unittest.TestCase):
    def test_plain_digits_are_a_bounded_hint(self):
        self.assertEqual(parse_retry_after("5"), 5)
        self.assertEqual(parse_retry_after(" 0 "), 0)
        self.assertEqual(parse_retry_after("3600"), 3600)
        self.assertEqual(parse_retry_after("999999"), 3600)  # six digits are read, then clamped
        self.assertEqual(parse_retry_after("1234567"), None)  # too long to be plausible

    def test_invalid_values_are_none(self):
        for bad in (None, "", "-1", "1.5", "soon", "١", "5 seconds", "Wed, 21 Oct 2026 07:28:00 GMT",
                    "1e3", "0x10", "9" * 50, 12):
            with self.subTest(value=bad):
                self.assertIsNone(parse_retry_after(bad))

    def test_hint_is_never_slept_on(self):
        with mock.patch("time.sleep", side_effect=AssertionError("must not sleep")):
            exc = rate_limit_error({"code": "slow_down"}, {"code": {"slow_down": "transient"}}, retry_after=5)
        self.assertIsInstance(exc, RateLimitedError)
        self.assertEqual(exc.retry_after_seconds, 5)  # metadata only


class ClassifierTests(unittest.TestCase):
    ALLOW = {
        "code": {"slow_down": "transient", "insufficient_quota": "quota", "credit_balance_exhausted": "billing"},
        "type": {"insufficient_quota": "quota"},
    }

    def test_known_transient_is_retryable_rate_limit(self):
        exc = rate_limit_error({"type": "rate_limit_error", "code": "slow_down"}, self.ALLOW, retry_after=9)
        self.assertIsInstance(exc, RateLimitedError)
        self.assertTrue(exc.retryable)
        self.assertEqual(exc.retry_after_seconds, 9)

    def test_known_quota_and_billing_are_not_retryable(self):
        q = rate_limit_error({"code": "insufficient_quota"}, self.ALLOW)
        b = rate_limit_error({"code": "credit_balance_exhausted"}, self.ALLOW)
        for exc, reason in ((q, "quota"), (b, "billing")):
            with self.subTest(reason=reason):
                self.assertNotIsInstance(exc, RateLimitedError)
                self.assertEqual(exc.failure_reason, reason)
                self.assertFalse(exc.retryable)
                self.assertEqual(exc.status_code, 429)

    def test_conflicting_fields_fail_closed_to_unknown(self):
        exc = rate_limit_error({"code": "slow_down", "type": "insufficient_quota"}, self.ALLOW)
        self.assertNotIsInstance(exc, RateLimitedError)
        self.assertEqual(exc.failure_reason, "unknown")

    def test_missing_or_absent_fields_are_unknown(self):
        for fields in (None, {}, {"code": "unlisted"}, {"type": "rate_limit_error"}):
            with self.subTest(fields=fields):
                assert_unknown_429(self, rate_limit_error(fields, self.ALLOW))

    def test_failure_reason_is_always_from_fixed_set(self):
        for fields in ({"code": "slow_down"}, {"code": "insufficient_quota"}, None, {"code": "x"}):
            exc = rate_limit_error(fields, self.ALLOW)
            if exc.failure_reason is not None:
                self.assertIn(exc.failure_reason, FAILURE_REASONS)

    def test_provider_error_rejects_non_fixed_reason(self):
        with self.assertRaises(ValueError):
            ProviderError("x", failure_reason="SECRET-REASON-1028")

    def test_payment_error_billing_only_when_allowlisted(self):
        allow = {"type": {"billing_error": "billing"}}
        billing = payment_error({"type": "billing_error"}, allow)
        self.assertEqual(billing.failure_reason, "billing")
        self.assertEqual(billing.status_code, 402)
        self.assertFalse(billing.retryable)
        unknown = payment_error({"type": "other"}, allow)
        self.assertEqual(unknown.failure_reason, "unknown")


# ---------------------------------------------------------------- per-provider behaviour
class GeminiErrorTests(unittest.TestCase):
    def test_resource_exhausted_is_ambiguous_and_unknown(self):
        p, t = gemini(429, err(status="RESOURCE_EXHAUSTED", code=429))
        assert_unknown_429(self, expect_error(p))
        self.assertEqual(t.calls, 1)

    def test_any_429_body_is_unknown_for_gemini(self):
        for body in (b"", b"not json", err("rate_limit_error", "slow_down"), err(status="RATE_LIMITED")):
            with self.subTest(body=body[:30]):
                p, _ = gemini(429, body)
                assert_unknown_429(self, expect_error(p))

    def test_402_is_unknown_billing_for_gemini(self):
        p, _ = gemini(402, err(status="PAYMENT_REQUIRED"))
        exc = expect_error(p)
        self.assertEqual(exc.status_code, 402)
        self.assertEqual(exc.failure_reason, "unknown")
        self.assertFalse(exc.retryable)

    def test_403_500_503_unchanged(self):
        p, _ = gemini(403)
        e = expect_error(p)
        self.assertFalse(e.retryable)
        self.assertIsNone(e.failure_reason)
        for status in (500, 503):
            p, _ = gemini(status)
            self.assertTrue(expect_error(p).retryable)

    def test_error_text_never_contains_key_or_body(self):
        p, _ = gemini(429, err(status="RESOURCE_EXHAUSTED", message=SECRET_MSG))
        exc = expect_error(p)
        for text in (str(exc), repr(exc), exc.args[0]):
            self.assertNotIn(KEY, text)
            self.assertNotIn("SECRET-MSG-1028", text)


class AnthropicErrorTests(unittest.TestCase):
    SPEND_CAP = json.dumps({"type": "error", "error": {
        "type": "rate_limit_error", "message": SECRET_MSG,
        "details": {"error_code": "enforced_spend_limit_reached"}}}).encode()

    def test_plain_rate_limit_is_unknown_not_transient(self):
        p, _ = anthropic(429, err("rate_limit_error"))
        assert_unknown_429(self, expect_error(p))

    def test_spend_cap_is_billing_via_details_error_code(self):
        # Stage 10.30: error.details.error_code is an allowlisted path (rate-limits page).
        p, _ = anthropic(429, self.SPEND_CAP)
        exc = expect_error(p)
        self.assertEqual(exc.status_code, 429)
        self.assertEqual(exc.failure_reason, "billing")
        self.assertFalse(exc.retryable)
        self.assertNotIsInstance(exc, RateLimitedError)

    def test_402_billing_error_is_billing(self):
        p, _ = anthropic(402, err("billing_error"))
        exc = expect_error(p)
        self.assertEqual(exc.status_code, 402)
        self.assertEqual(exc.failure_reason, "billing")
        self.assertFalse(exc.retryable)

    def test_402_other_type_is_unknown(self):
        p, _ = anthropic(402, err("permission_error"))
        self.assertEqual(expect_error(p).failure_reason, "unknown")

    def test_529_and_500_stay_retryable(self):
        for status in (500, 529):
            p, _ = anthropic(status, err("overloaded_error"))
            self.assertTrue(expect_error(p).retryable)


class GrokErrorTests(unittest.TestCase):
    def test_any_429_is_unknown_for_grok(self):
        for body in (b"", err("rate_limit_error"), err(code="rate_limit_exceeded"), b"not json"):
            with self.subTest(body=body[:30]):
                p, _ = grok(429, body)
                assert_unknown_429(self, expect_error(p))

    def test_402_is_unknown_for_grok(self):
        p, _ = grok(402, err())
        self.assertEqual(expect_error(p).failure_reason, "unknown")

    def test_400_401_403_404_unchanged(self):
        for status in (400, 401, 403, 404):
            p, _ = grok(status)
            e = expect_error(p)
            self.assertFalse(e.retryable)
            self.assertIsNone(e.failure_reason)


class BoundedBodyTests(unittest.TestCase):
    def test_oversized_error_body_is_unknown_even_if_structurally_valid(self):
        big = json.dumps({"error": {"type": "rate_limit_error", "code": "slow_down",
                                    "message": "x" * (MAX_ERROR_BODY_BYTES + 10)}}).encode()
        p, _ = anthropic(429, big)
        assert_unknown_429(self, expect_error(p))

    def test_malformed_error_body_is_unknown(self):
        p, _ = gemini(429, b"{broken")
        assert_unknown_429(self, expect_error(p))

    def test_default_transport_bounds_the_error_body_read(self):
        big = b"y" * (MAX_ERROR_BODY_BYTES * 3)
        fake_opener = SimpleNamespace(open=lambda req, timeout: (_ for _ in ()).throw(
            urllib.error.HTTPError("https://example.invalid/x", 429, "x", {}, io.BytesIO(big))))
        with mock.patch.object(common, "OPENER", fake_opener):
            status, raw = common.default_transport("https://example.invalid/x", {}, b"{}", 1.0)
        self.assertEqual(status, 429)
        self.assertEqual(len(raw), MAX_ERROR_BODY_BYTES + 1)  # enough to detect oversize, no more
        self.assertIsNone(fields_from_body(raw))

    def test_default_transport_handles_missing_body(self):
        fake_opener = SimpleNamespace(open=lambda req, timeout: (_ for _ in ()).throw(
            urllib.error.HTTPError("https://example.invalid/x", 429, "x", {}, None)))
        with mock.patch.object(common, "OPENER", fake_opener):
            status, raw = common.default_transport("https://example.invalid/x", {}, b"{}", 1.0)
        self.assertEqual((status, raw), (429, b""))


# ---------------------------------------------------------------- OpenAI SDK mapping (no SDK import)
class _SdkRateLimit(Exception):
    pass


class _SdkStatus(Exception):
    pass


class _Other(Exception):
    pass


def _sdk_types():
    return oai.SdkErrorTypes(
        base=Exception, authentication=_Other, permission_denied=_Other, not_found=_Other,
        rate_limit=_SdkRateLimit, internal_server=_Other, api_timeout=_Other,
        api_connection=_Other, api_status=_SdkStatus,
    )


def openai_map(exc):
    provider = oai.OpenAIProvider.__new__(oai.OpenAIProvider)
    provider._errors = _sdk_types()
    return provider._map_error(exc)


def sdk_exc(cls, status, body=None, headers=None):
    e = cls(SECRET_MSG)
    e.status_code = status
    e.body = body
    e.response = SimpleNamespace(headers=headers or {})
    return e


class OpenAIMappingTests(unittest.TestCase):
    def test_slow_down_is_the_only_transient_rate_limit(self):
        exc = openai_map(sdk_exc(_SdkRateLimit, 429, {"type": "rate_limit_error", "code": "slow_down"},
                                 {"retry-after": "4"}))
        self.assertIsInstance(exc, RateLimitedError)
        self.assertTrue(exc.retryable)
        self.assertEqual(exc.retry_after_seconds, 4)

    def test_plain_rate_limit_without_code_is_unknown(self):
        exc = openai_map(sdk_exc(_SdkRateLimit, 429, {"type": "rate_limit_error", "code": None}))
        assert_unknown_429(self, exc)

    def test_quota_and_billing_codes_map_to_fixed_reasons(self):
        quota = openai_map(sdk_exc(_SdkRateLimit, 429, {"code": "insufficient_quota"}))
        billing = openai_map(sdk_exc(_SdkRateLimit, 429, {"code": "credit_balance_exhausted"}))
        self.assertEqual(quota.failure_reason, "quota")
        self.assertEqual(billing.failure_reason, "billing")
        self.assertFalse(quota.retryable)
        self.assertFalse(billing.retryable)

    def test_unknown_code_and_non_dict_body_are_unknown(self):
        assert_unknown_429(self, openai_map(sdk_exc(_SdkRateLimit, 429, {"code": "SECRET-CODE-1028"})))
        assert_unknown_429(self, openai_map(sdk_exc(_SdkRateLimit, 429, "string body")))
        assert_unknown_429(self, openai_map(sdk_exc(_SdkRateLimit, 429, None)))

    def test_oversized_sdk_body_is_unknown(self):
        big = {"type": "rate_limit_error", "code": "slow_down", "pad": "x" * (MAX_ERROR_BODY_BYTES + 5)}
        assert_unknown_429(self, openai_map(sdk_exc(_SdkRateLimit, 429, big)))

    def test_invalid_retry_after_is_ignored(self):
        exc = openai_map(sdk_exc(_SdkRateLimit, 429, {"code": "slow_down"}, {"retry-after": "soon"}))
        self.assertIsNone(exc.retry_after_seconds)

    def test_402_uses_allowlist_and_is_not_retryable(self):
        exc = openai_map(sdk_exc(_SdkStatus, 402, {"type": "billing"}))
        self.assertEqual(exc.status_code, 402)
        self.assertEqual(exc.failure_reason, "unknown")
        self.assertFalse(exc.retryable)

    def test_retry_after_never_sleeps(self):
        with mock.patch("time.sleep", side_effect=AssertionError("must not sleep")):
            exc = openai_map(sdk_exc(_SdkRateLimit, 429, {"code": "slow_down"}, {"retry-after": "30"}))
        self.assertIsInstance(exc, RateLimitedError)

    def test_sdk_message_with_key_never_reaches_exception_text(self):
        exc = openai_map(sdk_exc(_SdkRateLimit, 429, {"code": "insufficient_quota"}))
        self.assertNotIn(KEY, str(exc))
        self.assertNotIn("SECRET-MSG-1028", str(exc))


# ---------------------------------------------------------------- gateway, core, audit, regressions
def profile(alias="p_primary", provider="gemini", model_id=MODEL, priority=0):
    return ModelProfile(
        alias=alias, provider=provider, model_id=model_id,
        capabilities=ModelCapabilities(text_generation=True, max_context_tokens=8192, max_output_tokens=4096),
        priority=priority,
    )


class _Capture(logging.Handler):
    def __init__(self):
        super().__init__()
        self.lines = []

    def emit(self, record):
        self.lines.append(record.getMessage())


def core_for(providers, profiles):
    gw = ModelGateway(providers, max_concurrent_calls=1)
    logger = logging.getLogger(AUDIT_LOGGER_NAME + ".stage1028")
    logger.handlers.clear()
    logger.propagate = False
    handler = _Capture()
    logger.addHandler(handler)
    return SanourCore(router=DeterministicRouter(profiles), gateway=gw,
                      audit=AuditLogger(logger)), gw, handler


class _FixedProvider:
    capabilities = TEST_ALL_CAPS

    def __init__(self, name, exc):
        self.name, self._exc, self.calls = name, exc, 0

    def generate(self, c):
        self.calls += 1
        raise self._exc


class GatewayAndCoreTests(unittest.TestCase):
    def test_transient_rate_limit_keeps_public_code_and_retryable_hint(self):
        prov = _FixedProvider("gemini", RateLimitedError("provider rate limited", retryable=True, status_code=429))
        gw = ModelGateway({"gemini": prov}, max_concurrent_calls=1)
        with self.assertRaises(SanourError) as ctx:
            gw.generate(profile(), call(), deadline_in(2.0), identity=_rid(profile()))
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_RATE_LIMITED)
        self.assertTrue(ctx.exception.retryable)
        self.assertEqual(ctx.exception.status_code, 429)
        self.assertEqual(prov.calls, 1)

    def test_quota_maps_to_provider_failed_with_reason_and_not_retryable(self):
        exc = ProviderError("provider limit reached", retryable=False, status_code=429, failure_reason="quota")
        gw = ModelGateway({"gemini": _FixedProvider("gemini", exc)}, max_concurrent_calls=1)
        with self.assertRaises(SanourError) as ctx:
            gw.generate(profile(), call(), deadline_in(2.0), identity=_rid(profile()))
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_FAILED)
        self.assertFalse(ctx.exception.retryable)
        self.assertEqual(ctx.exception.failure_reason, "quota")

    def test_unknown_429_releases_capacity_each_time(self):
        p, t = gemini(429, b"")
        gw = ModelGateway({"gemini": p}, max_concurrent_calls=1)
        for _ in range(3):
            with self.assertRaises(SanourError):
                gw.generate(profile(), call(), deadline_in(2.0), identity=_rid(profile()))
        self.assertEqual(gw.in_flight, 0)
        self.assertEqual(t.calls, 3)

    def test_unknown_429_is_not_retried_and_no_fallback_is_used(self):
        p, t = gemini(429, err(status="RESOURCE_EXHAUSTED"))
        other = _FixedProvider("grok", AssertionError("must not be called"))
        primary = profile(alias="p_primary", provider="gemini", priority=0)
        backup = profile(alias="p_backup", provider="grok", model_id="other-1", priority=1)
        core, _, _ = core_for({"gemini": p, "grok": other}, [primary, backup])
        response = core.handle({"profile_alias": "p_primary", "prompt": "hello"})
        self.assertEqual(response.error.code, ErrorCode.PROVIDER_FAILED.value)
        self.assertFalse(response.error.retryable)
        self.assertEqual(t.calls, 1)
        self.assertEqual(other.calls, 0)

    def test_audit_has_only_bounded_diagnostics_and_no_secrets(self):
        p, _ = gemini(429, err(status="RESOURCE_EXHAUSTED", message=SECRET_MSG))
        core, _, handler = core_for({"gemini": p}, [profile()])
        response = core.handle({"profile_alias": "p_primary", "prompt": PROMPT})
        failed = [line for line in handler.lines if "model.failed" in line]
        self.assertEqual(len(failed), 1)
        fields = json.loads(failed[0].split(" ", 1)[1])
        self.assertEqual(fields["provider"], "gemini")
        self.assertEqual(fields["status_code"], 429)
        self.assertEqual(fields["failure_reason"], "unknown")
        self.assertFalse(fields["retryable"])
        blob = "\n".join(handler.lines) + response.model_dump_json()
        for secret in (KEY, PROMPT, "SECRET-MSG-1028", "RESOURCE_EXHAUSTED", SECRET_MSG):
            self.assertNotIn(secret, blob)

    def test_audit_drops_invalid_diagnostic_values(self):
        logger = logging.getLogger(AUDIT_LOGGER_NAME + ".stage1028b")
        logger.handlers.clear()
        logger.propagate = False
        handler = _Capture()
        logger.addHandler(handler)
        AuditLogger(logger).emit("model.failed", failure_reason="SECRET-REASON-1028", status_code=True)
        AuditLogger(logger).emit("model.failed", failure_reason="quota", status_code=999)
        joined = "\n".join(handler.lines)
        self.assertNotIn("SECRET-REASON-1028", joined)
        self.assertNotIn('"status_code"', joined)
        self.assertIn('"failure_reason": "quota"', joined)


class RegressionTests(unittest.TestCase):
    def test_content_blocking_from_10_27_is_unchanged(self):
        body = json.dumps({"candidates": [{"content": {"parts": [{"text": "x"}]},
                                           "finishReason": "SAFETY"}]}).encode()
        p, _ = gemini(200, body)
        gw = ModelGateway({"gemini": p}, max_concurrent_calls=1)
        with self.assertRaises(SanourError) as ctx:
            gw.generate(profile(), call(), deadline_in(2.0), identity=_rid(profile()))
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_CONTENT_BLOCKED)
        self.assertFalse(ctx.exception.retryable)

    def test_identity_check_from_10_26_is_unchanged(self):
        body = json.dumps({"candidates": [{"content": {"parts": [{"text": "x"}]},
                                           "finishReason": "STOP"}], "modelVersion": "other-9"}).encode()
        p, _ = gemini(200, body)
        gw = ModelGateway({"gemini": p}, max_concurrent_calls=1)
        with self.assertRaises(SanourError) as ctx:
            gw.generate(profile(), call(), deadline_in(2.0), identity=_rid(profile()))
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_INVALID_RESPONSE)
        self.assertEqual(ctx.exception.scope, "model_identity")

    def test_success_path_is_unchanged(self):
        body = json.dumps({"candidates": [{"content": {"parts": [{"text": "hi"}]},
                                           "finishReason": "STOP"}], "modelVersion": MODEL}).encode()
        p, _ = gemini(200, body)
        result = ModelGateway({"gemini": p}, max_concurrent_calls=1).generate(profile(), call(), deadline_in(2.0), identity=_rid(profile()))
        self.assertEqual(result.text, "hi")
        self.assertEqual(result.reported_model_id, MODEL)


if __name__ == "__main__":
    unittest.main()
