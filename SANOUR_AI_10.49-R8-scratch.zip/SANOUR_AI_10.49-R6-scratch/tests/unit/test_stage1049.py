"""Stage 10.49: cost model, budgets, quotas, admission and settlement, persistence, audit.

Deterministic and offline: no SDK, no network, no real key, no real billing. Process-level tests use child
processes that touch only a temporary SQLite file.
"""

import json
import logging
import os
import sqlite3
import subprocess
import sys
import tempfile
import threading
import unittest
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

from sanour_ai.composition.runtime import Runtime
from sanour_ai.errors import ErrorCode, SanourError
from sanour_ai.governance import admission as admission_mod
from sanour_ai.governance.admission import AdmissionController
from sanour_ai.governance.cost import (
    STATUS_PRICED, STATUS_UNKNOWN_PRICING, STATUS_UNKNOWN_USAGE, PricingConfigError, PricingVersion,
    actual_cost, format_money, parse_price, select_pricing, worst_case_cost,
)
from sanour_ai.governance.store import GovernanceConflictError, GovernanceStorageError, GovernanceStore
from sanour_ai.governance.types import Bounds, Settlement
from sanour_ai.models.usage import Usage
from sanour_ai.observability.audit import AUDIT_LOGGER_NAME, AuditLogger
from tests.unit.test_stage1048 import OUTPUT, PROMPT, SECRET, env, raw
from tests.unit.r4_support import DownSink
from tests.unit.test_stage1047r1 import UsageProvider

SRC = Path(__file__).resolve().parents[2] / "src"
ALIAS = "openai_primary"
MODEL = "gpt-1048-test"
PROVIDER = "openai"
T0 = datetime(2026, 11, 7, 12, 0, tzinfo=timezone.utc).timestamp()
BOUNDS = {ALIAS: Bounds(max_input_tokens=8192, max_output_tokens=1024)}
WORST_512 = Decimal("0.02048")  # (8192 x 2 + 512 x 8) / 1e6 at 2.00 / 8.00 per million


def pricing(**kw):
    values = dict(provider_id=PROVIDER, model_id=MODEL, currency="USD", effective_from="2026-01-01",
                  input_per_million="2.00", output_per_million="8.00")
    values.update(kw)
    return PricingVersion.build(**values)


def request(max_output=512, timeout=30.0):
    return SimpleNamespace(request_id=os.urandom(16).hex(), max_output_tokens=max_output, timeout_seconds=timeout)


def profile():
    return SimpleNamespace(alias=ALIAS, provider=PROVIDER, model_id=MODEL)


class Clock:
    def __init__(self, now=T0):
        self.now = now

    def __call__(self):
        return self.now


def quiet_audit(name="test.1049"):
    return AuditLogger(logging.getLogger(name))


class GovBase(unittest.TestCase):
    def setUp(self):
        self._dir = tempfile.TemporaryDirectory()
        self.addCleanup(self._dir.cleanup)
        self.path = os.path.join(self._dir.name, "gov.db")
        self.clock = Clock()
        self._stores = []

    def store(self):
        s = GovernanceStore(self.path)
        self._stores.append(s)
        self.addCleanup(s.close)
        return s

    def controller(self, store=None, clock=None, bounds=BOUNDS, audit=None):
        c = AdmissionController(store or self.store(), audit=audit or quiet_audit(),
                                bounds=bounds, clock=clock or self.clock)
        return c

    def configure_pricing(self, store=None, **kw):
        (store or self.store()).upsert_pricing(pricing(**kw))

    def row_all(self, sql, *args):
        import sqlite3
        conn = sqlite3.connect(self.path)
        try:
            return conn.execute(sql, args).fetchall()
        finally:
            conn.close()

    def row(self, sql, *args):
        conn = sqlite3.connect(self.path)
        try:
            return conn.execute(sql, args).fetchone()
        finally:
            conn.close()

    def spent(self, budget_id, window):
        r = self.row("SELECT spent FROM budget_windows WHERE budget_id = ? AND window_start = ?", budget_id, window)
        return Decimal(r[0]) if r else Decimal(0)

    def exposed_budget(self, budget_id, window):
        r = self.row("SELECT exposed FROM budget_windows WHERE budget_id = ? AND window_start = ?", budget_id, window)
        return Decimal(r[0]) if r else Decimal(0)

    def reserved_budget(self, budget_id, window):
        r = self.row("SELECT reserved FROM budget_windows WHERE budget_id = ? AND window_start = ?", budget_id, window)
        return Decimal(r[0]) if r else Decimal(0)

    def quota_counts(self, quota_id, window):
        r = self.row("SELECT used, reserved FROM quota_windows WHERE quota_id = ? AND window_start = ?",
                     quota_id, window)
        return (r[0], r[1]) if r else (0, 0)


# ---------------------------------------------------------------- 1-10. cost model
class CostModel(unittest.TestCase):
    def test_decimal_cost_is_exact(self):
        cost = actual_cost(pricing(), Usage(input_tokens=1_000_000, output_tokens=500_000))
        self.assertEqual(cost.status, STATUS_PRICED)
        self.assertEqual(cost.amount, Decimal("6"))
        self.assertIsInstance(cost.amount, Decimal)

    def test_floats_and_malformed_prices_are_refused(self):
        for bad in (0.1, True, "NaN", "Infinity", "-1", "1e400", "0.0000000000001", "abc", None, 2):
            with self.subTest(value=bad):
                with self.assertRaises(PricingConfigError):
                    parse_price(bad)

    def test_unknown_pricing_is_unknown_not_zero(self):
        cost = actual_cost(None, Usage(input_tokens=5, output_tokens=5))
        self.assertEqual((cost.status, cost.amount), (STATUS_UNKNOWN_PRICING, None))

    def test_unknown_usage_is_unknown_not_zero(self):
        for usage in (None, Usage(input_tokens=None, output_tokens=3), Usage(input_tokens=3, output_tokens=None)):
            with self.subTest(usage=usage):
                cost = actual_cost(pricing(), usage)
                self.assertEqual((cost.status, cost.amount), (STATUS_UNKNOWN_USAGE, None))

    def test_no_price_is_inferred_from_a_model_name(self):
        versions = [pricing(model_id="gpt-4")]
        self.assertIsNone(select_pricing(versions, PROVIDER, "gpt-4-turbo", "2026-11-07"))
        self.assertIsNone(select_pricing(versions, "anthropic", "gpt-4", "2026-11-07"))

    def test_pricing_version_is_chosen_by_effective_day(self):
        old = pricing(effective_from="2026-01-01", input_per_million="1.00")
        new = pricing(effective_from="2026-11-01", input_per_million="3.00")
        versions = [old, new]
        self.assertIsNone(select_pricing(versions, PROVIDER, MODEL, "2025-12-31"))
        self.assertEqual(select_pricing(versions, PROVIDER, MODEL, "2026-10-31").input_per_million, Decimal("1.00"))
        self.assertEqual(select_pricing(versions, PROVIDER, MODEL, "2026-11-07").input_per_million, Decimal("3.00"))

    def test_cached_tokens_are_priced_once_inside_input(self):
        p = pricing(cached_input_per_million="0.50")
        cost = actual_cost(p, Usage(input_tokens=1_000_000, output_tokens=0, cached_input_tokens=400_000))
        self.assertEqual(cost.amount, Decimal("1.4"))  # 600k x 2.00 + 400k x 0.50

    def test_cached_tokens_without_a_cached_price_are_unknown(self):
        cost = actual_cost(pricing(), Usage(input_tokens=10, output_tokens=1, cached_input_tokens=4))
        self.assertEqual(cost.status, STATUS_UNKNOWN_PRICING)

    def test_reasoning_tokens_are_not_double_counted(self):
        self.assertEqual(actual_cost(pricing(), Usage(input_tokens=0, output_tokens=1_000_000,
                                                      reasoning_tokens=250_000)).amount, Decimal("8"))
        priced = pricing(reasoning_per_million="4.00")
        cost = actual_cost(priced, Usage(input_tokens=0, output_tokens=1_000_000, reasoning_tokens=250_000))
        self.assertEqual(cost.amount, Decimal("7"))  # 750k x 8 + 250k x 4, never 1M x 8 plus 250k x 4

    def test_reasoning_unknown_with_a_reasoning_price_is_unknown(self):
        cost = actual_cost(pricing(reasoning_per_million="4.00"), Usage(input_tokens=1, output_tokens=2))
        self.assertEqual(cost.status, STATUS_UNKNOWN_USAGE)

    def test_worst_case_bounds_the_real_cost(self):
        worst = worst_case_cost(pricing(), 8192, 512)
        self.assertEqual(worst, WORST_512)
        self.assertGreaterEqual(worst, actual_cost(pricing(), Usage(input_tokens=8192, output_tokens=512)).amount)

    def test_money_text_is_never_scientific(self):
        self.assertEqual(format_money(Decimal("0.000001")), "0.000001")
        self.assertEqual(format_money(Decimal("1E-7")), "0.0000001")

    def test_currency_and_dates_are_strict(self):
        with self.assertRaises(PricingConfigError):
            pricing(currency="usd")
        with self.assertRaises(PricingConfigError):
            pricing(effective_from="2026-02-30")

    def test_same_pricing_key_with_other_values_is_refused(self):
        store = GovernanceStore(os.path.join(tempfile.mkdtemp(), "p.db"))
        self.addCleanup(store.close)
        first = store.upsert_pricing(pricing())
        self.assertEqual(store.upsert_pricing(pricing()), first)
        with self.assertRaises(GovernanceConflictError):
            store.upsert_pricing(pricing(input_per_million="9.00"))


# -------------------------------------------------------------- budgets and admission
class Budgets(GovBase):
    def setUp(self):
        super().setUp()
        self.s = self.store()
        self.s.upsert_pricing(pricing())
        self.c = self.controller(self.s)

    def budget(self, scope="global", value="", period="daily", currency="USD", limit="1.00"):
        return self.s.upsert_budget(scope, value, period, currency, limit)

    def test_budget_refuses_before_any_reservation_is_written(self):
        bid = self.budget(limit="0.03")
        self.c.admit(request(), profile())  # 0.02048 fits
        with self.assertRaises(SanourError) as ctx:
            self.c.admit(request(), profile())  # 0.04096 would exceed 0.03
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_RATE_LIMITED)
        self.assertEqual(self.row("SELECT COUNT(*) FROM reservations")[0], 1)
        self.assertEqual(self.reserved_budget(bid, "2026-11-07"), WORST_512)

    def test_provider_model_and_profile_budgets_each_govern(self):
        for scope, value in (("provider", PROVIDER), ("model", MODEL), ("profile", ALIAS)):
            with self.subTest(scope=scope):
                s = GovernanceStore(os.path.join(tempfile.mkdtemp(), "s.db"))
                self.addCleanup(s.close)
                s.upsert_pricing(pricing())
                s.upsert_budget(scope, value, "daily", "USD", "0.01")
                with self.assertRaises(SanourError):
                    self.controller(s).admit(request(), profile())

    def test_unrelated_scope_does_not_apply(self):
        self.budget(scope="provider", value="anthropic", limit="0.00")
        self.c.admit(request(), profile())  # not refused: that budget is for another provider

    def test_strictest_applicable_limit_governs(self):
        self.budget(scope="global", limit="1.00")
        self.budget(scope="profile", value=ALIAS, limit="0.02")
        with self.assertRaises(SanourError):
            self.c.admit(request(), profile())

    def test_daily_and_monthly_windows(self):
        self.budget(period="monthly", limit="0.03")
        self.c.admit(request(), profile())
        self.clock.now = T0 + 86400  # next UTC day, same month
        with self.assertRaises(SanourError):
            self.c.admit(request(), profile())  # monthly window still full
        s = GovernanceStore(os.path.join(tempfile.mkdtemp(), "d.db"))
        self.addCleanup(s.close)
        s.upsert_pricing(pricing())
        s.upsert_budget("global", "", "daily", "USD", "0.03")
        clock = Clock(T0)
        c = self.controller(s, clock=clock)
        c.admit(request(), profile())
        clock.now = T0 + 86400
        c.admit(request(), profile())  # daily window reset

    def test_utc_day_boundary_uses_utc(self):
        self.budget(limit="0.03")
        self.clock.now = datetime(2026, 11, 7, 23, 59, 59, tzinfo=timezone.utc).timestamp()
        self.c.admit(request(), profile())
        self.clock.now = datetime(2026, 11, 8, 0, 0, 1, tzinfo=timezone.utc).timestamp()
        self.c.admit(request(), profile())  # new UTC day, new window

    def test_currency_mismatch_is_refused_as_unknown_cost(self):
        self.budget(currency="EUR", limit="10")
        with self.assertRaises(SanourError):
            self.c.admit(request(), profile())

    def test_budget_without_pricing_refuses_instead_of_treating_cost_as_zero(self):
        s = GovernanceStore(os.path.join(tempfile.mkdtemp(), "np.db"))
        self.addCleanup(s.close)
        s.upsert_budget("global", "", "daily", "USD", "100")
        with self.assertRaises(SanourError):
            self.controller(s).admit(request(), profile())

    def test_concurrent_reservations_never_exceed_the_budget(self):
        allowed = 3
        self.budget(limit=str(WORST_512 * allowed + Decimal("0.00001")))
        results = []
        codes = []
        guard = threading.Lock()
        gate = threading.Barrier(20)

        def attempt():
            c = self.controller(self.store())
            gate.wait(timeout=30)
            try:
                c.admit(request(), profile())
                outcome = True
            except SanourError as exc:
                outcome = False
                with guard:
                    codes.append(exc.code)
            with guard:
                results.append(outcome)

        threads = [threading.Thread(target=attempt) for _ in range(20)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=60)
        self.assertEqual(results.count(True), allowed)
        self.assertEqual(results.count(False), 20 - allowed)
        self.assertEqual(set(codes), {ErrorCode.PROVIDER_RATE_LIMITED})  # every failure is a refusal, never a storage error
        self.assertEqual(self.row("SELECT COUNT(*) FROM reservations")[0], allowed)

    def test_unused_reservation_is_released_after_actual_usage(self):
        bid = self.budget(limit="1.00")
        t = self.c.admit(request(), profile())
        self.assertEqual(self.reserved_budget(bid, "2026-11-07"), WORST_512)
        result = self.c.settle(t, Settlement("completed", True, Usage(input_tokens=4, output_tokens=2)))
        self.assertTrue(result.applied)
        self.assertEqual(self.reserved_budget(bid, "2026-11-07"), Decimal(0))
        self.assertEqual(self.spent(bid, "2026-11-07"), Decimal("0.000024"))  # (4x2 + 2x8) / 1e6

    def test_not_started_request_releases_everything(self):
        bid = self.budget(limit="1.00")
        t = self.c.admit(request(), profile())
        self.c.settle(t, Settlement("released", provider_started=False))
        self.assertEqual(self.reserved_budget(bid, "2026-11-07"), Decimal(0))
        self.assertEqual(self.spent(bid, "2026-11-07"), Decimal(0))
        self.assertEqual(self.row("SELECT cost_status FROM cost_records")[0], "not_billed")

    def test_failed_after_start_is_exposure_not_spending(self):
        bid = self.budget(limit="1.00")
        t = self.c.admit(request(), profile())
        self.c.settle(t, Settlement("failed", provider_started=True))
        self.assertEqual(self.spent(bid, "2026-11-07"), Decimal(0))  # no actual cost was ever reported
        self.assertEqual(self.exposed_budget(bid, "2026-11-07"), WORST_512)
        self.assertEqual(self.reserved_budget(bid, "2026-11-07"), Decimal(0))
        self.assertEqual(self.row("SELECT cost_status, charged_from FROM cost_records")[:2],
                         (STATUS_UNKNOWN_USAGE, "exposed"))

    def test_timeout_after_start_is_charged_like_a_failure(self):
        bid = self.budget(limit="1.00")
        t = self.c.admit(request(), profile())
        self.c.settle(t, Settlement("timed_out", provider_started=True))
        self.assertEqual(self.spent(bid, "2026-11-07"), Decimal(0))
        self.assertEqual(self.exposed_budget(bid, "2026-11-07"), WORST_512)

    def test_late_result_never_replaces_the_timeout_settlement(self):
        bid = self.budget(limit="1.00")
        t = self.c.admit(request(), profile())
        self.assertTrue(self.c.settle(t, Settlement("timed_out", True)).applied)
        late = self.c.settle(t, Settlement("completed", True, Usage(input_tokens=1, output_tokens=1)))
        self.assertFalse(late.applied)
        self.assertEqual(late.reason, "already_settled")
        self.assertEqual(self.spent(bid, "2026-11-07"), Decimal(0))  # the late, smaller usage never counts
        self.assertEqual(self.exposed_budget(bid, "2026-11-07"), WORST_512)

    def test_duplicate_reconciliation_counts_once(self):
        bid = self.budget(limit="1.00")
        t = self.c.admit(request(), profile())
        usage = Usage(input_tokens=4, output_tokens=2)
        self.assertTrue(self.c.settle(t, Settlement("completed", True, usage)).applied)
        self.assertFalse(self.c.settle(t, Settlement("completed", True, usage)).applied)
        self.assertEqual(self.spent(bid, "2026-11-07"), Decimal("0.000024"))

    def test_reservation_expires_and_is_charged_conservatively_after_restart(self):
        bid = self.budget(limit="1.00")
        t = self.c.admit(request(timeout=5), profile())
        self.s.close()
        later = Clock(T0 + 10_000)
        reopened = self.store()
        c2 = self.controller(reopened, clock=later)
        self.assertEqual(c2.sweep(), 1)
        self.assertEqual(self.spent(bid, "2026-11-07"), Decimal(0))
        self.assertEqual(self.exposed_budget(bid, "2026-11-07"), WORST_512)
        self.assertEqual(self.row("SELECT state FROM reservations")[0], "exposed")
        self.assertEqual(c2.settle(t, Settlement("completed", True, Usage(input_tokens=1, output_tokens=1))).reason,
                         "already_settled")

    def test_shutdown_settles_every_outstanding_reservation(self):
        bid = self.budget(limit="1.00")
        self.c.admit(request(), profile())
        self.c.admit(request(), profile())
        self.assertEqual(self.c.sweep(everything=True), 2)
        self.assertEqual(self.spent(bid, "2026-11-07"), Decimal(0))
        self.assertEqual(self.exposed_budget(bid, "2026-11-07"), WORST_512 * 2)
        self.assertEqual(self.row("SELECT COUNT(*) FROM reservations WHERE state = 'reserved'")[0], 0)

    def test_pricing_history_is_preserved_when_a_new_version_arrives(self):
        self.budget(limit="10.00")
        t = self.c.admit(request(), profile())
        self.c.settle(t, Settlement("completed", True, Usage(input_tokens=1_000_000, output_tokens=0)))
        self.s.upsert_pricing(pricing(effective_from="2026-11-01", input_per_million="50.00"))
        t2 = self.c.admit(request(), profile())
        self.c.settle(t2, Settlement("completed", True, Usage(input_tokens=1_000_000, output_tokens=0)))
        rows = self.row("SELECT pricing_version_id, actual_cost FROM cost_records WHERE request_id = ?", t.request_id)
        self.assertEqual(Decimal(rows[1]), Decimal("2"))
        self.assertEqual(self.row("SELECT COUNT(*) FROM pricing_versions WHERE model_id = ?", MODEL)[0], 2)


# ---------------------------------------------------------------------- quotas
class Quotas(GovBase):
    def setUp(self):
        super().setUp()
        self.s = self.store()
        self.c = self.controller(self.s)

    def quota(self, metric, limit, scope="global", value="", period="daily"):
        return self.s.upsert_quota(scope, value, period, metric, limit)

    def test_request_quota_refuses_the_extra_request(self):
        qid = self.quota("requests", 2)
        self.c.admit(request(), profile())
        self.c.admit(request(), profile())
        with self.assertRaises(SanourError):
            self.c.admit(request(), profile())
        self.assertEqual(self.quota_counts(qid, "2026-11-07"), (0, 2))

    def test_token_quota_uses_the_worst_case_bounds(self):
        self.quota("total_tokens", 1000)  # bounds sum is 8192 + 512
        with self.assertRaises(SanourError):
            self.c.admit(request(), profile())

    def test_quota_metric_is_named_in_the_refusal_audit(self):
        self.quota("input_tokens", 10)
        with self.assertLogs(AUDIT_LOGGER_NAME, level="INFO") as captured:
            with self.assertRaises(SanourError):
                self.controller(self.s, audit=AuditLogger()).admit(request(), profile())
        text = "\n".join(captured.output)
        self.assertIn("quota.rejected", text)
        self.assertIn("input_tokens", text)

    def test_concurrent_quota_reservations_never_exceed_the_limit(self):
        qid = self.quota("requests", 5)
        results = []
        codes = []
        guard = threading.Lock()
        gate = threading.Barrier(20)

        def attempt():
            gate.wait(timeout=30)
            try:
                self.controller(self.store()).admit(request(), profile())
                outcome = True
            except SanourError as exc:
                outcome = False
                with guard:
                    codes.append(exc.code)
            with guard:
                results.append(outcome)

        threads = [threading.Thread(target=attempt) for _ in range(20)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=60)
        self.assertEqual(results.count(True), 5)
        self.assertEqual(set(codes), {ErrorCode.PROVIDER_RATE_LIMITED})
        self.assertEqual(self.quota_counts(qid, "2026-11-07")[1], 5)

    def test_unknown_usage_never_becomes_zero_for_quota(self):
        qid = self.quota("input_tokens", 100_000)
        t = self.c.admit(request(), profile())
        self.c.settle(t, Settlement("completed", True, Usage(input_tokens=None, output_tokens=3)))
        used, reserved = self.quota_counts(qid, "2026-11-07")
        self.assertEqual((used, reserved), (0, 0))
        self.assertEqual(self.row("SELECT exposed FROM quota_windows WHERE quota_id = ?", qid)[0], 8192)  # exposed, not 0

    def test_known_usage_replaces_the_reservation(self):
        qid = self.quota("output_tokens", 100_000)
        t = self.c.admit(request(), profile())
        self.c.settle(t, Settlement("completed", True, Usage(input_tokens=3, output_tokens=7)))
        self.assertEqual(self.quota_counts(qid, "2026-11-07"), (7, 0))

    def test_released_request_frees_quota(self):
        qid = self.quota("requests", 1)
        t = self.c.admit(request(), profile())
        self.c.settle(t, Settlement("released", provider_started=False))
        self.assertEqual(self.quota_counts(qid, "2026-11-07"), (0, 0))
        self.c.admit(request(), profile())  # the slot is free again

    def test_monthly_quota_window_is_the_utc_month(self):
        qid = self.quota("requests", 1, period="monthly")
        self.c.admit(request(), profile())
        self.assertEqual(self.quota_counts(qid, "2026-11"), (0, 1))
        self.clock.now = T0 + 86400 * 20  # still November
        with self.assertRaises(SanourError):
            self.c.admit(request(), profile())


# ------------------------------------------------------------------- persistence
class Persistence(GovBase):
    def test_migrations_run_once_and_are_versioned(self):
        s = self.store()
        self.assertEqual(s.schema_version(), 6)
        s.close()
        again = self.store()
        self.assertEqual(again.schema_version(), 6)
        self.assertEqual(self.row("SELECT COUNT(*) FROM schema_migrations")[0], 6)

    def test_store_refuses_a_schema_written_by_a_newer_release(self):
        self.store().close()
        conn = sqlite3.connect(self.path)
        conn.execute("INSERT INTO schema_migrations (version, applied_at) VALUES (99, 0)")
        conn.commit()
        conn.close()
        with self.assertRaises(GovernanceStorageError):
            GovernanceStore(self.path)

    def test_budget_and_quota_state_survive_restart(self):
        s = self.store()
        s.upsert_pricing(pricing())
        bid = s.upsert_budget("global", "", "daily", "USD", "1.00")
        c = self.controller(s)
        t = c.admit(request(), profile())
        c.settle(t, Settlement("completed", True, Usage(input_tokens=4, output_tokens=2)))
        s.close()
        reopened = self.store()
        self.assertEqual(self.controller(reopened).settle(t, Settlement("failed", True)).reason, "already_settled")
        self.assertEqual(self.spent(bid, "2026-11-07"), Decimal("0.000024"))
        self.assertTrue(reopened.integrity_ok())

    def test_pricing_and_budget_rows_persist_as_text_decimals(self):
        s = self.store()
        s.upsert_pricing(pricing(input_per_million="0.000001"))
        s.upsert_budget("global", "", "daily", "USD", "12.5")
        self.assertEqual(self.row("SELECT input_per_million FROM pricing_versions")[0], "0.000001")
        self.assertEqual(self.row("SELECT limit_amount FROM budgets")[0], "12.5")

    def test_failed_write_is_refused_and_leaves_no_reservation(self):
        s = self.store()
        s.upsert_pricing(pricing())
        s.upsert_budget("global", "", "daily", "USD", "1.00")
        c = self.controller(s)
        real = s._conn
        s._conn = _FailOn(real, "INSERT INTO reservation_lines")
        with self.assertRaises(SanourError) as ctx:
            c.admit(request(), profile())
        s._conn = real
        self.assertEqual(ctx.exception.code, ErrorCode.INTERNAL_ERROR)
        self.assertEqual(self.row("SELECT COUNT(*) FROM reservations")[0], 0)
        self.assertEqual(self.row("SELECT COUNT(*) FROM budget_windows")[0], 0)


class _FailOn:
    def __init__(self, real, prefix):
        self._real, self._prefix = real, prefix

    def execute(self, sql, *args):
        if sql.startswith(self._prefix):
            raise sqlite3.OperationalError("disk I/O error")
        return self._real.execute(sql, *args)

    def close(self):
        self._real.close()


# --------------------------------------------------------------------- multi-process
class MultiProcess(GovBase):
    def test_processes_sharing_one_file_never_exceed_the_budget(self):
        s = self.store()
        s.upsert_pricing(pricing())
        s.upsert_budget("global", "", "daily", "USD", str(WORST_512 * 4 + Decimal("0.00001")))
        child = (
            "import sys, os\n"
            f"sys.path.insert(0, {str(SRC)!r})\n"
            "sys.path.insert(0, '.')\n"
            "from types import SimpleNamespace\n"
            "from sanour_ai.governance.store import GovernanceStore\n"
            "from sanour_ai.governance.admission import AdmissionController\n"
            "from sanour_ai.governance.types import Bounds\n"
            "from sanour_ai.observability.audit import AuditLogger\n"
            "from sanour_ai.errors import SanourError\n"
            "from tests.unit.test_stage1049 import ALIAS, BOUNDS, T0, Clock\n"
            "store = GovernanceStore(sys.argv[1])\n"
            "c = AdmissionController(store, audit=AuditLogger(), bounds=BOUNDS, clock=Clock(T0))\n"
            "ok = 0\n"
            "for i in range(8):\n"
            "    req = SimpleNamespace(request_id=os.urandom(16).hex(), max_output_tokens=512, timeout_seconds=30.0)\n"
            "    prof = SimpleNamespace(alias=ALIAS, provider='openai', model_id='gpt-1048-test')\n"
            "    try:\n"
            "        c.admit(req, prof)\n"
            "        ok += 1\n"
            "    except SanourError:\n"
            "        pass\n"
            "print(ok)\n"
        )
        procs = [subprocess.Popen([sys.executable, "-c", child, self.path], stdout=subprocess.PIPE,
                                  stderr=subprocess.PIPE, text=True, cwd=str(SRC.parent)) for _ in range(3)]
        admitted = 0
        for p in procs:
            out, err = p.communicate(timeout=120)
            self.assertEqual(p.returncode, 0, err)
            admitted += int(out.strip().splitlines()[-1])
        self.assertEqual(admitted, 4)
        self.assertEqual(self.row("SELECT COUNT(*) FROM reservations")[0], 4)


# -------------------------------------------------------------------------- audit
class GovernanceAudit(GovBase):
    def test_every_governance_event_is_emitted_with_allowlisted_fields(self):
        s = self.store()
        s.upsert_pricing(pricing())
        s.upsert_budget("global", "", "daily", "USD", "0.03")
        s.upsert_quota("global", "", "daily", "requests", 10)
        c = self.controller(s, audit=AuditLogger())
        with self.assertLogs(AUDIT_LOGGER_NAME, level="INFO") as captured:
            t = c.admit(request(), profile())
            with self.assertRaises(SanourError):
                c.admit(request(), profile())
            c.settle(t, Settlement("completed", True, Usage(input_tokens=4, output_tokens=2)))
        text = "\n".join(captured.output)
        for event in ("pricing.version_selected", "budget.rejected"):
            self.assertIn(event, text)
        # Settlement events are outbox rows since Stage 10.49-R3 (delivered to the sink after commit).
        self.assertEqual(sorted(r[0] for r in self.row_all("SELECT event FROM audit_outbox WHERE event IN "
                                                          "('budget.reconciled', 'quota.reconciled')")),
                         ["budget.reconciled", "quota.reconciled"])
        # Stage 10.49-R4: the reservation events are required outbox rows, delivered to the sink before any provider call.
        self.assertEqual(sorted(r[0] for r in self.row_all("SELECT event FROM audit_outbox WHERE event IN "
                                                          "('budget.reserved', 'quota.reserved')")),
                         ["budget.reserved", "quota.reserved"])
        self.assertNotIn(PROMPT, text)
        self.assertNotIn(SECRET, text)
        self.assertNotIn(self.path, text)

    def test_unknown_cost_is_audited(self):
        s = self.store()
        s.upsert_budget("global", "", "daily", "USD", "100")
        with self.assertLogs(AUDIT_LOGGER_NAME, level="INFO") as captured:
            with self.assertRaises(SanourError):
                self.controller(s, audit=AuditLogger()).admit(request(), profile())
        self.assertIn("cost.unknown", "\n".join(captured.output))

    def test_audit_failure_before_provider_releases_and_refuses(self):
        s = self.store()
        s.upsert_pricing(pricing())
        bid = s.upsert_budget("global", "", "daily", "USD", "1.00")
        broken = AuditLogger(logging.getLogger("test.1049.broken"))
        with self.assertRaises(SanourError) as ctx:
            AdmissionController(s, audit=broken, bounds=BOUNDS, clock=self.clock,
                                authorized_actors=frozenset({"ops.alice"}), sink=DownSink()).admit(request(), profile())
        self.assertEqual(ctx.exception.code, ErrorCode.INTERNAL_ERROR)
        self.assertNotIn(SECRET, str(ctx.exception))
        self.assertEqual(self.reserved_budget(bid, "2026-11-07"), Decimal(0))
        self.assertEqual(self.spent(bid, "2026-11-07"), Decimal(0))
        self.assertEqual(self.row("SELECT state FROM reservations")[0], "released")


# ----------------------------------------------------------- request admission in runtime
class RuntimeAdmission(GovBase):
    def runtime(self, provider, budget_limit=None, quota=None, clock=None):
        s = self.store()
        if budget_limit is not None:
            s.upsert_pricing(pricing())
            s.upsert_budget("global", "", "daily", "USD", budget_limit)
        if quota is not None:
            s.upsert_quota("global", "", "daily", "requests", quota)
        ctl = self.controller(s, clock=clock)
        rt = Runtime.build_for_tests(env(), provider=provider, usage_ledger_path=self.path, governance=ctl)
        self.addCleanup(lambda: rt.shutdown(1.0))
        return rt, ctl

    def test_budget_rejection_happens_before_any_provider_call(self):
        provider = UsageProvider(Usage(input_tokens=1, output_tokens=1))
        rt, _ = self.runtime(provider, budget_limit="0.01")
        response = rt.handle(raw(max_output_tokens=512))
        self.assertEqual(response.status, "error")
        self.assertEqual(response.error.code, ErrorCode.PROVIDER_RATE_LIMITED)
        self.assertEqual(provider.calls, 0)  # no provider call after a budget rejection

    def test_quota_rejection_happens_before_any_provider_call(self):
        provider = UsageProvider(Usage(input_tokens=1, output_tokens=1))
        rt, _ = self.runtime(provider, quota=0)
        self.assertEqual(rt.handle(raw()).error.code, ErrorCode.PROVIDER_RATE_LIMITED)
        self.assertEqual(provider.calls, 0)

    def test_admitted_request_settles_the_actual_cost(self):
        provider = UsageProvider(Usage(input_tokens=4, output_tokens=2, total_tokens=6))
        rt, ctl = self.runtime(provider, budget_limit="1.00")
        self.assertEqual(rt.handle(raw(max_output_tokens=512)).status, "success")
        self.assertEqual(provider.calls, 1)
        self.assertEqual(self.row("SELECT state FROM reservations")[0], "settled")
        self.assertEqual(self.row("SELECT actual_cost FROM cost_records")[0], "0.000024")

    def test_failed_provider_call_is_charged_reserved(self):
        class Failing(UsageProvider):
            def generate(self, call):
                from sanour_ai.models.base import ProviderError
                from sanour_ai.errors import FailureKind
                raise ProviderError("boom", kind=FailureKind.REQUEST_REJECTED, retryable=False)

        rt, _ = self.runtime(Failing(Usage()), budget_limit="1.00")
        self.assertNotEqual(rt.handle(raw(max_output_tokens=512)).status, "success")
        self.assertEqual(self.row("SELECT state, settlement FROM reservations")[:2], ("exposed", "failed"))
        self.assertEqual(self.row("SELECT charged_from FROM cost_records")[0], "exposed")

    def test_shutdown_with_outstanding_reservations_settles_them(self):
        provider = UsageProvider(Usage(input_tokens=1, output_tokens=1))
        rt, ctl = self.runtime(provider, budget_limit="1.00")
        ctl.admit(request(), profile())  # an admitted reservation nobody settled
        rt.shutdown(1.0)
        self.assertTrue(rt.wait_stopped(5))
        self.assertEqual(self.row("SELECT COUNT(*) FROM reservations WHERE state = 'reserved'")[0], 0)
        self.assertEqual(self.row("SELECT state FROM reservations")[0], "exposed")

    def test_no_fallback_or_auto_selection_when_refused(self):
        provider = UsageProvider(Usage(input_tokens=1, output_tokens=1))
        rt, _ = self.runtime(provider, budget_limit="0.01")
        rt.handle(raw())
        rt.handle({"profile_alias": "not_configured", "prompt": PROMPT})
        self.assertEqual(provider.calls, 0)


class CoordinatorSettlement(GovBase):
    def runtime(self, budget_limit="1.00"):
        s = self.store()
        s.upsert_pricing(pricing())
        bid = s.upsert_budget("global", "", "daily", "USD", budget_limit)
        ctl = self.controller(s)
        provider = UsageProvider(Usage(input_tokens=1, output_tokens=1))
        rt = Runtime.build_for_tests(env(), provider=provider, usage_ledger_path=self.path, governance=ctl)
        self.addCleanup(lambda: rt.shutdown(1.0))
        return rt, provider, bid

    def test_capacity_refusal_releases_the_reservation_and_calls_no_provider(self):
        rt, provider, bid = self.runtime()
        with mock.patch.object(rt._core._gateway, "generate",  # noqa: SLF001
                               side_effect=SanourError(ErrorCode.PROVIDER_OVERLOADED, "busy")):
            response = rt.handle(raw(max_output_tokens=512))
        self.assertEqual(response.error.code, ErrorCode.PROVIDER_OVERLOADED)
        self.assertEqual(provider.calls, 0)
        self.assertEqual(self.row("SELECT state, settlement FROM reservations")[:2], ("released", "released"))
        self.assertEqual(self.reserved_budget(bid, "2026-11-07"), Decimal(0))
        self.assertEqual(self.spent(bid, "2026-11-07"), Decimal(0))

    def test_unexpected_crash_after_start_settles_as_a_failure(self):
        rt, provider, bid = self.runtime()

        def started_then_crashed(profile, call, deadline, observer=None, identity=None):
            observer.on_admitted()  # the gateway reports that the worker is starting: a call may now happen
            raise RuntimeError("unexpected")

        with mock.patch.object(rt._core._gateway, "generate",  # noqa: SLF001
                               side_effect=started_then_crashed):
            response = rt.handle(raw(max_output_tokens=512))
        self.assertEqual(response.status, "error")
        self.assertEqual(self.row("SELECT state, settlement FROM reservations")[:2], ("exposed", "failed"))
        self.assertEqual(self.spent(bid, "2026-11-07"), Decimal(0))
        self.assertEqual(self.exposed_budget(bid, "2026-11-07"), WORST_512)
        self.assertEqual(self.reserved_budget(bid, "2026-11-07"), Decimal(0))

    def test_model_scoped_quota_applies_to_that_model_only(self):
        s = self.store()
        s.upsert_quota("model", MODEL, "daily", "requests", 1)
        c = self.controller(s)
        c.admit(request(), profile())
        with self.assertRaises(SanourError):
            c.admit(request(), profile())
        other = SimpleNamespace(alias="other_profile", provider=PROVIDER, model_id="gpt-other")
        c.admit(request(), other)  # a different model is not limited by that quota


if __name__ == "__main__":
    unittest.main()
