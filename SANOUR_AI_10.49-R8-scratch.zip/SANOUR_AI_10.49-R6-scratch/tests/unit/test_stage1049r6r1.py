"""Stage 10.49-R6-R1: governance logging failure visibility, settlement idempotency, read-only spend/usage
reconciliation, and restart after a process death between intent and apply.

Invariants under test:
- a lost DIAGNOSTIC record (refusal or failure log row) is counted and emitted, never silent, and never re-enters the
  logger (no recursion);
- a lost REQUIRED decision record aborts the mutation: nothing is committed and the caller sees an error;
- a settled reservation cannot be applied again, by any path: no second cost record, no second budget or quota move;
- concurrent settle attempts on one reservation move money exactly once;
- budget.spent and quota.used are recomputed read-only from authoritative records; tampering is reported and never
  repaired; verified-usage token counts (never persisted) are reported as unverifiable, never guessed.
"""

import logging
import os
import sqlite3
import subprocess
import sys
import threading
import unittest
from decimal import Decimal

from sanour_ai.errors import SanourError
from sanour_ai.governance.admission import OP_APPLY, AdmissionController
from sanour_ai.governance.reconcile import reconcile
from sanour_ai.governance.sink import DurableSqliteSink
from sanour_ai.governance.store import GovernanceStore
from sanour_ai.governance.types import Settlement
from sanour_ai.models.usage import Usage
from sanour_ai.observability.audit import AuditLogger
from tests.unit.r5_support import DieBefore, RaiseOn
from tests.unit.test_stage1049 import BOUNDS, Clock, GovBase, pricing, profile, request

REPO = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
SRC = os.path.join(REPO, "src")
USAGE = Usage(input_tokens=4, output_tokens=2, total_tokens=6)
PRICED = Decimal("0.000024")
OPS = "ops1"

CHILD_DIES_BEFORE_COST_ROW = r'''
import logging, sys
from sanour_ai.governance.admission import AdmissionController
from sanour_ai.governance.store import GovernanceStore
from sanour_ai.governance.sink import DurableSqliteSink
from sanour_ai.governance.types import Settlement
from sanour_ai.models.usage import Usage
from sanour_ai.observability.audit import AuditLogger
from tests.unit.r5_support import DieBefore
from tests.unit.test_stage1049 import BOUNDS, Clock
gov, rid = sys.argv[1:3]
store = GovernanceStore(gov)
store._conn = DieBefore(store._conn, "INSERT INTO cost_records", 7)  # noqa: SLF001
ctl = AdmissionController(store, audit=AuditLogger(logging.getLogger("child")), bounds=BOUNDS, clock=Clock(),
                          sink=DurableSqliteSink(gov + ".sink"))
ctl.settle_by_id(rid, Settlement("completed", provider_started=True,
                                 usage=Usage(input_tokens=4, output_tokens=2, total_tokens=6)))
raise SystemExit(0)
'''


class RecordingAudit:
    """Test double for the audit logger: records event names. emit never raises, like the real one."""

    def __init__(self):
        self.events = []

    def emit(self, event, **fields):
        self.events.append(event)
        return True


class Base(GovBase):
    # Budget 0.02 USD daily: a max_output=100 request fits (worst 0.017184), a max_output=512 request is refused.
    def setUp(self):
        super().setUp()
        s = self.store()
        s.upsert_pricing(pricing())
        s.upsert_budget("global", "", "daily", "USD", "0.02")

    def ctl(self, store=None, audit=None, authorized=frozenset()):
        return AdmissionController(store or self.store(), audit=audit or RecordingAudit(), bounds=BOUNDS,
                                   clock=self.clock, authorized_actors=authorized,
                                   sink=DurableSqliteSink(self.path + ".sink", clock=self.clock))

    def admit(self, ctl=None, max_output=100):
        ctl = ctl or self.ctl()
        return ctl, ctl.admit(request(max_output=max_output), profile()).request_id

    def state(self, rid):
        return self.row("SELECT state FROM reservations WHERE request_id = ?", rid)[0]

    def snapshot(self):
        return (self.row_all("SELECT budget_id, window_start, reserved, spent, exposed FROM budget_windows"),
                self.row_all("SELECT quota_id, window_start, reserved, used, exposed FROM quota_windows"),
                self.row_all("SELECT request_id, cost_status, actual_cost, charged_from FROM cost_records"),
                self.row_all("SELECT COUNT(*) FROM governance_log")[0][0],
                self.row_all("SELECT COUNT(*) FROM audit_outbox")[0][0])

    def errors(self, report=None):
        report = report or reconcile(self.path, now=self.clock.now)
        return [i for i in report["findings"]["items"] if i["severity"] == "error"], report


class DiagnosticLogFailure(Base):
    def test_refusal_log_loss_is_counted_audited_and_the_refusal_still_reaches_the_caller(self):
        store = self.store()
        store._conn = RaiseOn(store._conn, "INSERT INTO governance_log")  # noqa: SLF001
        audit = RecordingAudit()
        ctl = self.ctl(store, audit=audit)
        with self.assertRaises(SanourError):
            ctl.admit(request(max_output=512), profile())  # refused by budget; its diagnostic row cannot be written
        self.assertEqual(ctl.diagnostic_log_failures(), 1)
        self.assertIn("governance.log_failed", audit.events)
        self.assertIn("budget.rejected", audit.events)
        errors, _ = self.errors()
        self.assertEqual(errors, [])

    def test_diagnostic_loss_makes_exactly_one_write_attempt_no_recursion(self):
        store = self.store()
        attempts = []
        real = store.transaction

        def counted():
            attempts.append(1)
            return real()

        store.transaction = counted
        store._conn = RaiseOn(store._conn, "INSERT INTO governance_log")  # noqa: SLF001
        ctl = self.ctl(store)
        ctl._log_best_effort("req-x", "admit", "refused", None, 0)  # noqa: SLF001
        self.assertEqual(len(attempts), 1)
        self.assertEqual(ctl.diagnostic_log_failures(), 1)

    def test_working_diagnostic_path_still_writes_its_row(self):
        ctl = self.ctl()
        with self.assertRaises(SanourError):
            ctl.admit(request(max_output=512), profile())
        self.assertEqual(ctl.diagnostic_log_failures(), 0)
        rows = self.row_all("SELECT operation, outcome FROM governance_log WHERE outcome = 'refused'")
        self.assertEqual(rows, [("admit", "refused")])

    def test_required_decision_log_loss_aborts_admission_with_nothing_committed(self):
        store = self.store()
        store._conn = RaiseOn(store._conn, "INSERT INTO governance_log")  # noqa: SLF001
        ctl = self.ctl(store)
        with self.assertRaises(SanourError) as caught:
            ctl.admit(request(max_output=100), profile())
        self.assertEqual(caught.exception.code.value, "internal_error")
        self.assertEqual(self.row("SELECT COUNT(*) FROM reservations")[0], 0)
        self.assertEqual(self.row("SELECT COUNT(*) FROM reservation_lines")[0], 0)
        self.assertEqual(Decimal(self.row("SELECT COALESCE(SUM(CAST(reserved AS REAL)), 0) FROM budget_windows")[0]),
                         Decimal(0))

    def test_restart_after_diagnostic_loss_is_consistent_and_the_loss_is_not_hidden_in_the_new_process(self):
        store = self.store()
        store._conn = RaiseOn(store._conn, "INSERT INTO governance_log")  # noqa: SLF001
        ctl = self.ctl(store)
        with self.assertRaises(SanourError):
            ctl.admit(request(max_output=512), profile())
        self.assertEqual(ctl.diagnostic_log_failures(), 1)
        store.close()
        restarted = self.ctl()  # new process: the counter restarts at zero; the audit trail kept the failure event
        self.assertEqual(restarted.diagnostic_log_failures(), 0)
        errors, _ = self.errors()
        self.assertEqual(errors, [])


class SettlementIdempotency(Base):
    def settle(self, ctl, rid, kind="completed", started=True, usage=USAGE):
        return ctl.settle_by_id(rid, Settlement(kind, provider_started=started, usage=usage))

    def test_double_settle_of_a_settled_reservation_moves_no_money_and_writes_no_row(self):
        ctl, rid = self.admit()
        self.assertTrue(self.settle(ctl, rid).applied)
        before = self.snapshot()
        again = self.settle(ctl, rid)
        self.assertFalse(again.applied)
        self.assertEqual(again.reason, "already_settled")
        self.assertEqual(self.snapshot(), before)
        self.assertEqual(self.row("SELECT spent FROM budget_windows")[0], str(PRICED))

    def test_direct_apply_on_a_settled_reservation_is_refused_by_the_state_guard(self):
        # Targets the apply-once guard itself, not the intent stage: the apply path is invoked directly.
        ctl, rid = self.admit()
        self.assertTrue(self.settle(ctl, rid).applied)
        before = self.snapshot()
        result = ctl._apply(rid, OP_APPLY)  # noqa: SLF001
        self.assertFalse(result.applied)
        self.assertEqual(result.reason, "already_settled")
        self.assertEqual(self.snapshot(), before)

    def test_direct_apply_with_no_pending_intent_never_touches_budget_or_quota(self):
        ctl, rid = self.admit()
        before = self.snapshot()
        result = ctl._apply(rid, OP_APPLY)  # noqa: SLF001 - reserved, never intended
        self.assertFalse(result.applied)
        self.assertEqual(self.snapshot(), before)
        self.assertEqual(self.state(rid), "reserved")

    def test_a_conflicting_second_outcome_after_settlement_changes_nothing(self):
        ctl, rid = self.admit()
        self.settle(ctl, rid)
        before = self.snapshot()
        self.assertEqual(self.settle(ctl, rid, kind="failed", usage=None).reason, "already_settled")
        self.assertEqual(self.snapshot(), before)

    def test_concurrent_settle_attempts_on_one_reservation_apply_exactly_once(self):
        ctl, rid = self.admit()
        results, errors = [], []
        barrier = threading.Barrier(8)

        def attempt():
            try:
                store = GovernanceStore(self.path)
                c = AdmissionController(store, audit=RecordingAudit(), bounds=BOUNDS, clock=self.clock,
                                        sink=DurableSqliteSink(self.path + ".sink", clock=self.clock))
                barrier.wait()
                results.append(c.settle_by_id(rid, Settlement("completed", True, USAGE)))
                store.close()
            except Exception as exc:  # pragma: no cover - any escape is a failure below
                errors.append(exc)

        threads = [threading.Thread(target=attempt) for _ in range(8)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(60)
        self.assertEqual(errors, [])
        self.assertEqual(sum(1 for r in results if r.applied), 1)
        # Any attempt that did not apply must be refused or pending, never a second money move.
        self.assertTrue(all(r.reason in {"already_settled", "settlement_pending", "settlement_failed",
                                         "intent_conflict", "duplicate"} or r.applied for r in results), results)
        self.assertEqual(self.row("SELECT COUNT(*) FROM cost_records")[0], 1)
        self.assertEqual(self.row("SELECT spent FROM budget_windows")[0], str(PRICED))
        self.assertEqual(self.state(rid), "settled")
        self.assertEqual(self.errors()[0], [])

    def test_death_between_intent_and_apply_then_restart_applies_once(self):
        ctl, rid = self.admit()
        store = self.store()
        store._conn = RaiseOn(store._conn, "INSERT INTO cost_records")  # noqa: SLF001 - apply fails after intent
        broken = self.ctl(store)
        self.assertFalse(self.settle(broken, rid).applied)
        self.assertEqual(self.state(rid), "settlement_pending")
        self.assertEqual(self.row("SELECT COUNT(*) FROM cost_records")[0], 0)
        store.close()
        # Real process death at the same boundary: the child re-issues the settlement and dies before the apply.
        env = dict(os.environ, PYTHONPATH=f"{SRC}{os.pathsep}{REPO}")
        code = subprocess.run([sys.executable, "-c", CHILD_DIES_BEFORE_COST_ROW, self.path, rid], env=env,
                              cwd=REPO, timeout=120, capture_output=True).returncode
        self.assertEqual(code, 7)
        self.assertEqual(self.row("SELECT COUNT(*) FROM cost_records")[0], 0)
        restarted = self.ctl()
        self.assertEqual(restarted.sweep(), 1)  # the intent is applied exactly once
        second = restarted.sweep()
        self.assertEqual(self.row("SELECT COUNT(*) FROM cost_records")[0], 1)
        self.assertEqual(self.row("SELECT spent FROM budget_windows")[0], str(PRICED))
        self.assertEqual(self.state(rid), "settled")
        self.assertEqual(second, 0)
        self.assertEqual(self.errors()[0], [])


class SpendAndUsageReconciliation(Base):
    def setUp(self):
        super().setUp()
        self.store().upsert_quota("global", "", "daily", "requests", 100)
        self.store().upsert_quota("global", "", "daily", "total_tokens", 10000)

    def settled(self):
        ctl = self.ctl()
        rid = ctl.admit(request(max_output=100), profile()).request_id
        ctl.settle_by_id(rid, Settlement("completed", True, USAGE))
        return ctl, rid

    def test_healthy_settled_database_recomputes_spend_and_usage_with_no_findings(self):
        self.settled()
        errors, report = self.errors()
        self.assertEqual(errors, [])
        self.assertGreaterEqual(report["spend_usage"]["budget_windows_checked"], 1)
        self.assertEqual(report["spend_usage"]["quota_windows_checked"], 2)
        self.assertNotIn("unverifiable_buckets", report["spend_usage"])

    def test_tampered_budget_spent_is_reported_and_not_repaired(self):
        self.settled()
        raw = sqlite3.connect(self.path)
        raw.execute("UPDATE budget_windows SET spent = '0.5'")
        raw.commit()
        raw.close()
        errors, _ = self.errors()
        self.assertIn("BUDGET_SPENT_MISMATCH", [e["code"] for e in errors])
        self.assertEqual(self.row("SELECT spent FROM budget_windows")[0], "0.5")  # reconciliation never writes

    def test_tampered_quota_used_is_reported_and_not_repaired(self):
        self.settled()
        raw = sqlite3.connect(self.path)
        raw.execute("UPDATE quota_windows SET used = used + 7 WHERE quota_id IN "
                    "(SELECT quota_id FROM quota_limits WHERE metric = 'total_tokens')")
        raw.commit()
        raw.close()
        errors, _ = self.errors()
        self.assertIn("QUOTA_USED_MISMATCH", [e["code"] for e in errors])

    def test_actual_budget_line_without_its_priced_cost_is_an_error_never_a_zero(self):
        _, rid = self.settled()
        raw = sqlite3.connect(self.path)
        raw.execute("DELETE FROM cost_records WHERE request_id = ?", (rid,))
        raw.commit()
        raw.close()
        errors, _ = self.errors()
        self.assertIn("SPEND_WITHOUT_PRICED_COST", [e["code"] for e in errors])

    def test_verified_usage_settles_spend_exactly_and_leaves_token_counts_unverifiable_not_mismatched(self):
        ctl = self.ctl(authorized=frozenset({OPS}))
        rid = ctl.admit(request(max_output=100), profile()).request_id
        ctl.settle_by_id(rid, Settlement("failed", provider_started=True, usage=None))
        self.assertEqual(self.state(rid), "exposed")
        result = ctl.resolve_exposure(rid, USAGE, actor=OPS, evidence_ref="ticket:r6r1")
        self.assertTrue(result.applied)
        self.assertEqual(self.row("SELECT spent FROM budget_windows")[0], str(PRICED))
        errors, report = self.errors()
        self.assertEqual(errors, [])
        self.assertTrue(report["spend_usage"]["unverifiable_buckets"])

    def test_missing_total_tokens_is_derived_the_same_way_admission_derives_it(self):
        ctl = self.ctl()
        rid = ctl.admit(request(max_output=100), profile()).request_id
        ctl.settle_by_id(rid, Settlement("completed", True, Usage(input_tokens=4, output_tokens=2)))
        errors, _ = self.errors()
        self.assertEqual(errors, [])
        self.assertEqual(self.row("SELECT used FROM quota_windows WHERE quota_id IN "
                                  "(SELECT quota_id FROM quota_limits WHERE metric = 'total_tokens')")[0], 6)


class ExposureResolutionBoundary(Base):
    def test_fault_between_budget_and_cost_writes_rolls_back_the_whole_verified_usage_resolution(self):
        ctl = self.ctl(authorized=frozenset({OPS}))
        rid = ctl.admit(request(max_output=100), profile()).request_id
        ctl.settle_by_id(rid, Settlement("failed", provider_started=True, usage=None))
        before = self.snapshot()
        store = self.store()
        store._conn = RaiseOn(store._conn, "UPDATE cost_records")  # noqa: SLF001 - after the budget move
        faulted = self.ctl(store, authorized=frozenset({OPS}))
        result = faulted.resolve_exposure(rid, USAGE, actor=OPS, evidence_ref="ticket:r6r1")
        self.assertFalse(result.applied)
        self.assertEqual(self.state(rid), "exposed")
        self.assertEqual(self.snapshot(), before)  # nothing from the half-finished resolution is visible
        clean = self.ctl(authorized=frozenset({OPS}))
        self.assertTrue(clean.resolve_exposure(rid, USAGE, actor=OPS, evidence_ref="ticket:r6r1").applied)
        self.assertEqual(self.state(rid), "settled")
        again = clean.resolve_exposure(rid, USAGE, actor=OPS, evidence_ref="ticket:r6r1")
        self.assertFalse(again.applied)
        self.assertEqual(self.row("SELECT spent FROM budget_windows")[0], str(PRICED))
        self.assertEqual(self.errors()[0], [])


if __name__ == "__main__":
    unittest.main()
