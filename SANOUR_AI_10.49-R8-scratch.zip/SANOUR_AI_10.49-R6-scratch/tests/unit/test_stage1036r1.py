"""Stage 10.36-R1 tests: mandatory gateway identity, explicit routing only, legacy isolation.

Fake adapters only. No SDK, no network, no real key. Waits are bounded.
"""

import ast
import logging
import pathlib
import re
import threading
import time
import unittest
import warnings

from sanour_ai.core.sanour_core import SanourCore
from sanour_ai.errors import ErrorCode, SanourError
from sanour_ai.models.base import ModelCall, ModelResult
from sanour_ai.models.capabilities import ModelCapabilities, ModelProfile, ProviderCapabilities
from sanour_ai.models.gateway import ModelGateway
from sanour_ai.models.request_identity import RequestIdentity
from sanour_ai.models.router import DeterministicRouter
from sanour_ai.observability.audit import AuditLogger
from tests.support import request_identity_for as rid

SRC = pathlib.Path(__file__).resolve().parents[2] / "src" / "sanour_ai"
SECRET = "STAGE1036R1-SECRET-KEY-MN"  # fake, test-only
PROMPT = "STAGE1036R1-PROMPT-TEXT-LK"  # fake, must never reach a log or an error
TEXT = ProviderCapabilities(text_generation=True)


class CountingProvider:
    name = "p1"
    vendor = "openai"
    surface = "openai_responses"
    auth_method = "bearer_header"
    capabilities = TEXT

    def __init__(self):
        self.calls = 0

    def generate(self, call):
        self.calls += 1
        return ModelResult(text="answer", reported_model_id=call.model_id)


def profile(alias, provider="p1", model="model-r1", priority=100, surface="openai_responses"):
    return ModelProfile(
        alias=alias,
        provider=provider,
        model_id=model,
        capabilities=ModelCapabilities(text_generation=True, max_context_tokens=8192, max_output_tokens=1024),
        runs_locally=False,
        priority=priority,
        api_surface=surface,
    )


def call_for(prof):
    return ModelCall(model_id=prof.model_id, prompt=PROMPT, max_output_tokens=8, deadline=time.monotonic() + 5)


class AuditCapture(logging.Handler):
    def __init__(self):
        super().__init__(level=logging.DEBUG)
        self.lines = []

    def emit(self, record):
        self.lines.append(record.getMessage())

    @property
    def text(self):
        return "\n".join(self.lines)


# ---------------------------------------------------------------- 1. gateway: identity is mandatory
class MandatoryIdentityTests(unittest.TestCase):
    def setUp(self):
        self.provider = CountingProvider()
        self.gateway = ModelGateway({"p1": self.provider}, max_concurrent_calls=2)
        self.prof = profile("a_r1")

    def tearDown(self):
        self.gateway.shutdown(0.1)

    def test_call_without_identity_is_refused_before_any_provider_io(self):
        with self.assertRaises(SanourError) as ctx:
            self.gateway.generate(self.prof, call_for(self.prof), time.monotonic() + 5)
        self.assertEqual(ctx.exception.code, ErrorCode.NO_ELIGIBLE_MODEL)
        self.assertEqual(self.provider.calls, 0)

    def test_explicit_none_identity_is_refused_the_same_way(self):
        with self.assertRaises(SanourError):
            self.gateway.generate(self.prof, call_for(self.prof), time.monotonic() + 5, identity=None)
        self.assertEqual(self.provider.calls, 0)

    def test_identity_of_the_wrong_type_is_refused(self):
        for bad in ({"profile_id": "a_r1"}, "a_r1", self.prof, object()):
            with self.subTest(bad=type(bad).__name__):
                with self.assertRaises(SanourError):
                    self.gateway.generate(self.prof, call_for(self.prof), time.monotonic() + 5, identity=bad)
        self.assertEqual(self.provider.calls, 0)

    def test_refused_call_takes_no_capacity_and_leaves_no_worker(self):
        slots_before = self.gateway._slots._value  # noqa: SLF001
        with self.assertRaises(SanourError):
            self.gateway.generate(self.prof, call_for(self.prof), time.monotonic() + 5)
        self.assertEqual(self.gateway._slots._value, slots_before)  # noqa: SLF001
        self.assertEqual(self.gateway.in_flight, 0)

    def test_refusal_is_checked_before_the_shutdown_and_expiry_checks(self):
        self.gateway.shutdown(0.1)
        with self.assertRaises(SanourError) as ctx:
            self.gateway.generate(self.prof, call_for(self.prof), time.monotonic() - 1)
        self.assertEqual(ctx.exception.scope, "request_identity")

    def test_call_with_identity_still_succeeds(self):
        result = self.gateway.generate(self.prof, call_for(self.prof), time.monotonic() + 5,
                                       identity=rid(self.prof))
        self.assertEqual(result.text, "answer")
        self.assertEqual(self.provider.calls, 1)

    def test_legacy_profile_only_check_no_longer_exists_in_the_gateway(self):
        text = (SRC / "models" / "gateway.py").read_text(encoding="utf-8")
        self.assertNotIn("_reported_identity_accepted", text)
        self.assertNotIn("identity is not None", text)
        self.assertNotIn("if identity is None", text)

    def test_every_operational_generate_call_in_src_passes_an_identity(self):
        offenders = []
        for path in SRC.rglob("*.py"):
            tree = ast.parse(path.read_text(encoding="utf-8"))
            for node in ast.walk(tree):
                if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) \
                        and node.func.attr == "generate":
                    recv = ast.get_source_segment(path.read_text(encoding="utf-8"), node.func.value) or ""
                    if re.search(r"gateway|gw", recv, re.I):
                        if not any(k.arg == "identity" for k in node.keywords):
                            offenders.append(f"{path.name}:{node.lineno}")
        self.assertEqual(offenders, [])


# ---------------------------------------------------------------- 2. routing: no alias, no choice
class ExplicitOnlyRoutingTests(unittest.TestCase):
    def core(self, profiles):
        provider = CountingProvider()
        gateway = ModelGateway({"p1": provider}, max_concurrent_calls=2)
        core = SanourCore(router=DeterministicRouter(profiles), gateway=gateway, audit=AuditLogger())
        self.addCleanup(gateway.shutdown, 0.1)
        return core, provider

    def test_several_profiles_and_no_alias_selects_nothing(self):
        core, provider = self.core([profile("a_r1", priority=1), profile("b_r1", priority=2),
                                    profile("c_r1", priority=0)])
        for body in ({"prompt": PROMPT}, {"prompt": PROMPT, "profile_alias": ""},
                     {"prompt": PROMPT, "profile_alias": "   "}):
            with self.subTest(body=sorted(body)):
                resp = core.handle(body)
                self.assertEqual(resp.status, "error")
                self.assertEqual(resp.error.code, ErrorCode.INVALID_REQUEST)
        self.assertEqual(provider.calls, 0)

    def test_registration_order_never_changes_the_resolved_profile(self):
        orders = [
            [profile("a_r1"), profile("b_r1"), profile("c_r1")],
            [profile("c_r1"), profile("a_r1"), profile("b_r1")],
            [profile("b_r1"), profile("c_r1"), profile("a_r1")],
        ]
        for order in orders:
            core, _ = self.core(order)
            with self.subTest(order=[p.alias for p in order]):
                self.assertEqual(core.handle({"prompt": PROMPT, "profile_alias": "b_r1"}).model_alias, "b_r1")

    def test_priority_cannot_change_the_resolved_profile(self):
        low = DeterministicRouter([profile("x_r1", priority=0), profile("y_r1", priority=999)])
        high = DeterministicRouter([profile("x_r1", priority=999), profile("y_r1", priority=0)])
        from sanour_ai.core.request_manager import accept
        request = accept({"profile_alias": "x_r1", "prompt": "hi"}, "a" * 32)
        self.assertEqual(low.resolve(request).alias, high.resolve(request).alias)

    def test_router_source_never_reads_priority(self):
        text = (SRC / "models" / "router.py").read_text(encoding="utf-8")
        self.assertNotIn("priority", text)

    def test_no_operational_module_reads_priority(self):
        for part in ("core", "composition", "models/router.py", "models/gateway.py",
                     "models/request_identity.py", "models/profile_management.py",
                     "models/model_catalog.py"):
            target = SRC / part
            files = [target] if target.is_file() else list(target.rglob("*.py"))
            for path in files:
                with self.subTest(file=path.name):
                    self.assertNotIn("priority", path.read_text(encoding="utf-8"))

    def test_the_automatic_selection_api_is_absent(self):
        self.assertFalse(hasattr(DeterministicRouter, "select"))


# ---------------------------------------------------------------- 3. legacy isolation
class LegacyIsolationTests(unittest.TestCase):
    def test_legacy_catalog_is_not_imported_by_any_operational_path(self):
        for part in ("core", "composition", "models/gateway.py", "models/router.py",
                     "models/request_identity.py", "models/profile_management.py",
                     "models/model_catalog.py", "providers"):
            target = SRC / part
            files = [target] if target.is_file() else list(target.rglob("*.py"))
            for path in files:
                with self.subTest(file=path.name):
                    text = path.read_text(encoding="utf-8")
                    self.assertNotIn("models.catalog import", text)
                    self.assertNotIn("models import catalog", text)

    def test_constructing_the_legacy_catalog_warns_as_deprecated(self):
        from sanour_ai.models.catalog import ModelCatalog as Legacy
        with warnings.catch_warnings(record=True) as seen:
            warnings.simplefilter("always")
            Legacy(profiles=(profile("legacy_r1"),))
        self.assertTrue(any(issubclass(w.category, DeprecationWarning) for w in seen))

    def test_legacy_catalog_has_no_selection_method(self):
        from sanour_ai.models.catalog import ModelCatalog as Legacy
        for name in ("select", "resolve", "route", "choose", "pick"):
            self.assertFalse(hasattr(Legacy, name))

    def test_priority_is_documented_as_deprecated(self):
        self.assertIn("DEPRECATED", (SRC / "models" / "capabilities.py").read_text(encoding="utf-8"))

    def test_production_profile_comes_only_from_the_new_registries(self):
        text = (SRC / "composition" / "production.py").read_text(encoding="utf-8")
        self.assertIn("ProfileRegistry", text)
        self.assertNotIn("models.catalog", text)


# ---------------------------------------------------------------- 4. security and preserved behaviour
class SecurityTests(unittest.TestCase):
    def test_identity_refusal_never_contains_secret_prompt_or_provider_text(self):
        provider = CountingProvider()
        gateway = ModelGateway({"p1": provider}, max_concurrent_calls=1)
        prof = profile("a_r1")
        bad_call = ModelCall(model_id=prof.model_id, prompt=PROMPT + SECRET, max_output_tokens=8,
                             deadline=time.monotonic() + 5)
        capture = AuditCapture()
        logging.getLogger("sanour_ai.audit").addHandler(capture)
        try:
            with self.assertRaises(SanourError) as ctx:
                gateway.generate(prof, bad_call, time.monotonic() + 5)
        finally:
            logging.getLogger("sanour_ai.audit").removeHandler(capture)
            gateway.shutdown(0.1)
        self.assertNotIn(SECRET, str(ctx.exception))
        self.assertNotIn(PROMPT, str(ctx.exception))
        self.assertNotIn(SECRET, capture.text)

    def test_deadline_is_still_taken_from_the_core_and_not_from_identity(self):
        self.assertFalse(hasattr(RequestIdentity, "deadline"))

    def test_shutdown_and_lifecycle_still_refuse_new_calls(self):
        provider = CountingProvider()
        gateway = ModelGateway({"p1": provider}, max_concurrent_calls=1)
        gateway.shutdown(0.1)
        prof = profile("a_r1")
        with self.assertRaises(SanourError):
            gateway.generate(prof, call_for(prof), time.monotonic() + 5, identity=rid(prof))
        self.assertEqual(provider.calls, 0)

    def test_worker_capacity_is_held_while_a_worker_runs(self):
        release = threading.Event()
        entered = threading.Event()

        class Blocking(CountingProvider):
            def generate(self, call):
                entered.set()
                release.wait(5)
                return ModelResult(text="late", reported_model_id=call.model_id)

        provider = Blocking()
        gateway = ModelGateway({"p1": provider}, max_concurrent_calls=1)
        prof = profile("a_r1")
        try:
            with self.assertRaises(SanourError):
                gateway.generate(prof, call_for(prof), time.monotonic() + 0.05, identity=rid(prof))
            self.assertTrue(entered.wait(2.0))
            self.assertEqual(gateway.in_flight, 1)  # still held after the caller gave up
        finally:
            release.set()
            gateway.shutdown(0.1)


if __name__ == "__main__":
    unittest.main()
