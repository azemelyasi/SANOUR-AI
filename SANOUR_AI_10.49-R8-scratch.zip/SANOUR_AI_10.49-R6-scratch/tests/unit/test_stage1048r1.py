"""Stage 10.48-R1: production storage policy, runtime ledger lifecycle, SQL reporting, storage integrity.

Deterministic and offline: no SDK, no network, no real key. Process-level tests use child Python processes
that touch only a local SQLite file in a temporary directory.
"""

import json
import os
import sqlite3
import stat
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest import mock

from sanour_ai.composition import production
from sanour_ai.composition.runtime import Runtime
from sanour_ai.config.settings import ConfigError
from sanour_ai.core import usage_accounting
from sanour_ai.core.usage_accounting import UsageAccountingService, build_report
from sanour_ai.ledger.record import LedgerRecord
from sanour_ai.ledger.repository import InMemoryUsageRepository, LedgerConflictError, LedgerStorageError
from sanour_ai.ledger.sqlite_repository import SqliteUsageRepository
from sanour_ai.models import production_gate
from sanour_ai.models.usage import Usage
from sanour_ai.observability.audit import AUDIT_LOGGER_NAME
from tests.unit.test_stage1045 import FakeOpenAI
from tests.unit.test_stage1048 import (
    OUTPUT, PROMPT, SECRET, TempLedger, env, execution, raw, rec,
)
from tests.unit.test_stage1047r1 import UsageProvider

SRC = Path(__file__).resolve().parents[2] / "src"


def _record(i: int) -> LedgerRecord:
    """Deterministic record i with every kind of NULL, status and dimension spread across the data."""
    day = ["2026-09-14", "2026-09-15", "2026-09-16"][i % 3]
    kind = i % 4
    counts = {"input_tokens": None, "output_tokens": None, "total_tokens": None,
              "cached_input_tokens": None, "reasoning_tokens": None}
    usage_status = "reported"
    if kind == 0:
        usage_status = "unavailable"
    elif kind == 1:
        counts["input_tokens"] = i
    elif kind == 2:
        counts.update(input_tokens=i, output_tokens=2 * i, total_tokens=3 * i,
                      cached_input_tokens=1 if i % 2 else None)
    else:
        counts.update(input_tokens=i + 2, output_tokens=i + 1, total_tokens=2 * i + 3,
                      cached_input_tokens=1, reasoning_tokens=1)
    return LedgerRecord(
        request_id=f"req-{i:03d}", utc_day=day, recorded_at=f"{day}T{i % 24:02d}:00:00+00:00",
        provider_id=["openai", "anthropic"][i % 2], profile_id=["p1", "p2", "p3"][i % 3],
        model_id=["m1", "m2"][(i // 2) % 2], api_surface="openai_responses",
        delivery="withheld" if i % 5 == 0 else "delivered",
        audit_status=["recorded", "failed", "unavailable"][i % 3], usage_status=usage_status, **counts,
    )


FILTER_SETS = (
    None,
    {"provider": "openai"},
    {"period": "2026-09-15", "delivery": "withheld"},
    {"model": "m2", "audit": "failed", "profile": "p3"},
    {"provider": "nobody"},
    {"period": None, "audit": "unavailable"},
)


# ------------------------------------------------------------ production storage policy
class ProductionStoragePolicy(unittest.TestCase):
    def setUp(self):
        self._dir = tempfile.TemporaryDirectory()
        self.addCleanup(self._dir.cleanup)
        self.path = os.path.join(self._dir.name, "usage.db")
        FakeOpenAI.instances = []
        FakeOpenAI.calls = []
        for p in (
            mock.patch.object(production, "OpenAIProvider", FakeOpenAI),
            mock.patch.object(production, "_sdk_present", return_value=True),
        ):
            p.start()
            self.addCleanup(p.stop)

    def open_gate(self):
        for p in (
            mock.patch.object(production_gate, "APPROVED_PRODUCTION_MODELS",
                              frozenset({("openai", "openai_responses", "gpt-1048-test")})),
            mock.patch.object(production_gate.capability_intelligence, "production_ready",
                              return_value={"text_generation"}),
        ):
            p.start()
            self.addCleanup(p.stop)

    def test_production_without_a_ledger_path_is_refused_before_any_adapter(self):
        with mock.patch.object(production_gate, "check") as gate:
            with self.assertRaises(ConfigError) as ctx:
                Runtime.build(env())
        gate.assert_not_called()
        self.assertEqual(FakeOpenAI.instances, [])
        self.assertIn("ledger", str(ctx.exception))

    def test_production_with_a_healthy_sqlite_ledger_is_built(self):
        self.open_gate()
        rt = Runtime.build(env(), usage_ledger_path=self.path)
        self.assertEqual(rt.mode, "production")
        self.assertIsInstance(rt._usage._repo, SqliteUsageRepository)  # noqa: SLF001
        self.assertEqual(len(FakeOpenAI.instances), 1)
        rt.shutdown(1.0)
        self.assertTrue(rt.wait_stopped(5))

    def test_unusable_path_fails_closed_with_no_memory_fallback(self):
        self.open_gate()  # the gate is open, so only the storage can refuse the runtime
        os.mkdir(os.path.join(self._dir.name, "a_directory.db"))
        bad = os.path.join(self._dir.name, "a_directory.db")
        with mock.patch("sanour_ai.ledger.repository.InMemoryUsageRepository") as memory:
            with self.assertRaises(ConfigError) as ctx:
                Runtime.build(env(), usage_ledger_path=bad)
        memory.assert_not_called()
        self.assertEqual(FakeOpenAI.instances, [])
        self.assertNotIn(bad, str(ctx.exception))
        self.assertNotIn(self._dir.name, str(ctx.exception))

    def test_non_database_file_is_refused_with_a_fixed_message(self):
        self.open_gate()  # the gate is open, so only the storage can refuse the runtime
        with open(self.path, "wb") as handle:
            handle.write(b"this is not a database " * 200)
        with mock.patch("sanour_ai.ledger.repository.InMemoryUsageRepository") as memory:
            with self.assertRaises(ConfigError) as ctx:
                Runtime.build(env(), usage_ledger_path=self.path)
        memory.assert_not_called()
        self.assertNotIn(self.path, str(ctx.exception))
        self.assertNotIn(SECRET, str(ctx.exception))
        self.assertEqual(FakeOpenAI.instances, [])

    def test_memory_database_name_is_refused_for_production(self):
        self.open_gate()
        with self.assertRaises(ConfigError):
            Runtime.build(env(), usage_ledger_path=":memory:")
        self.assertEqual(FakeOpenAI.instances, [])

    def test_memory_database_name_is_refused_by_the_storage_itself(self):
        with self.assertRaises(LedgerStorageError):
            SqliteUsageRepository(":memory:")

    def test_gate_refusal_closes_the_ledger_it_opened(self):
        closed = []
        real_close = SqliteUsageRepository.close

        def spy(repo):
            closed.append(repo)
            real_close(repo)

        with mock.patch.object(SqliteUsageRepository, "close", spy):
            with self.assertRaises(ConfigError):  # no approval: the real gate refuses
                Runtime.build(env(), usage_ledger_path=self.path)
        self.assertEqual(len(closed), 1)
        self.assertEqual(FakeOpenAI.instances, [])
        self.assertIsNone(closed[0]._conn)  # noqa: SLF001


# ----------------------------------------------------------------- runtime ledger lifecycle
class RuntimeLedgerLifecycle(TempLedger):
    def build(self, provider=None):
        provider = provider if provider is not None else UsageProvider(Usage(input_tokens=2, output_tokens=1,
                                                                             total_tokens=3))
        return Runtime.build_for_tests(env(), provider=provider, usage_ledger_path=self.path)

    def test_shutdown_closes_the_sqlite_connection(self):
        rt = self.build()
        self.assertEqual(rt.handle(raw()).status, "success")
        rt.shutdown(1.0)
        self.assertTrue(rt.wait_stopped(5))
        repo = rt._usage._repo  # noqa: SLF001
        self.assertIsNone(repo._conn)  # noqa: SLF001
        with self.assertRaises(LedgerStorageError):
            repo.append(rec("after-shutdown"))

    def test_repeated_shutdown_is_safe_and_closes_once(self):
        rt = self.build()
        repo = rt._usage._repo  # noqa: SLF001
        real_close = repo.close
        calls = []

        def counting_close():
            calls.append(1)
            real_close()

        with mock.patch.object(repo, "close", counting_close):
            first = rt.shutdown(1.0)
            second = rt.shutdown(1.0)
            third = rt.shutdown(1.0)
        self.assertEqual(first, second)
        self.assertEqual(second, third)
        self.assertEqual(len(calls), 1)
        self.assertTrue(rt.wait_stopped(5))

    def test_request_after_shutdown_is_refused_and_writes_nothing(self):
        rt = self.build()
        self.assertEqual(rt.handle(raw()).status, "success")
        rt.shutdown(1.0)
        self.assertTrue(rt.wait_stopped(5))
        self.assertNotEqual(rt.handle(raw()).status, "success")
        reopened = SqliteUsageRepository(self.path)
        self.addCleanup(reopened.close)
        self.assertEqual(len(reopened.records()), 1)

    def test_record_in_flight_during_shutdown_is_kept_and_the_ledger_closes_after_it(self):
        class Blocking(UsageProvider):
            def __init__(self):
                super().__init__(Usage(input_tokens=5))
                self.entered, self.release = threading.Event(), threading.Event()

            def generate(self, call):
                self.entered.set()
                self.release.wait(timeout=30)
                return super().generate(call)

        provider = Blocking()
        rt = self.build(provider)
        outcome = {}
        caller = threading.Thread(target=lambda: outcome.update(status=rt.handle(raw()).status))
        caller.start()
        self.assertTrue(provider.entered.wait(timeout=10))
        rt.shutdown(timeout=0.2)  # the provider is still busy: DRAINING, nothing closed yet
        self.assertEqual(rt.state.value, "draining")
        self.assertIsNotNone(rt._usage._repo._conn)  # noqa: SLF001
        provider.release.set()
        caller.join(timeout=20)
        self.assertEqual(outcome.get("status"), "success")
        self.assertTrue(rt.wait_stopped(10))
        self.assertEqual(rt.state.value, "shutdown")
        reopened = SqliteUsageRepository(self.path)
        self.addCleanup(reopened.close)
        self.assertEqual(len(reopened.records()), 1)  # the in-flight completion was recorded in full

    def test_concurrent_requests_during_shutdown_record_exactly_the_successes(self):
        rt = self.build()
        statuses = []
        guard = threading.Lock()

        def caller():
            for _ in range(15):
                status = rt.handle(raw()).status
                with guard:
                    statuses.append(status)

        threads = [threading.Thread(target=caller) for _ in range(6)]
        for t in threads:
            t.start()
        time.sleep(0.02)
        rt.shutdown(timeout=5)
        for t in threads:
            t.join(timeout=60)
        self.assertTrue(rt.wait_stopped(10))
        reopened = SqliteUsageRepository(self.path)
        self.addCleanup(reopened.close)
        self.assertEqual(len(reopened.records()), statuses.count("success"))
        self.assertTrue(reopened.integrity_ok())

    def test_ledger_close_error_is_counted_and_still_settles_the_runtime(self):
        rt = self.build()
        repo = rt._usage._repo  # noqa: SLF001
        real_close = repo.close
        self.addCleanup(real_close)  # release the file even if an assertion fails
        with mock.patch.object(repo, "close", side_effect=OSError(SECRET)):
            states = rt.shutdown(1.0)
        self.assertTrue(rt.wait_stopped(5))
        self.assertEqual(rt.state.value, "shutdown")
        self.assertTrue(all(value in {"closed", "failed"} for value in states.values()))
        self.assertEqual(rt.usage_summary()["health"]["ledger_close_failures"], 1)
        self.assertNotIn(SECRET, json.dumps(rt.usage_summary()))

    def test_ledger_close_runs_once_even_if_asked_twice_internally(self):
        rt = self.build()
        repo = rt._usage._repo  # noqa: SLF001
        with mock.patch.object(repo, "close", wraps=repo.close) as close:
            with rt._lock:  # noqa: SLF001
                rt._close_ledger_locked()  # noqa: SLF001
                rt._close_ledger_locked()  # noqa: SLF001
        self.assertEqual(close.call_count, 1)

    def test_ledger_close_error_does_not_leak_into_stats_or_summary(self):
        rt = self.build()
        repo = rt._usage._repo  # noqa: SLF001
        self.addCleanup(repo.close)
        with mock.patch.object(repo, "close", side_effect=OSError(self.path)):
            rt.shutdown(1.0)
        self.assertNotIn(self.path, json.dumps(rt.stats(), default=str))
        self.assertNotIn(self.path, json.dumps(rt.usage_summary(), default=str))

    def test_close_while_a_write_is_running_is_safe(self):
        repo = SqliteUsageRepository(self.path)
        self.addCleanup(repo.close)
        acct = UsageAccountingService(repository=repo)
        errors, stored = [], [0]

        def writer():
            for i in range(300):
                try:
                    if acct.record(execution(f"c-{i:04d}", Usage(input_tokens=1))):
                        stored[0] += 1
                except LedgerStorageError:
                    return
                except Exception as exc:  # pragma: no cover - any other error is a failure
                    errors.append(exc)
                    return

        thread = threading.Thread(target=writer)
        thread.start()
        time.sleep(0.02)
        repo.close()
        thread.join(timeout=60)
        self.assertEqual(errors, [])
        reopened = SqliteUsageRepository(self.path)
        self.addCleanup(reopened.close)
        self.assertEqual(len(reopened.records()), stored[0])


# ------------------------------------------------------------------ SQL reporting
class SqlReporting(TempLedger):
    def filled(self):
        sql = self.open()
        memory = InMemoryUsageRepository()
        records = [_record(i) for i in range(1, 61)]
        for r in records:
            self.assertTrue(sql.append(r))
            self.assertTrue(memory.append(r))
        return sql, memory, records

    def test_sql_report_equals_memory_report_and_the_reference_for_every_filter(self):
        sql, memory, records = self.filled()
        for flt in FILTER_SETS:
            with self.subTest(filter=flt):
                expected = build_report(records, flt)
                self.assertEqual(sql.report(flt), expected)
                self.assertEqual(memory.report(flt), expected)

    def test_sql_report_equals_memory_for_single_dimensions(self):
        sql, memory, records = self.filled()
        for dim in ("provider", "profile", "model", "period", "delivery", "audit"):
            with self.subTest(dimension=dim):
                self.assertEqual(sql.report(None, (dim,)), memory.report(None, (dim,)))
                self.assertEqual(sql.report(None, (dim,)), build_report(records, None, (dim,)))

    def test_null_stays_null_and_is_never_turned_into_zero(self):
        sql = self.open()
        sql.append(rec("n-1", provider="anthropic", counts={"input_tokens": None, "output_tokens": None,
                                                           "total_tokens": None, "cached_input_tokens": None,
                                                           "reasoning_tokens": None}))
        sql.append(rec("n-2", provider="anthropic", counts={"input_tokens": None, "output_tokens": None,
                                                           "total_tokens": None, "cached_input_tokens": None,
                                                           "reasoning_tokens": None}))
        group = sql.report()["provider"]["anthropic"]
        self.assertIsNone(group["tokens"]["input_tokens"]["sum"])
        self.assertEqual(group["tokens"]["input_tokens"]["unknown_count"], 2)
        self.assertFalse(group["tokens_complete"]["input_tokens"])
        self.assertEqual(sql.report()["total"]["tokens"]["output_tokens"]["sum"], None)

    def test_partial_sum_is_flagged_as_not_complete(self):
        sql = self.open()
        sql.append(rec("p-1", counts={"input_tokens": 3, "output_tokens": None, "total_tokens": None,
                                      "cached_input_tokens": None, "reasoning_tokens": None}))
        sql.append(rec("p-2", counts={"input_tokens": None, "output_tokens": None, "total_tokens": None,
                                      "cached_input_tokens": None, "reasoning_tokens": None}))
        total = sql.report()["total"]
        self.assertEqual(total["tokens"]["input_tokens"], {"sum": 3, "known_count": 1, "unknown_count": 1})
        self.assertFalse(total["tokens_complete"]["input_tokens"])  # 3 is known-only, not the full total
        self.assertFalse(total["tokens_complete"]["output_tokens"])

    def test_fully_known_bucket_is_complete(self):
        sql = self.open()
        sql.append(rec("c-1", counts={"input_tokens": 3, "output_tokens": 1, "total_tokens": 4,
                                      "cached_input_tokens": None, "reasoning_tokens": None}))
        sql.append(rec("c-2", counts={"input_tokens": 2, "output_tokens": 1, "total_tokens": 3,
                                      "cached_input_tokens": None, "reasoning_tokens": None}))
        self.assertTrue(sql.report()["total"]["tokens_complete"]["input_tokens"])
        self.assertEqual(sql.report()["total"]["tokens"]["input_tokens"]["sum"], 5)

    def test_filtered_report_counts_only_matching_records(self):
        sql, memory, records = self.filled()
        report = sql.report({"provider": "openai", "period": "2026-09-14"})
        self.assertEqual(report["total"]["requests"], sum(
            1 for r in records if r.provider_id == "openai" and r.utc_day == "2026-09-14"))
        self.assertEqual(sql.report({"provider": "nobody"})["total"]["requests"], 0)

    def test_injection_shaped_filters_are_refused_and_the_table_is_intact(self):
        sql, _memory, records = self.filled()
        hostile = ["openai' OR '1'='1", "x; DROP TABLE usage_records", "OPENAI", "a" * 200, "openai\n"]
        for value in hostile:
            with self.assertRaises(ValueError) as ctx:
                sql.report({"provider": value})
            self.assertNotIn(value, str(ctx.exception))
        with self.assertRaises(ValueError):
            sql.report({"request_id": "req-001"})
        with self.assertRaises(ValueError):
            sql.report({"period": "2026-13-40"})
        with self.assertRaises(ValueError):
            sql.report({"delivery": "delivered' --"})
        with self.assertRaises(ValueError):
            sql.report(None, ("request_id",))
        self.assertEqual(len(sql.records()), len(records))

    def test_report_after_restart_matches_before_restart_for_every_filter(self):
        sql, _memory, _records = self.filled()
        before = {repr(f): sql.report(f) for f in FILTER_SETS}
        sql.close()
        reopened = self.open()
        for flt in FILTER_SETS:
            with self.subTest(filter=flt):
                self.assertEqual(reopened.report(flt), before[repr(flt)])

    def test_empty_ledger_reports_zeros_and_no_sums(self):
        sql = self.open()
        report = sql.report()
        self.assertEqual(report, InMemoryUsageRepository().report())
        self.assertEqual(report["total"]["requests"], 0)
        self.assertIsNone(report["total"]["tokens"]["input_tokens"]["sum"])

    def test_runtime_usage_report_applies_filters_and_refuses_bad_ones(self):
        rt = Runtime.build_for_tests(env(), provider=UsageProvider(Usage(input_tokens=2)),
                                     usage_ledger_path=os.path.join(self._dir.name, "rt.db"))
        self.addCleanup(rt.close_usage_ledger)
        rt.handle(raw())
        self.assertEqual(rt.usage_report({"provider": "openai"})["total"]["requests"], 1)
        self.assertEqual(rt.usage_report({"provider": "anthropic"})["total"]["requests"], 0)
        with self.assertRaises(ValueError):
            rt.usage_report({"provider": "x' OR 1=1"})


# ---------------------------------------------------------------- storage integrity
class StorageIntegrity(TempLedger):
    def _child(self, body: str, *args: str):
        script = (
            "import os, sys\n"
            f"sys.path.insert(0, {str(SRC)!r})\n"
            "from sanour_ai.ledger.sqlite_repository import SqliteUsageRepository\n"
            "from tests.unit.test_stage1048 import rec\n"
        ) + body
        return subprocess.run([sys.executable, "-c", script, *args], capture_output=True, text=True,
                              timeout=120)

    def test_integrity_check_is_ok_after_writes_and_after_restart(self):
        repo = self.open()
        for i in range(10):
            repo.append(rec(f"i-{i}"))
        self.assertTrue(repo.integrity_ok())
        repo.close()
        self.assertTrue(self.open().integrity_ok())

    def test_wal_recovery_restores_every_committed_record_after_a_sudden_stop(self):
        body = (
            "repo = SqliteUsageRepository(sys.argv[1])\n"
            "for i in range(5):\n"
            "    assert repo.append(rec(f'wal-{i}'))\n"
            "os._exit(7)\n"  # no close, no checkpoint
        )
        proc = self._child(body, self.path)
        self.assertEqual(proc.returncode, 7, proc.stderr)
        self.assertTrue(os.path.exists(self.path + "-wal"))
        self.assertGreater(os.path.getsize(self.path + "-wal"), 0)
        reopened = self.open()
        self.assertEqual(sorted(r.request_id for r in reopened.records()), [f"wal-{i}" for i in range(5)])
        self.assertTrue(reopened.integrity_ok())

    def test_torn_wal_tail_after_a_crash_is_ignored_and_committed_rows_survive(self):
        body = (
            "repo = SqliteUsageRepository(sys.argv[1])\n"
            "for i in range(4):\n"
            "    assert repo.append(rec(f'tail-{i}'))\n"
            "os._exit(7)\n"
        )
        self.assertEqual(self._child(body, self.path).returncode, 7)
        with open(self.path + "-wal", "ab") as handle:  # a partial, garbage frame at the end
            handle.write(b"\x00\x7f" * 300 + b"torn")
        reopened = self.open()
        self.assertEqual(len(reopened.records()), 4)
        self.assertTrue(reopened.integrity_ok())
        self.assertTrue(reopened.append(rec("after-torn")))

    def test_corrupted_database_header_is_refused_with_a_fixed_message(self):
        self.open().close()
        with open(self.path, "r+b") as handle:
            handle.write(b"\xff" * 100)
        with self.assertRaises(LedgerStorageError) as ctx:
            SqliteUsageRepository(self.path)
        self.assertNotIn(self.path, str(ctx.exception))

    def test_read_only_file_is_refused_for_writing_without_a_partial_open(self):
        if hasattr(os, "geteuid") and os.geteuid() == 0:
            self.skipTest("root ignores file permissions")
        self.open().close()
        os.chmod(self.path, stat.S_IRUSR)
        self.addCleanup(os.chmod, self.path, stat.S_IRUSR | stat.S_IWUSR)
        with self.assertRaises(LedgerStorageError):
            SqliteUsageRepository(self.path)

    def test_failed_commit_rolls_back_and_leaves_no_row(self):
        repo = self.open()

        class FailingCommit:
            def __init__(self, real):
                self._real = real

            def execute(self, sql, *args):
                if sql == "COMMIT":
                    raise sqlite3.OperationalError("disk I/O error")
                return self._real.execute(sql, *args)

        real = repo._conn  # noqa: SLF001
        repo._conn = FailingCommit(real)  # noqa: SLF001
        with self.assertRaises(LedgerStorageError):
            repo.append(rec("rb-1"))
        repo._conn = real  # noqa: SLF001
        self.assertEqual(repo.records(), [])
        self.assertTrue(repo.append(rec("rb-1")))  # the same id is free again after the rollback

    def test_duplicate_and_conflict_hold_across_a_restart(self):
        repo = self.open()
        repo.append(rec("dup-1", provider="openai"))
        repo.close()
        again = self.open()
        self.assertFalse(again.append(rec("dup-1", provider="openai", stamp="2026-11-07T12:00:09+00:00")))
        with self.assertRaises(LedgerConflictError):
            again.append(rec("dup-1", provider="anthropic"))
        self.assertEqual([r.provider_id for r in again.records()], ["openai"])

    def test_concurrent_processes_still_neither_lose_nor_duplicate_with_reports(self):
        body = (
            "repo = SqliteUsageRepository(sys.argv[1])\n"
            "ok = 0\n"
            "for i in range(20):\n"
            "    ok += 1 if repo.append(rec(f'mp-{sys.argv[2]}-{i}')) else 0\n"
            "print(ok)\n"
        )
        procs = [subprocess.Popen([sys.executable, "-c",
                                   f"import sys\nsys.path.insert(0, {str(SRC)!r})\n"
                                   "from sanour_ai.ledger.sqlite_repository import SqliteUsageRepository\n"
                                   "from tests.unit.test_stage1048 import rec\n" + body,
                                   self.path, str(w)], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                  text=True) for w in range(3)]
        for p in procs:
            out, err = p.communicate(timeout=120)
            self.assertEqual(p.returncode, 0, err)
        reopened = self.open()
        self.assertEqual(len(reopened.records()), 60)
        self.assertEqual(reopened.report()["total"]["requests"], 60)
        self.assertTrue(reopened.integrity_ok())


# -------------------------------------------------------------------- privacy
class LedgerPrivacy(TempLedger):
    def test_summary_and_reports_carry_no_prompt_output_or_secret(self):
        rt = Runtime.build_for_tests(env(), provider=UsageProvider(Usage(input_tokens=2), text=OUTPUT),
                                     usage_ledger_path=self.path)
        rt.handle(raw())
        blob = json.dumps({"summary": rt.usage_summary(), "report": rt.usage_report({"audit": "recorded"})})
        for secret in (SECRET, PROMPT, OUTPUT):
            self.assertNotIn(secret, blob)
        rt.close_usage_ledger()

    def test_audit_lines_during_ledger_close_failure_hold_no_path_or_secret(self):
        rt = Runtime.build_for_tests(env(), provider=UsageProvider(Usage(input_tokens=2)),
                                     usage_ledger_path=self.path)
        repo = rt._usage._repo  # noqa: SLF001
        self.addCleanup(repo.close)
        with self.assertLogs(AUDIT_LOGGER_NAME, level="INFO") as captured:
            with mock.patch.object(repo, "close", side_effect=OSError(SECRET)):
                rt.shutdown(1.0)
        text = "\n".join(captured.output)
        self.assertIn("runtime.ledger_close_failed", text)
        self.assertNotIn(SECRET, text)
        self.assertNotIn(self.path, text)


class ValidationRegressions(TempLedger):
    def test_trailing_newline_is_not_accepted_as_an_identifier(self):
        base = dict(utc_day="2026-09-14", recorded_at="2026-09-14T12:00:00+00:00", provider_id="openai",
                    profile_id="p", model_id="m", api_surface="openai_responses", delivery="delivered",
                    audit_status="recorded", usage_status="unavailable", input_tokens=None, output_tokens=None,
                    total_tokens=None, cached_input_tokens=None, reasoning_tokens=None)
        for field, value in (("request_id", "abc\n"), ("provider_id", "openai\n"), ("profile_id", "p\n"),
                             ("model_id", "m\n"), ("utc_day", "2026-09-14\n")):
            values = dict(base, request_id="ok-1")
            values[field] = value
            with self.subTest(field=field):
                with self.assertRaises(ValueError):
                    LedgerRecord(**values)

    def test_report_filters_refuse_a_trailing_newline(self):
        repo = self.open()
        repo.append(rec("nl-1"))
        for value in ("openai\n", "2026-11-07\n", "delivered\n"):
            key = "period" if value.startswith("2026") else ("delivery" if value.startswith("deliv") else "provider")
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    repo.report({key: value})


class AggregationStaysInStorage(TempLedger):
    def test_sqlite_report_does_not_read_every_record_into_python(self):
        repo = self.open()
        for i in range(1, 25):
            repo.append(_record(i))
        expected = build_report(repo.records())
        with mock.patch.object(repo, "records", side_effect=AssertionError("row-by-row read")):
            self.assertEqual(repo.report(), expected)
            openai_only = [_record(i) for i in range(1, 25) if _record(i).provider_id == "openai"]
            self.assertEqual(repo.report({"provider": "openai"}), build_report(openai_only))


class OpenTimeIntegrity(TempLedger):
    def test_a_failing_integrity_check_refuses_the_file_on_open(self):
        import sanour_ai.ledger.sqlite_repository as module

        class ReportsDamage:
            def __init__(self, real):
                self._real = real

            def execute(self, sql, *args):
                if sql == "PRAGMA integrity_check":
                    return mock.Mock(fetchall=lambda: [("row 3 missing from index",)])
                return self._real.execute(sql, *args)

            def close(self):
                self._real.close()

        real_connect = sqlite3.connect
        with mock.patch.object(module.sqlite3, "connect", lambda *a, **k: ReportsDamage(real_connect(*a, **k))):
            with self.assertRaises(LedgerStorageError) as ctx:
                SqliteUsageRepository(self.path)
        self.assertNotIn(self.path, str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
