"""Stage 10.49-R5: transactional atomicity of the sink receipt/inbox pair and of the governance settlement.

Each boundary is killed with a real os._exit at a statement boundary, then the files are inspected from a fresh
process view. Invariants:
- an audit_receipts row exists if and only if its audit_inbox row exists (no partial receipt, no partial dedupe);
- a death before COMMIT leaves nothing behind, and a retry creates the one logical receipt;
- a death after COMMIT leaves one receipt, and a retry returns that same receipt as a duplicate;
- an outbox event is marked confirmed only after the sink returned a receipt, never because of a partial write.
"""

import logging
import os
import sqlite3
import tempfile
import unittest

from sanour_ai.governance.sink import DurableSqliteSink
from sanour_ai.governance.sink_contract import SinkFailed, SinkOutcomeUnknown
from sanour_ai.governance.store import GovernanceStore
from sanour_ai.governance.admission import AdmissionController
from sanour_ai.observability.audit import AuditLogger
from tests.unit.r4_support import ACTOR, run_child
from tests.unit.r5_support import GOV_DELIVER_CHILD, SINK_DELIVER_CHILD, SINK_POINTS, RaiseOn
from tests.unit.test_stage1049 import BOUNDS
from tests.unit.test_stage1049r3_outbox import Base

FIELDS = {"request_id": "r-atomic", "resolution": "write_off", "actor": "ops.alice", "decision": "applied"}
KEY = "gov:42:exposure.resolved"


def sink_invariants(path):
    conn = sqlite3.connect(path)
    try:
        receipts = conn.execute("SELECT COUNT(*) FROM audit_receipts").fetchone()[0]
        receipts_without_inbox = conn.execute(
            "SELECT COUNT(*) FROM audit_receipts r WHERE NOT EXISTS "
            "(SELECT 1 FROM audit_inbox i WHERE i.receipt_id = r.receipt_id)").fetchone()[0]
        inbox_without_receipt = conn.execute(
            "SELECT COUNT(*) FROM audit_inbox i WHERE NOT EXISTS "
            "(SELECT 1 FROM audit_receipts r WHERE r.receipt_id = i.receipt_id)").fetchone()[0]
        return receipts, receipts_without_inbox, inbox_without_receipt
    finally:
        conn.close()


def receipts_for(path, key):
    conn = sqlite3.connect(path)
    try:
        return conn.execute("SELECT COUNT(*) FROM audit_receipts WHERE outbox_key = ?", (key,)).fetchone()[0]
    finally:
        conn.close()


class SinkBoundaries(unittest.TestCase):
    def setUp(self):
        self._dir = tempfile.TemporaryDirectory()
        self.addCleanup(self._dir.cleanup)

    def path(self, name):
        return os.path.join(self._dir.name, name)

    def kill_at(self, point):
        path = self.path(f"sink-{point}.db")
        done = run_child(SINK_DELIVER_CHILD, [path, point, KEY])
        self.assertEqual(done.returncode, 7, f"the death point {point} must be reached")
        return path

    def test_death_at_every_boundary_leaves_no_partial_state_and_retry_is_exact(self):
        for point in SINK_POINTS:
            with self.subTest(point=point):
                path = self.kill_at(point)
                self.assertEqual(sink_invariants(path)[1:], (0, 0), "no receipt without inbox, no inbox without receipt")
                committed = point == "after_commit"
                self.assertEqual(receipts_for(path, KEY), 1 if committed else 0)
                sink = DurableSqliteSink(path)
                self.addCleanup(sink.close)
                receipt = sink.deliver(KEY, "exposure.resolved", FIELDS)
                self.assertEqual(receipt.duplicate, committed)
                self.assertEqual(receipts_for(path, KEY), 1, "exactly one logical receipt after the retry")
                self.assertEqual(sink_invariants(path)[1:], (0, 0))
                if committed:
                    self.assertEqual(receipt.receipt_id, 1, "the retry returns the original receipt")

    def test_rollback_on_an_inbox_failure_leaves_no_receipt_and_restart_is_clean(self):
        path = self.path("rollback.db")
        sink = DurableSqliteSink(path)
        real = sink._conn  # noqa: SLF001
        sink._conn = RaiseOn(real, "INSERT INTO audit_inbox")  # noqa: SLF001
        with self.assertRaises(SinkFailed):
            sink.deliver(KEY, "exposure.resolved", FIELDS)
        sink._conn = real  # noqa: SLF001
        sink.close()
        self.assertEqual(sink_invariants(path), (0, 0, 0), "the receipt row must roll back with the inbox failure")
        reopened = DurableSqliteSink(path)
        self.addCleanup(reopened.close)
        receipt = reopened.deliver(KEY, "exposure.resolved", FIELDS)
        self.assertFalse(receipt.duplicate)
        self.assertEqual(receipt.receipt_id, 1)

    def test_commit_failure_is_unknown_and_nothing_is_visible_to_another_connection(self):
        path = self.path("commit.db")
        sink = DurableSqliteSink(path)
        self.addCleanup(sink.close)
        real = sink._conn  # noqa: SLF001
        sink._conn = RaiseOn(real, "COMMIT")  # noqa: SLF001
        with self.assertRaises(SinkOutcomeUnknown):
            sink.deliver(KEY, "exposure.resolved", FIELDS)
        sink._conn = real  # noqa: SLF001
        self.assertEqual(sink_invariants(path), (0, 0, 0))

    def test_partial_writes_are_never_visible_to_a_reader_mid_transaction(self):
        path = self.path("visible.db")
        sink = DurableSqliteSink(path)
        self.addCleanup(sink.close)
        seen = []
        real = sink._conn  # noqa: SLF001

        class PeekAfterReceiptInsert:
            def execute(self, sql, *args):
                out = real.execute(sql, *args)
                if sql.startswith("INSERT INTO audit_receipts"):
                    seen.append(sink_invariants(path))  # another connection, mid-transaction
                return out

            def close(self):
                real.close()

        sink._conn = PeekAfterReceiptInsert()  # noqa: SLF001
        sink.deliver(KEY, "exposure.resolved", FIELDS)
        self.assertEqual(seen, [(0, 0, 0)], "an uncommitted receipt must be invisible outside its transaction")


class SinkBoundaryContract(unittest.TestCase):
    def test_the_contract_module_has_no_storage_import_and_sqlite_implements_the_protocol(self):
        from sanour_ai.governance import sink_contract
        from sanour_ai.governance.sink_contract import AuditSink
        text = open(sink_contract.__file__).read()
        imports = [line for line in text.splitlines() if line.startswith(("import ", "from "))]
        self.assertFalse(any("sqlite" in line for line in imports), imports)
        self._dir = tempfile.TemporaryDirectory()
        self.addCleanup(self._dir.cleanup)
        sink = DurableSqliteSink(os.path.join(self._dir.name, "p.db"))
        self.addCleanup(sink.close)
        self.assertIsInstance(sink, AuditSink)


class GovernanceBoundaries(Base):
    def child_write_off(self, where, point, rid):
        return run_child(GOV_DELIVER_CHILD, [self.path, self.path + ".sink", where, point, rid])

    def assert_not_confirmed_yet(self, key):
        self.assertNotEqual(self.one("SELECT status FROM audit_outbox WHERE event_key = ?", key), "delivered")
        self.assertNotIn(self.delivery_states_of(key), ("confirmed",))

    def delivery_states_of(self, key):
        return self.c.delivery_states([key])[key]

    def recover(self, key):
        self.clock.now += 61  # the dead worker's lease has expired
        sink, c2 = self.restart()
        c2.sweep()
        return sink, c2

    def test_death_between_receipt_and_inbox_is_never_confirmed_and_recovers_to_one_receipt(self):
        rid = self.exposed_request()
        done = self.child_write_off("sink", "between_receipt_and_inbox", rid)
        self.assertEqual(done.returncode, 7)
        key = self.key_for(rid)
        self.assertEqual(sink_invariants(self.path + ".sink")[1:], (0, 0))
        self.assertEqual(receipts_for(self.path + ".sink", key), 0)
        self.assert_not_confirmed_yet(key)
        self.assertEqual(self.delivery_states_of(key), "attempted")
        self.clock.now += 61
        self.assertEqual(self.delivery_states_of(key), "unknown", "an expired lease is never reported as confirmed")
        sink, _ = self.recover(key)
        self.assertEqual(receipts_for(self.path + ".sink", key), 1)
        self.assertEqual(self.one("SELECT status FROM audit_outbox WHERE event_key = ?", key), "delivered")
        self.assertFalse(sink.receipts[-1].duplicate)

    def test_death_before_commit_is_never_confirmed_and_recovers_to_one_receipt(self):
        rid = self.exposed_request()
        done = self.child_write_off("sink", "before_commit", rid)
        self.assertEqual(done.returncode, 7)
        key = self.key_for(rid)
        self.assertEqual(sink_invariants(self.path + ".sink")[1:], (0, 0))
        self.assertEqual(receipts_for(self.path + ".sink", key), 0)
        self.assert_not_confirmed_yet(key)
        sink, _ = self.recover(key)
        self.assertEqual(receipts_for(self.path + ".sink", key), 1)
        self.assertEqual(self.one("SELECT status FROM audit_outbox WHERE event_key = ?", key), "delivered")
        self.assertFalse(sink.receipts[-1].duplicate)

    def test_death_after_commit_before_marking_confirms_once_with_the_original_receipt(self):
        rid = self.exposed_request()
        done = self.child_write_off("sink", "after_commit", rid)
        self.assertEqual(done.returncode, 7)
        key = self.key_for(rid)
        self.assertEqual(receipts_for(self.path + ".sink", key), 1)
        original = sqlite3.connect(self.path + ".sink").execute(
            "SELECT receipt_id FROM audit_receipts WHERE outbox_key = ?", (key,)).fetchone()[0]
        self.assert_not_confirmed_yet(key)
        sink, _ = self.recover(key)
        self.assertEqual(receipts_for(self.path + ".sink", key), 1)
        self.assertTrue(sink.receipts[-1].duplicate)
        self.assertEqual(sink.receipts[-1].receipt_id, original)
        self.assertEqual(self.one("SELECT receipt_id FROM audit_outbox WHERE event_key = ?", key), original)

    def test_death_before_the_governance_settlement_commits_is_recovered_without_a_second_receipt(self):
        rid = self.exposed_request()
        done = self.child_write_off("gov", "settle", rid)
        self.assertEqual(done.returncode, 7)
        key = self.key_for(rid)
        self.assertEqual(receipts_for(self.path + ".sink", key), 1, "the sink committed before the death")
        self.assert_not_confirmed_yet(key)
        sink, _ = self.recover(key)
        self.assertEqual(receipts_for(self.path + ".sink", key), 1)
        self.assertTrue(sink.receipts[-1].duplicate)
        self.assertEqual(self.one("SELECT status FROM audit_outbox WHERE event_key = ?", key), "delivered")
        self.assertEqual(self.snapshot()["write_off_ok"], 1)


if __name__ == "__main__":
    unittest.main()
