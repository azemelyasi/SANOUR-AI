"""Stage 10.49-R1: cost vs reservation separation, failed and timed-out accounting, two-phase settlement,
persistent recovery, reporting and currency isolation. Deterministic and offline.
"""

import sqlite3
import tempfile
import threading
import os
from decimal import Decimal
from unittest import mock

from sanour_ai.composition.runtime import Runtime
from sanour_ai.errors import ErrorCode, FailureKind, SanourError
from sanour_ai.governance.admission import AdmissionController
from sanour_ai.governance.cost import STATUS_UNKNOWN_USAGE
from sanour_ai.governance.store import _MIGRATIONS, GovernanceStore
from sanour_ai.governance.types import Bounds, Settlement
from sanour_ai.models.usage import Usage
from sanour_ai.observability.audit import AUDIT_LOGGER_NAME, AuditLogger
from tests.unit.test_stage1048 import env, raw
from tests.unit.test_stage1047r1 import UsageProvider
from tests.unit.test_stage1049 import (
    ALIAS, BOUNDS, GovBase, MODEL, PROVIDER, WORST_512, Clock, T0, _FailOn, pricing, profile, request,
)

DAY = "2026-11-07"
ACTUAL_24 = Decimal("0.000024")  # (4 x 2.00 + 2 x 8.00) / 1e6
VALID = Usage(input_tokens=4, output_tokens=2)
PHASE1 = "UPDATE reservations SET state = 'settlement_pending'"
PHASE2 = "UPDATE reservations SET state = ?, settled_at"


class R1(GovBase):
    def setUp(self):
        super().setUp()
        self.s = self.store()
        self.s.upsert_pricing(pricing())
        self.bid = self.s.upsert_budget("global", "", "daily", "USD", "1.00")
        self.c = self.controller(self.s)

    def state_of(self, rid=None):
        if rid is None:
            return self.row("SELECT state FROM reservations")[0]
        return self.row("SELECT state FROM reservations WHERE request_id = ?", rid)[0]

    def fail_next(self, prefix):
        """Make the next write matching prefix fail, then restore the real connection."""
        real = self.s._conn  # noqa: SLF001
        self.s._conn = _FailOn(real, prefix)  # noqa: SLF001
        return real

    def restore(self, real):
        self.s._conn = real  # noqa: SLF001


# ------------------------------------------- 1-3. provider failure and timeout accounting
class FailureAccounting(R1):
    def test_provider_failure_with_known_usage_records_actual_cost(self):
        t = self.c.admit(request(), profile())
        result = self.c.settle(t, Settlement("failed", provider_started=True, usage=VALID))
        self.assertTrue(result.applied)
        self.assertEqual(self.spent_of(), ACTUAL_24)
        self.assertEqual(self.exposed_of(), Decimal(0))
        self.assertEqual(self.state_of(), "settled")
        self.assertEqual(self.row("SELECT cost_status, charged_from FROM cost_records")[:2], ("priced", "actual"))

    def test_provider_failure_with_unknown_usage_is_exposure(self):
        t = self.c.admit(request(), profile())
        self.c.settle(t, Settlement("failed", provider_started=True))
        self.assertEqual(self.spent_of(), Decimal(0))
        self.assertEqual(self.exposed_of(), WORST_512)
        self.assertEqual(self.state_of(), "exposed")
        row = self.row("SELECT cost_status, actual_cost, charged_from FROM cost_records")
        self.assertEqual(row, (STATUS_UNKNOWN_USAGE, None, "exposed"))  # no actual cost invented

    def test_timeout_with_unknown_usage_is_exposure(self):
        t = self.c.admit(request(), profile())
        self.c.settle(t, Settlement("timed_out", provider_started=True))
        self.assertEqual(self.spent_of(), Decimal(0))
        self.assertEqual(self.exposed_of(), WORST_512)
        self.assertEqual(self.state_of(), "exposed")

    def spent_of(self):
        return self._w("spent")

    def exposed_of(self):
        return self._w("exposed")

    def _w(self, column):
        r = self.row(f"SELECT {column} FROM budget_windows WHERE budget_id = ? AND window_start = ?", self.bid, DAY)
        return Decimal(r[0]) if r else Decimal(0)


# ------------------------------------------ 4-5, 14. uncertain settlement and storage failure
class UncertainSettlement(R1):
    def test_reservation_stays_active_after_an_uncertain_settlement(self):
        t = self.c.admit(request(), profile())
        real = self.fail_next(PHASE2)  # phase 1 stores the intent; the apply write fails
        result = self.c.settle(t, Settlement("completed", True, VALID))
        self.restore(real)
        self.assertFalse(result.applied)
        self.assertEqual(result.reason, "settlement_pending")  # never reported as success
        self.assertEqual(self.state_of(), "settlement_pending")
        self.assertEqual(self._res(), WORST_512)  # still reserved against the budget
        self.assertEqual(self._spent(), Decimal(0))  # not actual spending

    def test_failed_intent_write_keeps_the_reservation_and_is_retried_by_the_next_call(self):
        t = self.c.admit(request(), profile())
        real = self.fail_next(PHASE1)
        result = self.c.settle(t, Settlement("completed", True, VALID))
        self.restore(real)
        self.assertEqual(result.reason, "settlement_failed")
        self.assertEqual(self.state_of(), "reserved")
        self.assertEqual(self._res(), WORST_512)  # no reservation loss
        self.assertTrue(self.c.settle(t, Settlement("completed", True, VALID)).applied)
        self.assertEqual(self._spent(), ACTUAL_24)

    def test_settlement_failure_is_audited_and_visible(self):
        c = self.controller(self.s, audit=AuditLogger())
        t = c.admit(request(), profile())
        real = self.fail_next(PHASE2)
        with self.assertLogs(AUDIT_LOGGER_NAME, level="INFO") as captured:
            c.settle(t, Settlement("completed", True, VALID))
        self.restore(real)
        self.assertIn("settlement.failed", "\n".join(captured.output))

    def test_a_failing_settlement_write_retries_at_most_once_per_call(self):
        t = self.c.admit(request(), profile())
        real = self.fail_next(PHASE2)
        with mock.patch.object(self.c, "_apply", wraps=self.c._apply) as apply:  # noqa: SLF001
            self.c.settle(t, Settlement("completed", True, VALID))
            self.c.settle(t, Settlement("completed", True, VALID))  # pending: applies the stored intent once more
        self.restore(real)
        self.assertLessEqual(apply.call_count, 2)  # one apply per settle call, no loop
        self.assertEqual(self._spent(), Decimal(0))
        self.assertEqual(self.state_of(), "settlement_pending")

    def _res(self):
        r = self.row("SELECT reserved FROM budget_windows WHERE budget_id = ?", self.bid)
        return Decimal(r[0]) if r else Decimal(0)

    def _spent(self):
        r = self.row("SELECT spent FROM budget_windows WHERE budget_id = ?", self.bid)
        return Decimal(r[0]) if r else Decimal(0)


# ------------------------------------------------------ 6-8. restart, recovery, duplicates
class Recovery(R1):
    def reopen(self):
        self.s.close()
        store = self.store()
        return store, self.controller(store)

    def test_unresolved_reservation_is_reconciled_after_restart(self):
        t = self.c.admit(request(), profile())
        self.fail_next(PHASE2)
        self.c.settle(t, Settlement("completed", True, VALID))  # apply fails; intent stays stored
        store, c2 = self.reopen()
        self.assertEqual(c2.sweep(), 1)
        self.assertEqual(self.state_of(), "settled")
        self.assertEqual(self.row("SELECT spent FROM budget_windows WHERE budget_id = ?", self.bid)[0], "0.000024")

    def test_restart_without_stored_intent_turns_the_reservation_into_exposure(self):
        t = self.c.admit(request(), profile())
        store, c2 = self.reopen()  # the process died before any settlement was attempted
        self.assertEqual(c2.sweep(everything=True), 1)
        self.assertEqual(self.state_of(), "exposed")
        self.assertEqual(self.row("SELECT spent FROM budget_windows WHERE budget_id = ?", self.bid)[0], "0")

    def test_duplicate_recovery_does_not_double_count(self):
        t = self.c.admit(request(), profile())
        self.fail_next(PHASE2)
        self.c.settle(t, Settlement("completed", True, VALID))
        store, c2 = self.reopen()
        c2.sweep()
        self.assertEqual(c2.sweep(), 0)
        self.assertFalse(c2.settle(t, Settlement("completed", True, VALID)).applied)
        self.assertEqual(self.row("SELECT spent FROM budget_windows WHERE budget_id = ?", self.bid)[0], "0.000024")

    def test_runtime_shutdown_recovers_unresolved_settlements(self):
        provider = UsageProvider(Usage(input_tokens=4, output_tokens=2))
        ctl = self.controller(self.s)
        rt = Runtime.build_for_tests(env(), provider=provider, usage_ledger_path=self.path, governance=ctl)
        self.addCleanup(lambda: rt.shutdown(1.0))
        t = ctl.admit(request(), profile())
        real = self.fail_next(PHASE2)
        ctl.settle(t, Settlement("completed", True, VALID))
        self.restore(real)  # the storage recovers before shutdown
        rt.shutdown(1.0)
        self.assertTrue(rt.wait_stopped(5))
        self.assertEqual(self.row("SELECT state FROM reservations")[0], "settled")
        self.assertEqual(self.row("SELECT spent FROM budget_windows WHERE budget_id = ?", self.bid)[0], "0.000024")


# ----------------------------------------------------------------- 9. concurrency
class Concurrency(R1):
    def test_concurrent_settlement_attempts_apply_exactly_once(self):
        t = self.c.admit(request(), profile())
        results = []
        guard = threading.Lock()
        gate = threading.Barrier(10)

        def attempt():
            c = self.controller(self.store())
            gate.wait(timeout=30)
            outcome = c.settle(t, Settlement("completed", True, VALID))
            with guard:
                results.append(outcome.applied)

        threads = [threading.Thread(target=attempt) for _ in range(10)]
        for th in threads:
            th.start()
        for th in threads:
            th.join(timeout=60)
        self.assertEqual(results.count(True), 1)
        self.assertEqual(self.row("SELECT spent FROM budget_windows WHERE budget_id = ?", self.bid)[0], "0.000024")
        self.assertEqual(self.row("SELECT COUNT(*) FROM cost_records")[0], 1)


# ------------------------------------------------------- 10. availability and late results
class AvailabilityAndLateResults(R1):
    def test_unresolved_reservation_reduces_availability(self):
        self.bid2 = self.s.upsert_budget("global", "", "daily", "USD", WORST_512 + Decimal("0.00001"))
        t = self.c.admit(request(), profile())
        real = self.fail_next(PHASE2)
        self.c.settle(t, Settlement("completed", True, VALID))
        self.restore(real)
        with self.assertRaises(SanourError) as ctx:
            self.c.admit(request(), profile())  # the pending reservation still holds the budget
        self.assertEqual(ctx.exception.scope, "budget")

    def test_uncertain_exposure_alone_reduces_availability(self):
        self.s.upsert_budget("global", "", "daily", "USD", WORST_512 + Decimal("0.00001"))
        t = self.c.admit(request(), profile())
        self.c.settle(t, Settlement("failed", True))  # exposure only, nothing in flight
        with self.assertRaises(SanourError) as ctx:
            self.c.admit(request(), profile())
        self.assertEqual(ctx.exception.scope, "budget")

    def test_retry_after_a_failed_apply_applies_the_stored_intent(self):
        t = self.c.admit(request(), profile())
        real = self.fail_next(PHASE2)
        self.c.settle(t, Settlement("completed", True, VALID))
        self.restore(real)
        retry = self.c.settle(t, Settlement("completed", True, VALID))  # storage is back
        self.assertTrue(retry.applied)
        self.assertEqual(self.state_of(), "settled")
        self.assertEqual(self.row("SELECT spent FROM budget_windows WHERE budget_id = ?", self.bid)[0], "0.000024")

    def test_applying_an_already_settled_reservation_is_a_no_op(self):
        t = self.c.admit(request(), profile())
        self.c.settle(t, Settlement("completed", True, VALID))
        result = self.c._apply(t.request_id, "settle_apply")  # noqa: SLF001  (a second, direct apply)
        self.assertFalse(result.applied)
        self.assertEqual(result.reason, "already_settled")
        self.assertEqual(self.row("SELECT spent FROM budget_windows WHERE budget_id = ?", self.bid)[0], "0.000024")

    def test_late_result_cannot_overwrite_a_pending_timeout(self):
        t = self.c.admit(request(), profile())
        real = self.fail_next(PHASE2)
        self.c.settle(t, Settlement("timed_out", True))  # intent recorded: timed out; apply fails
        late = self.c.settle(t, Settlement("completed", True, VALID))  # the late answer arrives
        self.assertFalse(late.applied)
        self.restore(real)
        self.c.sweep()  # recovery applies the timeout intent, not the late one
        self.assertEqual(self.row("SELECT intent_kind FROM reservations")[0], "timed_out")
        self.assertEqual(self.row("SELECT spent FROM budget_windows WHERE budget_id = ?", self.bid)[0], "0")
        self.assertEqual(self.row("SELECT exposed FROM budget_windows WHERE budget_id = ?", self.bid)[0], "0.02048")

    def test_late_result_cannot_overwrite_a_settled_timeout(self):
        t = self.c.admit(request(), profile())
        self.c.settle(t, Settlement("timed_out", True))
        self.assertEqual(self.c.settle(t, Settlement("completed", True, VALID)).reason, "already_settled")
        self.assertEqual(self.row("SELECT spent FROM budget_windows WHERE budget_id = ?", self.bid)[0], "0")


# ------------------------------------------------------------ resolving exposure
class ResolveExposure(R1):
    def setUp(self):
        super().setUp()
        # Stage 10.49-R2 review: resolve_exposure requires an authorized actor
        self.c = AdmissionController(self.s, audit=self.c._audit, bounds=self.c._bounds, clock=self.c._clock,  # noqa: SLF001
                                     authorized_actors=frozenset({"ops.alice"}))

    def test_verified_usage_replaces_exposure_once(self):
        t = self.c.admit(request(), profile())
        self.c.settle(t, Settlement("failed", True))
        result = self.c.resolve_exposure(t.request_id, VALID, actor="ops.alice")
        self.assertTrue(result.applied)
        self.assertEqual(self.row("SELECT spent, exposed FROM budget_windows WHERE budget_id = ?", self.bid),
                         ("0.000024", "0"))
        self.assertEqual(self.state_of(), "settled")
        self.assertEqual(self.c.resolve_exposure(t.request_id, VALID, actor="ops.alice").reason, "not_exposed")

    def test_unpriceable_usage_is_refused_and_writes_nothing(self):
        t = self.c.admit(request(), profile())
        self.c.settle(t, Settlement("failed", True))
        result = self.c.resolve_exposure(t.request_id, Usage(input_tokens=None, output_tokens=2), actor="ops.alice")
        self.assertFalse(result.applied)
        self.assertEqual(result.reason, "usage_not_priced")
        self.assertEqual(self.row("SELECT exposed FROM budget_windows WHERE budget_id = ?", self.bid)[0], "0.02048")
        self.assertEqual(self.state_of(), "exposed")


# ---------------------------------------------------------- 11. reports and 12. currency
class ReportsAndCurrency(R1):
    def test_report_separates_actual_spend_from_reserved_and_exposed_amounts(self):
        t1 = self.c.admit(request(), profile())
        self.c.settle(t1, Settlement("completed", True, VALID))
        t2 = self.c.admit(request(), profile())
        self.c.settle(t2, Settlement("failed", True))
        t3 = self.c.admit(request(), profile())  # still in flight
        report = self.c.report(DAY)
        entry = report["budgets"][0]
        self.assertEqual(entry["actual_spent"], "0.000024")
        self.assertEqual(entry["uncertain_exposure"], "0.02048")
        self.assertEqual(entry["reserved_in_flight"], "0.02048")
        self.assertEqual(entry["available"], format(Decimal("1.00") - ACTUAL_24 - WORST_512 - WORST_512, "f"))
        self.assertNotEqual(entry["actual_spent"], entry["reserved_in_flight"])
        self.assertIsNotNone(t3)

    def test_usd_exposure_never_moves_a_eur_budget(self):
        self.s.upsert_budget("profile", "other_profile", "daily", "EUR", "5.00")
        t = self.c.admit(request(), profile())
        self.c.settle(t, Settlement("failed", True))
        eur = [b for b in self.c.report(DAY)["budgets"] if b["currency"] == "EUR"]
        self.assertEqual(len(eur), 1)
        self.assertEqual(eur[0]["uncertain_exposure"], "0")
        self.assertEqual(eur[0]["actual_spent"], "0")
        self.assertEqual(eur[0]["available"], "5.00")

    def test_eur_budget_for_this_profile_refuses_usd_pricing_fail_closed(self):
        self.s.upsert_budget("profile", ALIAS, "daily", "EUR", "5.00")
        with self.assertRaises(SanourError) as ctx:
            self.c.admit(request(), profile())
        self.assertEqual(ctx.exception.scope, "budget")  # cost cannot be bounded in EUR: refused, never free


# ------------------------------------------------------ errors, migration, sanity checks
class Semantics(R1):
    def test_budget_and_quota_refusals_are_distinct_internally(self):
        self.s.upsert_budget("global", "", "daily", "USD", "0.01")
        with self.assertRaises(SanourError) as budget_err:
            self.c.admit(request(), profile())
        self.assertEqual((budget_err.exception.code, budget_err.exception.scope),
                         (ErrorCode.PROVIDER_RATE_LIMITED, "budget"))
        self.assertEqual(budget_err.exception.internal_kind, FailureKind.LIMIT_REACHED)
        s2 = GovernanceStore(os.path.join(tempfile.mkdtemp(), "quota-only.db"))
        self.addCleanup(s2.close)
        s2.upsert_pricing(pricing())
        s2.upsert_quota("global", "", "daily", "requests", 0)
        with self.assertRaises(SanourError) as quota_err:
            self.controller(s2).admit(request(), profile())
        self.assertEqual(quota_err.exception.scope, "quota")

    def test_exposure_is_never_recorded_as_an_actual_cost(self):
        t = self.c.admit(request(), profile())
        self.c.settle(t, Settlement("timed_out", True))
        self.assertEqual(self.row("SELECT actual_cost FROM cost_records")[0], None)

    def test_migration_two_upgrades_version_one_data_without_losing_rows(self):
        path = os.path.join(tempfile.mkdtemp(), "v1.db")
        conn = sqlite3.connect(path, isolation_level=None)
        for statement in _MIGRATIONS[1].split(";\n"):
            if statement.strip():
                conn.execute(statement)
        conn.execute("CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, applied_at INTEGER)")
        conn.execute("INSERT INTO schema_migrations VALUES (1, 0)")
        conn.execute("INSERT INTO reservations (request_id, state, provider_id, model_id, profile_id, utc_day, "
                     "created_at, expires_at) VALUES ('old-expired', 'expired', 'openai', 'm', 'p', '2026-11-07', 0, 0)")
        conn.execute("INSERT INTO reservations (request_id, state, provider_id, model_id, profile_id, utc_day, "
                     "created_at, expires_at) VALUES ('old-settled', 'settled', 'openai', 'm', 'p', '2026-11-07', 0, 0)")
        conn.execute("INSERT INTO cost_records (request_id, cost_status, charged_from) "
                     "VALUES ('old-expired', 'unknown_usage', 'reserved')")
        conn.close()
        store = GovernanceStore(path)
        self.addCleanup(store.close)
        self.assertEqual(store.schema_version(), 6)
        rows = dict(store._live().execute("SELECT request_id, state FROM reservations").fetchall())  # noqa: SLF001
        self.assertEqual(rows, {"old-expired": "exposed", "old-settled": "settled"})
        self.assertEqual(store._live().execute("SELECT charged_from FROM cost_records").fetchone()[0],  # noqa: SLF001
                         "exposed")
        self.assertTrue(store.integrity_ok())


if __name__ == "__main__":
    import unittest
    unittest.main()
