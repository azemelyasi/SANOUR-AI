"""Stage 10.39: runtime lifecycle, refusal during shutdown, cleanup on failed startup, safe stats,
and concurrency. Offline only: a fake OpenAI adapter, no SDK, no network, no key. Waits are bounded.
"""

import json
import threading
import time
import unittest
from unittest import mock

from sanour_ai.providers.offline_contract import OfflineTestProvider
from sanour_ai.composition import production
from sanour_ai.composition.runtime import (
    REFUSED_MESSAGE,
    RUNTIME_TRANSITIONS,
    Runtime,
    RuntimeState,
    RuntimeTransitionError,
)
from sanour_ai.config.settings import ConfigError
from sanour_ai.errors import ErrorCode
from sanour_ai.models.base import ModelResult
from sanour_ai.models.capabilities import ProviderCapabilities
from sanour_ai.providers.registry import RegistryError
from tests.support import wait_until

SECRET = "STAGE1039-SECRET-KEY-ZX"
MODEL = "gpt-test-1039"
PROMPT = "STAGE1039-PROMPT-TEXT-QQ"
ALLOWED_TOP_KEYS = {"state", "refused_requests", "providers", "provider_close_failures", "settlement", "coordinator", "audit", "mode"}


def env():
    return {
        "SANOUR_PROVIDER": "openai",
        "SANOUR_OPENAI_MODEL_ID": MODEL,
        "SANOUR_OPENAI_MAX_CONTEXT_TOKENS": "8192",
        "SANOUR_OPENAI_MAX_OUTPUT_TOKENS": "1024",
        "OPENAI_API_KEY": SECRET,
    }


class LifeOpenAI(OfflineTestProvider):
    name = "openai"
    vendor = "openai"
    surface = "openai_responses"
    auth_method = "sdk_bearer_client"
    capabilities = ProviderCapabilities(text_generation=True)
    instances: list = []
    events: list = []
    gate = None  # threading.Event: when set, generate waits on it
    fail_init = False
    fail_init_exc = RuntimeError
    lock = threading.Lock()

    def __init__(self, api_key):
        self.closed = False
        self.close_count = 0
        LifeOpenAI.instances.append(self)

    def initialize(self):
        if LifeOpenAI.fail_init:
            raise LifeOpenAI.fail_init_exc("init failed")

    def generate(self, call):
        with LifeOpenAI.lock:
            LifeOpenAI.events.append(("start", None))
        gate = LifeOpenAI.gate
        if gate is not None:
            gate.wait(3.0)
        time.sleep(0.002)
        with LifeOpenAI.lock:
            LifeOpenAI.events.append(("end", None))
        return ModelResult(text="ok", reported_model_id=call.model_id)

    def close(self):
        with LifeOpenAI.lock:
            LifeOpenAI.events.append(("close", None))
            self.close_count += 1
            self.closed = True


class Base(unittest.TestCase):
    def setUp(self):
        LifeOpenAI.instances = []
        LifeOpenAI.events = []
        LifeOpenAI.gate = None
        LifeOpenAI.fail_init = False
        LifeOpenAI.fail_init_exc = RuntimeError
        self._patches = [
            mock.patch.object(production, "OpenAIProvider", LifeOpenAI), mock.patch.object(production, "_default_test_provider", lambda: LifeOpenAI("test")),
            mock.patch.object(production, "_sdk_present", return_value=True),
        ]
        for p in self._patches:
            p.start()

    def tearDown(self):
        LifeOpenAI.gate = None
        for p in self._patches:
            p.stop()

    def build(self):
        return Runtime.build_for_tests(env())

    def ask(self, rt, text=PROMPT):
        return rt.handle({"profile_alias": "openai_primary", "prompt": text})

    @property
    def adapter(self):
        return LifeOpenAI.instances[-1]


class LifecycleStates(Base):
    def test_transition_table_is_the_documented_one(self):
        self.assertEqual(RUNTIME_TRANSITIONS[RuntimeState.READY], frozenset({RuntimeState.DRAINING}))
        self.assertEqual(RUNTIME_TRANSITIONS[RuntimeState.DRAINING], frozenset({RuntimeState.SHUTDOWN}))
        self.assertEqual(RUNTIME_TRANSITIONS[RuntimeState.SHUTDOWN], frozenset())
        self.assertNotIn(RuntimeState.SHUTDOWN, RUNTIME_TRANSITIONS[RuntimeState.READY])

    def test_build_is_ready(self):
        self.assertIs(self.build().state, RuntimeState.READY)

    def test_idle_shutdown_goes_through_draining_to_shutdown(self):
        rt = self.build()
        states = rt.shutdown(1.0)
        self.assertIs(rt.state, RuntimeState.SHUTDOWN)
        self.assertEqual(states, {"openai": "closed"})
        self.assertEqual(self.adapter.close_count, 1)

    def test_live_worker_keeps_runtime_draining_and_provider_open(self):
        rt = self.build()
        LifeOpenAI.gate = threading.Event()
        result = {}
        t = threading.Thread(target=lambda: result.setdefault("r", self.ask(rt)))
        t.start()
        self.assertTrue(wait_until(lambda: ("start", None) in LifeOpenAI.events, timeout=2.0))
        states = rt.shutdown(0.05)
        self.assertIs(rt.state, RuntimeState.DRAINING)
        self.assertEqual(states, {"openai": "closing"})
        self.assertEqual(self.adapter.close_count, 0)  # never closed under a live worker
        LifeOpenAI.gate.set()
        t.join(3.0)
        self.assertEqual(result["r"].status, "success")
        self.assertIs(rt.shutdown(1.0)["openai"], "closed")
        self.assertIs(rt.state, RuntimeState.SHUTDOWN)
        self.assertEqual(self.adapter.close_count, 1)

    def test_repeated_shutdown_is_predictable_and_closes_once(self):
        rt = self.build()
        results = [rt.shutdown(1.0) for _ in range(4)]
        self.assertEqual(results, [{"openai": "closed"}] * 4)
        self.assertIs(rt.state, RuntimeState.SHUTDOWN)
        self.assertEqual(self.adapter.close_count, 1)

    def test_repeated_shutdown_while_draining_never_closes_under_worker(self):
        rt = self.build()
        LifeOpenAI.gate = threading.Event()
        t = threading.Thread(target=lambda: self.ask(rt))
        t.start()
        self.assertTrue(wait_until(lambda: ("start", None) in LifeOpenAI.events, timeout=2.0))
        for _ in range(3):
            rt.shutdown(0.02)
        self.assertIs(rt.state, RuntimeState.DRAINING)
        self.assertEqual(self.adapter.close_count, 0)
        LifeOpenAI.gate.set()
        t.join(3.0)
        rt.shutdown(1.0)
        self.assertEqual(self.adapter.close_count, 1)

    def test_illegal_transition_is_refused(self):
        rt = self.build()
        rt.shutdown(1.0)
        with self.assertRaises(RuntimeTransitionError):
            rt._move(RuntimeState.READY)  # terminal state: no way back


class RefusalDuringShutdown(Base):
    def test_request_after_shutdown_is_refused_without_reaching_core_or_provider(self):
        rt = self.build()
        rt.shutdown(1.0)
        before = rt.core_stats().requests
        response = self.ask(rt)
        self.assertEqual(response.status, "error")
        self.assertIs(response.error.code, ErrorCode.PROVIDER_FAILED)
        self.assertEqual(response.error.message, REFUSED_MESSAGE)
        self.assertFalse(response.error.retryable)
        self.assertEqual(rt.core_stats().requests, before)
        self.assertNotIn(("start", None), LifeOpenAI.events)
        self.assertEqual(rt.stats()["refused_requests"], 1)

    def test_request_while_draining_is_refused(self):
        rt = self.build()
        LifeOpenAI.gate = threading.Event()
        t = threading.Thread(target=lambda: self.ask(rt))
        t.start()
        self.assertTrue(wait_until(lambda: ("start", None) in LifeOpenAI.events, timeout=2.0))
        rt.shutdown(0.02)
        self.assertIs(rt.state, RuntimeState.DRAINING)
        refused = self.ask(rt, "second")
        self.assertEqual(refused.error.message, REFUSED_MESSAGE)
        LifeOpenAI.gate.set()
        t.join(3.0)

    def test_request_admitted_before_shutdown_completes_normally(self):
        rt = self.build()
        LifeOpenAI.gate = threading.Event()
        result = {}
        t = threading.Thread(target=lambda: result.setdefault("r", self.ask(rt)))
        t.start()
        self.assertTrue(wait_until(lambda: ("start", None) in LifeOpenAI.events, timeout=2.0))
        rt.shutdown(0.02)
        LifeOpenAI.gate.set()
        t.join(3.0)
        self.assertEqual(result["r"].status, "success")
        self.assertEqual(result["r"].output, "ok")


class FailedStartupReleasesResources(Base):
    def assert_closed_and_refused(self, exc_type):
        with self.assertRaises(exc_type):
            self.build()
        self.assertTrue(LifeOpenAI.instances, "the adapter should have been created")
        self.assertTrue(all(a.close_count == 1 for a in LifeOpenAI.instances))

    def test_initialization_failure_closes_the_adapter(self):
        LifeOpenAI.fail_init = True
        with self.assertRaises(ConfigError):
            self.build()
        self.assertEqual(LifeOpenAI.instances[-1].close_count, 1)

    def test_profile_validation_failure_closes_the_adapter(self):
        with mock.patch("sanour_ai.providers.registry.ProviderRegistry.validate_profile",
                        side_effect=RegistryError("refused")):
            self.assert_closed_and_refused(ConfigError)

    def test_assembly_value_error_closes_the_adapter(self):
        with mock.patch.object(production, "_assemble", side_effect=ValueError("bad")):
            self.assert_closed_and_refused(ConfigError)

    def test_unexpected_assembly_error_closes_the_adapter_and_propagates(self):
        with mock.patch.object(production, "_assemble", side_effect=KeyError("boom")):
            with self.assertRaises(KeyError):
                self.build()
        self.assertEqual(LifeOpenAI.instances[-1].close_count, 1)

    def test_failed_startup_leaves_no_runtime_and_no_live_worker(self):
        with mock.patch.object(production, "_assemble", side_effect=ValueError("bad")):
            with self.assertRaises(ConfigError):
                self.build()
        self.assertEqual(LifeOpenAI.events.count(("start", None)), 0)


class GatewayAdmissionAfterShutdown(unittest.TestCase):
    def test_refused_call_never_takes_capacity_or_reaches_the_provider(self):
        import threading as _t
        from sanour_ai.errors import ErrorCode as _EC, SanourError as _SE
        from sanour_ai.models.gateway import ModelGateway
        from tests.support import deadline_in
        from tests.support import request_identity_for as _rid
        from sanour_ai.composition.runtime import RuntimeState as _RS  # noqa: F401 (import check)
        from tests.unit.test_gateway import PROFILE, CALL

        class Spy(threading.Semaphore):
            acquires = 0

            def acquire(self, *a, **k):
                Spy.acquires += 1
                return super().acquire(*a, **k)

        class Counting:
            name = "mock"
            capabilities = ProviderCapabilities(text_generation=True)
            calls = 0

            def generate(self, call):
                Counting.calls += 1
                return ModelResult(text="x", reported_model_id=call.model_id)

        provider = Counting()
        gw = ModelGateway({"mock": provider}, max_concurrent_calls=1)
        gw.shutdown(0.5)
        gw._slots = Spy(1)
        with self.assertRaises(_SE) as ctx:
            gw.generate(PROFILE, CALL, deadline_in(2.0), identity=_rid(PROFILE))
        self.assertIs(ctx.exception.code, _EC.PROVIDER_FAILED)
        self.assertEqual(str(ctx.exception), "model gateway is shut down")
        self.assertEqual(Spy.acquires, 0)  # refused before any capacity is taken
        self.assertEqual(Counting.calls, 0)


class SafeStats(Base):
    def test_stats_keys_are_bounded_and_contain_no_request_content_or_secrets(self):
        rt = self.build()
        self.ask(rt, PROMPT)
        rt.shutdown(1.0)
        self.ask(rt, PROMPT)
        stats = rt.stats()
        self.assertEqual(set(stats), ALLOWED_TOP_KEYS)
        self.assertEqual(stats["refused_requests"], 1)
        self.assertEqual(stats["state"], "shutdown")
        text = json.dumps(stats, default=str)
        self.assertNotIn(SECRET, text)
        self.assertNotIn(PROMPT, text)
        self.assertNotIn(MODEL, text)

    def test_provider_states_are_plain_state_names(self):
        rt = self.build()
        self.assertEqual(rt.stats()["providers"], {"openai": "ready"})


class ConcurrencyAndRaces(Base):
    def test_shutdown_under_concurrent_load_never_starts_a_call_after_close(self):
        rt = self.build()
        responses = []
        errors = []
        lock = threading.Lock()

        def worker():
            try:
                for _ in range(25):
                    r = self.ask(rt)
                    with lock:
                        responses.append(r)
            except Exception as exc:  # any exception is a failure
                with lock:
                    errors.append(type(exc).__name__)

        threads = [threading.Thread(target=worker) for _ in range(8)]
        for t in threads:
            t.start()
        self.assertTrue(wait_until(lambda: len(responses) >= 10, timeout=5.0))
        rt.shutdown(0.5)
        for t in threads:
            t.join(10.0)
        self.assertEqual(errors, [])
        self.assertFalse(any(t.is_alive() for t in threads))
        allowed = {REFUSED_MESSAGE, "model gateway is shut down"}
        for r in responses:
            if r.status == "error":
                # Capacity overflow is a legitimate public outcome under 8 threads; refusals are PROVIDER_FAILED.
                self.assertIn(r.error.code, {ErrorCode.PROVIDER_FAILED, ErrorCode.PROVIDER_OVERLOADED})
                if r.error.code is ErrorCode.PROVIDER_FAILED:
                    self.assertIn(r.error.message, allowed)
        rt.shutdown(2.0)
        self.assertIs(rt.state, RuntimeState.SHUTDOWN)
        self.assertEqual(self.adapter.close_count, 1)
        # Ordering invariant: every call that started has ended before the one close, and no start follows close.
        close_at = LifeOpenAI.events.index(("close", None))
        self.assertNotIn(("start", None), LifeOpenAI.events[close_at:])
        starts = LifeOpenAI.events.count(("start", None))
        ends = LifeOpenAI.events.count(("end", None))
        self.assertEqual(starts, ends)
        self.assertGreater(starts, 0)

    def test_concurrent_shutdowns_close_exactly_once(self):
        rt = self.build()
        results = []
        threads = [threading.Thread(target=lambda: results.append(rt.shutdown(1.0))) for _ in range(6)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(5.0)
        self.assertEqual(len(results), 6)
        self.assertTrue(all(r == {"openai": "closed"} for r in results))
        self.assertEqual(self.adapter.close_count, 1)
        self.assertIs(rt.state, RuntimeState.SHUTDOWN)


if __name__ == "__main__":
    unittest.main()
