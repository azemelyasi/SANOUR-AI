"""Stage 10.33 tests: configuration governance and runtime governance.

Fake OpenAI adapter only. No network, no real key, no SDK. Waits are bounded.
"""

import json
import unittest
from unittest import mock

from sanour_ai.providers.offline_contract import OfflineTestProvider
from sanour_ai.composition import production
from sanour_ai.composition.runtime import Runtime, RuntimeState
from sanour_ai.config import governance
from sanour_ai.config.settings import ConfigError
from sanour_ai.models.base import ModelResult
from sanour_ai.models.capabilities import ProviderCapabilities
from tests.support import production_ledger_path

SECRET = "STAGE1033-SECRET-KEY-PQ"
MODEL = "gpt-test-1033"


def env(**overrides):
    base = {
        "SANOUR_PROVIDER": "openai",
        "SANOUR_OPENAI_MODEL_ID": MODEL,
        "SANOUR_OPENAI_MAX_CONTEXT_TOKENS": "8192",
        "SANOUR_OPENAI_MAX_OUTPUT_TOKENS": "1024",
        "OPENAI_API_KEY": SECRET,
    }
    for name, value in overrides.items():
        if value is None:
            base.pop(name, None)
        else:
            base[name] = value
    return base


class FakeOpenAI(OfflineTestProvider):
    name = "openai"
    vendor = "openai"
    surface = "openai_responses"
    auth_method = "sdk_bearer_client"
    capabilities = ProviderCapabilities(text_generation=True)
    calls: list = []

    def __init__(self, api_key):
        self.key = api_key

    def generate(self, call):
        FakeOpenAI.calls.append(call.model_id)
        return ModelResult(text="fake", reported_model_id=call.model_id)

    def close(self):
        pass


class Base(unittest.TestCase):
    def setUp(self):
        FakeOpenAI.calls = []
        self._patches = [
            mock.patch.object(production, "OpenAIProvider", FakeOpenAI), mock.patch.object(production, "_default_test_provider", lambda: FakeOpenAI("test")),
            mock.patch.object(production, "_sdk_present", return_value=True),
        ]
        for p in self._patches:
            p.start()

    def tearDown(self):
        for p in self._patches:
            p.stop()

    def build(self, environ=None):
        return Runtime.build_for_tests(env() if environ is None else environ)


# ---------------------------------------------------------------- valid and invalid configuration
class ConfigValidationTests(Base):
    def test_valid_configuration_builds_a_ready_runtime(self):
        rt = self.build()
        self.assertEqual(rt.state, RuntimeState.READY)
        view = rt.describe()
        for group in ("core", "runtime", "providers", "capacity", "deadlines", "security", "observability"):
            self.assertIn(group, view)
        self.assertEqual(view["providers"]["selected"], "openai")
        self.assertEqual(view["providers"]["model_id"], MODEL)

    def test_describe_fingerprint_and_repr_never_contain_the_key(self):
        rt = self.build()
        blob = json.dumps(rt.describe(), default=str) + repr(rt._config) + rt._config.fingerprint()
        self.assertNotIn(SECRET, blob)
        self.assertEqual(rt.describe()["security"]["openai_api_key"], "configured")

    def test_missing_or_wrong_provider_selection_is_refused(self):
        for value in (None, "OpenAI", " openai", "anthropic", "xai"):
            with self.subTest(value=value):
                with self.assertRaises(ConfigError):
                    self.build(env(SANOUR_PROVIDER=value))

    def test_missing_model_id_is_refused_and_named(self):
        with self.assertRaises(ConfigError) as ctx:
            self.build(env(SANOUR_OPENAI_MODEL_ID=None))
        self.assertIn("SANOUR_OPENAI_MODEL_ID", str(ctx.exception))

    def test_invalid_model_id_shape_is_refused_without_echo(self):
        bad = "gpt test with spaces"
        with self.assertRaises(ConfigError) as ctx:
            self.build(env(SANOUR_OPENAI_MODEL_ID=bad))
        self.assertNotIn(bad, str(ctx.exception))

    def test_out_of_range_token_limits_are_refused(self):
        for name in ("SANOUR_OPENAI_MAX_CONTEXT_TOKENS", "SANOUR_OPENAI_MAX_OUTPUT_TOKENS"):
            for value in ("0", "-5", "12.5", "08", "1 000", "abc"):
                with self.subTest(name=name, value=value):
                    with self.assertRaises(ConfigError) as ctx:
                        self.build(env(**{name: value}))
                    self.assertIn(name, str(ctx.exception))
                    self.assertNotIn(value, str(ctx.exception))

    def test_output_limit_above_context_limit_is_a_contradiction(self):
        with self.assertRaises(ConfigError) as ctx:
            self.build(env(SANOUR_OPENAI_MAX_OUTPUT_TOKENS="9000", SANOUR_OPENAI_MAX_CONTEXT_TOKENS="8192"))
        self.assertIn("SANOUR_OPENAI_MAX_OUTPUT_TOKENS", str(ctx.exception))

    def test_missing_key_is_refused_and_names_the_variable_only(self):
        with self.assertRaises(ConfigError) as ctx:
            self.build(env(OPENAI_API_KEY=None))
        self.assertIn("OPENAI_API_KEY", str(ctx.exception))
        # Blank-key refusal is a production loader rule. Test factories never read the key value, so
        # they do not police it; the governance loader is checked directly here.
        blank = "   "
        with self.assertRaises(ConfigError) as ctx:
            governance.load_runtime_config(env(OPENAI_API_KEY=blank))
        self.assertNotIn(blank.strip() + "x", str(ctx.exception))

    def test_out_of_range_worker_cap_is_refused(self):
        for value in ("0", "17", "x", "-1"):
            with self.subTest(value=value):
                with self.assertRaises(ConfigError) as ctx:
                    self.build(env(SANOUR_MAX_CONCURRENT_PROVIDER_CALLS=value))
                self.assertIn("SANOUR_MAX_CONCURRENT_PROVIDER_CALLS", str(ctx.exception))

    def test_provider_limit_for_an_unselected_provider_is_refused(self):
        with self.assertRaises(ConfigError) as ctx:
            self.build(env(SANOUR_PROVIDER_CONCURRENCY="anthropic=2"))
        self.assertIn("SANOUR_PROVIDER_CONCURRENCY", str(ctx.exception))

    def test_provider_limit_above_the_global_cap_is_a_contradiction(self):
        with self.assertRaises(ConfigError) as ctx:
            self.build(env(SANOUR_MAX_CONCURRENT_PROVIDER_CALLS="2", SANOUR_PROVIDER_CONCURRENCY="openai=5"))
        self.assertIn("SANOUR_PROVIDER_CONCURRENCY", str(ctx.exception))

    def test_duplicate_provider_limit_is_refused(self):
        with self.assertRaises(ConfigError):
            self.build(env(SANOUR_PROVIDER_CONCURRENCY="openai=1,openai=2"))

    def test_valid_provider_limit_is_accepted_and_reported(self):
        rt = self.build(env(SANOUR_MAX_CONCURRENT_PROVIDER_CALLS="4", SANOUR_PROVIDER_CONCURRENCY="openai=2"))
        self.assertEqual(rt.describe()["capacity"]["provider_limits"], {"openai": 2})

    def test_no_guessed_defaults_when_only_the_switch_is_set(self):
        with self.assertRaises(ConfigError) as ctx:
            self.build({"SANOUR_PROVIDER": "openai"})
        self.assertIn("SANOUR_OPENAI_MODEL_ID", str(ctx.exception))

    def test_no_error_message_contains_the_secret(self):
        bad_sets = [
            env(SANOUR_OPENAI_MODEL_ID="bad model"),
            env(SANOUR_OPENAI_MAX_CONTEXT_TOKENS="zero"),
            env(SANOUR_PROVIDER="anthropic"),
            env(SANOUR_PROVIDER_CONCURRENCY="openai=99"),
        ]
        for bad in bad_sets:
            with self.subTest(bad=sorted(bad)):
                with self.assertRaises(ConfigError) as ctx:
                    self.build(bad)
                self.assertNotIn(SECRET, str(ctx.exception))


# ---------------------------------------------------------------- fail-closed runtime readiness
class RuntimeReadinessTests(Base):
    def test_an_invalid_configuration_never_produces_a_runtime(self):
        with self.assertRaises(ConfigError):
            self.build(env(SANOUR_OPENAI_MODEL_ID=None))

    def test_missing_sdk_never_produces_a_runtime(self):
        with mock.patch.object(production, "_sdk_present", return_value=False):
            with self.assertRaises(ConfigError):
                Runtime.build(env(), usage_ledger_path=production_ledger_path())  # the production entry point: SDK check first, then the gate

    def test_capacity_setting_reaches_the_gateway(self):
        rt = self.build(env(SANOUR_MAX_CONCURRENT_PROVIDER_CALLS="1"))
        self.assertEqual(rt._core._gateway._slots._value, 1)  # noqa: SLF001

    def test_provider_state_is_reported_through_the_runtime(self):
        rt = self.build()
        self.assertEqual(rt._core.coordinator_stats().provider_states, {"openai": "ready"})  # noqa: SLF001


# ---------------------------------------------------------------- reload, restart, no silent change
class ReloadTests(Base):
    def test_same_configuration_reports_no_change(self):
        rt = self.build()
        report = rt.check_reload(env())
        self.assertEqual(report.changed, ())
        self.assertFalse(report.restart_required)
        self.assertFalse(report.applied)

    def test_model_change_is_reported_as_restart_required_and_not_applied(self):
        rt = self.build()
        report = rt.check_reload(env(SANOUR_OPENAI_MODEL_ID="gpt-other-1033"))
        self.assertIn("providers.model_id", report.changed)
        self.assertTrue(report.restart_required)
        self.assertFalse(report.applied)
        self.assertNotIn("gpt-other-1033", repr(report))
        self.assertEqual(rt.describe()["providers"]["model_id"], MODEL)  # unchanged

    def test_key_change_is_reported_by_name_without_any_value(self):
        # Test factories never read the key value, so key changes are checked at the governance layer.
        base = governance.load_runtime_config(env())
        other = governance.load_runtime_config(env(OPENAI_API_KEY="STAGE1033-OTHER-KEY-QQ"))
        changed = base.changed_fields(other)
        self.assertIn("security.openai_api_key", changed)
        self.assertNotIn("STAGE1033-OTHER-KEY-QQ", repr(changed))
        self.assertNotIn(SECRET, repr(changed))

    def test_invalid_candidate_is_refused_and_the_running_runtime_is_untouched(self):
        rt = self.build()
        before = rt.describe()
        with self.assertRaises(ConfigError):
            rt.check_reload(env(SANOUR_OPENAI_MAX_CONTEXT_TOKENS="0"))
        self.assertEqual(rt.describe(), before)
        self.assertEqual(rt.state, RuntimeState.READY)

    def test_a_changed_model_is_never_switched_live(self):
        rt = self.build()
        rt.check_reload(env(SANOUR_OPENAI_MODEL_ID="gpt-other-1033"))
        resp = rt.handle({"profile_alias": "openai_primary", "prompt": "hi"})
        self.assertEqual(resp.status, "success")
        self.assertEqual(FakeOpenAI.calls, [MODEL])  # the running model, not the candidate

    def test_a_changed_provider_is_never_switched_live(self):
        rt = self.build()
        with self.assertRaises(ConfigError):
            rt.check_reload(env(SANOUR_PROVIDER="anthropic"))
        self.assertEqual(rt.describe()["providers"]["selected"], "openai")


# ---------------------------------------------------------------- shutdown, deadline, invariants
class ShutdownAndInvariantTests(Base):
    def test_shutdown_moves_the_runtime_and_the_provider_together(self):
        rt = self.build()
        states = rt.shutdown(0.1)
        self.assertEqual(states, {"openai": "closed"})
        self.assertEqual(rt.state, RuntimeState.SHUTDOWN)
        self.assertEqual(rt._core.coordinator_stats().provider_states, {"openai": "closed"})  # noqa: SLF001

    def test_requests_are_refused_after_shutdown(self):
        rt = self.build()
        rt.shutdown(0.1)
        resp = rt.handle({"profile_alias": "openai_primary", "prompt": "hi"})
        self.assertEqual(resp.status, "error")
        self.assertEqual(FakeOpenAI.calls, [])

    def test_runtime_describes_the_xai_responses_adapter_as_not_active(self):
        rt = self.build()
        self.assertEqual(set(rt._registry.states()), {"openai"})  # noqa: SLF001

    def test_timeout_default_and_maximum_come_from_one_place(self):
        from sanour_ai.models import requests as req_mod
        view = self.build().describe()["deadlines"]
        self.assertEqual(view["default_request_timeout_seconds"], req_mod.DEFAULT_TIMEOUT_SECONDS)
        self.assertEqual(view["max_request_timeout_seconds"], req_mod.MAX_TIMEOUT_SECONDS)

    def test_governance_is_the_only_parser_of_the_provider_settings(self):
        import pathlib
        src = pathlib.Path("src/sanour_ai/composition/production.py").read_text(encoding="utf-8")
        self.assertNotIn("os.environ", src)
        self.assertNotIn("env.get(", src)
        self.assertIn("load_runtime_config", src)

    def test_the_same_validated_config_yields_the_same_fingerprint(self):
        a = governance.load_runtime_config(env())
        b = governance.load_runtime_config(env())
        self.assertEqual(a.fingerprint(), b.fingerprint())
        self.assertEqual(a.changed_fields(b), ())


if __name__ == "__main__":
    unittest.main()
