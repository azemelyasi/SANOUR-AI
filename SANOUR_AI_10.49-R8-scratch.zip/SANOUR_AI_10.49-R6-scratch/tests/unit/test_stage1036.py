"""Stage 10.36 tests: explicit routing, request identity chain, identity validation, audit.

Fake adapters only. No SDK, no network, no real key. Waits are bounded.
"""

import dataclasses
import logging
import pathlib
import re
import time
import unittest
from unittest import mock

from sanour_ai.core.sanour_core import SanourCore
from sanour_ai.errors import ErrorCode, SanourError
from sanour_ai.models.base import ModelResult, ProviderError
from sanour_ai.models.capabilities import ModelCapabilities, ModelProfile, ProviderCapabilities
from sanour_ai.models.gateway import ModelGateway
from sanour_ai.models.request_identity import RequestIdentity
from sanour_ai.models.router import DeterministicRouter, RoutingRefusal
from sanour_ai.observability.audit import AuditLogger
from sanour_ai.providers.contract import ProviderIdentity

SRC = pathlib.Path(__file__).resolve().parents[2] / "src" / "sanour_ai"
SECRET = "STAGE1036-SECRET-KEY-QP"  # fake, test-only
PROMPT = "STAGE1036-PROMPT-TEXT-ZQ"  # fake prompt marker, must never reach a log
REPORTED = "STAGE1036-REPORTED-ID-RX"  # fake provider id, must never reach a log
TEXT = ProviderCapabilities(text_generation=True)


_UNSET = object()  # "no reported value given": echo the requested id; anything else is sent as is


class FakeProvider:
    """Counts calls. The behaviour is set per test. Declares its full identity like a real adapter."""

    def __init__(self, name, surface="openai_responses", vendor="openai", reported=_UNSET, error=None):
        self.name = name
        self.vendor = vendor
        self.surface = surface
        self.auth_method = "bearer_header"
        self.capabilities = TEXT
        self.calls = 0
        self._reported = reported
        self._error = error

    def generate(self, call):
        self.calls += 1
        if self._error is not None:
            raise self._error
        reported = call.model_id if self._reported is _UNSET else self._reported
        return ModelResult(text="answer", reported_model_id=reported)


def profile(alias, provider="p1", model="model-1036", surface="openai_responses", **extra):
    return ModelProfile(
        alias=alias,
        provider=provider,
        model_id=model,
        capabilities=ModelCapabilities(text_generation=True, max_context_tokens=8192, max_output_tokens=1024),
        runs_locally=False,
        api_surface=surface,
        **extra,
    )


def raw(alias="a_1036", **extra):
    body = {"profile_alias": alias, "prompt": PROMPT, "timeout_seconds": 5}
    body.update(extra)
    return body


class AuditCapture(logging.Handler):
    def __init__(self):
        super().__init__(level=logging.DEBUG)
        self.lines = []

    def emit(self, record):
        self.lines.append(record.getMessage())

    @property
    def text(self):
        return "\n".join(self.lines)

    def events(self, name):
        return [line for line in self.lines if line.startswith(name + " ")]


class CoreTestCase(unittest.TestCase):
    def core(self, providers, profiles, disabled=()):
        logger = logging.getLogger("sanour_ai.audit")
        capture = AuditCapture()
        logger.addHandler(capture)
        self.addCleanup(logger.removeHandler, capture)
        gateway = ModelGateway({p.name: p for p in providers}, max_concurrent_calls=2)
        core = SanourCore(router=DeterministicRouter(profiles, disabled_aliases=disabled), gateway=gateway,
                          audit=AuditLogger())
        self.addCleanup(gateway.shutdown, 0.1)
        return core, capture


# ---------------------------------------------------------------- 1. explicit alias, no auto-select
class ExplicitRoutingTests(CoreTestCase):
    def test_request_without_profile_alias_is_rejected(self):
        core, _ = self.core([FakeProvider("p1")], [profile("a_1036")])
        body = raw()
        del body["profile_alias"]
        resp = core.handle(body)
        self.assertEqual(resp.status, "error")
        self.assertEqual(resp.error.code, ErrorCode.INVALID_REQUEST)

    def test_empty_or_malformed_alias_is_rejected_before_routing(self):
        core, _ = self.core([FakeProvider("p1")], [profile("a_1036")])
        for bad in ("", "   ", "BAD ALIAS", "x"):
            with self.subTest(alias=bad):
                self.assertEqual(core.handle(raw(bad)).error.code, ErrorCode.INVALID_REQUEST)

    def test_unknown_alias_is_refused_and_no_provider_is_called(self):
        p = FakeProvider("p1")
        core, capture = self.core([p], [profile("a_1036")])
        resp = core.handle(raw("z_1036"))
        self.assertEqual(resp.error.code, ErrorCode.NO_ELIGIBLE_MODEL)
        self.assertEqual(p.calls, 0)
        self.assertIn('"reason": "unknown_profile"', capture.text)

    def test_disabled_profile_is_refused_and_logged_with_its_reason(self):
        p = FakeProvider("p1")
        core, capture = self.core([p], [profile("a_1036"), profile("b_1036")], disabled=("b_1036",))
        resp = core.handle(raw("b_1036"))
        self.assertEqual(resp.error.code, ErrorCode.NO_ELIGIBLE_MODEL)
        self.assertEqual(p.calls, 0)
        self.assertIn('"reason": "disabled_profile"', capture.text)

    def test_several_profiles_never_cause_automatic_selection(self):
        a = FakeProvider("p1")
        core, _ = self.core([a], [profile("a_1036", priority=1), profile("b_1036", priority=99)])
        self.assertEqual(core.handle(raw("b_1036")).model_alias, "b_1036")
        self.assertEqual(core.handle(raw("a_1036")).model_alias, "a_1036")

    def test_registration_order_does_not_change_routing(self):
        p = FakeProvider("p1")
        first, _ = self.core([p], [profile("a_1036"), profile("b_1036")])
        second, _ = self.core([p], [profile("b_1036"), profile("a_1036")])
        self.assertEqual(first.handle(raw("b_1036")).model_alias, second.handle(raw("b_1036")).model_alias)

    def test_the_automatic_selection_api_is_gone(self):
        self.assertFalse(hasattr(DeterministicRouter, "select"))
        self.assertFalse(hasattr(DeterministicRouter, "select_default"))

    def test_no_production_source_mentions_select_or_default_profiles(self):
        for path in list((SRC / "core").rglob("*.py")) + list((SRC / "composition").rglob("*.py")) + [
            SRC / "models" / "router.py", SRC / "models" / "gateway.py", SRC / "models" / "request_identity.py",
        ]:
            text = path.read_text(encoding="utf-8")
            with self.subTest(file=path.name):
                self.assertNotIn(".select(", text)
                self.assertNotIn("default_profile", text)
                self.assertNotIn("fallback", text.lower().replace("no fallback", "").replace("fallback.", ""))

    def test_refusal_reason_is_logged_as_a_fixed_word_and_never_the_alias(self):
        core, capture = self.core([FakeProvider("p1")], [profile("a_1036")])
        core.handle(raw("secret_alias_9"))
        events = capture.events("routing.auto_select_blocked")
        self.assertEqual(len(events), 1)
        self.assertNotIn("secret_alias_9", events[0])


# ---------------------------------------------------------------- 2. no fallback, no retry
class NoFallbackNoRetryTests(CoreTestCase):
    def test_provider_failure_is_one_attempt_and_no_other_profile_is_tried(self):
        bad = FakeProvider("p1", error=ProviderError("boom", retryable=True))
        good = FakeProvider("p2")
        core, _ = self.core([bad, good], [profile("a_1036", provider="p1"), profile("b_1036", provider="p2")])
        resp = core.handle(raw("a_1036"))
        self.assertEqual(resp.status, "error")
        self.assertEqual(bad.calls, 1)  # one attempt, no retry
        self.assertEqual(good.calls, 0)  # no other provider is tried

    def test_identity_failure_triggers_no_retry_and_no_other_model(self):
        wrong = FakeProvider("p1", reported="someone-else-1036")
        other = FakeProvider("p2")
        core, _ = self.core([wrong, other], [profile("a_1036", provider="p1"), profile("b_1036", provider="p2")])
        resp = core.handle(raw("a_1036"))
        self.assertEqual(resp.error.code, ErrorCode.PROVIDER_INVALID_RESPONSE)
        self.assertEqual(wrong.calls, 1)
        self.assertEqual(other.calls, 0)


# ---------------------------------------------------------------- 3. identity chain
class IdentityChainTests(CoreTestCase):
    def test_identity_is_created_once_per_request_with_the_profile_fields(self):
        core, capture = self.core([FakeProvider("p1")], [profile("a_1036", surface="openai_responses")])
        core.handle(raw("a_1036"))
        created = capture.events("request.identity.created")
        self.assertEqual(len(created), 1)
        self.assertIn('"api_surface": "openai_responses"', created[0])
        self.assertIn('"provider": "p1"', created[0])
        self.assertIn('"model_alias": "a_1036"', created[0])
        self.assertEqual(len(capture.events("request.profile.resolved")), 1)

    def test_reported_model_equal_to_requested_is_validated(self):
        core, capture = self.core([FakeProvider("p1")], [profile("a_1036")])
        self.assertEqual(core.handle(raw("a_1036")).status, "success")
        self.assertEqual(len(capture.events("model.identity.validated")), 1)

    def test_reported_model_in_the_profiles_exact_allowlist_is_accepted(self):
        snap = "model-1036-2026-01-01"
        p = FakeProvider("p1", reported=snap)
        core, _ = self.core([p], [profile("a_1036", accepted_reported_model_ids=frozenset({snap}))])
        self.assertEqual(core.handle(raw("a_1036")).status, "success")

    def test_unknown_reported_model_is_refused_and_not_shown_to_the_caller(self):
        core, capture = self.core([FakeProvider("p1", reported=REPORTED)], [profile("a_1036")])
        resp = core.handle(raw("a_1036"))
        self.assertEqual(resp.error.code, ErrorCode.PROVIDER_INVALID_RESPONSE)
        self.assertNotIn(REPORTED, repr(resp.model_dump()))
        self.assertEqual(len(capture.events("model.identity.mismatch")), 1)

    def test_empty_or_missing_reported_model_fails_closed(self):
        for value in ("", None):
            with self.subTest(value=value):
                core, _ = self.core([FakeProvider("p1", reported=value)], [profile("a_1036")])
                self.assertEqual(core.handle(raw("a_1036")).status, "error")

    def test_one_profiles_allowlist_does_not_leak_into_another_profile(self):
        snap = "model-1036-2026-02-02"
        shared = FakeProvider("p1", reported=snap)
        core, _ = self.core([shared], [
            profile("a_1036", accepted_reported_model_ids=frozenset({snap})),
            profile("b_1036"),
        ])
        self.assertEqual(core.handle(raw("a_1036")).status, "success")
        self.assertEqual(core.handle(raw("b_1036")).error.code, ErrorCode.PROVIDER_INVALID_RESPONSE)

    def test_wildcards_are_refused_in_the_allowlist(self):
        from sanour_ai.models.capabilities import AllowlistConfigError
        for bad in ("model-*", "*", "model-1036.*", "model-?"):
            with self.subTest(bad=bad):
                with self.assertRaises(AllowlistConfigError):
                    profile("a_1036", accepted_reported_model_ids=frozenset({bad}))

    def test_provider_reported_value_is_never_logged(self):
        core, capture = self.core([FakeProvider("p1", reported=REPORTED)], [profile("a_1036")])
        core.handle(raw("a_1036"))
        self.assertNotIn(REPORTED, capture.text)

    def test_prompt_and_secret_never_appear_in_any_log_line(self):
        p = FakeProvider("p1", error=ProviderError("upstream said " + SECRET, retryable=False))
        core, capture = self.core([p], [profile("a_1036")])
        resp = core.handle(raw("a_1036"))
        self.assertEqual(resp.status, "error")
        self.assertNotIn(SECRET, capture.text)
        self.assertNotIn(PROMPT, capture.text)
        self.assertNotIn(SECRET, repr(resp.model_dump()))
        self.assertNotIn(PROMPT, repr(resp.model_dump()))


# ---------------------------------------------------------------- 4. RequestIdentity object
class RequestIdentityTests(unittest.TestCase):
    def test_identity_is_frozen_and_cannot_be_changed_midway(self):
        ident = RequestIdentity.for_profile("r" * 32, profile("a_1036"))
        with self.assertRaises(dataclasses.FrozenInstanceError):
            ident.profile_id = "other"  # type: ignore[misc]
        with self.assertRaises(dataclasses.FrozenInstanceError):
            ident.requested_model_id = "other"  # type: ignore[misc]

    def test_identity_holds_no_deadline_key_prompt_or_response(self):
        ident = RequestIdentity.for_profile("r" * 32, profile("a_1036"))
        names = {f.name for f in dataclasses.fields(ident)}
        self.assertEqual(names, {"request_id", "profile_id", "provider_id", "api_surface",
                                 "requested_model_id", "accepted_reported_model_ids"})

    def test_identity_allowlist_is_a_frozenset_copy(self):
        ident = RequestIdentity.for_profile("r" * 32, profile("a_1036", accepted_reported_model_ids=frozenset({"x-1"})))
        self.assertIsInstance(ident.accepted_reported_model_ids, frozenset)
        self.assertTrue(ident.accepts_reported("x-1"))
        self.assertFalse(ident.accepts_reported("x-2"))
        self.assertFalse(ident.accepts_reported(None))
        self.assertFalse(ident.accepts_reported(""))

    def test_log_fields_never_include_a_reported_value(self):
        ident = RequestIdentity.for_profile("r" * 32, profile("a_1036"))
        self.assertNotIn("reported", " ".join(ident.log_fields().keys()))
        self.assertEqual(set(ident.log_fields()), {"request_id", "model_alias", "provider", "api_surface"})

    def test_identity_created_for_one_profile_is_refused_by_the_gateway_for_another(self):
        p = FakeProvider("p1")
        gateway = ModelGateway({"p1": p}, max_concurrent_calls=1)
        a, b = profile("a_1036"), profile("b_1036")
        wrong = RequestIdentity.for_profile("r" * 32, a)
        from sanour_ai.models.base import ModelCall
        call = ModelCall(model_id=b.model_id, prompt="x", max_output_tokens=8, deadline=time.monotonic() + 5)
        with self.assertRaises(SanourError) as ctx:
            gateway.generate(b, call, time.monotonic() + 5, identity=wrong)
        self.assertEqual(ctx.exception.code, ErrorCode.NO_ELIGIBLE_MODEL)
        self.assertEqual(p.calls, 0)  # refused before any call
        gateway.shutdown(0.1)

    def test_identity_for_a_different_provider_is_refused_before_any_call(self):
        p = FakeProvider("p1")
        gateway = ModelGateway({"p1": p}, max_concurrent_calls=1)
        prof = profile("a_1036")
        ident = dataclasses.replace(RequestIdentity.for_profile("r" * 32, prof), provider_id="p9")
        from sanour_ai.models.base import ModelCall
        call = ModelCall(model_id=prof.model_id, prompt="x", max_output_tokens=8, deadline=time.monotonic() + 5)
        with self.assertRaises(SanourError):
            gateway.generate(prof, call, time.monotonic() + 5, identity=ident)
        self.assertEqual(p.calls, 0)
        gateway.shutdown(0.1)


# ---------------------------------------------------------------- 5. surface and provider compatibility
class CompatibilityTests(CoreTestCase):
    def test_api_surface_mismatch_is_refused_before_any_call(self):
        p = FakeProvider("p1", surface="openai_responses")
        core, capture = self.core([p], [profile("a_1036", surface="grok_responses")])
        resp = core.handle(raw("a_1036"))
        self.assertEqual(resp.error.code, ErrorCode.NO_ELIGIBLE_MODEL)
        self.assertEqual(p.calls, 0)
        self.assertIn('"reason": "identity_conflict"', capture.text)

    def test_provider_that_speaks_another_surface_is_refused(self):
        p = FakeProvider("p1", surface="grok_responses", vendor="xai")
        core, _ = self.core([p], [profile("a_1036", surface="openai_responses")])
        self.assertEqual(core.handle(raw("a_1036")).error.code, ErrorCode.NO_ELIGIBLE_MODEL)
        self.assertEqual(p.calls, 0)

    def test_provider_identity_contract_is_still_enforced_by_the_registry(self):
        self.assertEqual(ProviderIdentity("p1", "openai", "openai_responses", "bearer_header").provider_id, "p1")


# ---------------------------------------------------------------- 6. deadline, capacity, lifecycle
class PreservedBehaviourTests(CoreTestCase):
    def test_one_deadline_is_passed_through_and_identity_carries_none(self):
        seen = []
        p = FakeProvider("p1")
        gateway = ModelGateway({"p1": p}, max_concurrent_calls=2)
        real = gateway.generate

        def spy(profile_, call, deadline, observer=None, identity=None):
            seen.append((call.deadline, deadline))
            self.assertFalse(hasattr(identity, "deadline"))
            return real(profile_, call, deadline, observer=observer, identity=identity)

        gateway.generate = spy
        core = SanourCore(router=DeterministicRouter([profile("a_1036")]), gateway=gateway, audit=AuditLogger())
        core.handle(raw("a_1036", timeout_seconds=3.0))
        self.assertEqual(len(seen), 1)
        self.assertEqual(seen[0][0], seen[0][1])
        gateway.shutdown(0.1)

    def test_shutdown_still_refuses_requests(self):
        p = FakeProvider("p1")
        core, _ = self.core([p], [profile("a_1036")])
        core._gateway.shutdown(0.1)  # noqa: SLF001
        self.assertEqual(core.handle(raw("a_1036")).status, "error")
        self.assertEqual(p.calls, 0)

    def test_catalog_change_after_registration_does_not_reach_a_request(self):
        from sanour_ai.models.model_catalog import ModelCatalog, blank_capabilities, build_model_record
        from sanour_ai.models.profile_management import (
            ProfileRecord,
            ProfileRegistry,
            ProviderBinding,
            RequestLimits,
            TimeoutPolicy,
        )
        catalog = ModelCatalog([build_model_record(
            model_id="model-1036", provider_id="p1", vendor="openai", api_surface="openai_responses",
            display_name="x", capabilities=blank_capabilities(), lifecycle_status="active",
            source="operator_configuration")])
        registry = ProfileRegistry(catalog)
        binding = ProviderBinding("p1", "openai_responses", TEXT)
        registry.register_profile(ProfileRecord(
            profile_id="a_1036", provider_id="p1", model_id="model-1036", api_surface="openai_responses",
            request_limits=RequestLimits(max_output_tokens=64, max_context_tokens=512),
            timeout_policy=TimeoutPolicy(default_seconds=5, max_seconds=60)), binding)
        catalog.deactivate_model("p1", "model-1036", authorized=True, reason="retired")
        from sanour_ai.models.profile_management import ProfileError
        with self.assertRaises(ProfileError):
            registry.model_profile("a_1036", binding)  # the removed model cannot serve a request


# ---------------------------------------------------------------- 7. identity conflict audit path
class ConflictAuditTests(CoreTestCase):
    def test_coordinator_identity_conflict_is_audited_and_refused(self):
        p = FakeProvider("p1")
        core, capture = self.core([p], [profile("a_1036")])
        other = profile("z_1036")
        with mock.patch("sanour_ai.core.coordinator.RequestIdentity.for_profile",
                        return_value=RequestIdentity.for_profile("r" * 32, other)):
            resp = core.handle(raw("a_1036"))
        self.assertEqual(resp.error.code, ErrorCode.NO_ELIGIBLE_MODEL)
        self.assertEqual(p.calls, 0)
        self.assertEqual(len(capture.events("request.identity.rejected")), 1)


if __name__ == "__main__":
    unittest.main()
