"""Stage 10.37 integration tests: the full request path with real adapters and fake transports.

No SDK, no network, no real key. Waits are bounded. The deadline uses the real monotonic clock with
short budgets, because the gateway waits on real threads.
"""

import dataclasses
import json
import logging
import threading
import time
import unittest

from pydantic import SecretStr

from sanour_ai.core.sanour_core import SanourCore
from sanour_ai.errors import ErrorCode, FailureKind, SanourError
from sanour_ai.models.capabilities import ModelCapabilities, ModelProfile, ProviderCapabilities
from sanour_ai.models.error_taxonomy import _KIND_TO_INTERNAL, InternalErrorKind, classify
from sanour_ai.models.execution import ExecutionResult, ExecutionStage
from sanour_ai.models.gateway import ModelGateway
from sanour_ai.models.router import DeterministicRouter
from sanour_ai.observability.audit import AuditLogger
from sanour_ai.providers import common
from sanour_ai.providers.anthropic_provider import AnthropicProvider
from sanour_ai.providers.common import HttpResult
from sanour_ai.providers.gemini_provider import GeminiProvider
from sanour_ai.providers.registry import ProviderRegistry

SECRET = "STAGE1037-INT-SECRET-PQ"  # fake, test-only
PROMPT = "STAGE1037-INT-PROMPT-WX"
MODEL = "int-model-1037"
SUCCESS = {"stop_reason": "end_turn", "content": [{"type": "text", "text": "hello"}], "model": MODEL}


class Transport:
    def __init__(self, status=200, body=None, headers=None, raise_exc=None, block=None, sleep=0.0):
        self.status = status
        self.body = json.dumps(SUCCESS).encode() if body is None else body
        self.headers = headers or {}
        self.raise_exc, self.block, self.sleep = raise_exc, block, sleep
        self.count = 0

    def __call__(self, url, headers, body, timeout):
        self.count += 1
        if self.block is not None:
            self.block.wait(5.0)
        if self.sleep:
            time.sleep(self.sleep)
        if self.raise_exc is not None:
            raise self.raise_exc
        return HttpResult(self.status, self.body, self.headers)


class Capture(logging.Handler):
    def __init__(self):
        super().__init__(level=logging.DEBUG)
        self.lines = []

    def emit(self, record):
        self.lines.append(record.getMessage())

    @property
    def text(self):
        return "\n".join(self.lines)


def anth_profile(alias="ant_1037", model=MODEL, **caps):
    base = dict(text_generation=True, max_context_tokens=8192, max_output_tokens=1024)
    base.update(caps)
    return ModelProfile(alias=alias, provider="anthropic", model_id=model,
                        capabilities=ModelCapabilities(**base), runs_locally=False,
                        api_surface="anthropic_messages")


def build(transport, profiles=None, max_calls=2, adapter_cls=AnthropicProvider, provider="anthropic"):
    adapter = adapter_cls(SecretStr(SECRET), transport=transport)
    gateway = ModelGateway({provider: adapter}, max_concurrent_calls=max_calls)
    core = SanourCore(router=DeterministicRouter(profiles or [anth_profile()]), gateway=gateway,
                      audit=AuditLogger())
    capture = Capture()
    logging.getLogger("sanour_ai.audit").addHandler(capture)
    return core, gateway, adapter, capture


class IntegrationBase(unittest.TestCase):
    def setUp(self):
        self._handlers = []

    def tearDown(self):
        for gw in self._handlers:
            gw.shutdown(0.1)
        logging.getLogger("sanour_ai.audit").handlers = [
            h for h in logging.getLogger("sanour_ai.audit").handlers if not isinstance(h, Capture)]

    def start(self, transport, **kwargs):
        core, gateway, adapter, capture = build(transport, **kwargs)
        self._handlers.append(gateway)
        return core, gateway, capture

    def raw(self, alias="ant_1037", **extra):
        body = {"profile_alias": alias, "prompt": PROMPT, "timeout_seconds": 5}
        body.update(extra)
        return body


# ---------------------------------------------------------------- 1. full round trip
class RoundTripTests(IntegrationBase):
    def test_valid_request_travels_from_core_to_fake_provider_and_back(self):
        t = Transport()
        core, _gw, capture = self.start(t)
        response, result = core.handle_with_result(self.raw())
        self.assertEqual(response.status, "success")
        self.assertEqual(response.output, "hello")
        self.assertIsInstance(result, ExecutionResult)
        self.assertEqual(result.output, "hello")
        self.assertEqual(t.count, 1)
        self.assertIn("model.identity.validated", capture.text)

    def test_result_keeps_requested_and_reported_identity_separate(self):
        core, _gw, _c = self.start(Transport())
        _resp, result = core.handle_with_result(self.raw())
        self.assertEqual(result.requested_model_id, MODEL)
        self.assertEqual(result.provider_reported_model_id, MODEL)
        self.assertEqual(result.provider_id, "anthropic")
        self.assertEqual(result.api_surface, "anthropic_messages")
        self.assertEqual(result.profile_id, "ant_1037")

    def test_usage_is_none_and_never_zero_when_not_reported(self):
        core, _gw, _c = self.start(Transport())
        _resp, result = core.handle_with_result(self.raw())
        self.assertIsNone(result.usage)

    def test_verification_status_is_never_verified(self):
        core, _gw, _c = self.start(Transport())
        _resp, result = core.handle_with_result(self.raw())
        self.assertEqual(result.verification_status, "implemented_unverified")
        with self.assertRaises(ValueError):
            ExecutionResult(request_id="r" * 32, profile_id="p", provider_id="p", api_surface=None,
                            requested_model_id="m", provider_reported_model_id="m", output="x",
                            finish_status="completed", execution_ms=1, verification_status="verified")

    def test_result_is_immutable(self):
        core, _gw, _c = self.start(Transport())
        _resp, result = core.handle_with_result(self.raw())
        with self.assertRaises(dataclasses.FrozenInstanceError):
            result.output = "changed"  # type: ignore[misc]

    def test_result_never_contains_the_key_or_the_prompt(self):
        core, _gw, _c = self.start(Transport())
        _resp, result = core.handle_with_result(self.raw())
        blob = repr(result)
        self.assertNotIn(SECRET, blob)
        self.assertNotIn(PROMPT, blob)

    def test_execute_still_returns_only_the_public_response(self):
        core, _gw, _c = self.start(Transport())
        self.assertEqual(core.handle(self.raw()).status, "success")

    def test_stage_list_is_the_documented_fifteen_in_order(self):
        names = [s.value for s in ExecutionStage]
        self.assertEqual(len(names), 15)
        self.assertEqual(names[0], "request_received")
        self.assertEqual(names[-1], "request_completion")


# ---------------------------------------------------------------- 2. refusals before provider I/O
class RefusalBeforeIoTests(IntegrationBase):
    def test_unknown_alias_makes_no_provider_io(self):
        t = Transport()
        core, _gw, _c = self.start(t)
        self.assertEqual(core.handle(self.raw("nope_1037")).error.code, ErrorCode.NO_ELIGIBLE_MODEL)
        self.assertEqual(t.count, 0)

    def test_missing_alias_makes_no_provider_io(self):
        t = Transport()
        core, _gw, _c = self.start(t)
        body = self.raw()
        del body["profile_alias"]
        self.assertEqual(core.handle(body).error.code, ErrorCode.INVALID_REQUEST)
        self.assertEqual(t.count, 0)

    def test_incompatible_capability_makes_no_provider_io(self):
        t = Transport()
        core, _gw, _c = self.start(t)
        resp = core.handle(self.raw(required_capabilities=["image_input"]))
        self.assertEqual(resp.error.code, ErrorCode.NO_ELIGIBLE_MODEL)
        self.assertEqual(t.count, 0)

    def test_invalid_identity_makes_no_provider_io(self):
        t = Transport()
        adapter = AnthropicProvider(SecretStr(SECRET), transport=t)
        gateway = ModelGateway({"anthropic": adapter}, max_concurrent_calls=1)
        self._handlers.append(gateway)
        from sanour_ai.models.base import ModelCall
        from sanour_ai.models.request_identity import RequestIdentity
        prof = anth_profile()
        other = anth_profile("other_1037")
        call = ModelCall(model_id=prof.model_id, prompt=PROMPT, max_output_tokens=8,
                         deadline=time.monotonic() + 5)
        with self.assertRaises(SanourError):
            gateway.generate(prof, call, time.monotonic() + 5,
                             identity=RequestIdentity.for_profile("r" * 32, other))
        self.assertEqual(t.count, 0)

    def test_deadline_already_passed_makes_no_provider_io(self):
        t = Transport()
        adapter = AnthropicProvider(SecretStr(SECRET), transport=t)
        gateway = ModelGateway({"anthropic": adapter}, max_concurrent_calls=1)
        self._handlers.append(gateway)
        from sanour_ai.models.base import ModelCall
        from sanour_ai.models.request_identity import RequestIdentity
        prof = anth_profile()
        call = ModelCall(model_id=prof.model_id, prompt=PROMPT, max_output_tokens=8,
                         deadline=time.monotonic() - 1)
        with self.assertRaises(SanourError) as ctx:
            gateway.generate(prof, call, time.monotonic() - 1,
                             identity=RequestIdentity.for_profile("r" * 32, prof))
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_TIMEOUT)
        self.assertEqual(t.count, 0)


# ---------------------------------------------------------------- 3. capacity and deadlines during execution
class CapacityAndDeadlineTests(IntegrationBase):
    def test_full_capacity_rejects_a_new_request_without_io(self):
        release = threading.Event()
        t = Transport(block=release)
        core, gw, _c = self.start(t, max_calls=1)
        first = core.handle(self.raw(timeout_seconds=0.05))
        self.assertEqual(first.error.code, ErrorCode.PROVIDER_TIMEOUT)
        second = core.handle(self.raw())
        self.assertEqual(second.error.code, ErrorCode.PROVIDER_OVERLOADED)
        self.assertEqual(t.count, 1)  # the second request never reached the provider
        release.set()

    def test_deadline_during_execution_returns_timeout_and_keeps_capacity_until_worker_ends(self):
        t = Transport(sleep=0.3)
        core, gw, _c = self.start(t, max_calls=1)
        started = time.monotonic()
        resp = core.handle(self.raw(timeout_seconds=0.05))
        elapsed = time.monotonic() - started
        self.assertEqual(resp.error.code, ErrorCode.PROVIDER_TIMEOUT)
        self.assertLess(elapsed, 0.25)  # the caller returns near the deadline
        self.assertEqual(gw.in_flight, 1)  # the thread is still running and holds its slot
        deadline = time.monotonic() + 3.0
        while gw.in_flight and time.monotonic() < deadline:
            time.sleep(0.01)
        self.assertEqual(gw.in_flight, 0)

    def test_one_deadline_is_used_for_the_whole_request(self):
        t = Transport()
        core, gw, _c = self.start(t)
        seen = []
        real = gw.generate

        def spy(profile_, call_, deadline, observer=None, identity=None):
            seen.append((call_.deadline, deadline))
            return real(profile_, call_, deadline, observer=observer, identity=identity)

        gw.generate = spy
        core.handle(self.raw(timeout_seconds=4.0))
        self.assertEqual(len(seen), 1)
        self.assertEqual(seen[0][0], seen[0][1])


# ---------------------------------------------------------------- 4. provider outcomes
class ProviderOutcomeTests(IntegrationBase):
    def outcome(self, transport, **kwargs):
        core, gw, capture = self.start(transport, **kwargs)
        response, result = core.handle_with_result(self.raw())
        return response, result, transport, capture

    def test_complete_response_succeeds(self):
        resp, result, _t, _c = self.outcome(Transport())
        self.assertEqual(resp.status, "success")
        self.assertIsNotNone(result)

    def test_incomplete_response_is_refused_not_succeeded(self):
        body = json.dumps({"stop_reason": "max_tokens", "content": [{"type": "text", "text": "x"}],
                           "model": MODEL}).encode()
        resp, result, _t, capture = self.outcome(Transport(body=body))
        self.assertEqual(resp.error.code, ErrorCode.PROVIDER_INVALID_RESPONSE)
        self.assertIsNone(result)
        self.assertIn("provider_incomplete_response", capture.text)

    def test_reported_model_mismatch_is_refused(self):
        body = json.dumps({"stop_reason": "end_turn", "content": [{"type": "text", "text": "x"}],
                           "model": "someone-else-1037"}).encode()
        resp, result, _t, capture = self.outcome(Transport(body=body))
        self.assertEqual(resp.error.code, ErrorCode.PROVIDER_INVALID_RESPONSE)
        self.assertIsNone(result)
        self.assertNotIn("someone-else-1037", capture.text)
        self.assertNotIn("someone-else-1037", repr(resp.model_dump()))

    def test_rate_limit_is_classified_and_not_retried(self):
        body = json.dumps({"type": "error", "error": {"type": "rate_limit_error"}}).encode()
        resp, _r, t, capture = self.outcome(Transport(status=429, body=body, headers={"retry-after": "5"}))
        self.assertEqual(resp.error.code, ErrorCode.PROVIDER_RATE_LIMITED)
        self.assertTrue(resp.error.retryable)
        self.assertEqual(t.count, 1)
        self.assertIn("provider_rate_limit", capture.text)

    def test_quota_or_billing_is_not_mistaken_for_rate_limit(self):
        body = json.dumps({"error": {"details": {"error_code": "enforced_spend_limit_reached"}}}).encode()
        resp, _r, t, capture = self.outcome(Transport(status=429, body=body))
        self.assertEqual(resp.error.code, ErrorCode.PROVIDER_FAILED)
        self.assertFalse(resp.error.retryable)
        self.assertEqual(t.count, 1)
        self.assertIn("provider_quota", capture.text)

    def test_content_block_is_its_own_code_not_a_technical_failure(self):
        body = json.dumps({"promptFeedback": {"blockReason": "SAFETY"}}).encode()
        core, gw, capture = self.start(Transport(body=body), adapter_cls=GeminiProvider, provider="gemini",
                                       profiles=[ModelProfile(alias="gem_1037", provider="gemini", model_id=MODEL,
                                                              capabilities=ModelCapabilities(
                                                                  text_generation=True, max_context_tokens=8192,
                                                                  max_output_tokens=1024),
                                                              runs_locally=False,
                                                              api_surface="gemini_generate_content")])
        resp = core.handle(self.raw("gem_1037"))
        self.assertEqual(resp.error.code, ErrorCode.PROVIDER_CONTENT_BLOCKED)
        self.assertIn("provider_content_blocked", capture.text)

    def test_invalid_response_is_refused(self):
        resp, result, _t, _c = self.outcome(Transport(body=b"not json"))
        self.assertEqual(resp.error.code, ErrorCode.PROVIDER_INVALID_RESPONSE)
        self.assertIsNone(result)

    def test_transport_error_is_one_retryable_connection_failure(self):
        resp, _r, t, capture = self.outcome(Transport(raise_exc=OSError("reset " + SECRET)))
        self.assertEqual(resp.error.code, ErrorCode.PROVIDER_FAILED)
        self.assertTrue(resp.error.retryable)
        self.assertEqual(t.count, 1)
        self.assertIn("provider_transport", capture.text)
        self.assertNotIn(SECRET, repr(resp.model_dump()))
        self.assertNotIn(SECRET, capture.text)

    def test_authentication_failure_is_classified_without_the_key(self):
        body = ("denied " + SECRET).encode()
        resp, _r, t, capture = self.outcome(Transport(status=401, body=body))
        self.assertEqual(resp.error.code, ErrorCode.PROVIDER_FAILED)
        self.assertFalse(resp.error.retryable)
        self.assertIn("provider_authentication", capture.text)
        self.assertNotIn(SECRET, capture.text)
        self.assertNotIn(SECRET, repr(resp.model_dump()))


# ---------------------------------------------------------------- 5. shutdown and lifecycle
class ShutdownAndLifecycleTests(IntegrationBase):
    def test_shutdown_during_a_worker_does_not_close_the_provider_early(self):
        release = threading.Event()
        t = Transport(block=release)
        core, gw, _c = self.start(t, max_calls=1)
        core.handle(self.raw(timeout_seconds=0.05))
        self.assertEqual(gw.shutdown(0.05), 1)  # still running: reported, not forced
        self.assertEqual(gw.provider_state("anthropic"), "open")
        release.set()
        deadline = time.monotonic() + 3.0
        while gw.in_flight and time.monotonic() < deadline:
            time.sleep(0.01)
        gw.shutdown(0.1)
        self.assertEqual(gw.provider_state("anthropic"), "closed")

    def test_one_failing_close_does_not_stop_shutdown_of_other_providers(self):
        log = []

        class Failing(AnthropicProvider):
            def close(self):
                log.append("anthropic")
                raise RuntimeError("close failed " + SECRET)

        class Fine(GeminiProvider):
            def close(self):
                log.append("gemini")

        reg = ProviderRegistry()
        reg.register("anthropic", vendor="anthropic", surface="anthropic_messages",
                     adapter=Failing(SecretStr(SECRET), transport=Transport()))
        reg.register("gemini", vendor="google", surface="gemini_generate_content",
                     adapter=Fine(SecretStr(SECRET), transport=Transport()))
        reg.initialize("anthropic")
        reg.initialize("gemini")
        gw = ModelGateway(reg.ready_providers(), max_concurrent_calls=2)
        with self.assertLogs("sanour_ai.gateway", level="WARNING") as logs:
            states = reg.shutdown(gw, 0.1)
        self.assertEqual(states, {"anthropic": "failed", "gemini": "closed"})
        self.assertEqual(sorted(log), ["anthropic", "gemini"])
        self.assertNotIn(SECRET, "\n".join(logs.output))


# ---------------------------------------------------------------- 6. no retry and no fallback in any outcome
class NoRetryNoFallbackTests(IntegrationBase):
    def test_every_failure_is_one_attempt_and_never_another_model(self):
        cases = [
            Transport(status=503, body=b"{}"),
            Transport(status=500, body=b"{}"),
            Transport(raise_exc=OSError("x")),
            Transport(body=b"nope"),
            Transport(status=429, body=b"{}"),
            Transport(status=401, body=b"{}"),
        ]
        for t in cases:
            with self.subTest(case=type(t.raise_exc).__name__ if t.raise_exc else t.status):
                core, gw, _c = self.start(t)
                core.handle(self.raw())
                self.assertEqual(t.count, 1)
                gw.shutdown(0.1)


# ---------------------------------------------------------------- 7. taxonomy
class TaxonomyTests(unittest.TestCase):
    def err(self, code, detail=None, kind=FailureKind.UNCLASSIFIED, **kw):
        return SanourError(code, "model provider failed", internal_detail=detail, internal_kind=kind, **kw)

    def test_every_public_code_maps_to_one_internal_kind(self):
        for code in ErrorCode:
            with self.subTest(code=code.value):
                self.assertIsInstance(classify(self.err(code)), InternalErrorKind)

    def test_auth_transport_and_quota_are_distinct(self):
        self.assertEqual(classify(self.err(ErrorCode.PROVIDER_FAILED, kind=FailureKind.AUTHENTICATION)),
                         InternalErrorKind.PROVIDER_AUTHENTICATION)
        self.assertEqual(classify(self.err(ErrorCode.PROVIDER_FAILED, kind=FailureKind.CONNECTION)),
                         InternalErrorKind.PROVIDER_TRANSPORT)
        self.assertEqual(classify(self.err(ErrorCode.PROVIDER_FAILED, kind=FailureKind.LIMIT_REACHED,
                                           failure_reason="billing")), InternalErrorKind.PROVIDER_QUOTA)

    def test_rate_limit_is_not_quota(self):
        self.assertEqual(classify(self.err(ErrorCode.PROVIDER_RATE_LIMITED)), InternalErrorKind.PROVIDER_RATE_LIMIT)

    def test_every_failure_kind_has_exactly_one_internal_kind(self):
        self.assertEqual(set(_KIND_TO_INTERNAL), set(FailureKind))
        for kind in FailureKind:
            with self.subTest(kind=kind.value):
                self.assertIsInstance(_KIND_TO_INTERNAL[kind], InternalErrorKind)
                self.assertEqual(classify(self.err(ErrorCode.PROVIDER_FAILED, kind=kind)),
                                 _KIND_TO_INTERNAL[kind])

    def test_every_provider_raise_site_passes_a_typed_kind(self):
        import ast
        import pathlib
        root = pathlib.Path(__file__).resolve().parents[2] / "src" / "sanour_ai" / "providers"
        names = {"ProviderError", "RateLimitedError", "IncompleteResponseError", "ContentBlockedError"}
        sites = 0
        for path in sorted(root.glob("*.py")):
            for node in ast.walk(ast.parse(path.read_text(encoding="utf-8"))):
                if isinstance(node, ast.Call) and getattr(node.func, "id", None) in names:
                    sites += 1
                    with self.subTest(file=path.name, line=node.lineno):
                        kw = {k.arg: k.value for k in node.keywords}
                        self.assertIn("kind", kw)
                        self.assertIsInstance(kw["kind"], ast.Attribute)
                        self.assertEqual(kw["kind"].value.id, "FailureKind")
        self.assertGreater(sites, 50)

    def test_authentication_kinds_are_exactly_the_documented_pair(self):
        self.assertEqual({k for k, v in _KIND_TO_INTERNAL.items() if v is InternalErrorKind.PROVIDER_AUTHENTICATION},
                         {FailureKind.AUTHENTICATION, FailureKind.PERMISSION})

    def test_taxonomy_never_creates_a_public_error_code(self):
        self.assertEqual(sorted(c.value for c in ErrorCode), sorted([
            "invalid_request", "no_eligible_model", "provider_failed", "provider_timeout", "provider_overloaded",
            "provider_rate_limited", "provider_invalid_response", "provider_content_blocked", "internal_error"]))

    def test_retryable_is_only_a_hint_and_nothing_retries_on_it(self):
        import pathlib
        import re
        root = pathlib.Path(__file__).resolve().parents[2] / "src" / "sanour_ai"
        for path in root.rglob("*.py"):
            text = path.read_text(encoding="utf-8")
            with self.subTest(file=path.name):
                self.assertIsNone(re.search(r"while .*retr|for attempt in|retry_count|max_retries=[1-9]", text))


if __name__ == "__main__":
    unittest.main()
