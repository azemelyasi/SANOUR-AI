"""Stage 10.32 tests: execution pipeline, coordinator, request lifecycle, bounded metrics.

Fake providers only. No network, no real key, no SDK. Waits are bounded and event-driven.
"""

from tests.support import request_identity_for as _rid
import logging
import threading
import time
import unittest
from unittest import mock

from sanour_ai.core import coordinator as coord_mod
from sanour_ai.core.lifecycle import ALLOWED, TERMINAL_STATES, InvalidTransition, RequestLifecycle, RequestState
from sanour_ai.core.sanour_core import SanourCore
from sanour_ai.errors import ErrorCode, SanourError
from sanour_ai.models.base import ModelResult, ProviderError
from sanour_ai.models.capabilities import ModelCapabilities, ModelProfile, ProviderCapabilities
from sanour_ai.models.gateway import ModelGateway
from sanour_ai.models.router import DeterministicRouter
from sanour_ai.observability.audit import AUDIT_LOGGER_NAME, AuditLogger
from sanour_ai.providers.common import ContentBlockedError, IncompleteResponseError
from tests.support import wait_until

R = RequestState
SECRET = "STAGE1032-SECRET-KEY-ZZ"
TEXT = ProviderCapabilities(text_generation=True)


class FakeProvider:
    """Fake adapter. behavior(call) returns a ModelResult, or raises. Counts calls."""

    def __init__(self, name="p1", behavior=None, caps=TEXT):
        self.name = name
        self.capabilities = caps
        self._behavior = behavior or (lambda call: ModelResult(text="ok", reported_model_id=call.model_id))
        self.lock = threading.Lock()
        self.calls = 0
        self.started = threading.Event()
        self.release = threading.Event()

    def generate(self, call):
        with self.lock:
            self.calls += 1
        self.started.set()
        return self._behavior(call)


def blocking(provider):
    def behavior(call):
        provider.release.wait(5)
        return ModelResult(text="ok", reported_model_id=call.model_id)
    return behavior


def profile(alias="p_one", provider="p1", model_id="m-1032", priority=0, flags=None):
    caps = dict(text_generation=True, max_context_tokens=8192, max_output_tokens=4096)
    caps.update(flags or {})
    return ModelProfile(alias=alias, provider=provider, model_id=model_id,
                        capabilities=ModelCapabilities(**caps), priority=priority)


def make_core(providers, profiles=None, max_calls=4):
    profiles = profiles or [profile(provider=next(iter(providers)))]
    gw = ModelGateway(providers, max_concurrent_calls=max_calls)
    return SanourCore(router=DeterministicRouter(profiles), gateway=gw, audit=AuditLogger()), gw


def req(alias="p_one", prompt="hello", timeout=5.0, **extra):
    d = {"profile_alias": alias, "prompt": prompt, "timeout_seconds": timeout}
    d.update(extra)
    return d


class AuditCapture:
    """Captures the audit logger's text. Used to prove no prompt, key or secret is written."""

    def __enter__(self):
        self.records = []
        self._logger = logging.getLogger(AUDIT_LOGGER_NAME)
        self._handler = logging.Handler()
        self._handler.emit = lambda record: self.records.append(record.getMessage())
        self._logger.addHandler(self._handler)
        return self

    def __exit__(self, *exc):
        self._logger.removeHandler(self._handler)

    @property
    def text(self):
        return "\n".join(self.records)


# ---------------------------------------------------------------- lifecycle state machine
class LifecycleTests(unittest.TestCase):
    def test_happy_path_history_is_exact(self):
        lc = RequestLifecycle()
        for to in (R.VALIDATING, R.RESOLVED, R.WAITING_CAPACITY, R.EXECUTING, R.VALIDATING_RESPONSE, R.COMPLETED):
            lc.move(to)
        self.assertEqual(lc.history, (R.RECEIVED, R.VALIDATING, R.RESOLVED, R.WAITING_CAPACITY,
                                      R.EXECUTING, R.VALIDATING_RESPONSE, R.COMPLETED))
        self.assertEqual(lc.state, R.COMPLETED)

    def test_every_pair_not_in_the_table_is_refused(self):
        for src in R:
            for dst in R:
                lc = RequestLifecycle()
                lc._state = src  # test-only: place the machine in a given state
                if src in TERMINAL_STATES:
                    with self.assertRaises(InvalidTransition):
                        lc.move(dst)
                elif dst in ALLOWED[src]:
                    lc.move(dst)
                    self.assertEqual(lc.state, dst)
                else:
                    with self.assertRaises(InvalidTransition, msg=f"{src}->{dst}"):
                        lc.move(dst)

    def test_rejected_never_reaches_executing(self):
        lc = RequestLifecycle()
        lc.move(R.VALIDATING)
        lc.move(R.RESOLVED)
        lc.move(R.WAITING_CAPACITY)
        lc.move(R.REJECTED)  # allowed from waiting_capacity: admission was refused
        with self.assertRaises(InvalidTransition):
            lc.move(R.EXECUTING)  # final state: nothing can follow, executing included
        self.assertNotIn(R.EXECUTING, lc.history)

    def test_terminal_state_never_changes(self):
        for terminal in TERMINAL_STATES:
            lc = RequestLifecycle()
            lc._state = terminal
            with self.assertRaises(InvalidTransition):
                lc.move(R.FAILED)
            lc.finish(R.FAILED)  # finish() is a no-op on a final state
            self.assertEqual(lc.state, terminal)

    def test_finish_is_idempotent_and_records_no_content(self):
        lc = RequestLifecycle()
        lc.move(R.VALIDATING)
        lc.finish(R.REJECTED)
        lc.finish(R.FAILED)
        self.assertEqual(lc.state, R.REJECTED)
        self.assertTrue(all(isinstance(s, RequestState) for s in lc.history))

    def test_states_are_exactly_the_specified_set(self):
        self.assertEqual({s.value for s in R}, {"received", "validating", "resolved", "waiting_capacity",
                                                "executing", "validating_response", "completed", "failed",
                                                "timed_out", "rejected"})
        self.assertEqual(TERMINAL_STATES, {R.COMPLETED, R.FAILED, R.TIMED_OUT, R.REJECTED})

    def test_timing_uses_injected_clock(self):
        ticks = iter([0.0, 1.0, 2.0])
        lc = RequestLifecycle(clock=lambda: next(ticks))
        lc.move(R.VALIDATING)
        self.assertEqual(lc.entered_at(R.VALIDATING), 1.0)
        self.assertIsNone(lc.entered_at(R.EXECUTING))


# ---------------------------------------------------------------- pipeline: success and early refusals
class PipelineTests(unittest.TestCase):
    def test_full_success_pipeline(self):
        p = FakeProvider()
        core, gw = make_core({"p1": p})
        with AuditCapture() as cap:
            resp = core.handle(req())
        self.assertEqual(resp.status, "success")
        self.assertEqual(resp.output, "ok")
        self.assertEqual(resp.model_alias, "p_one")
        self.assertEqual(p.calls, 1)
        stats = core.coordinator_stats()
        self.assertEqual((stats.requests, stats.terminal_counts["completed"]), (1, 1))
        self.assertEqual(stats.error_counts["none"], 1)
        self.assertNotIn("hello", cap.text)  # prompt never logged
        gw.shutdown(0.1)

    def test_lifecycle_history_for_success(self):
        recorded = []

        class Spy(coord_mod.RequestLifecycle):
            def __init__(self, *a, **k):
                super().__init__(*a, **k)
                recorded.append(self)

        p = FakeProvider()
        core, gw = make_core({"p1": p})
        with mock.patch.object(coord_mod, "RequestLifecycle", Spy):
            core.handle(req())
        self.assertEqual(recorded[0].history, (R.RECEIVED, R.VALIDATING, R.RESOLVED, R.WAITING_CAPACITY,
                                               R.EXECUTING, R.VALIDATING_RESPONSE, R.COMPLETED))
        gw.shutdown(0.1)

    def test_validation_failure_is_rejected_and_never_reaches_provider(self):
        p = FakeProvider()
        core, gw = make_core({"p1": p})
        resp = core.handle({"profile_alias": "p_one", "prompt": ""})
        self.assertEqual(resp.status, "error")
        self.assertEqual(resp.error.code, ErrorCode.INVALID_REQUEST)
        self.assertEqual(p.calls, 0)
        self.assertEqual(core.coordinator_stats().terminal_counts["rejected"], 1)
        gw.shutdown(0.1)

    def test_invalid_profile_is_rejected_without_substitution(self):
        p = FakeProvider()
        core, gw = make_core({"p1": p})
        resp = core.handle(req(alias="p_missing"))
        self.assertEqual(resp.error.code, ErrorCode.NO_ELIGIBLE_MODEL)
        self.assertEqual(p.calls, 0)
        self.assertEqual(core.coordinator_stats().terminal_counts["rejected"], 1)
        gw.shutdown(0.1)

    def test_unregistered_provider_is_rejected_before_admission(self):
        core, gw = make_core({"p1": FakeProvider()}, profiles=[profile(provider="ghost")])
        resp = core.handle(req())
        self.assertEqual(resp.error.code, ErrorCode.PROVIDER_FAILED)
        self.assertEqual(core.coordinator_stats().terminal_counts["rejected"], 1)
        gw.shutdown(0.1)

    def test_capability_mismatch_is_rejected_and_no_call_is_made(self):
        p = FakeProvider()  # text only
        core, gw = make_core({"p1": p}, profiles=[profile(flags={"streaming": True})])
        resp = core.handle(req())
        self.assertEqual(resp.error.code, ErrorCode.NO_ELIGIBLE_MODEL)
        self.assertEqual(p.calls, 0)
        gw.shutdown(0.1)

    def test_deadline_expired_before_execution_is_timed_out_without_a_call(self):
        p = FakeProvider()
        core, gw = make_core({"p1": p})
        real_resolve = core._coordinator._resolve  # the coordinator holds the resolver it was given

        def slow(request):
            time.sleep(0.05)
            return real_resolve(request)

        with mock.patch.object(core._coordinator, "_resolve", slow):
            resp = core.handle(req(timeout=0.01))
        self.assertEqual(resp.error.code, ErrorCode.PROVIDER_TIMEOUT)
        self.assertEqual(p.calls, 0)
        self.assertEqual(core.coordinator_stats().terminal_counts["timed_out"], 1)
        gw.shutdown(0.1)

    def test_on_admitted_never_fires_for_a_refused_request(self):
        p = FakeProvider(caps=TEXT)
        gw = ModelGateway({"p1": p}, max_concurrent_calls=1)
        spy = mock.Mock()
        pr = profile(flags={"streaming": True})  # capability refusal happens before admission
        from sanour_ai.models.base import ModelCall
        call = ModelCall(model_id="m-1032", prompt="x", max_output_tokens=8, deadline=time.monotonic() + 5)
        with self.assertRaises(SanourError):
            gw.generate(pr, call, time.monotonic() + 5, observer=spy, identity=_rid(pr))
        spy.on_admitted.assert_not_called()
        spy.on_validating.assert_not_called()
        gw.shutdown(0.1)


# ---------------------------------------------------------------- provider outcomes
class OutcomeTests(unittest.TestCase):
    def _run(self, behavior):
        p = FakeProvider(behavior=behavior)
        core, gw = make_core({"p1": p})
        resp = core.handle(req())
        return core, gw, p, resp

    def test_incomplete_response_is_failed_with_invalid_response_code(self):
        def behavior(call):
            raise IncompleteResponseError("cut off")
        core, gw, _, resp = self._run(behavior)
        self.assertEqual(resp.error.code, ErrorCode.PROVIDER_INVALID_RESPONSE)
        self.assertEqual(core.coordinator_stats().terminal_counts["failed"], 1)
        gw.shutdown(0.1)

    def test_invalid_response_from_unknown_status_is_failed(self):
        def behavior(call):
            raise IncompleteResponseError("unknown status")
        core, gw, _, resp = self._run(behavior)
        self.assertEqual(resp.error.code, ErrorCode.PROVIDER_INVALID_RESPONSE)
        gw.shutdown(0.1)

    def test_model_identity_mismatch_is_failed_and_audited_without_provider_text(self):
        def behavior(call):
            return ModelResult(text="ok", reported_model_id="someone-else-entirely")
        p = FakeProvider(behavior=behavior)
        core, gw = make_core({"p1": p})
        with AuditCapture() as cap:
            resp = core.handle(req())
        self.assertEqual(resp.status, "error")
        self.assertIn("model.identity.mismatch", cap.text)  # renamed in Stage 10.36
        self.assertNotIn("someone-else-entirely", cap.text)
        self.assertEqual(core.coordinator_stats().terminal_counts["failed"], 1)
        gw.shutdown(0.1)

    def test_content_blocked_is_failed_with_its_code(self):
        def behavior(call):
            raise ContentBlockedError("blocked")
        core, gw, _, resp = self._run(behavior)
        self.assertEqual(resp.error.code, ErrorCode.PROVIDER_CONTENT_BLOCKED)
        self.assertEqual(core.coordinator_stats().terminal_counts["failed"], 1)
        gw.shutdown(0.1)

    def test_retryable_provider_error_is_not_retried(self):
        def behavior(call):
            raise ProviderError("down", retryable=True)
        p = FakeProvider(behavior=behavior)
        core, gw = make_core({"p1": p})
        resp = core.handle(req())
        self.assertEqual(resp.status, "error")
        self.assertEqual(p.calls, 1)  # zero auto-retry
        gw.shutdown(0.1)

    def test_no_fallback_to_another_profile_when_one_fails(self):
        def boom(call):
            raise ProviderError("down")
        a = FakeProvider("p1", behavior=boom)
        b = FakeProvider("p2")
        core, gw = make_core({"p1": a, "p2": b},
                             profiles=[profile("p_one", "p1", priority=0), profile("p_two", "p2", priority=1)])
        resp = core.handle(req(alias="p_one"))
        self.assertEqual(resp.status, "error")
        self.assertEqual((a.calls, b.calls), (1, 0))  # zero fallback, zero auto-select
        gw.shutdown(0.1)

    def test_secret_in_provider_error_never_reaches_response_or_audit(self):
        def behavior(call):
            raise ProviderError(f"upstream said {SECRET}")
        p = FakeProvider(behavior=behavior)
        core, gw = make_core({"p1": p})
        with AuditCapture() as cap:
            resp = core.handle(req())
        self.assertNotIn(SECRET, resp.error.message)
        self.assertNotIn(SECRET, cap.text)
        gw.shutdown(0.1)


# ---------------------------------------------------------------- capacity, timeouts, shutdown
class CapacityAndTimeoutTests(unittest.TestCase):
    def test_capacity_rejection_is_rejected_and_the_busy_worker_is_untouched(self):
        p = FakeProvider(behavior=None)
        p._behavior = blocking(p)
        core, gw = make_core({"p1": p}, max_calls=1)
        first = {}
        t = threading.Thread(target=lambda: first.update(r=core.handle(req())))
        t.start()
        self.assertTrue(p.started.wait(5))
        second = core.handle(req())
        self.assertEqual(second.error.code, ErrorCode.PROVIDER_OVERLOADED)
        self.assertEqual(p.calls, 1)  # the rejected request never reached the provider
        self.assertEqual(core.coordinator_stats().terminal_counts["rejected"], 1)
        p.release.set()
        t.join(5)
        self.assertEqual(first["r"].status, "success")
        gw.shutdown(0.1)

    def test_timeout_during_execution_is_timed_out_and_worker_is_still_counted(self):
        p = FakeProvider()
        p._behavior = blocking(p)
        core, gw = make_core({"p1": p})
        resp = core.handle(req(timeout=0.2))
        self.assertEqual(resp.error.code, ErrorCode.PROVIDER_TIMEOUT)
        stats = gw.stats()
        self.assertEqual(stats.active_workers, 1)        # timeout is not the worker ending
        self.assertEqual(stats.abandoned_in_flight, 1)
        p.release.set()
        self.assertTrue(wait_until(lambda: gw.stats().active_workers == 0, timeout=3.0))
        self.assertEqual(core.coordinator_stats().terminal_counts["timed_out"], 1)
        gw.shutdown(0.1)

    def test_shutdown_during_active_request(self):
        p = FakeProvider()
        p._behavior = blocking(p)
        core, gw = make_core({"p1": p})
        result = {}
        t = threading.Thread(target=lambda: result.update(r=core.handle(req())))
        t.start()
        self.assertTrue(p.started.wait(5))
        self.assertEqual(core.shutdown(0.05), 1)            # still running: not closed under the worker
        refused = core.handle(req())
        self.assertEqual(refused.error.code, ErrorCode.PROVIDER_FAILED)   # shutdown rejection
        self.assertEqual(p.calls, 1)
        p.release.set()
        t.join(5)
        self.assertEqual(result["r"].status, "success")
        self.assertEqual(core.shutdown(1.0), 0)

    def test_concurrent_requests_are_bounded_and_every_request_ends_in_a_final_state(self):
        def slow(call):
            time.sleep(0.05)
            return ModelResult(text="ok", reported_model_id=call.model_id)
        p = FakeProvider(behavior=slow)
        core, gw = make_core({"p1": p}, max_calls=2)
        out = []
        lock = threading.Lock()

        def one():
            r = core.handle(req())
            with lock:
                out.append(r.status)

        threads = [threading.Thread(target=one) for _ in range(6)]
        for th in threads:
            th.start()
        for th in threads:
            th.join(10)
        self.assertEqual(len(out), 6)
        self.assertLessEqual(gw.stats().peak_in_flight, 2)
        stats = core.coordinator_stats()
        self.assertEqual(stats.requests, 6)
        self.assertEqual(sum(stats.terminal_counts.values()), 6)
        gw.shutdown(0.1)

    def test_deadline_is_the_one_created_by_the_core(self):
        p = FakeProvider()
        gw = ModelGateway({"p1": p}, max_concurrent_calls=2)
        seen = []
        real = gw.generate

        def spy(profile_, call, deadline, observer=None, identity=None):
            seen.append((call.deadline, deadline))
            return real(profile_, call, deadline, observer=observer, identity=identity)

        gw.generate = spy
        core = SanourCore(router=DeterministicRouter([profile()]), gateway=gw, audit=AuditLogger())
        core.handle(req(timeout=3.0))
        self.assertEqual(len(seen), 1)
        self.assertEqual(seen[0][0], seen[0][1])
        gw.shutdown(0.1)


# ---------------------------------------------------------------- metrics and boundaries
class MetricsAndBoundaryTests(unittest.TestCase):
    def test_metrics_have_fixed_keys_and_do_not_grow_with_traffic(self):
        p = FakeProvider()
        core, gw = make_core({"p1": p})
        before = core.coordinator_stats()
        for _ in range(40):
            core.handle(req())
        after = core.coordinator_stats()
        self.assertEqual(set(before.terminal_counts), set(after.terminal_counts))
        self.assertEqual(set(before.error_counts), set(after.error_counts))
        self.assertEqual(after.terminal_counts["completed"], 40)
        gw.shutdown(0.1)

    def test_metrics_carry_no_prompt_or_identifiers_of_a_person(self):
        p = FakeProvider()
        core, gw = make_core({"p1": p})
        core.handle(req(prompt="private prompt text"))
        blob = repr(core.coordinator_stats())
        self.assertNotIn("private prompt text", blob)
        gw.shutdown(0.1)

    def test_coordinator_never_selects_a_profile(self):
        src = (coord_mod.__file__)
        with open(src, encoding="utf-8") as fh:
            text = fh.read()
        self.assertNotIn(".select(", text)
        self.assertNotIn(".resolve(", text)  # no direct Router call: resolution is injected by the Core
        self.assertNotIn("DeterministicRouter", text)

    def test_core_remains_the_only_router_owner(self):
        with open("src/sanour_ai/core/sanour_core.py", encoding="utf-8") as fh:
            core_src = fh.read()
        self.assertIn("self._router.resolve(request)", core_src)


if __name__ == "__main__":
    unittest.main()
