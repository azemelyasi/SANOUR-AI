"""Stage 10.37-R1: structural error classification.

Classification must depend only on typed fields (ErrorCode, FailureKind, failure_reason). These tests
fail if anyone classifies on message text (Mutation C), and check the typed path end to end through
the gateway for deadline, lifecycle, rate limit, content blocked, invalid response, and public output.
No network, no SDK, no key. Waits are bounded.
"""

import ast
import json
import pathlib
import time
import unittest

from tests.support import TEST_ALL_CAPS, deadline_in
from tests.support import request_identity_for as _rid

from sanour_ai.errors import FAILURE_REASONS, ErrorCode, FailureKind, SanourError
from sanour_ai.models.base import ModelCall, ModelResult, ProviderError
from sanour_ai.models.capabilities import ModelCapabilities, ModelProfile
from sanour_ai.models.error_taxonomy import InternalErrorKind, classify
from sanour_ai.models.gateway import ModelGateway
from sanour_ai.models.responses import SanourResponse
from sanour_ai.providers.common import ContentBlockedError, IncompleteResponseError, RateLimitedError

PROFILE = ModelProfile(
    alias="mock_default", provider="mock", model_id="mock-echo-1",
    capabilities=ModelCapabilities(text_generation=True, max_context_tokens=8192, max_output_tokens=4096),
    runs_locally=True,
)
CALL = ModelCall(model_id="mock-echo-1", prompt="hi", max_output_tokens=16)
SRC = pathlib.Path(__file__).resolve().parents[2] / "src" / "sanour_ai"
MISLEADING_TEXTS = [
    "rate", "provider rate limited", "rate limit reached", "timed out", "provider call timed out",
    "deadline expired", "response arrived after deadline", "provider rejected credentials",
    "provider connection failed", "model gateway is shut down", "quota", "billing", "payment required",
    "model id is not a valid identifier", "content blocked", "response malformed", "",
]


class _Raising:
    name = "mock"
    capabilities = TEST_ALL_CAPS

    def __init__(self, exc):
        self._exc = exc

    def generate(self, call):
        raise self._exc


class _Returning:
    name = "mock"
    capabilities = TEST_ALL_CAPS

    def __init__(self, value):
        self._value = value

    def generate(self, call):
        return self._value


class _Slow:
    name = "mock"
    capabilities = TEST_ALL_CAPS

    def generate(self, call):
        time.sleep(0.3)
        return ModelResult(text="late", reported_model_id="mock-echo-1")


def _run(provider, deadline=None):
    gw = ModelGateway({"mock": provider}, max_concurrent_calls=2)
    try:
        gw.generate(PROFILE, CALL, deadline if deadline is not None else deadline_in(2.0), identity=_rid(PROFILE))
    except SanourError as exc:
        return exc
    finally:
        gw.shutdown(0.5)
    raise AssertionError("expected a failure")


def _err(code, kind=FailureKind.UNCLASSIFIED, detail=None, **kw):
    return SanourError(code, "model provider failed", internal_kind=kind, internal_detail=detail, **kw)


class MessageTextIsNeverClassified(unittest.TestCase):
    """Mutation C detector: any text-based decision changes one of these outcomes."""

    def test_text_alone_never_changes_the_kind(self):
        for text in MISLEADING_TEXTS:
            with self.subTest(text=text):
                self.assertIs(classify(_err(ErrorCode.PROVIDER_FAILED, detail=text)),
                              InternalErrorKind.PROVIDER_UNCLASSIFIED)
                self.assertIs(classify(_err(ErrorCode.PROVIDER_FAILED, detail=text, kind=FailureKind.UNCLASSIFIED)),
                              InternalErrorKind.PROVIDER_UNCLASSIFIED)

    def test_typed_kind_decides_even_when_text_disagrees(self):
        self.assertIs(classify(_err(ErrorCode.PROVIDER_FAILED, FailureKind.CONNECTION, "rate limit timed out")),
                      InternalErrorKind.PROVIDER_TRANSPORT)
        self.assertIs(classify(_err(ErrorCode.PROVIDER_FAILED, FailureKind.DEADLINE_LATE, "rejected credentials")),
                      InternalErrorKind.DEADLINE_EXCEEDED)

    def test_classify_body_contains_no_message_literals(self):
        # Structural tags only: the failure_reason values and the gateway's validation tag names.
        allowed = set(FAILURE_REASONS) | {"incomplete_response", "validation_outcome", "internal_kind"}
        tree = ast.parse((SRC / "models" / "error_taxonomy.py").read_text(encoding="utf-8"))
        fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "classify")
        body = fn.body[1:]  # skip the docstring
        literals = {n.value for stmt in body for n in ast.walk(stmt)
                    if isinstance(n, ast.Constant) and isinstance(n.value, str)}
        self.assertTrue(literals <= allowed, f"non-structural literals: {literals - allowed}")
        reads = {n.attr for stmt in body for n in ast.walk(stmt) if isinstance(n, ast.Attribute)}
        self.assertNotIn("message", reads)
        self.assertNotIn("internal_detail", reads)

    def test_taxonomy_module_never_reads_message_or_detail(self):
        tree = ast.parse((SRC / "models" / "error_taxonomy.py").read_text(encoding="utf-8"))
        reads = {n.attr for n in ast.walk(tree) if isinstance(n, ast.Attribute)}
        self.assertNotIn("message", reads)
        self.assertNotIn("internal_detail", reads)


class TypedFieldContract(unittest.TestCase):
    def test_default_kind_is_unclassified(self):
        self.assertIs(ProviderError("x").kind, FailureKind.UNCLASSIFIED)

    def test_provider_error_rejects_a_string_kind(self):
        with self.assertRaises(TypeError):
            ProviderError("provider rejected credentials", kind="authentication")

    def test_sanour_error_rejects_a_string_kind(self):
        with self.assertRaises(TypeError):
            SanourError(ErrorCode.PROVIDER_FAILED, "model provider failed", internal_kind="authentication")

    def test_failure_reason_quota_and_billing_still_win(self):
        self.assertIs(classify(_err(ErrorCode.PROVIDER_FAILED, FailureKind.PAYMENT_REQUIRED,
                                    failure_reason="billing")), InternalErrorKind.PROVIDER_QUOTA)
        self.assertIs(classify(_err(ErrorCode.PROVIDER_FAILED, FailureKind.LIMIT_REACHED,
                                    failure_reason="quota")), InternalErrorKind.PROVIDER_QUOTA)

    def test_non_provider_failure_without_kind_fails_closed(self):
        self.assertIs(classify(SanourError(ErrorCode.PROVIDER_FAILED, "model provider failed")),
                      InternalErrorKind.PROVIDER_UNCLASSIFIED)


class PipelineClassificationTests(unittest.TestCase):
    def test_deadline_late_provider_error_is_deadline(self):
        exc = _run(_Raising(ProviderError("anything", kind=FailureKind.DEADLINE_LATE, retryable=True)))
        self.assertIs(exc.code, ErrorCode.PROVIDER_FAILED)
        self.assertIs(exc.internal_kind, FailureKind.DEADLINE_LATE)
        self.assertIs(classify(exc), InternalErrorKind.DEADLINE_EXCEEDED)

    def test_response_after_deadline_is_never_success(self):
        exc = _run(_Slow(), deadline=deadline_in(0.1))
        self.assertIs(exc.code, ErrorCode.PROVIDER_TIMEOUT)
        self.assertIs(classify(exc), InternalErrorKind.DEADLINE_EXCEEDED)

    def test_expired_deadline_before_call_is_deadline(self):
        exc = _run(_Returning(ModelResult(text="x", reported_model_id="mock-echo-1")), deadline=time.monotonic() - 1)
        self.assertIs(classify(exc), InternalErrorKind.DEADLINE_EXCEEDED)

    def test_lifecycle_after_shutdown_is_lifecycle(self):
        gw = ModelGateway({"mock": _Returning(ModelResult(text="x", reported_model_id="mock-echo-1"))},
                          max_concurrent_calls=1)
        gw.shutdown(0.5)
        with self.assertRaises(SanourError) as ctx:
            gw.generate(PROFILE, CALL, deadline_in(2.0), identity=_rid(PROFILE))
        self.assertIs(ctx.exception.internal_kind, FailureKind.GATEWAY_SHUT_DOWN)
        self.assertIs(classify(ctx.exception), InternalErrorKind.PROVIDER_LIFECYCLE)

    def test_unregistered_provider_is_lifecycle(self):
        gw = ModelGateway({}, max_concurrent_calls=1)
        try:
            with self.assertRaises(SanourError) as ctx:
                gw.generate(PROFILE, CALL, deadline_in(2.0), identity=_rid(PROFILE))
        finally:
            gw.shutdown(0.5)
        self.assertIs(ctx.exception.internal_kind, FailureKind.PROVIDER_NOT_REGISTERED)
        self.assertIs(classify(ctx.exception), InternalErrorKind.PROVIDER_LIFECYCLE)

    def test_rate_limit_is_rate_limit_and_not_quota(self):
        exc = _run(_Raising(RateLimitedError("provider rate limited", retryable=True)))
        self.assertIs(exc.code, ErrorCode.PROVIDER_RATE_LIMITED)
        self.assertIs(classify(exc), InternalErrorKind.PROVIDER_RATE_LIMIT)

    def test_unknown_429_text_does_not_become_rate_limit(self):
        exc = _run(_Raising(ProviderError("rate limit reached, timed out", kind=FailureKind.LIMIT_REACHED)))
        self.assertIs(exc.code, ErrorCode.PROVIDER_FAILED)
        self.assertIs(classify(exc), InternalErrorKind.PROVIDER_LIMIT_UNCONFIRMED)

    def test_content_blocked_is_content_blocked(self):
        exc = _run(_Raising(ContentBlockedError("provider blocked content", retryable=False)))
        self.assertIs(exc.code, ErrorCode.PROVIDER_CONTENT_BLOCKED)
        self.assertIs(classify(exc), InternalErrorKind.PROVIDER_CONTENT_BLOCKED)

    def test_incomplete_response_is_incomplete(self):
        exc = _run(_Raising(IncompleteResponseError("response incomplete", retryable=False)))
        self.assertIs(exc.code, ErrorCode.PROVIDER_INVALID_RESPONSE)
        self.assertIs(classify(exc), InternalErrorKind.PROVIDER_INCOMPLETE_RESPONSE)

    def test_wrong_return_type_is_invalid_response(self):
        exc = _run(_Returning("not a result"))
        self.assertIs(exc.code, ErrorCode.PROVIDER_INVALID_RESPONSE)
        self.assertIs(classify(exc), InternalErrorKind.PROVIDER_INVALID_RESPONSE)

    def test_authentication_kind_reaches_taxonomy_without_text(self):
        exc = _run(_Raising(ProviderError("provider rejected credentials", kind=FailureKind.AUTHENTICATION)))
        self.assertIs(classify(exc), InternalErrorKind.PROVIDER_AUTHENTICATION)


class PublicContractUnchanged(unittest.TestCase):
    def test_public_error_carries_no_internal_fields(self):
        exc = _run(_Raising(ProviderError("secret sk-live-123 in text", kind=FailureKind.AUTHENTICATION)))
        self.assertEqual(exc.message, "model provider failed")
        response = SanourResponse.failure(request_id="r1", error=exc, latency_ms=1)
        payload = json.dumps(response.model_dump(mode="json"))
        self.assertNotIn("sk-live-123", payload)
        self.assertNotIn("authentication", payload)
        self.assertEqual(set(response.error.model_dump()), {"code", "message", "retryable"})
        self.assertIs(response.error.code, ErrorCode.PROVIDER_FAILED)


if __name__ == "__main__":
    unittest.main()
