"""Stage 10.49-R5: admission release failure, visibility, recovery, and restart between failure and recovery.

Invariants under test:
- the provider runs only after the admission gate has opened in its own committed transaction;
- a release that fails leaves the reservation visible (reserved, gate closed), never silently dropped;
- sweep releases a gate-closed reservation exactly once, never exposes it, and never invokes the provider;
- process death at any point between reservation and recovery is recovered without double release.
"""

import json
import logging
import os
import sqlite3
import tempfile
import time
import unittest
from decimal import Decimal

from sanour_ai.composition.runtime import Runtime
from sanour_ai.errors import ErrorCode
from sanour_ai.governance.admission import AdmissionController
from sanour_ai.governance.sink import DurableSqliteSink
from sanour_ai.governance.sink_contract import SinkFailed
from sanour_ai.governance.store import GovernanceStore
from sanour_ai.models.usage import Usage
from sanour_ai.observability.audit import AuditLogger
from tests.unit.r4_support import ACTOR, RecordingSink, run_child
from tests.unit.r5_support import ADMIT_CHILD, RaiseOn
from tests.unit.test_stage1047r1 import UsageProvider
from tests.unit.test_stage1048 import env, raw
from tests.unit.test_stage1049 import BOUNDS, Clock, pricing

WORST = Decimal("0.02048")
RELEASE_PREFIX = "UPDATE reservations SET state = 'settlement_pending'"
GATE_PREFIX = "UPDATE reservations SET admission_gate"


class Fixture(unittest.TestCase):
    def setUp(self):
        self._dir = tempfile.TemporaryDirectory()
        self.addCleanup(self._dir.cleanup)
        self.path = os.path.join(self._dir.name, "gov.db")
        self.mark = os.path.join(self._dir.name, "provider.mark")
        os.environ["PROVIDER_MARK"] = self.mark
        self.addCleanup(os.environ.pop, "PROVIDER_MARK", None)
        self.s = GovernanceStore(self.path)
        self.addCleanup(self.s.close)
        self.s.upsert_pricing(pricing())
        self.s.upsert_budget("global", "", "daily", "USD", "1.00")
        self.clock = Clock()

    def q(self, sql, *args):
        conn = sqlite3.connect(self.path)
        try:
            return conn.execute(sql, args).fetchall()
        finally:
            conn.close()

    def one(self, sql, *args):
        return self.q(sql, *args)[0][0]

    def provider_calls(self):
        if not os.path.exists(self.mark):
            return 0
        return open(self.mark).read().count("called")

    def sink(self):
        sink = RecordingSink(self.path + ".sink", self.path)
        self.addCleanup(sink.close)
        return sink

    def controller(self, sink, clock=None, store=None):
        return AdmissionController(store or self.s, audit=AuditLogger(logging.getLogger("test.r5.release")),
                                   bounds=BOUNDS, clock=clock or self.clock, authorized_actors=frozenset({ACTOR}),
                                   sink=sink)

    def runtime(self, provider, ctl):
        rt = Runtime.build_for_tests(env(), provider=provider, usage_ledger_path=self.path, governance=ctl)
        self.addCleanup(lambda: rt.shutdown(1.0))
        return rt

    def assert_visible_reserved(self):
        self.assertEqual(self.one("SELECT state FROM reservations"), "reserved")
        self.assertEqual(self.one("SELECT admission_gate FROM reservations"), "closed")
        self.assertEqual(Decimal(self.one("SELECT reserved FROM budget_windows")), WORST)

    def assert_released(self):
        self.assertEqual(self.one("SELECT state FROM reservations"), "released")
        self.assertEqual(Decimal(self.one("SELECT reserved FROM budget_windows")), Decimal(0))
        self.assertEqual(Decimal(self.one("SELECT spent FROM budget_windows")), Decimal(0))
        self.assertEqual(self.one("SELECT COUNT(*) FROM budget_windows WHERE exposed != '0'"), 0)

    def assert_released_once(self):
        self.assert_released()
        # one settlement = one intent row + one apply row, both under the recovery operation
        self.assertEqual(self.one("SELECT COUNT(*) FROM governance_log WHERE operation = 'recovery_release' "
                                  "AND outcome = 'ok'"), 2)


class AdmissionRelease(Fixture):
    def test_required_event_failure_with_healthy_storage_releases_immediately(self):
        sink = self.sink()
        sink.down = True
        ctl = self.controller(sink)
        provider = UsageProvider(Usage(input_tokens=4, output_tokens=2, total_tokens=6))
        rt = self.runtime(provider, ctl)
        response = rt.handle(raw(max_output_tokens=512))
        self.assertEqual(response.error.code, ErrorCode.INTERNAL_ERROR)
        self.assertEqual(provider.calls, 0)
        self.assert_released()

    def test_release_failure_leaves_the_reservation_visible_then_recovery_releases_it_once(self):
        sink = self.sink()
        sink.down = True
        ctl = self.controller(sink)
        provider = UsageProvider(Usage(input_tokens=4, output_tokens=2, total_tokens=6))
        rt = self.runtime(provider, ctl)
        real = self.s._conn  # noqa: SLF001
        self.s._conn = RaiseOn(real, RELEASE_PREFIX)  # noqa: SLF001 the release cannot commit
        response = rt.handle(raw(max_output_tokens=512))
        self.s._conn = real  # noqa: SLF001
        self.assertEqual(response.error.code, ErrorCode.INTERNAL_ERROR)
        self.assertEqual(provider.calls, 0)
        self.assert_visible_reserved()  # nothing silently lost: the hold is still on the books

        sink.down = False
        self.clock.now += 200  # past the reservation expiry
        self.assertGreaterEqual(ctl.sweep(), 1)
        self.assert_released_once()
        self.assertEqual(ctl.sweep(), 0, "a second sweep must not release again")
        self.assert_released_once()
        self.assertEqual(provider.calls, 0, "recovery never invokes the provider")

    def test_gate_open_failure_refuses_before_any_provider_call_and_releases(self):
        sink = self.sink()
        ctl = self.controller(sink)
        provider = UsageProvider(Usage(input_tokens=4, output_tokens=2, total_tokens=6))
        rt = self.runtime(provider, ctl)
        real = self.s._conn  # noqa: SLF001
        self.s._conn = RaiseOn(real, GATE_PREFIX)  # noqa: SLF001
        response = rt.handle(raw(max_output_tokens=512))
        self.s._conn = real  # noqa: SLF001
        self.assertEqual(response.error.code, ErrorCode.INTERNAL_ERROR)
        self.assertEqual(provider.calls, 0)
        self.assert_released()

    def test_successful_admission_opens_the_gate_before_the_provider_runs(self):
        seen = []
        db = self.path

        class CheckingProvider(UsageProvider):
            def generate(self, call):
                conn = sqlite3.connect(db)
                try:
                    seen.append(conn.execute("SELECT admission_gate FROM reservations").fetchone()[0])
                finally:
                    conn.close()
                return super().generate(call)

        sink = self.sink()
        provider = CheckingProvider(Usage(input_tokens=4, output_tokens=2, total_tokens=6))
        rt = self.runtime(provider, self.controller(sink))
        self.assertEqual(rt.handle(raw(max_output_tokens=512)).status, "success")
        self.assertEqual(seen, ["open"], "the provider must observe a committed open gate")


class ProcessRestart(Fixture):
    def restart(self):
        """A new process view after the crash: new store, new controller, sink up, clock past every lease and expiry."""
        clock = lambda: time.time() + 1000  # noqa: E731
        sink = RecordingSink(self.path + ".sink", self.path)
        self.addCleanup(sink.close)
        store = GovernanceStore(self.path)
        self.addCleanup(store.close)
        return AdmissionController(store, audit=AuditLogger(logging.getLogger("test.r5.restart")), bounds=BOUNDS,
                                   clock=clock, authorized_actors=frozenset({ACTOR}), sink=sink)

    def test_death_after_reservation_before_confirmation_is_recovered_after_restart(self):
        out = os.path.join(self._dir.name, "child.json")
        done = run_child(ADMIT_CHILD, [self.path, self.path + ".sink", "die_at_deliver", out])
        self.assertEqual(done.returncode, 9, "the child must die after the reservation commit")
        self.assert_visible_reserved()
        self.assertEqual(self.provider_calls(), 0)
        ctl = self.restart()
        self.assertGreaterEqual(ctl.sweep(), 1)
        self.assert_released_once()
        self.assertEqual(ctl.sweep(), 0)
        self.assert_released_once()
        self.assertEqual(self.provider_calls(), 0)

    def test_restart_between_a_failed_release_and_its_recovery_releases_once(self):
        out = os.path.join(self._dir.name, "child.json")
        done = run_child(ADMIT_CHILD, [self.path, self.path + ".sink", "release_fail", out])
        self.assertEqual(done.returncode, 0)
        with open(out) as fh:
            result = json.load(fh)
        self.assertEqual(result, {"status": "error", "code": ErrorCode.INTERNAL_ERROR.value})
        self.assert_visible_reserved()
        self.assertEqual(self.provider_calls(), 0)
        ctl = self.restart()
        ctl.sweep()
        self.assert_released_once()
        ctl.sweep()
        self.assert_released_once()
        self.assertEqual(self.provider_calls(), 0)


if __name__ == "__main__":
    unittest.main()
