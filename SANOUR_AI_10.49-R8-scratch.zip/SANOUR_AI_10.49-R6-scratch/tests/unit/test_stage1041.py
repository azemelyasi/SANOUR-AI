"""Stage 10.41: capacity invariant regression tests.

Capacity stays occupied until the worker thread has finished its last statement. Provider close runs
only after that, never on the worker thread, exactly once, through one settler thread per provider.
Offline only: fake providers, no SDK, no network, no key. Every wait is bounded.
"""

import threading
import time
import unittest

from sanour_ai.errors import ErrorCode, SanourError
from sanour_ai.models.base import ModelResult
from sanour_ai.models.gateway import ModelGateway
from tests.support import TEST_ALL_CAPS, deadline_in, wait_until
from tests.support import request_identity_for as _rid
from tests.unit import test_gateway as gw_tests


class Probe:
    """Records what happens on which thread. generate() can be held open with `gate`."""

    name = "mock"
    capabilities = TEST_ALL_CAPS

    def __init__(self):
        self.gate = threading.Event()
        self.close_gate = None
        self.generate_thread = None
        self.close_thread = None
        self.close_calls = 0
        self.unfinished_at_close = None
        self.in_flight_at_close = None
        self.gateway = None
        self.settled = threading.Event()

    def generate(self, call):
        self.generate_thread = threading.get_ident()
        self.gate.wait(3.0)
        return ModelResult(text="x", reported_model_id=call.model_id)

    def close(self):
        self.close_thread = threading.get_ident()
        self.close_calls += 1
        if self.gateway is not None:
            self.unfinished_at_close = self.gateway._unfinished["mock"]
            self.in_flight_at_close = self.gateway._provider_in_flight["mock"]
        if self.close_gate is not None:
            self.close_gate.wait(3.0)


def make(probe, max_calls=1):
    gw = ModelGateway({"mock": probe}, max_concurrent_calls=max_calls)
    probe.gateway = gw
    gw.add_settlement_observer(lambda name, outcome: probe.settled.set())
    return gw


def start_call(gw):
    result = {}

    def run():
        try:
            result["r"] = gw.generate(gw_tests.PROFILE, gw_tests.CALL, deadline_in(3.0),
                                      identity=_rid(gw_tests.PROFILE))
        except SanourError as exc:
            result["e"] = exc

    t = threading.Thread(target=run, name="caller")
    t.start()
    assert wait_until(lambda: gw.in_flight == 1, timeout=2.0)
    return t, result


def settler_threads():
    return [t for t in threading.enumerate() if t.name.startswith("sanour-settle-")]


class CapacityInvariant(unittest.TestCase):
    def test_capacity_is_held_while_the_worker_runs_and_no_new_call_is_admitted(self):  # req 1
        probe = Probe()
        gw = make(probe, max_calls=1)
        t, _ = start_call(gw)
        self.assertEqual(gw._slots._value, 0)
        with self.assertRaises(SanourError) as ctx:  # gateway still open: capacity is really taken
            gw.generate(gw_tests.PROFILE, gw_tests.CALL, deadline_in(1.0), identity=_rid(gw_tests.PROFILE))
        self.assertIs(ctx.exception.code, ErrorCode.PROVIDER_OVERLOADED)
        gw.shutdown(0.01)
        self.assertEqual(gw._slots._value, 0)  # shutdown does not free a busy slot
        probe.gate.set()
        t.join(3.0)
        self.assertTrue(probe.settled.wait(2.0))
        self.assertEqual(gw._slots._value, 1)

    def test_close_never_runs_on_the_worker_thread(self):  # req 2
        probe = Probe()
        gw = make(probe)
        t, _ = start_call(gw)
        gw.shutdown(0.01)
        probe.gate.set()
        t.join(3.0)
        self.assertTrue(probe.settled.wait(2.0))
        self.assertIsNotNone(probe.close_thread)
        self.assertNotEqual(probe.close_thread, probe.generate_thread)

    def test_close_runs_only_after_worker_completion_bookkeeping(self):  # req 3
        probe = Probe()
        gw = make(probe)
        t, _ = start_call(gw)
        gw.shutdown(0.01)
        probe.gate.set()
        t.join(3.0)
        self.assertTrue(probe.settled.wait(2.0))
        self.assertEqual(probe.unfinished_at_close, 0)
        self.assertEqual(probe.in_flight_at_close, 0)

    def test_close_waits_for_a_worker_that_is_still_inside_its_final_release(self):  # req 3, race
        probe = Probe()
        gw = make(probe)
        in_release = threading.Event()
        let_go = threading.Event()
        original = gw._release_slots

        def held_release(state):
            if threading.current_thread().name.startswith("sanour-model"):
                in_release.set()       # the worker is at its last statement, counters already dropped
                let_go.wait(3.0)
            original(state)

        gw._release_slots = held_release
        t, _ = start_call(gw)
        gw.shutdown(0.01)
        probe.gate.set()
        self.assertTrue(in_release.wait(2.0))
        self.assertEqual(gw.in_flight, 0)        # admission counter already dropped
        # Negative check: give a wrongly-early settler a real chance to run before asserting it did not.
        time.sleep(0.2)
        self.assertEqual(probe.close_calls, 0)   # but the thread has not finished: no close yet
        let_go.set()
        t.join(3.0)
        self.assertTrue(probe.settled.wait(2.0))
        self.assertEqual(probe.close_calls, 1)


class AutomaticSettlement(unittest.TestCase):
    def test_settlement_happens_without_another_shutdown_call(self):  # req 4
        probe = Probe()
        gw = make(probe)
        t, _ = start_call(gw)
        gw.shutdown(0.01)
        self.assertEqual(gw.provider_state("mock"), "open")
        probe.gate.set()
        t.join(3.0)
        self.assertTrue(probe.settled.wait(2.0))
        self.assertEqual(gw.provider_state("mock"), "closed")
        self.assertEqual(probe.close_calls, 1)

    def test_shutdown_returns_only_after_an_in_time_worker_is_closed(self):  # req 5
        probe = Probe()
        gw = make(probe)
        t, _ = start_call(gw)
        threading.Timer(0.05, probe.gate.set).start()
        gw.shutdown(3.0)
        self.assertEqual(gw.provider_state("mock"), "closed")
        self.assertEqual(probe.close_calls, 1)
        t.join(3.0)


class SlowCloseIsBounded(unittest.TestCase):
    def test_slow_close_neither_frees_nor_steals_capacity_and_threads_stay_bounded(self):  # req 6
        probe = Probe()
        probe.close_gate = threading.Event()
        gw = make(probe)
        t, _ = start_call(gw)
        gw.shutdown(0.01)
        probe.gate.set()
        t.join(3.0)
        before = threading.active_count()
        for _ in range(20):
            gw.shutdown(0.001)  # repeated shutdowns while the close is still running
        self.assertLessEqual(len(settler_threads()), 1)
        self.assertLessEqual(threading.active_count() - before, 1)
        self.assertEqual(gw.provider_state("mock"), "closing")
        self.assertEqual(gw._slots._value, 1)  # the finished worker's capacity is back
        with self.assertRaises(SanourError):   # and the closed gateway admits nothing new
            gw.generate(gw_tests.PROFILE, gw_tests.CALL, deadline_in(1.0), identity=_rid(gw_tests.PROFILE))
        probe.close_gate.set()
        self.assertTrue(probe.settled.wait(2.0))
        self.assertEqual(probe.close_calls, 1)

    def test_concurrent_shutdowns_during_settlement_close_exactly_once(self):
        probe = Probe()
        gw = make(probe)
        t, _ = start_call(gw)
        threads = [threading.Thread(target=lambda: gw.shutdown(0.01)) for _ in range(30)]
        for th in threads:
            th.start()
        probe.gate.set()
        for th in threads:
            th.join(3.0)
        t.join(3.0)
        self.assertTrue(probe.settled.wait(2.0))
        gw.shutdown(0.01)
        self.assertEqual(probe.close_calls, 1)


if __name__ == "__main__":
    unittest.main()
