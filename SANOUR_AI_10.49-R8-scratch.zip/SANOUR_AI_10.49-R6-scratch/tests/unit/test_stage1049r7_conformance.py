"""Stage 10.49-R7: offline adapter conformance for the four HTTP adapters that need no SDK.

Anthropic, Gemini (generateContent), Grok (chat completions) and xAI Responses are called through their own
injectable transport. These tests use fake transports only: no network, no key, no SDK. They verify the behavior
the code implements, which is NOT the same as verifying the live provider API (see the R7 report).

The OpenAI adapter needs the openai and httpx2 packages. It is deliberately NOT faked here; its SDK-dependent tests
skip where the packages are absent and are reported separately.
"""

import json
import re
import threading
import time
import unittest
from pydantic import SecretStr

from sanour_ai.errors import FailureKind
from sanour_ai.models.base import ModelCall, ProviderError
from sanour_ai.providers import anthropic_provider as ap
from sanour_ai.providers import gemini_provider as gp
from sanour_ai.providers import grok_provider as grp
from sanour_ai.providers import xai_responses_provider as xp
from sanour_ai.providers.common import MAX_RESPONSE_BYTES, DeadlineExpired, RequestTimeout

SECRET = "TESTONLY-r7-not-a-real-key-0123456789"
MODEL = "test-model-1"


class FakeTransport:
    """Records each attempt. Returns (status, body) like the real transports. Never touches the network."""

    def __init__(self, status=200, body=b"{}", raise_exc=None, delay=0.0):
        self.status, self.body, self.raise_exc, self.delay = status, body, raise_exc, delay
        self.calls = []

    def __call__(self, url, headers, body, timeout):
        self.calls.append({"url": url, "headers": dict(headers), "body": body, "timeout": timeout})
        if self.delay:
            time.sleep(self.delay)
        if self.raise_exc is not None:
            raise self.raise_exc
        return self.status, self.body


def call(deadline_in=5.0, model=MODEL, max_tokens=64, prompt="hi"):
    return ModelCall(model_id=model, prompt=prompt, max_output_tokens=max_tokens,
                     deadline=time.monotonic() + deadline_in)


class HttpAdapterConformance:
    """Shared checks (a mixin, not collected on its own). Subclasses set the provider-specific table."""

    adapter_cls = None
    key_header = None          # header that must carry the key
    max_field_path = ()        # where max_output_tokens is serialized
    body_model_field = True    # False: the model id is only in the URL (Gemini)

    def make(self, transport):
        return self.adapter_cls(SecretStr(SECRET), transport=transport)

    def ok_body(self, text="hello", model="reported-model-x"):
        raise NotImplementedError

    def incomplete_body(self):
        raise NotImplementedError

    def assert_error(self, kind, body=None, status=200, retry=False):
        transport = FakeTransport(status=status, body=body if body is not None else self.ok_body())
        with self.assertRaises(ProviderError) as caught:
            self.make(transport).generate(call())
        self.assertEqual(caught.exception.kind, kind)
        self.assertEqual(caught.exception.retryable, retry)
        return caught.exception, transport

    # ---- request serialization and auth
    def test_request_carries_model_prompt_and_max_tokens_in_the_provider_shape(self):
        t = FakeTransport(body=self.ok_body())
        self.make(t).generate(call(max_tokens=77, prompt="ping"))
        self.assertEqual(len(t.calls), 1)
        body = json.loads(t.calls[0]["body"])
        node = body
        for key in self.max_field_path[:-1]:
            node = node[key]
        self.assertEqual(node[self.max_field_path[-1]], 77)
        self.assertIn("ping", t.calls[0]["body"].decode())
        if self.body_model_field:
            self.assertEqual(body.get("model"), MODEL)
        else:
            self.assertIn(MODEL, t.calls[0]["url"])
            self.assertNotIn("model", body)

    def test_key_travels_only_in_its_header_never_in_url_or_body(self):
        t = FakeTransport(body=self.ok_body())
        self.make(t).generate(call())
        c = t.calls[0]
        self.assertIn(SECRET, c["headers"][self.key_header])
        self.assertNotIn(SECRET, c["url"])
        self.assertNotIn(SECRET, c["body"].decode())

    # ---- model identity
    def test_reports_the_model_the_provider_returned_not_the_requested_one(self):
        t = FakeTransport(body=self.ok_body(model="served-by-provider"))
        result = self.make(t).generate(call())
        self.assertEqual(result.reported_model_id, "served-by-provider")
        self.assertEqual(result.text, "hello")

    # ---- classification
    def test_incomplete_response_is_classified_and_not_retried(self):
        self.assert_error(FailureKind.INCOMPLETE_RESPONSE, body=self.incomplete_body())

    def test_malformed_json_is_never_a_success(self):
        t = FakeTransport(body=b"not json")
        if self.fails_closed_on_malformed:
            self.assert_error(FailureKind.INCOMPLETE_RESPONSE, body=b"not json")
        else:
            # Documented: this adapter returns an empty result, which the gateway rejects as an invalid response.
            result = self.make(t).generate(call())
            self.assertEqual(result.text, "")

    status_cases = [(401, FailureKind.AUTHENTICATION, False), (403, FailureKind.PERMISSION, False),
                    (404, FailureKind.MODEL_NOT_FOUND, False), (400, FailureKind.REQUEST_REJECTED, False),
                    (500, FailureKind.SERVER_ERROR, True)]

    def test_http_status_mapping_is_fixed_and_single_attempt(self):
        for status, kind, retry in self.status_cases:
            with self.subTest(status=status):
                transport = FakeTransport(status=status, body=b"{}")
                with self.assertRaises(ProviderError) as caught:
                    self.make(transport).generate(call())
                self.assertEqual(caught.exception.kind, kind)
                self.assertEqual(caught.exception.retryable, retry)
                self.assertEqual(len(transport.calls), 1, "no automatic retry")

    def test_provider_error_text_and_secrets_never_reach_the_exception(self):
        t = FakeTransport(status=401, body=f'{{"error": "bad key {SECRET}"}}'.encode())
        with self.assertRaises(ProviderError) as caught:
            self.make(t).generate(call())
        self.assertNotIn(SECRET, str(caught.exception))
        self.assertNotIn(SECRET, repr(caught.exception))

    # ---- bounded response
    def test_oversized_success_body_is_refused_not_parsed(self):
        big = b"{" + b" " * (MAX_RESPONSE_BYTES + 1) + b"}"
        self.assert_error(FailureKind.RESPONSE_TOO_LARGE, body=big)

    # ---- deadline propagation
    def test_transport_timeout_is_capped_by_the_one_monotonic_deadline(self):
        c = call(deadline_in=3.0)
        t = FakeTransport(body=self.ok_body())
        self.make(t).generate(c)
        timeout = t.calls[0]["timeout"]
        self.assertIsInstance(timeout, RequestTimeout)
        self.assertEqual(timeout.deadline, c.deadline)
        self.assertLessEqual(float(timeout), c.deadline - time.monotonic() + 1e-3)
        self.assertGreater(float(timeout), 0)

    def test_expired_deadline_fails_before_any_io(self):
        c = ModelCall(model_id=MODEL, prompt="hi", max_output_tokens=8, deadline=time.monotonic() - 1)
        t = FakeTransport(body=self.ok_body())
        with self.assertRaises(ProviderError) as caught:
            self.make(t).generate(c)
        self.assertEqual(caught.exception.kind, FailureKind.DEADLINE_EXPIRED)
        self.assertEqual(t.calls, [])

    def test_missing_deadline_is_refused_before_any_io(self):
        c = ModelCall(model_id=MODEL, prompt="hi", max_output_tokens=8, deadline=None)
        t = FakeTransport(body=self.ok_body())
        with self.assertRaises(ProviderError) as caught:
            self.make(t).generate(c)
        self.assertEqual(caught.exception.kind, FailureKind.DEADLINE_MISSING)
        self.assertEqual(t.calls, [])

    def test_response_arriving_after_the_deadline_is_refused(self):
        c = call(deadline_in=0.05)
        t = FakeTransport(body=self.ok_body(), delay=0.15)
        with self.assertRaises(ProviderError) as caught:
            self.make(t).generate(c)
        self.assertEqual(caught.exception.kind, FailureKind.DEADLINE_LATE)
        self.assertTrue(caught.exception.retryable)

    def test_deadline_expiry_inside_the_transport_is_a_deadline_failure(self):
        c = call(deadline_in=0.05)
        t = FakeTransport(raise_exc=DeadlineExpired("late"), delay=0.1)
        with self.assertRaises(ProviderError) as caught:
            self.make(t).generate(c)
        self.assertEqual(caught.exception.kind, FailureKind.DEADLINE_IN_CALL)

    def test_deadline_exception_raised_well_before_the_deadline_is_still_a_deadline_failure(self):
        t = FakeTransport(raise_exc=DeadlineExpired("late"))  # no delay: the time check alone cannot decide
        with self.assertRaises(ProviderError) as caught:
            self.make(t).generate(call(deadline_in=5.0))
        self.assertEqual(caught.exception.kind, FailureKind.DEADLINE_IN_CALL)

    def test_transport_failure_before_the_deadline_is_a_connection_failure(self):
        t = FakeTransport(raise_exc=OSError("boom"))
        with self.assertRaises(ProviderError) as caught:
            self.make(t).generate(call(deadline_in=5.0))
        self.assertEqual(caught.exception.kind, FailureKind.CONNECTION)
        self.assertTrue(caught.exception.retryable)
        self.assertNotIn("boom", str(caught.exception))

    # ---- cancellation limitation (characterization: the adapter cannot interrupt a transport that ignores timeouts)
    def test_a_transport_that_ignores_its_timeout_holds_the_call_until_it_returns(self):
        release = threading.Event()
        result = {}

        def hung(url, headers, body, timeout):
            release.wait(10)
            return 200, self.ok_body()

        def worker():
            try:
                result["value"] = self.make(hung).generate(call(deadline_in=0.2))
            except ProviderError as exc:  # pragma: no cover - reached only if the call returned early
                result["error"] = exc

        thread = threading.Thread(target=worker, daemon=True)
        thread.start()
        time.sleep(0.5)  # well past the deadline
        still_running = thread.is_alive()
        release.set()
        thread.join(5)
        self.assertTrue(still_running, "no cancellation: the call only returns when the transport returns")
        # Once released, the late response is refused by the post-deadline check, not returned as a success.
        self.assertIn("error", result)
        self.assertEqual(result["error"].kind, FailureKind.DEADLINE_LATE)

    # ---- close semantics
    def test_close_is_a_no_op_that_is_safe_to_repeat_and_adapter_still_serves_calls(self):
        adapter = self.make(FakeTransport(body=self.ok_body()))
        self.assertIsNone(adapter.close())
        self.assertIsNone(adapter.close())
        self.assertEqual(adapter.generate(call()).text, "hello")

    def test_invalid_model_id_is_refused_before_any_io(self):
        t = FakeTransport(body=self.ok_body())
        with self.assertRaises(ProviderError) as caught:
            self.make(t).generate(call(model="bad model!"))
        self.assertEqual(caught.exception.kind, FailureKind.INVALID_MODEL_ID)
        self.assertEqual(t.calls, [])


class AnthropicConformance(HttpAdapterConformance, unittest.TestCase):
    adapter_cls = ap.AnthropicProvider
    key_header = "x-api-key"
    max_field_path = ("max_tokens",)
    fails_closed_on_malformed = False  # returns an empty result, which the gateway rejects

    def ok_body(self, text="hello", model="reported-model-x"):
        return json.dumps({"model": model, "stop_reason": "end_turn",
                           "content": [{"type": "text", "text": text}],
                           "usage": {"input_tokens": 3, "output_tokens": 2, "cache_read_input_tokens": 0,
                                     "cache_creation_input_tokens": 0}}).encode()

    def incomplete_body(self):
        return json.dumps({"model": MODEL, "stop_reason": "max_tokens", "content": []}).encode()

    def test_usage_is_extracted_when_cache_fields_are_present(self):
        result = self.make(FakeTransport(body=self.ok_body())).generate(call())
        self.assertEqual(result.usage.output_tokens, 2)
        self.assertEqual(result.usage.input_tokens, 3)

    def test_usage_input_total_is_unknown_when_cache_fields_are_missing(self):
        body = json.dumps({"model": MODEL, "stop_reason": "end_turn", "content": [{"type": "text", "text": "x"}],
                           "usage": {"input_tokens": 3, "output_tokens": 2}}).encode()
        result = self.make(FakeTransport(body=body)).generate(call())
        self.assertIsNone(result.usage.input_tokens)

    def test_unlisted_stop_reason_such_as_refusal_fails_closed_as_incomplete(self):
        body = json.dumps({"model": MODEL, "stop_reason": "refusal", "content": []}).encode()
        self.assert_error(FailureKind.INCOMPLETE_RESPONSE, body=body)

    def test_rate_limit_without_structure_is_not_retried_as_transient(self):
        exc, t = self.assert_error(FailureKind.LIMIT_REACHED, body=b"{}", status=429, retry=False)
        self.assertEqual(len(t.calls), 1)

    def test_structured_transient_rate_limit_is_retryable_only_with_retry_after(self):
        body = json.dumps({"type": "error", "error": {"type": "rate_limit_error"}}).encode()
        t = FakeTransport(status=429, body=body)
        with self.assertRaises(ProviderError) as caught:
            self.make(t).generate(call())
        self.assertEqual(caught.exception.kind, FailureKind.LIMIT_REACHED)  # no retry-after header given


class GeminiConformance(HttpAdapterConformance, unittest.TestCase):
    adapter_cls = gp.GeminiProvider
    key_header = "x-goog-api-key"
    max_field_path = ("generationConfig", "maxOutputTokens")
    body_model_field = False
    fails_closed_on_malformed = True

    def ok_body(self, text="hello", model="reported-model-x"):
        return json.dumps({"candidates": [{"content": {"parts": [{"text": text}]}, "finishReason": "STOP"}],
                           "modelVersion": model,
                           "usageMetadata": {"promptTokenCount": 3, "candidatesTokenCount": 2,
                                             "totalTokenCount": 5}}).encode()

    def incomplete_body(self):
        return json.dumps({"candidates": [{"content": {"parts": [{"text": "x"}]}, "finishReason": "MAX_TOKENS"}]}).encode()

    def test_key_is_sent_in_the_goog_header_and_not_the_url(self):
        t = FakeTransport(body=self.ok_body())
        self.make(t).generate(call())
        self.assertEqual(t.calls[0]["headers"]["x-goog-api-key"], SECRET)
        self.assertNotIn("key=", t.calls[0]["url"])

    def test_usage_is_extracted_and_total_is_reported_only_with_reasoning_counts(self):
        result = self.make(FakeTransport(body=self.ok_body())).generate(call())
        self.assertEqual((result.usage.input_tokens, result.usage.output_tokens), (3, 2))
        # Documented in usage.py: the total is never derived without thoughtsTokenCount.
        self.assertIsNone(result.usage.total_tokens)
        with_thoughts = json.dumps({"candidates": [{"content": {"parts": [{"text": "x"}]}, "finishReason": "STOP"}],
                                    "usageMetadata": {"promptTokenCount": 3, "candidatesTokenCount": 2,
                                                      "thoughtsTokenCount": 1, "totalTokenCount": 6}}).encode()
        result = self.make(FakeTransport(body=with_thoughts)).generate(call())
        self.assertEqual((result.usage.output_tokens, result.usage.total_tokens), (3, 6))

    def test_prompt_block_is_content_blocked_not_incomplete(self):
        body = json.dumps({"promptFeedback": {"blockReason": "SAFETY"}}).encode()
        self.assert_error(FailureKind.CONTENT_BLOCKED, body=body)

    def test_candidate_safety_finish_is_content_blocked(self):
        body = json.dumps({"candidates": [{"content": {"parts": [{"text": "x"}]}, "finishReason": "SAFETY"}]}).encode()
        self.assert_error(FailureKind.CONTENT_BLOCKED, body=body)

    def test_unlisted_finish_reason_fails_closed(self):
        body = json.dumps({"candidates": [{"content": {"parts": [{"text": "x"}]}, "finishReason": "RECITATION"}]}).encode()
        self.assert_error(FailureKind.INCOMPLETE_RESPONSE, body=body)

    def test_unknown_block_reason_fails_closed(self):
        body = json.dumps({"promptFeedback": {"blockReason": "NEW_FUTURE_REASON"}}).encode()
        self.assert_error(FailureKind.INCOMPLETE_RESPONSE, body=body)


class GrokChatConformance(HttpAdapterConformance, unittest.TestCase):
    adapter_cls = grp.GrokProvider
    key_header = "authorization"
    max_field_path = ("max_tokens",)
    fails_closed_on_malformed = False

    def ok_body(self, text="hello", model="reported-model-x"):
        return json.dumps({"model": model, "choices": [{"finish_reason": "stop",
                                                        "message": {"content": text}}],
                           "usage": {"prompt_tokens": 3, "completion_tokens": 2, "total_tokens": 5}}).encode()

    def incomplete_body(self):
        return json.dumps({"model": MODEL, "choices": [{"finish_reason": "length", "message": {"content": "x"}}]}).encode()

    def test_bearer_header_carries_the_key(self):
        t = FakeTransport(body=self.ok_body())
        self.make(t).generate(call())
        self.assertEqual(t.calls[0]["headers"]["authorization"], f"Bearer {SECRET}")

    def test_usage_maps_prompt_and_completion_tokens(self):
        result = self.make(FakeTransport(body=self.ok_body())).generate(call())
        self.assertEqual((result.usage.input_tokens, result.usage.output_tokens, result.usage.total_tokens),
                         (3, 2, 5))

    def test_unknown_finish_reason_is_incomplete(self):
        body = json.dumps({"choices": [{"finish_reason": "content_filter", "message": {"content": "x"}}]}).encode()
        self.assert_error(FailureKind.INCOMPLETE_RESPONSE, body=body)


class XaiResponsesConformance(HttpAdapterConformance, unittest.TestCase):
    adapter_cls = xp.XaiResponsesProvider
    # Only 400, 401, 403, 404, 429 are documented for this surface. Other statuses fail closed (documented as unverified).
    status_cases = [(401, FailureKind.AUTHENTICATION, False), (403, FailureKind.PERMISSION, False),
                    (404, FailureKind.MODEL_NOT_FOUND, False), (400, FailureKind.REQUEST_REJECTED, False),
                    (500, FailureKind.CALL_FAILED, False)]
    key_header = "authorization"
    max_field_path = ("max_output_tokens",)
    fails_closed_on_malformed = True

    def ok_body(self, text="hello", model="reported-model-x"):
        return json.dumps({"model": model, "status": "completed",
                           "output": [{"type": "message", "status": "completed",
                                       "content": [{"type": "output_text", "text": text}]}],
                           "usage": {"input_tokens": 3, "output_tokens": 2, "total_tokens": 5}}).encode()

    def incomplete_body(self):
        return json.dumps({"model": MODEL, "status": "incomplete", "output": []}).encode()

    def test_store_is_sent_explicitly_as_false(self):
        t = FakeTransport(body=self.ok_body())
        self.make(t).generate(call())
        self.assertIs(json.loads(t.calls[0]["body"])["store"], False)

    def test_reasoning_items_are_skipped_and_message_text_is_kept(self):
        body = json.dumps({"model": MODEL, "status": "completed",
                           "output": [{"type": "reasoning", "summary": []},
                                      {"type": "message", "status": "completed",
                                       "content": [{"type": "output_text", "text": "answer"}]}]}).encode()
        self.assertEqual(self.make(FakeTransport(body=body)).generate(call()).text, "answer")

    def test_refusal_content_part_is_invalid_not_content(self):
        body = json.dumps({"model": MODEL, "status": "completed",
                           "output": [{"type": "message", "status": "completed",
                                       "content": [{"type": "refusal", "refusal": "no"}]}]}).encode()
        self.assert_error(FailureKind.INCOMPLETE_RESPONSE, body=body)

    def test_empty_text_is_invalid(self):
        body = json.dumps({"model": MODEL, "status": "completed",
                           "output": [{"type": "message", "status": "completed",
                                       "content": [{"type": "output_text", "text": "   "}]}]}).encode()
        self.assert_error(FailureKind.INCOMPLETE_RESPONSE, body=body)

    def test_error_object_in_a_200_body_is_incomplete(self):
        body = json.dumps({"error": {"message": "x"}, "status": "completed", "output": []}).encode()
        self.assert_error(FailureKind.INCOMPLETE_RESPONSE, body=body)


if __name__ == "__main__":
    unittest.main()
