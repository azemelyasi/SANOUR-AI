"""Stage 10.35 tests: model catalog, capability intelligence, profile management, identity.

Fake data only. No SDK, no network, no real key, no provider discovery. Waits are bounded.
"""

from tests.support import request_identity_for as _rid
import pathlib
import re
import threading
import time
import unittest

from pydantic import ValidationError

from sanour_ai.errors import ErrorCode, SanourError
from sanour_ai.models import capability_intelligence as ci
from sanour_ai.models.base import ModelCall, ModelResult
from sanour_ai.models.capabilities import (
    ModelCapabilities,
    ModelProfile,
    ProviderCapabilities,
)
from sanour_ai.models.gateway import ModelGateway
from sanour_ai.models.model_catalog import (
    CATEGORIES,
    CapabilityStatus,
    CatalogError,
    LifecycleStatus,
    ModelCatalog,
    ModelRecord,
    SourceKind,
    VerificationStatus,
    blank_capabilities,
    build_model_record,
)
from sanour_ai.models.profile_management import (
    ProfileError,
    ProfileRecord,
    ProfileRegistry,
    ProviderBinding,
    RequestLimits,
    TimeoutPolicy,
)
from sanour_ai.models.requests import SanourRequest
from sanour_ai.models.router import DeterministicRouter
from sanour_ai.providers import readiness
from sanour_ai.providers.openai_provider import OpenAIProvider

SRC = pathlib.Path(__file__).resolve().parents[2] / "src" / "sanour_ai"
SECRET = "STAGE1035-SECRET-KEY-ZZ"  # fake, test-only
OPENAI_BINDING = ProviderBinding("openai", "openai_responses", ProviderCapabilities(text_generation=True))


def operator_model(model_id="gpt-fake-1035", provider="openai", surface="openai_responses", **extra):
    fields = dict(model_id=model_id, provider_id=provider, vendor="openai", api_surface=surface,
                  display_name="Fake model", capabilities=blank_capabilities(),
                  lifecycle_status="active", verification_status="unverified",
                  source="operator_configuration")
    fields.update(extra)
    return build_model_record(**fields)


def profile(profile_id="fake_primary", model_id="gpt-fake-1035", **extra):
    fields = dict(profile_id=profile_id, provider_id="openai", model_id=model_id,
                  api_surface="openai_responses", capability_requirements=("text_generation",),
                  request_limits=RequestLimits(max_output_tokens=512, max_context_tokens=8192),
                  timeout_policy=TimeoutPolicy(default_seconds=10, max_seconds=60))
    fields.update(extra)
    return ProfileRecord(**fields)


def fresh():
    catalog = ModelCatalog()
    catalog.register_model(operator_model())
    return catalog, ProfileRegistry(catalog)


# ---------------------------------------------------------------- 1. model catalog: valid and invalid
class ModelCatalogTests(unittest.TestCase):
    def test_valid_model_registers_and_reads_back(self):
        catalog = ModelCatalog([operator_model()])
        self.assertEqual(catalog.get_model("openai", "gpt-fake-1035").display_name, "Fake model")
        self.assertEqual(catalog.version, 1)
        self.assertEqual(catalog.change_log, ((1, "register_model", "openai", "gpt-fake-1035"),))

    def test_invalid_model_is_rejected_and_names_fields_only(self):
        with self.assertRaises(CatalogError) as ctx:
            build_model_record(model_id="bad model " + SECRET, provider_id="openai", vendor="openai",
                               api_surface="openai_responses", display_name="x",
                               capabilities=blank_capabilities())
        message = str(ctx.exception)
        self.assertIn("model_id", message)
        self.assertNotIn(SECRET, message)
        self.assertNotIn("bad model", message)

    def test_unknown_api_surface_and_unknown_category_are_rejected(self):
        with self.assertRaises(CatalogError):
            operator_model(surface="made_up_surface")
        caps = blank_capabilities()
        caps["telepathy"] = CapabilityStatus.UNKNOWN
        with self.assertRaises(CatalogError):
            build_model_record(model_id="m-1", provider_id="openai", vendor="openai",
                               api_surface="openai_responses", display_name="x", capabilities=caps)

    def test_a_missing_category_is_rejected(self):
        caps = blank_capabilities()
        del caps["reasoning"]
        with self.assertRaises(CatalogError):
            build_model_record(model_id="m-1", provider_id="openai", vendor="openai",
                               api_surface="openai_responses", display_name="x", capabilities=caps)


# ---------------------------------------------------------------- 2. identity: duplicates and exactness
class ModelIdentityTests(unittest.TestCase):
    def test_same_identity_twice_is_refused(self):
        catalog = ModelCatalog([operator_model()])
        with self.assertRaises(CatalogError):
            catalog.register_model(operator_model())
        self.assertEqual(catalog.version, 1)

    def test_conflicting_identity_under_the_same_provider_is_refused(self):
        catalog = ModelCatalog([operator_model()])
        with self.assertRaises(CatalogError):
            catalog.register_model(operator_model(display_name="Other name"))

    def test_same_model_id_under_another_provider_is_a_different_model(self):
        catalog = ModelCatalog([operator_model()])
        other = operator_model(provider="anthropic", surface="anthropic_messages", vendor="anthropic")
        catalog.register_model(other)
        self.assertEqual(catalog.get_model("openai", "gpt-fake-1035").api_surface, "openai_responses")
        self.assertEqual(catalog.get_model("anthropic", "gpt-fake-1035").api_surface, "anthropic_messages")

    def test_model_id_is_stored_exactly_with_no_normalisation(self):
        catalog = ModelCatalog([operator_model(model_id="GPT-Fake-1035")])
        self.assertEqual(catalog.get_model("openai", "GPT-Fake-1035").model_id, "GPT-Fake-1035")
        with self.assertRaises(CatalogError):
            catalog.get_model("openai", "gpt-fake-1035")  # no case folding
        with self.assertRaises(ValidationError):
            ModelRecord.model_validate({**operator_model().model_dump(), "model_id": "gpt-fake-1035 "})

    def test_removed_model_cannot_be_registered_again(self):
        catalog = ModelCatalog([operator_model()])
        catalog.deactivate_model("openai", "gpt-fake-1035", authorized=True, reason="retired")
        with self.assertRaises(CatalogError):
            catalog.register_model(operator_model())
        self.assertEqual(catalog.get_model("openai", "gpt-fake-1035").lifecycle_status, LifecycleStatus.REMOVED)


# ---------------------------------------------------------------- 3. facts need sources; unknown stays unknown
class FactSourceTests(unittest.TestCase):
    def test_token_limit_without_documentation_is_refused(self):
        with self.assertRaises(CatalogError):
            build_model_record(model_id="m-1", provider_id="openai", vendor="openai",
                               api_surface="openai_responses", display_name="x",
                               capabilities=blank_capabilities(), context_window=8192,
                               source="unknown")

    def test_documented_capability_without_reference_is_refused(self):
        caps = blank_capabilities()
        caps["vision"] = CapabilityStatus.DOCUMENTED_ONLY
        with self.assertRaises(CatalogError):
            build_model_record(model_id="m-1", provider_id="openai", vendor="openai",
                               api_surface="openai_responses", display_name="x", capabilities=caps,
                               source="official_documentation")

    def test_documented_capability_needs_an_official_source(self):
        caps = blank_capabilities()
        caps["vision"] = CapabilityStatus.DOCUMENTED_ONLY
        with self.assertRaises(CatalogError):
            build_model_record(model_id="m-1", provider_id="openai", vendor="openai",
                               api_surface="openai_responses", display_name="x", capabilities=caps,
                               documentation_reference="some page", source="operator_configuration")

    def test_verified_cannot_be_stated_as_a_model_capability(self):
        caps = blank_capabilities()
        caps["vision"] = "VERIFIED"  # not a CapabilityStatus value
        with self.assertRaises(CatalogError):
            build_model_record(model_id="m-1", provider_id="openai", vendor="openai",
                               api_surface="openai_responses", display_name="x", capabilities=caps)

    def test_unknown_values_are_none_or_unknown_not_guessed(self):
        record = operator_model()
        self.assertIsNone(record.context_window)
        self.assertIsNone(record.output_token_limit)
        self.assertEqual(record.model_family, "unknown")
        self.assertEqual(record.model_version, "unknown")
        self.assertEqual(set(record.capabilities.values()), {CapabilityStatus.UNKNOWN})
        self.assertEqual(record.confidence, "operator_declared")
        self.assertEqual(record.verification_status, VerificationStatus.UNVERIFIED)

    def test_operator_models_cannot_state_capabilities(self):
        caps = blank_capabilities()
        caps["text_generation"] = CapabilityStatus.UNSUPPORTED
        with self.assertRaises(CatalogError):
            operator_model(capabilities=caps)


# ---------------------------------------------------------------- 4. catalog governance
class CatalogGovernanceTests(unittest.TestCase):
    def test_deactivation_needs_explicit_authorization(self):
        catalog = ModelCatalog([operator_model()])
        for bad in (False, None, 1, "yes"):
            with self.subTest(authorized=bad):
                with self.assertRaises(CatalogError):
                    catalog.deactivate_model("openai", "gpt-fake-1035", authorized=bad, reason="x")
        self.assertEqual(catalog.get_model("openai", "gpt-fake-1035").lifecycle_status, LifecycleStatus.ACTIVE)

    def test_deactivation_is_logged_and_idempotent(self):
        catalog = ModelCatalog([operator_model()])
        catalog.deactivate_model("openai", "gpt-fake-1035", authorized=True, reason="retired")
        catalog.deactivate_model("openai", "gpt-fake-1035", authorized=True, reason="retired")
        self.assertEqual(catalog.version, 2)
        self.assertEqual(catalog.change_log[-1][1], "deactivate_model")

    def test_frozen_catalog_refuses_every_write(self):
        catalog = ModelCatalog([operator_model()])
        catalog.freeze()
        with self.assertRaises(CatalogError):
            catalog.register_model(operator_model(model_id="other-1035"))
        with self.assertRaises(CatalogError):
            catalog.deactivate_model("openai", "gpt-fake-1035", authorized=True, reason="x")
        self.assertEqual(catalog.version, 1)

    def test_reader_view_has_no_write_methods(self):
        reader = ModelCatalog([operator_model()]).reader()
        self.assertFalse(hasattr(reader, "register_model"))
        self.assertFalse(hasattr(reader, "deactivate_model"))
        self.assertEqual(reader.get_model("openai", "gpt-fake-1035").model_id, "gpt-fake-1035")
        self.assertEqual(len(reader.list_models(active_only=True)), 1)  # the operator stated it is active

    def test_list_is_deterministic_and_filters_by_provider(self):
        catalog = ModelCatalog([operator_model("b-1035"), operator_model("a-1035"),
                                operator_model("z-1035", provider="anthropic", surface="anthropic_messages",
                                               vendor="anthropic")])
        self.assertEqual([r.model_id for r in catalog.list_models("openai")], ["a-1035", "b-1035"])


# ---------------------------------------------------------------- 5. profiles: valid, invalid, linked
class ProfileTests(unittest.TestCase):
    def test_valid_profile_registers_and_builds_a_router_profile(self):
        catalog, reg = fresh()
        reg.register_profile(profile(), OPENAI_BINDING)
        mp = reg.model_profile("fake_primary", OPENAI_BINDING)
        self.assertEqual((mp.alias, mp.provider, mp.model_id), ("fake_primary", "openai", "gpt-fake-1035"))
        self.assertTrue(mp.capabilities.text_generation)
        self.assertFalse(mp.runs_locally)

    def test_profile_verification_status_is_always_unverified(self):
        with self.assertRaises(ValidationError):
            profile(verification_status="verified")
        self.assertEqual(profile().verification_status, "unverified")

    def test_profile_linked_to_another_provider_is_refused(self):
        _catalog, reg = fresh()
        with self.assertRaises(ProfileError):
            reg.register_profile(profile(provider_id="anthropic"), OPENAI_BINDING)

    def test_profile_linked_to_an_unknown_model_is_refused(self):
        _catalog, reg = fresh()
        with self.assertRaises(ProfileError):
            reg.register_profile(profile(model_id="not-in-catalog"), OPENAI_BINDING)

    def test_profile_surface_must_match_adapter_and_model(self):
        _catalog, reg = fresh()
        other = ProviderBinding("openai", "grok_responses", ProviderCapabilities(text_generation=True))
        self.assertIn("profile API surface does not match the adapter",
                      reg.validate_profile(profile(api_surface="openai_responses"), other))

    def test_profile_must_require_text_generation(self):
        _catalog, reg = fresh()
        with self.assertRaises(ProfileError):
            reg.register_profile(profile(capability_requirements=("streaming",)), OPENAI_BINDING)

    def test_duplicate_profile_id_is_refused(self):
        _catalog, reg = fresh()
        reg.register_profile(profile(), OPENAI_BINDING)
        with self.assertRaises(ProfileError):
            reg.register_profile(profile(), OPENAI_BINDING)

    def test_profile_is_checked_against_documented_model_limits(self):
        catalog = ModelCatalog([build_model_record(
            model_id="gpt-doc-1035", provider_id="openai", vendor="openai", api_surface="openai_responses",
            display_name="Doc", capabilities=blank_capabilities(), output_token_limit=256,
            context_window=4096, documentation_reference="https://example.invalid/doc",
            source="official_documentation", verification_status="documented")])
        reg = ProfileRegistry(catalog)
        self.assertIn("request output limit exceeds the documented model limit",
                      reg.validate_profile(profile(model_id="gpt-doc-1035"), OPENAI_BINDING))

    def test_unknown_limits_are_not_invented(self):
        _catalog, reg = fresh()  # operator model: all documented limits unknown
        self.assertEqual(reg.validate_profile(profile(), OPENAI_BINDING), ())

    def test_request_output_cannot_exceed_context(self):
        with self.assertRaises(ValidationError):
            RequestLimits(max_output_tokens=9000, max_context_tokens=8192)


# ---------------------------------------------------------------- 6. capability validation, three levels
class CapabilityValidationTests(unittest.TestCase):
    def test_profile_cannot_require_a_capability_the_adapter_does_not_implement(self):
        _catalog, reg = fresh()
        with self.assertRaises(ProfileError):
            reg.register_profile(profile(capability_requirements=("text_generation", "streaming")), OPENAI_BINDING)

    def test_profile_cannot_require_a_category_with_no_adapter_flag(self):
        _catalog, reg = fresh()
        binding = ProviderBinding("openai", "openai_responses", ProviderCapabilities(text_generation=True,
                                                                                     streaming=True))
        with self.assertRaises(ProfileError):
            reg.register_profile(profile(capability_requirements=("text_generation", "reasoning")), binding)

    def test_profile_cannot_require_a_capability_the_model_says_is_unsupported(self):
        caps = blank_capabilities()
        caps["streaming"] = CapabilityStatus.UNSUPPORTED
        catalog = ModelCatalog([build_model_record(
            model_id="gpt-nostream-1035", provider_id="openai", vendor="openai", api_surface="openai_responses",
            display_name="x", capabilities=caps, documentation_reference="https://example.invalid/d",
            source="official_documentation")])
        reg = ProfileRegistry(catalog)
        binding = ProviderBinding("openai", "openai_responses",
                                  ProviderCapabilities(text_generation=True, streaming=True))
        with self.assertRaises(ProfileError):
            reg.register_profile(profile(model_id="gpt-nostream-1035",
                                         capability_requirements=("text_generation", "streaming")), binding)

    def test_three_levels_are_separate_and_no_built_in_capability_is_verified(self):
        for pid, cls in readiness.ADAPTERS.items():
            with self.subTest(provider=pid):
                table = ci.levels(pid, cls.surface, cls.capabilities)
                for category in CATEGORIES:
                    self.assertNotEqual(table[category][ci.Level.RUNTIME_VERIFIED], ci.Status.VERIFIED)
                    self.assertNotEqual(table[category][ci.Level.ADAPTER], ci.Status.VERIFIED)
                    self.assertNotEqual(table[category][ci.Level.PROVIDER_API], ci.Status.IMPLEMENTED_UNVERIFIED)
        self.assertEqual(ci.production_ready("openai", "openai_responses", OpenAIProvider.capabilities), ())

    def test_documentation_alone_is_never_verified_or_implemented(self):
        # vision is documented as supported on openai_responses, but the adapter does not implement it.
        status = ci.levels("openai", "openai_responses", OpenAIProvider.capabilities)["vision"]
        self.assertEqual(status[ci.Level.PROVIDER_API], ci.Status.DOCUMENTED_ONLY)
        self.assertEqual(status[ci.Level.ADAPTER], ci.Status.DOCUMENTED_ONLY)
        self.assertEqual(status[ci.Level.RUNTIME_VERIFIED], ci.Status.UNKNOWN)

    def test_unknown_category_stays_unknown(self):
        for category in ("json_mode", "embeddings", "video_input", "batch_processing", "file_input"):
            with self.subTest(category=category):
                self.assertEqual(ci.provider_api_status("openai_responses", category), ci.Status.UNKNOWN)

    def test_runtime_verified_needs_a_matching_evidence_record_with_a_test_reference(self):
        caps = OpenAIProvider.capabilities
        proof = ci.RuntimeEvidence("openai", "openai_responses", "text_generation", "tests/live/test_x.py::test_y",
                                   "gpt-x", "approved_live_verification", "live_provider_test",
                                   "2026-11-07T12:00:00Z", "VERIFIED")
        self.assertEqual(ci.runtime_status("openai", "openai_responses", "text_generation", caps, (proof,),
                                           model_id="gpt-x"), ci.Status.VERIFIED)
        # Same evidence, other model: not verified for the requested model.
        self.assertNotEqual(ci.runtime_status("openai", "openai_responses", "text_generation", caps, (proof,),
                                              model_id="gpt-y"), ci.Status.VERIFIED)
        # No model named: never verified.
        self.assertNotEqual(ci.runtime_status("openai", "openai_responses", "text_generation", caps, (proof,)),
                            ci.Status.VERIFIED)
        other = ci.RuntimeEvidence("anthropic", "openai_responses", "text_generation", "t", "gpt-x",
                                   "approved_live_verification", "live_provider_test", "2026-11-07T12:00:00Z",
                                   "VERIFIED")
        self.assertNotEqual(ci.runtime_status("openai", "openai_responses", "text_generation", caps, (other,),
                                              model_id="gpt-x"), ci.Status.VERIFIED)

    def test_blank_test_reference_is_inert(self):
        rec = ci.RuntimeEvidence("openai", "openai_responses", "text_generation", "  ", "gpt-x",
                                 "approved_live_verification", "live_provider_test", "2026-11-07T12:00:00Z",
                                 "VERIFIED")
        self.assertFalse(rec.is_verified_eligible())

    def test_evidence_moves_only_the_runtime_level(self):
        proof = ci.RuntimeEvidence("openai", "openai_responses", "text_generation", "t::x", "gpt-x",
                                   "approved_live_verification", "live_provider_test", "2026-11-07T12:00:00Z",
                                   "VERIFIED")
        table = ci.levels("openai", "openai_responses", OpenAIProvider.capabilities, (proof,))
        self.assertEqual(table["text_generation"][ci.Level.ADAPTER], ci.Status.IMPLEMENTED_UNVERIFIED)
        self.assertEqual(table["text_generation"][ci.Level.RUNTIME_VERIFIED], ci.Status.UNKNOWN)

    def test_capability_matrix_document_matches_the_generator(self):
        doc = (SRC.parents[1] / "docs" / "MODEL_CAPABILITY_MATRIX.md").read_text(encoding="utf-8")
        self.assertEqual(doc, readiness.render_capability_matrix_markdown())


# ---------------------------------------------------------------- 7. model identity at request time
class IdentityTests(unittest.TestCase):
    def _gateway(self, reported, allow=frozenset()):
        class Adapter:
            name = "openai"
            capabilities = ProviderCapabilities(text_generation=True)

            def generate(self, c):
                return ModelResult(text="ok", reported_model_id=reported)

        profile_obj = ModelProfile(alias="fake_primary", provider="openai", model_id="gpt-fake-1035",
                                   capabilities=ModelCapabilities(text_generation=True, max_context_tokens=64,
                                                                  max_output_tokens=16),
                                   accepted_reported_model_ids=allow)
        gw = ModelGateway({"openai": Adapter()}, max_concurrent_calls=1)
        return gw, profile_obj

    def _call(self):
        return ModelCall(model_id="gpt-fake-1035", prompt="hi", max_output_tokens=8,
                         deadline=time.monotonic() + 5)

    def test_matching_reported_identity_is_accepted(self):
        gw, prof = self._gateway("gpt-fake-1035")
        self.assertEqual(gw.generate(prof, self._call(), time.monotonic() + 5, identity=_rid(prof)).text, "ok")

    def test_mismatched_reported_identity_fails_closed(self):
        gw, prof = self._gateway("gpt-other-1035")
        from sanour_ai.errors import SanourError
        with self.assertRaises(SanourError) as ctx:
            gw.generate(prof, self._call(), time.monotonic() + 5, identity=_rid(prof))
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_INVALID_RESPONSE)
        self.assertNotIn("gpt-other-1035", str(ctx.exception))  # the provider's id is never echoed

    def test_exact_allowlist_accepts_only_its_listed_ids(self):
        gw, prof = self._gateway("gpt-fake-1035-2026-01-01", allow=frozenset({"gpt-fake-1035-2026-01-01"}))
        self.assertEqual(gw.generate(prof, self._call(), time.monotonic() + 5, identity=_rid(prof)).text, "ok")
        gw2, prof2 = self._gateway("gpt-fake-1035-2026-02-01", allow=frozenset({"gpt-fake-1035-2026-01-01"}))
        from sanour_ai.errors import SanourError
        with self.assertRaises(SanourError):
            gw2.generate(prof2, self._call(), time.monotonic() + 5, identity=_rid(prof2))

    def test_wildcards_and_patterns_are_refused_in_the_allowlist(self):
        _catalog, reg = fresh()
        for bad in ("gpt-*", "*", "gpt-fake-1035.*", "gpt-fake?"):
            with self.subTest(bad=bad):
                with self.assertRaises(ProfileError):
                    reg.register_profile(profile(profile_id="w_" + str(abs(hash(bad)) % 10000),
                                                 accepted_reported_model_ids=frozenset({bad})), OPENAI_BINDING)

    def test_empty_reported_identity_fails_closed(self):
        gw, prof = self._gateway("")
        from sanour_ai.errors import SanourError
        with self.assertRaises(SanourError):
            gw.generate(prof, self._call(), time.monotonic() + 5, identity=_rid(prof))

    def test_secret_never_appears_in_profile_errors(self):
        _catalog, reg = fresh()
        with self.assertRaises(ProfileError) as ctx:
            reg.register_profile(profile(accepted_reported_model_ids=frozenset({SECRET + "*"})), OPENAI_BINDING)
        self.assertNotIn(SECRET, str(ctx.exception))


# ---------------------------------------------------------------- 8. deactivation and request-time checks
class DeactivationTests(unittest.TestCase):
    def test_deactivated_model_cannot_serve_an_enabled_profile(self):
        catalog, reg = fresh()
        reg.register_profile(profile(), OPENAI_BINDING)
        catalog.deactivate_model("openai", "gpt-fake-1035", authorized=True, reason="retired")
        with self.assertRaises(ProfileError):
            reg.model_profile("fake_primary", OPENAI_BINDING)

    def test_deactivated_profile_is_refused_at_request_time(self):
        _catalog, reg = fresh()
        reg.register_profile(profile(), OPENAI_BINDING)
        reg.deactivate_profile("fake_primary", authorized=True, reason="pause")
        with self.assertRaises(ProfileError):
            reg.model_profile("fake_primary", OPENAI_BINDING)
        self.assertEqual(reg.list_profiles(enabled_only=True), ())

    def test_profile_deactivation_needs_authorization(self):
        _catalog, reg = fresh()
        reg.register_profile(profile(), OPENAI_BINDING)
        with self.assertRaises(ProfileError):
            reg.deactivate_profile("fake_primary", authorized=False, reason="pause")
        self.assertTrue(reg.get_profile("fake_primary").enabled)

    def test_disabled_profile_cannot_be_registered_on_a_removed_model(self):
        catalog, reg = fresh()
        catalog.deactivate_model("openai", "gpt-fake-1035", authorized=True, reason="retired")
        with self.assertRaises(ProfileError):
            reg.register_profile(profile(), OPENAI_BINDING)

    def test_frozen_profiles_refuse_every_write(self):
        _catalog, reg = fresh()
        reg.register_profile(profile(), OPENAI_BINDING)
        reg.freeze()
        with self.assertRaises(ProfileError):
            reg.register_profile(profile(profile_id="later_1035"), OPENAI_BINDING)
        with self.assertRaises(ProfileError):
            reg.deactivate_profile("fake_primary", authorized=True, reason="x")

    def test_catalog_changes_do_not_rewrite_registered_profiles(self):
        catalog, reg = fresh()
        reg.register_profile(profile(), OPENAI_BINDING)
        before = reg.get_profile("fake_primary")
        catalog.register_model(operator_model("second-1035"))
        self.assertEqual(reg.get_profile("fake_primary"), before)


# ---------------------------------------------------------------- 9. explicit selection, no fallback
class ExplicitSelectionTests(unittest.TestCase):
    def _request(self, alias, **extra):
        from sanour_ai.core.request_manager import accept
        raw = {"profile_alias": alias, "prompt": "hi", **extra}
        return accept(raw, "a" * 32)

    def test_router_resolves_exactly_the_named_profile(self):
        _catalog, reg = fresh()
        reg.register_profile(profile("alpha_1035", model_id="gpt-fake-1035"), OPENAI_BINDING)
        reg.register_profile(profile("beta_1035", model_id="gpt-fake-1035"), OPENAI_BINDING)
        router = DeterministicRouter([reg.model_profile(p, OPENAI_BINDING) for p in ("alpha_1035", "beta_1035")])
        self.assertEqual(router.resolve(self._request("beta_1035")).alias, "beta_1035")

    def test_unknown_alias_is_an_error_not_a_substitute(self):
        _catalog, reg = fresh()
        reg.register_profile(profile(), OPENAI_BINDING)
        router = DeterministicRouter([reg.model_profile("fake_primary", OPENAI_BINDING)])
        with self.assertRaises(SanourError) as ctx:
            router.resolve(self._request("no_such_profile"))
        self.assertEqual(ctx.exception.code, ErrorCode.NO_ELIGIBLE_MODEL)

    def test_capability_mismatch_is_an_error_not_a_substitute(self):
        _catalog, reg = fresh()
        reg.register_profile(profile("text_only_1035"), OPENAI_BINDING)
        router = DeterministicRouter([reg.model_profile("text_only_1035", OPENAI_BINDING)])
        with self.assertRaises(SanourError) as ctx:
            router.resolve(self._request("text_only_1035", required_capabilities=["image_input"]))
        self.assertEqual(ctx.exception.code, ErrorCode.NO_ELIGIBLE_MODEL)

    def test_production_path_never_calls_select(self):
        for part in ("core", "composition", "models/gateway.py", "models/model_catalog.py",
                     "models/profile_management.py"):
            target = SRC / part
            files = [target] if target.is_file() else list(target.rglob("*.py"))
            for path in files:
                with self.subTest(file=path.name):
                    self.assertNotIn(".select(", path.read_text(encoding="utf-8"))


# ---------------------------------------------------------------- 10. integration and preserved behaviour
class IntegrationTests(unittest.TestCase):
    def test_production_profile_comes_from_the_governed_path(self):
        from sanour_ai.composition import production
        from sanour_ai.config.governance import RuntimeConfig, load_runtime_config
        env = {"SANOUR_PROVIDER": "openai", "SANOUR_OPENAI_MODEL_ID": "gpt-prod-1035",
               "SANOUR_OPENAI_MAX_CONTEXT_TOKENS": "8192", "SANOUR_OPENAI_MAX_OUTPUT_TOKENS": "1024",
               "OPENAI_API_KEY": SECRET}
        config: RuntimeConfig = load_runtime_config(env)
        profile_obj = production._governed_profile(config)
        self.assertEqual((profile_obj.alias, profile_obj.model_id), ("openai_primary", "gpt-prod-1035"))
        self.assertEqual(profile_obj.capabilities.max_output_tokens, 1024)
        self.assertEqual(set(k for k, v in profile_obj.capabilities.model_dump().items() if v is True),
                         {"text_generation"})

    def test_model_catalog_and_profile_refuse_secret_in_their_errors(self):
        with self.assertRaises(CatalogError) as ctx:
            build_model_record(model_id=SECRET + " space", provider_id="openai", vendor="openai",
                               api_surface="openai_responses", display_name="x",
                               capabilities=blank_capabilities())
        self.assertNotIn(SECRET, str(ctx.exception))

    def test_no_model_is_registered_by_default(self):
        self.assertEqual(ModelCatalog().list_models(), ())

    def test_legacy_profile_catalog_still_works(self):
        from sanour_ai.models.catalog import ModelCatalog as LegacyCatalog
        legacy = LegacyCatalog(profiles=(ModelProfile(
            alias="legacy_1035", provider="openai", model_id="m",
            capabilities=ModelCapabilities(text_generation=True, max_context_tokens=8, max_output_tokens=4)),))
        self.assertEqual(legacy.profiles[0].alias, "legacy_1035")

    def test_concurrent_registration_of_one_identity_admits_exactly_one(self):
        catalog = ModelCatalog()
        results = []
        barrier = threading.Barrier(8)

        def attempt():
            barrier.wait(2.0)
            try:
                catalog.register_model(operator_model())
                results.append("ok")
            except CatalogError:
                results.append("refused")

        threads = [threading.Thread(target=attempt) for _ in range(8)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(3.0)
        self.assertEqual(results.count("ok"), 1)
        self.assertEqual(results.count("refused"), 7)


if __name__ == "__main__":
    unittest.main()
