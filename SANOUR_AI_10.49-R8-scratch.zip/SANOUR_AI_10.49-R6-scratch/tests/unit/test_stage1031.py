"""Stage 10.31 tests: unified provider registry, lifecycle, capability gating, composition root.

Fake adapters, fake transports, and fake SDK constructors only. No network, no real key, no SDK.
Waits are event-driven and bounded.
"""

from tests.support import request_identity_for as _rid
import threading
import time
import unittest
from unittest import mock

from pydantic import SecretStr

from sanour_ai.providers.offline_contract import OfflineTestProvider
from sanour_ai.composition import production
from sanour_ai.config.settings import ConfigError
from sanour_ai.core.sanour_core import SanourCore
from sanour_ai.errors import ErrorCode, SanourError
from sanour_ai.models import provider_matrix as pm
from sanour_ai.models.base import ModelCall, ModelResult, ProviderError
from sanour_ai.models.capabilities import CAPABILITY_FLAGS, ModelCapabilities, ModelProfile, ProviderCapabilities
from sanour_ai.models.gateway import ModelGateway
from sanour_ai.models.router import DeterministicRouter
from sanour_ai.providers.anthropic_provider import AnthropicProvider
from sanour_ai.providers.gemini_provider import GeminiProvider
from sanour_ai.providers.grok_provider import GrokProvider
from sanour_ai.providers.registry import VENDOR_SURFACES, ProviderRegistry, ProviderState, RegistryError
from sanour_ai.providers.xai_responses_provider import XaiResponsesProvider
from tests.support import deadline_in, wait_until

SECRET = "STAGE1031-SECRET-KEY-QQ"
TEXT_ONLY = ProviderCapabilities(text_generation=True)


class FakeAdapter:
    """Fake provider: counts calls and closes, can block a worker, and can fail close or init."""

    def __init__(self, name, caps=TEXT_ONLY, *, close_error=None, init_error=None, block=False):
        self.name = name
        self.capabilities = caps
        self.close_error, self.init_error, self.block = close_error, init_error, block
        self.lock = threading.Lock()
        self.calls = 0
        self.closes = 0
        self.inits = 0
        self.started = threading.Event()
        self.release = threading.Event()

    def initialize(self):
        with self.lock:
            self.inits += 1
        if self.init_error is not None:
            raise self.init_error

    def generate(self, call):
        with self.lock:
            self.calls += 1
        if self.block:
            self.started.set()
            self.release.wait(5)
        return ModelResult(text="ok", reported_model_id=call.model_id)

    def close(self):
        with self.lock:
            self.closes += 1
        if self.close_error is not None:
            raise self.close_error


def gateway_for(registry, max_calls=2):
    return ModelGateway(registry.ready_providers(), max_concurrent_calls=max_calls)


def profile(provider, alias="p_profile", model_id="m-1031", flags=None, priority=100):
    caps = dict(text_generation=True, max_context_tokens=8192, max_output_tokens=4096)
    caps.update(flags or {})
    return ModelProfile(alias=alias, provider=provider, model_id=model_id,
                        capabilities=ModelCapabilities(**caps), priority=priority)


def call(model="m-1031"):
    return ModelCall(model_id=model, prompt="hi", max_output_tokens=16, deadline=time.monotonic() + 5)


# ---------------------------------------------------------------- registration
class RegistrationTests(unittest.TestCase):
    def test_register_then_initialize_makes_provider_ready(self):
        reg = ProviderRegistry()
        reg.register("openai", vendor="openai", surface="openai_responses", adapter=FakeAdapter("openai"))
        self.assertEqual(reg.state("openai"), ProviderState.REGISTERED)
        self.assertEqual(reg.ready_providers(), {})  # registered is not ready
        reg.initialize("openai")
        self.assertEqual(reg.state("openai"), ProviderState.READY)
        self.assertEqual(set(reg.ready_providers()), {"openai"})
        self.assertEqual(reg.describe("openai"), {"provider_id": "openai", "vendor": "openai",
                                                  "surface": "openai_responses", "state": "ready"})

    def test_duplicate_id_is_refused(self):
        reg = ProviderRegistry()
        reg.register("openai", vendor="openai", surface="openai_responses", adapter=FakeAdapter("openai"))
        with self.assertRaises(RegistryError):
            reg.register("openai", vendor="openai", surface="openai_responses", adapter=FakeAdapter("openai"))

    def test_invalid_id_is_refused_without_echoing_it(self):
        reg = ProviderRegistry()
        bad = f"Bad-{SECRET}"
        with self.assertRaises(RegistryError) as ctx:
            reg.register(bad, vendor="openai", surface="openai_responses", adapter=FakeAdapter("x"))
        self.assertNotIn(SECRET, str(ctx.exception))

    def test_unknown_vendor_and_unknown_surface_are_refused(self):
        reg = ProviderRegistry()
        with self.assertRaises(RegistryError):
            reg.register("acme", vendor="acme", surface="openai_responses", adapter=FakeAdapter("acme"))
        with self.assertRaises(RegistryError):
            reg.register("openai", vendor="openai", surface="no_such_surface", adapter=FakeAdapter("openai"))

    def test_incompatible_vendor_and_surface_are_refused(self):
        reg = ProviderRegistry()
        with self.assertRaises(RegistryError) as ctx:
            reg.register("openai", vendor="openai", surface="anthropic_messages", adapter=FakeAdapter("openai"))
        self.assertIn("does not belong", str(ctx.exception))

    def test_adapter_name_must_equal_provider_id(self):
        reg = ProviderRegistry()
        with self.assertRaises(RegistryError):
            reg.register("openai", vendor="openai", surface="openai_responses", adapter=FakeAdapter("other"))

    def test_adapter_without_generate_or_contract_is_refused(self):
        reg = ProviderRegistry()
        broken = SimpleAdapter()
        with self.assertRaises(RegistryError):
            reg.register("openai", vendor="openai", surface="openai_responses", adapter=broken)
        bad_caps = FakeAdapter("openai")
        bad_caps.capabilities = {"text_generation": True}
        with self.assertRaises(RegistryError):
            reg.register("openai", vendor="openai", surface="openai_responses", adapter=bad_caps)

    def test_unverified_or_unsupported_capabilities_are_refused_at_registration(self):
        reg = ProviderRegistry()
        cases = [
            ("gemini", "google", "gemini_generate_content", ProviderCapabilities(text_generation=True, streaming=True)),
            ("gemini", "google", "gemini_generate_content", ProviderCapabilities(text_generation=True, tool_calling=True)),
            ("openai", "openai", "openai_responses", ProviderCapabilities(text_generation=True, video_output=True)),
            ("grok", "xai", "grok_chat_completions", ProviderCapabilities(text_generation=True,
                                                                           structured_output=True)),
        ]
        for pid, vendor, surface, caps in cases:
            with self.subTest(pid=pid, surface=surface):
                with self.assertRaises(RegistryError) as ctx:
                    reg.register(pid, vendor=vendor, surface=surface, adapter=FakeAdapter(pid, caps))
                self.assertIn("not verified", str(ctx.exception))
        self.assertEqual(reg.states(), {})  # nothing was half-registered

    def test_verified_capabilities_are_accepted(self):
        reg = ProviderRegistry()
        reg.register("anthropic", vendor="anthropic", surface="anthropic_messages",
                     adapter=FakeAdapter("anthropic", ProviderCapabilities(text_generation=True, streaming=True,
                                                                           tool_calling=True)))
        self.assertIn("anthropic", reg.states())

    def test_remove_rules(self):
        reg = ProviderRegistry()
        reg.register("openai", vendor="openai", surface="openai_responses", adapter=FakeAdapter("openai"))
        reg.remove("openai")  # registered: removable
        self.assertEqual(reg.states(), {})
        reg.register("openai", vendor="openai", surface="openai_responses", adapter=FakeAdapter("openai"))
        reg.initialize("openai")
        with self.assertRaises(RegistryError):
            reg.remove("openai")  # ready: must shut down first

    def test_unknown_provider_operations_are_refused(self):
        reg = ProviderRegistry()
        for op in (lambda: reg.state("ghost"), lambda: reg.describe("ghost"),
                   lambda: reg.initialize("ghost"), lambda: reg.remove("ghost")):
            with self.assertRaises(RegistryError):
                op()

    def test_surface_table_is_consistent_with_the_matrix(self):
        for vendor, surfaces in VENDOR_SURFACES.items():
            for surface in surfaces:
                self.assertIn(surface, pm.MATRIX, vendor)
        for flag in CAPABILITY_FLAGS:
            # Every ModelCapabilities flag is either mapped to a matrix row or refused as unknown.
            self.assertTrue(flag in pm.PROVIDER_FLAG_TO_CAPABILITY or flag == "video_output", flag)


class SimpleAdapter:
    name = "openai"
    capabilities = TEXT_ONLY


class RealAdapterRegistrationTests(unittest.TestCase):
    def test_every_real_adapter_registers_with_an_explicit_vendor_and_surface(self):
        reg = ProviderRegistry()
        key = SecretStr("STAGE1031-TESTONLY")
        t = lambda *a, **k: (200, b"{}")  # never called: registration does no I/O
        reg.register("anthropic", vendor="anthropic", surface="anthropic_messages",
                     adapter=AnthropicProvider(key, transport=t))
        reg.register("gemini", vendor="google", surface="gemini_generate_content",
                     adapter=GeminiProvider(key, transport=t))
        reg.register("grok", vendor="xai", surface="grok_chat_completions", adapter=GrokProvider(key, transport=t))
        reg.register("grok_responses", vendor="xai", surface="grok_responses",
                     adapter=XaiResponsesProvider(key, transport=t))
        self.assertEqual(set(reg.states()), {"anthropic", "gemini", "grok", "grok_responses"})
        for pid in reg.states():
            reg.initialize(pid)
        self.assertEqual(len(reg.ready_providers()), 4)

    def test_profile_validation_uses_the_surface_of_the_provider(self):
        reg = ProviderRegistry()
        reg.register("gemini", vendor="google", surface="gemini_generate_content", adapter=FakeAdapter("gemini"))
        reg.initialize("gemini")
        reg.validate_profile("gemini", {f: f == "text_generation" for f in CAPABILITY_FLAGS})
        with self.assertRaises(RegistryError):
            reg.validate_profile("gemini", {f: f in ("text_generation", "streaming") for f in CAPABILITY_FLAGS})


# ---------------------------------------------------------------- lifecycle
class LifecycleTests(unittest.TestCase):
    def test_full_lifecycle_registered_ready_closed(self):
        reg = ProviderRegistry()
        adapter = FakeAdapter("openai")
        reg.register("openai", vendor="openai", surface="openai_responses", adapter=adapter)
        reg.initialize("openai")
        gw = gateway_for(reg)
        self.assertEqual(gw.generate(profile("openai", model_id="m-1031"), call(), deadline_in(2.0), identity=_rid(profile("openai", model_id="m-1031"))).text, "ok")
        states = reg.shutdown(gw, timeout=1.0)
        self.assertEqual(states, {"openai": "closed"})
        self.assertEqual((adapter.inits, adapter.closes), (1, 1))

    def test_initialization_failure_is_failed_and_not_ready(self):
        reg = ProviderRegistry()
        secret_error = RuntimeError(SECRET)
        reg.register("openai", vendor="openai", surface="openai_responses",
                     adapter=FakeAdapter("openai", init_error=secret_error))
        with self.assertRaises(RegistryError) as ctx:
            reg.initialize("openai")
        self.assertEqual(str(ctx.exception), "provider initialization failed")
        self.assertNotIn(SECRET, repr(ctx.exception))
        self.assertEqual(reg.state("openai"), ProviderState.FAILED)
        self.assertEqual(reg.ready_providers(), {})
        with self.assertRaises(RegistryError):
            reg.initialize("openai")  # a failed provider is not re-initialized silently

    def test_double_initialize_is_refused(self):
        reg = ProviderRegistry()
        reg.register("openai", vendor="openai", surface="openai_responses", adapter=FakeAdapter("openai"))
        reg.initialize("openai")
        with self.assertRaises(RegistryError):
            reg.initialize("openai")

    def test_closed_provider_refuses_requests(self):
        reg = ProviderRegistry()
        reg.register("openai", vendor="openai", surface="openai_responses", adapter=FakeAdapter("openai"))
        reg.initialize("openai")
        gw = gateway_for(reg)
        reg.shutdown(gw, timeout=0.5)
        with self.assertRaises(SanourError) as ctx:
            gw.generate(profile("openai"), call(), deadline_in(2.0), identity=_rid(profile("openai")))
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_FAILED)
        self.assertEqual(reg.ready_providers(), {})

    def test_repeated_shutdown_releases_each_provider_once(self):
        reg = ProviderRegistry()
        a = FakeAdapter("openai")
        reg.register("openai", vendor="openai", surface="openai_responses", adapter=a)
        reg.initialize("openai")
        gw = gateway_for(reg)
        for _ in range(4):
            reg.shutdown(gw, timeout=0.1)
        self.assertEqual(a.closes, 1)
        self.assertEqual(reg.state("openai"), ProviderState.CLOSED)

    def test_concurrent_shutdown_closes_once_and_raises_nothing(self):
        reg = ProviderRegistry()
        adapters = [FakeAdapter(f"p{i}") for i in range(3)]
        for a in adapters:
            reg.register(a.name, vendor="openai", surface="openai_responses", adapter=a)
            reg.initialize(a.name)
        gw = gateway_for(reg, max_calls=3)
        errors = []

        def shut():
            try:
                reg.shutdown(gw, timeout=0.2)
            except Exception as exc:  # collected, asserted empty below
                errors.append(exc)

        threads = [threading.Thread(target=shut) for _ in range(6)]
        for th in threads:
            th.start()
        for th in threads:
            th.join(5)
        self.assertEqual(errors, [])
        self.assertTrue(all(a.closes == 1 for a in adapters), [a.closes for a in adapters])
        self.assertEqual(set(reg.states().values()), {"closed"})

    def test_close_error_is_isolated_and_visible(self):
        reg = ProviderRegistry()
        bad = FakeAdapter("bad", close_error=RuntimeError(SECRET))
        good = FakeAdapter("good")
        for a in (bad, good):
            reg.register(a.name, vendor="openai", surface="openai_responses", adapter=a)
            reg.initialize(a.name)
        gw = gateway_for(reg)
        states = reg.shutdown(gw, timeout=0.2)
        self.assertEqual(states, {"bad": "failed", "good": "closed"})
        self.assertEqual(good.closes, 1)
        self.assertEqual(bad.closes, 1)
        reg.shutdown(gw, timeout=0.2)
        self.assertEqual((bad.closes, good.closes), (1, 1))  # a failed close is not retried

    def test_active_worker_keeps_provider_closing_until_it_really_ends(self):
        reg = ProviderRegistry()
        busy = FakeAdapter("busy", block=True)
        reg.register("busy", vendor="openai", surface="openai_responses", adapter=busy)
        reg.initialize("busy")
        gw = gateway_for(reg, max_calls=1)
        result = {}
        th = threading.Thread(target=lambda: result.update(
            r=gw.generate(profile("busy"), call(), deadline_in(5.0), identity=_rid(profile("busy")))))
        th.start()
        self.assertTrue(busy.started.wait(5))
        self.assertEqual(reg.shutdown(gw, timeout=0.05), {"busy": "closing"})
        self.assertEqual(busy.closes, 0)  # never closed under a live worker
        busy.release.set()
        th.join(5)
        self.assertEqual(result["r"].text, "ok")
        self.assertEqual(reg.shutdown(gw, timeout=1.0), {"busy": "closed"})
        self.assertEqual(busy.closes, 1)

    def test_registered_but_never_initialized_provider_is_closed_directly(self):
        reg = ProviderRegistry()
        a = FakeAdapter("openai")
        reg.register("openai", vendor="openai", surface="openai_responses", adapter=a)
        gw = gateway_for(reg)
        self.assertEqual(reg.shutdown(gw, timeout=0.1), {"openai": "closed"})
        self.assertEqual(a.closes, 1)

    def test_shutdown_refuses_new_registrations_implicitly_via_state(self):
        reg = ProviderRegistry()
        reg.register("openai", vendor="openai", surface="openai_responses", adapter=FakeAdapter("openai"))
        reg.initialize("openai")
        gw = gateway_for(reg)
        reg.shutdown(gw, timeout=0.1)
        with self.assertRaises(RegistryError):
            reg.initialize("openai")


# ---------------------------------------------------------------- no fallback, no auto-select, no leaks
class RoutingAndSecrecyTests(unittest.TestCase):
    def test_request_uses_exactly_its_profile_and_never_another_provider(self):
        reg = ProviderRegistry()
        a, b = FakeAdapter("openai"), FakeAdapter("grok_responses")
        reg.register("openai", vendor="openai", surface="openai_responses", adapter=a)
        reg.register("grok_responses", vendor="xai", surface="grok_responses", adapter=b)
        reg.initialize("openai")
        reg.initialize("grok_responses")
        router = DeterministicRouter([profile("openai", alias="p_one", priority=0),
                                      profile("grok_responses", alias="p_two", model_id="g-1", priority=1)])
        core = SanourCore(router=router, gateway=gateway_for(reg))
        response = core.handle({"profile_alias": "p_one", "prompt": "hi"})
        self.assertEqual(response.status, "success")
        self.assertEqual((a.calls, b.calls), (1, 0))

    def test_unknown_alias_is_refused_not_substituted(self):
        reg = ProviderRegistry()
        a = FakeAdapter("openai")
        reg.register("openai", vendor="openai", surface="openai_responses", adapter=a)
        reg.initialize("openai")
        core = SanourCore(router=DeterministicRouter([profile("openai", alias="p_one")]), gateway=gateway_for(reg))
        response = core.handle({"profile_alias": "p_missing", "prompt": "hi"})
        self.assertEqual(response.status, "error")
        self.assertEqual(a.calls, 0)

    def test_registry_errors_never_echo_secrets(self):
        reg = ProviderRegistry()
        cases = [
            lambda: reg.register(f"x-{SECRET}", vendor="openai", surface="openai_responses", adapter=FakeAdapter("y")),
            lambda: reg.register("openai", vendor=SECRET, surface="openai_responses", adapter=FakeAdapter("openai")),
            lambda: reg.register("openai", vendor="openai", surface=SECRET, adapter=FakeAdapter("openai")),
            lambda: reg.initialize(SECRET),
        ]
        for op in cases:
            with self.subTest():
                with self.assertRaises(RegistryError) as ctx:
                    op()
                self.assertNotIn(SECRET, str(ctx.exception))
                self.assertNotIn(SECRET, repr(ctx.exception))


# ---------------------------------------------------------------- composition root
class _FakeOpenAI(OfflineTestProvider):
    name = "openai"
    capabilities = TEXT_ONLY
    vendor = "openai"
    surface = "openai_responses"
    auth_method = "sdk_bearer_client"
    instances = []

    def __init__(self, api_key):
        self.key = api_key
        _FakeOpenAI.instances.append(self)

    def generate(self, call):
        return ModelResult(text="fake", reported_model_id=call.model_id)

    def close(self):
        pass


def production_env(**extra):
    env = {
        "SANOUR_PROVIDER": "openai",
        "SANOUR_OPENAI_MODEL_ID": "gpt-test-1031",
        "SANOUR_OPENAI_MAX_CONTEXT_TOKENS": "8192",
        "SANOUR_OPENAI_MAX_OUTPUT_TOKENS": "1024",
        "OPENAI_API_KEY": SECRET,
    }
    env.update(extra)
    return env


class CompositionRootTests(unittest.TestCase):
    def test_no_provider_without_explicit_setting(self):
        env = production_env()
        del env["SANOUR_PROVIDER"]
        with self.assertRaises(ConfigError):
            production.build_test_core(env)

    def test_only_openai_is_registered_and_xai_responses_is_absent(self):
        _FakeOpenAI.instances.clear()
        with mock.patch.object(production, "OpenAIProvider", _FakeOpenAI), mock.patch.object(production, "_default_test_provider", lambda: _FakeOpenAI("test")), \
                mock.patch.object(production, "_sdk_present", return_value=True):
            core = production.build_test_core(production_env())
        providers = set(core._gateway._providers)  # noqa: SLF001 (test-only inspection)
        self.assertEqual(providers, {"openai"})
        self.assertNotIn("grok_responses", providers)
        self.assertEqual(len(_FakeOpenAI.instances), 1)

    def test_composed_core_answers_only_through_the_configured_profile(self):
        with mock.patch.object(production, "OpenAIProvider", _FakeOpenAI), mock.patch.object(production, "_default_test_provider", lambda: _FakeOpenAI("test")), \
                mock.patch.object(production, "_sdk_present", return_value=True):
            core = production.build_test_core(production_env())
        response = core.handle({"profile_alias": production.OPENAI_ALIAS, "prompt": "hi"})
        self.assertEqual(response.status, "success")
        self.assertEqual(response.model_alias, production.OPENAI_ALIAS)
        other = core.handle({"profile_alias": "grok_responses_profile", "prompt": "hi"})
        self.assertEqual(other.status, "error")

    def test_missing_sdk_still_fails_closed_with_config_error(self):
        with mock.patch.object(production, "_sdk_present", return_value=False):
            with self.assertRaises(ConfigError):
                production.build_production_core(production_env())


if __name__ == "__main__":
    unittest.main()
