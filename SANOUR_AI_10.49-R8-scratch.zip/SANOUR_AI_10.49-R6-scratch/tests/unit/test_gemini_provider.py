"""Gemini adapter tests. Fake transport only: no network, no real key, no SDK."""

from tests.support import request_identity_for as _rid
import json
import time
import unittest
import urllib.error
import urllib.request

from pydantic import SecretStr

from sanour_ai.config.settings import ConfigError
from sanour_ai.errors import ErrorCode, SanourError
from sanour_ai.models.base import ModelCall, ModelResult, ProviderError
from sanour_ai.providers.common import IncompleteResponseError
from sanour_ai.models.capabilities import ModelCapabilities, ModelProfile, ProviderCapabilities
from sanour_ai.models.gateway import ModelGateway
from sanour_ai.providers.gemini_provider import (
    PINNED_BASE,
    GeminiProvider,
    _RefuseRedirects,
    load_gemini_api_key,
)

FAKE_KEY = "AIza-TESTONLY-0123456789"
MODEL = "gemini-test-1"


class FakeTransport:
    def __init__(self, status=200, body=None, raise_exc=None):
        self.status = status
        self.body = body if body is not None else self._ok_body()
        self.raise_exc = raise_exc
        self.calls = []

    @staticmethod
    def _ok_body(text="hello", model=MODEL):
        return json.dumps({
            "candidates": [{"content": {"parts": [{"text": text}]}, "finishReason": "STOP"}],
            "modelVersion": model,
        }).encode("utf-8")

    def __call__(self, url, headers, body, timeout):
        self.calls.append({"url": url, "headers": headers, "body": body, "timeout": timeout})
        if self.raise_exc is not None:
            raise self.raise_exc
        return self.status, self.body


def call(deadline_in=5.0, model=MODEL, max_tokens=64, prompt="hi"):
    return ModelCall(model_id=model, prompt=prompt, max_output_tokens=max_tokens,
                     deadline=time.monotonic() + deadline_in)


def make(transport):
    return GeminiProvider(SecretStr(FAKE_KEY), transport=transport)


class CapabilityDeclarationTests(unittest.TestCase):
    def test_declares_only_text_generation(self):
        self.assertEqual(GeminiProvider.capabilities, ProviderCapabilities(text_generation=True))
        self.assertEqual(GeminiProvider.name, "gemini")


class AuthenticationTests(unittest.TestCase):
    def test_key_read_from_environment_and_stripped(self):
        self.assertEqual(load_gemini_api_key({"GEMINI_API_KEY": " abc "}).get_secret_value(), "abc")

    def test_missing_or_blank_key_names_setting_not_value(self):
        for env in ({}, {"GEMINI_API_KEY": "  "}):
            with self.subTest(env=env), self.assertRaises(ConfigError) as ctx:
                load_gemini_api_key(env)
            self.assertIn("GEMINI_API_KEY", str(ctx.exception))

    def test_adapter_requires_secret_str_with_content(self):
        with self.assertRaises(ConfigError):
            GeminiProvider("plain", transport=FakeTransport())
        with self.assertRaises(ConfigError):
            GeminiProvider(SecretStr(" "), transport=FakeTransport())


class RequestShapeTests(unittest.TestCase):
    def test_pinned_path_key_in_header_not_url(self):
        t = FakeTransport()
        make(t).generate(call())
        sent = t.calls[0]
        self.assertEqual(sent["url"], f"{PINNED_BASE}{MODEL}:generateContent")
        self.assertNotIn(FAKE_KEY, sent["url"])
        self.assertEqual(sent["headers"]["x-goog-api-key"], FAKE_KEY)
        self.assertNotIn("key=", sent["url"])

    def test_body_carries_prompt_and_output_limit(self):
        t = FakeTransport()
        make(t).generate(call(max_tokens=64, prompt="ping"))
        self.assertEqual(json.loads(t.calls[0]["body"]), {
            "contents": [{"role": "user", "parts": [{"text": "ping"}]}],
            "generationConfig": {"maxOutputTokens": 64},
        })

    def test_timeout_is_min_of_cap_and_remaining_budget(self):
        t = FakeTransport()
        make(t).generate(call(deadline_in=2.0))
        self.assertLessEqual(t.calls[0]["timeout"], 2.0)
        self.assertGreater(t.calls[0]["timeout"], 1.0)

    def test_missing_deadline_refused_before_io(self):
        t = FakeTransport()
        with self.assertRaises(ProviderError):
            make(t).generate(ModelCall(model_id=MODEL, prompt="p", max_output_tokens=8, deadline=None))
        self.assertEqual(t.calls, [])

    def test_expired_deadline_makes_no_call(self):
        t = FakeTransport()
        with self.assertRaises(ProviderError) as ctx:
            make(t).generate(ModelCall(model_id=MODEL, prompt="p", max_output_tokens=8,
                                       deadline=time.monotonic() - 1))
        self.assertTrue(ctx.exception.retryable)
        self.assertEqual(t.calls, [])

    def test_model_id_cannot_change_the_path(self):
        for bad in ("../other", "a/b", "x?key=1", "", "m" * 129, "name with space"):
            with self.subTest(bad=bad):
                t = FakeTransport()
                with self.assertRaises(ProviderError) as ctx:
                    make(t).generate(call(model=bad))
                self.assertFalse(ctx.exception.retryable)
                self.assertEqual(t.calls, [])


class ResponseParsingTests(unittest.TestCase):
    def test_text_parts_joined_and_model_version_echoed(self):
        body = json.dumps({"candidates": [{"content": {"parts": [
            {"text": "one "}, {"thoughtSignature": "opaque"}, {"text": "two"}]}, "finishReason": "STOP"}],
            "modelVersion": MODEL}).encode()
        self.assertEqual(make(FakeTransport(body=body)).generate(call()), ModelResult(text="one two", reported_model_id=MODEL))

    def test_unexpected_part_is_refused_not_ignored(self):
        body = json.dumps({"candidates": [{"content": {"parts": [
            {"text": "one "}, {"functionCall": {}}]}, "finishReason": "STOP"}],
            "modelVersion": MODEL}).encode()
        with self.assertRaises(IncompleteResponseError):
            make(FakeTransport(body=body)).generate(call())

    def test_malformed_bodies_are_refused_as_incomplete(self):
        for body in (b"not json", b"[]", b'{"candidates": []}'):
            with self.subTest(body=body), self.assertRaises(IncompleteResponseError):
                make(FakeTransport(body=body)).generate(call())

    def test_oversized_response_refused(self):
        with self.assertRaises(ProviderError):
            make(FakeTransport(body=b"x" * 2_000_001)).generate(call())


class ErrorMappingTests(unittest.TestCase):
    def test_status_codes_map_to_expected_retryability(self):
        cases = [(429, False), (401, False), (403, False), (404, False), (400, False),
                 (500, True), (503, True), (418, False)]
        for status, retryable in cases:
            with self.subTest(status=status):
                with self.assertRaises(ProviderError) as ctx:
                    make(FakeTransport(status=status, body=b"")).generate(call())
                self.assertEqual(ctx.exception.retryable, retryable)

    def test_unknown_429_is_not_transient(self):
        # Stage 10.28: no structural 429 code is confirmed for this provider, so it is unknown.
        with self.assertRaises(ProviderError) as ctx:
            make(FakeTransport(status=429, body=b"")).generate(call())
        self.assertIsNone(getattr(ctx.exception, "error_code", None))
        self.assertEqual(ctx.exception.failure_reason, "unknown")
        self.assertFalse(ctx.exception.retryable)

    def test_network_failure_retryable_and_hides_details(self):
        t = FakeTransport(raise_exc=urllib.error.URLError("dns failed for internal-host AIza-LEAKME"))
        with self.assertRaises(ProviderError) as ctx:
            make(t).generate(call())
        self.assertTrue(ctx.exception.retryable)
        self.assertNotIn("LEAKME", str(ctx.exception))

    def test_error_body_and_key_never_reach_exception_text(self):
        t = FakeTransport(status=401, body=b'{"error": "bad AIza-SECRETBODY"}')
        with self.assertRaises(ProviderError) as ctx:
            make(t).generate(call())
        text = str(ctx.exception) + repr(ctx.exception)
        self.assertNotIn("SECRETBODY", text)
        self.assertNotIn(FAKE_KEY, text)

    def test_redirects_are_refused(self):
        with self.assertRaises(urllib.error.HTTPError):
            _RefuseRedirects().redirect_request(urllib.request.Request(PINNED_BASE), None, 302, "Found", {},
                                                "https://evil.example/")


class GatewayIntegrationTests(unittest.TestCase):
    PROFILE = ModelProfile(
        alias="gemini_primary",
        provider="gemini",
        model_id=MODEL,
        capabilities=ModelCapabilities(text_generation=True, max_context_tokens=8192, max_output_tokens=4096),
        runs_locally=False,
    )

    def _gateway(self, transport):
        return ModelGateway({"gemini": make(transport)}, max_concurrent_calls=2)

    def test_success_through_gateway(self):
        self.assertEqual(self._gateway(FakeTransport()).generate(self.PROFILE, call(), time.monotonic() + 5, identity=_rid(self.PROFILE)).text,
                         "hello")

    def test_unknown_429_is_one_attempt_and_provider_failed(self):
        t = FakeTransport(status=429, body=b"")
        with self.assertRaises(SanourError) as ctx:
            self._gateway(t).generate(self.PROFILE, call(), time.monotonic() + 5, identity=_rid(self.PROFILE))
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_FAILED)
        self.assertFalse(ctx.exception.retryable)
        self.assertEqual(len(t.calls), 1)

    def test_wrong_model_version_rejected_by_gateway(self):
        t = FakeTransport(body=FakeTransport._ok_body(model="gemini-other-9"))
        with self.assertRaises(SanourError) as ctx:
            self._gateway(t).generate(self.PROFILE, call(), time.monotonic() + 5, identity=_rid(self.PROFILE))
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_INVALID_RESPONSE)


if __name__ == "__main__":
    unittest.main()
