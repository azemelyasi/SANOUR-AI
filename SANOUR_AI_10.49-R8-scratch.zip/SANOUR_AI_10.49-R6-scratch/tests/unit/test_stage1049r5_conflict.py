"""Stage 10.49-R5: controlled operator resolution of terminal conflict rows.

Security model under test (see docs/AUDIT_SINK_BOUNDARY.md):
- only an actor on the controller allowlist may resolve; the allowlist is supplied by the host, not by the caller;
- a non-empty reason (1-500 printable characters) and a well-formed evidence reference are both required;
- the original conflict row and its payload are never changed; the resolution is a new append-only row plus a
  governance_log row, written in one transaction;
- no retry, no deletion, no money movement; duplicate resolutions are refused; the state survives restart.
"""

import logging
import os
import sqlite3
import tempfile
import unittest
from decimal import Decimal

from sanour_ai.governance.admission import AdmissionController
from sanour_ai.governance.sink import DurableSqliteSink
from sanour_ai.governance.store import GovernanceStore
from sanour_ai.governance.types import Settlement
from sanour_ai.observability.audit import AuditLogger
from tests.unit.r4_support import ACTOR
from tests.unit.test_stage1049 import BOUNDS
from tests.unit.test_stage1049r3_outbox import Base

TAMPERED = {"request_id": "req-tampered", "tampered": True}


class Conflict(Base):
    def make_conflict(self):
        rid = self.exposed_request()
        self.sink.down = True
        self.c.write_off(rid, actor=ACTOR, reason="conflicting")
        self.sink.down = False
        key = self.key_for(rid)
        DurableSqliteSink.deliver(self.sink, key, "exposure.resolved", TAMPERED)  # another writer got there first
        self.assertEqual(self.c.deliver_outbox(keys=[key]), 0)
        self.assertEqual(self.c.delivery_states([key]), {key: "conflict"})
        return rid, key

    def resolve(self, key, actor=ACTOR, reason="duplicate from a retried writer", evidence="ticket-2026-1108-7"):
        return self.c.resolve_conflict(key, actor=actor, reason=reason, evidence_ref=evidence)

    def outbox_snapshot(self, key):
        return self.q("SELECT status, attempts, lease_token, receipt_id, fields, last_error FROM audit_outbox "
                      "WHERE event_key = ?", key)[0]

    def sink_fields(self, key):
        conn = sqlite3.connect(self.path + ".sink")
        try:
            return conn.execute("SELECT fields FROM audit_receipts WHERE outbox_key = ?", (key,)).fetchone()[0]
        finally:
            conn.close()

    # ---------------------------------------------------------------- authorization and input
    def test_unauthorized_actor_is_refused_and_changes_nothing(self):
        rid, key = self.make_conflict()
        before = self.outbox_snapshot(key)
        spent = self.spent()
        result = self.resolve(key, actor="intruder")
        self.assertFalse(result.applied)
        self.assertEqual(result.reason, "unauthorized")
        self.assertEqual(self.one("SELECT COUNT(*) FROM conflict_resolutions"), 0)
        self.assertEqual(self.outbox_snapshot(key), before)
        self.assertEqual(self.spent(), spent)
        self.assertEqual(self.one("SELECT COUNT(*) FROM governance_log WHERE operation = 'conflict_resolve' "
                                  "AND outcome = 'refused'"), 1)

    def test_missing_or_malformed_reason_is_refused(self):
        _, key = self.make_conflict()
        for reason in ("", " ", "x" * 501, "line\nbreak"):
            with self.subTest(reason=reason[:20]):
                result = self.resolve(key, reason=reason)
                self.assertEqual((result.applied, result.reason), (False, "invalid_input"))
        self.assertEqual(self.one("SELECT COUNT(*) FROM conflict_resolutions"), 0)

    def test_missing_or_malformed_evidence_is_refused(self):
        _, key = self.make_conflict()
        for evidence in (None, "", "has space", "x;DROP TABLE audit_outbox", "a" * 129, "bad\nref"):
            with self.subTest(evidence=str(evidence)[:20]):
                result = self.resolve(key, evidence=evidence)
                self.assertEqual((result.applied, result.reason), (False, "invalid_input"))
        self.assertEqual(self.one("SELECT COUNT(*) FROM conflict_resolutions"), 0)

    def test_malformed_key_and_unknown_key_are_refused(self):
        self.make_conflict()
        self.assertEqual(self.resolve("gov:1:x y").reason, "invalid_input")
        self.assertEqual(self.resolve("gov:999999:exposure.resolved").reason, "not_found")

    def test_only_a_conflict_row_can_be_resolved(self):
        rid = self.exposed_request()
        self.c.write_off(rid, actor=ACTOR, reason="delivered normally")
        key = self.key_for(rid)
        self.assertEqual(self.c.delivery_states([key]), {key: "confirmed"})
        result = self.resolve(key)
        self.assertEqual((result.applied, result.reason), (False, "not_conflict"))

    # ---------------------------------------------------------------- the resolution itself
    def test_authorized_resolution_is_appended_and_the_original_row_is_preserved(self):
        _, key = self.make_conflict()
        before = self.outbox_snapshot(key)
        sink_before = self.sink_fields(key)
        spent, written_off = self.spent(), self.written_off()
        result = self.resolve(key)
        self.assertTrue(result.applied)
        self.assertEqual(result.reason, "resolved")
        self.assertEqual(result.audit_status, "conflict_resolved")
        self.assertEqual(self.outbox_snapshot(key), before, "the conflict row and its payload are unchanged")
        self.assertEqual(self.sink_fields(key), sink_before, "the sink record is unchanged")
        self.assertEqual(self.c.delivery_states([key]), {key: "conflict_resolved"})
        row = self.q("SELECT actor, reason, evidence_ref, decision, original_digest, log_id FROM conflict_resolutions "
                     "WHERE event_key = ?", key)[0]
        self.assertEqual(row[:4], (ACTOR, "duplicate from a retried writer", "ticket-2026-1108-7", "acknowledged"))
        self.assertEqual(len(row[4]), 64)
        self.assertEqual(self.one("SELECT operation || ':' || outcome || ':' || actor FROM governance_log "
                                  "WHERE log_id = ?", row[5]), f"conflict_resolve:ok:{ACTOR}")
        self.assertEqual((self.spent(), self.written_off()), (spent, written_off), "no money moves")

    def test_a_failed_resolution_write_leaves_no_log_entry_and_no_resolution(self):
        from tests.unit.r5_support import RaiseOn
        _, key = self.make_conflict()
        real = self.s._conn  # noqa: SLF001
        self.s._conn = RaiseOn(real, "INSERT INTO conflict_resolutions")  # noqa: SLF001
        result = self.resolve(key)
        self.s._conn = real  # noqa: SLF001
        self.assertEqual(result.reason, "storage_error")
        self.assertEqual(self.one("SELECT COUNT(*) FROM conflict_resolutions"), 0)
        self.assertEqual(self.one("SELECT COUNT(*) FROM governance_log WHERE operation = 'conflict_resolve' "
                                  "AND outcome = 'ok'"), 0, "the decision log and its resolution commit together")
        self.assertEqual(self.outbox_snapshot(key)[0], "conflict")

    def test_resolution_is_never_retried_against_the_sink(self):
        _, key = self.make_conflict()
        self.assertTrue(self.resolve(key).applied)
        attempts = len(self.sink.attempts)
        self.assertEqual(self.c.deliver_outbox(), 0)
        self.assertEqual(len(self.sink.attempts), attempts)

    def test_duplicate_resolution_is_refused_and_the_first_one_stands(self):
        _, key = self.make_conflict()
        first = self.resolve(key, reason="first decision", evidence="ticket-1")
        second = self.resolve(key, reason="second decision", evidence="ticket-2")
        self.assertTrue(first.applied)
        self.assertEqual((second.applied, second.reason), (False, "already_resolved"))
        self.assertEqual(self.one("SELECT COUNT(*) FROM conflict_resolutions"), 1)
        self.assertEqual(self.q("SELECT reason, evidence_ref FROM conflict_resolutions")[0],
                         ("first decision", "ticket-1"))

    def test_resolution_survives_restart_and_stays_terminal(self):
        _, key = self.make_conflict()
        self.assertTrue(self.resolve(key).applied)
        self.clock.now += 1000
        store = GovernanceStore(self.path)
        self.addCleanup(store.close)
        sink = DurableSqliteSink(self.path + ".sink")
        self.addCleanup(sink.close)
        c2 = AdmissionController(store, audit=AuditLogger(logging.getLogger("test.r5.conflict.restart")),
                                 bounds=BOUNDS, clock=self.clock, authorized_actors=frozenset({ACTOR}), sink=sink)
        self.assertEqual(c2.delivery_states([key]), {key: "conflict_resolved"})
        self.assertEqual(c2.deliver_outbox(), 0)
        self.assertEqual(c2.resolve_conflict(key, actor=ACTOR, reason="again", evidence_ref="ticket-3").reason,
                         "already_resolved")

    # ---------------------------------------------------------------- append-only enforcement in the database
    def test_resolution_rows_cannot_be_updated_or_deleted(self):
        _, key = self.make_conflict()
        self.assertTrue(self.resolve(key).applied)
        conn = sqlite3.connect(self.path)
        self.addCleanup(conn.close)
        with self.assertRaises(sqlite3.Error):
            conn.execute("UPDATE conflict_resolutions SET reason = 'rewritten'")
        with self.assertRaises(sqlite3.Error):
            conn.execute("DELETE FROM conflict_resolutions")
        self.assertEqual(self.q("SELECT reason FROM conflict_resolutions")[0][0], "duplicate from a retried writer")

    def test_conflict_rows_cannot_be_updated_or_deleted_even_after_resolution(self):
        _, key = self.make_conflict()
        self.assertTrue(self.resolve(key).applied)
        conn = sqlite3.connect(self.path)
        self.addCleanup(conn.close)
        with self.assertRaises(sqlite3.Error):
            conn.execute("UPDATE audit_outbox SET status = 'pending' WHERE event_key = ?", (key,))
        with self.assertRaises(sqlite3.Error):
            conn.execute("DELETE FROM audit_outbox WHERE event_key = ?", (key,))
        self.assertEqual(self.q("SELECT status FROM audit_outbox WHERE event_key = ?", key)[0][0], "conflict")


class MigrationSix(unittest.TestCase):
    def test_v5_database_upgrades_with_existing_reservations_open_and_append_only_tables(self):
        from sanour_ai.governance.store import _MIGRATIONS
        path = os.path.join(tempfile.mkdtemp(), "v5.db")
        conn = sqlite3.connect(path, isolation_level=None)
        for version in (1, 2, 3, 4, 5):
            for statement in _MIGRATIONS[version].split(";\n"):
                if statement.strip():
                    conn.execute(statement)
        conn.execute("CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, applied_at INTEGER)")
        conn.execute("INSERT INTO schema_migrations VALUES (1, 0), (2, 0), (3, 0), (4, 0), (5, 0)")
        conn.execute("INSERT INTO reservations (request_id, state, provider_id, model_id, profile_id, utc_day, "
                     "created_at, expires_at) VALUES ('old', 'settled', 'openai', 'm', 'p', '2026-11-07', 0, 0)")
        conn.close()
        store = GovernanceStore(path)
        self.addCleanup(store.close)
        self.assertEqual(store.schema_version(), 6)
        self.assertEqual(store.read(lambda c: c.execute("SELECT admission_gate FROM reservations").fetchone())[0], "open")
        names = {row[0] for row in store.read(lambda c: c.execute(
            "SELECT name FROM sqlite_master WHERE type IN ('table', 'trigger')").fetchall())}
        self.assertIn("conflict_resolutions", names)
        self.assertIn("conflict_resolutions_no_update", names)
        self.assertTrue(store.integrity_ok())


if __name__ == "__main__":
    unittest.main()
