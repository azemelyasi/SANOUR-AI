"""Grok (xAI) adapter tests. Fake transport only: no network, no real key, no SDK."""

from tests.support import request_identity_for as _rid
import json
import time
import unittest
import urllib.error
import urllib.request

from pydantic import SecretStr

from sanour_ai.config.settings import ConfigError
from sanour_ai.errors import ErrorCode, SanourError
from sanour_ai.models.base import ModelCall, ModelResult, ProviderError
from sanour_ai.models.capabilities import ModelCapabilities, ModelProfile, ProviderCapabilities
from sanour_ai.models.gateway import ModelGateway
from sanour_ai.providers.grok_provider import (
    PINNED_URL,
    GrokProvider,
    _RefuseRedirects,
    load_xai_api_key,
)

FAKE_KEY = "xai-TESTONLY-0123456789"
MODEL = "grok-test-1"


class FakeTransport:
    def __init__(self, status=200, body=None, raise_exc=None):
        self.status = status
        self.body = body if body is not None else self._ok_body()
        self.raise_exc = raise_exc
        self.calls = []

    @staticmethod
    def _ok_body(text="hello", model=MODEL):
        return json.dumps({
            "choices": [{"message": {"role": "assistant", "content": text}, "finish_reason": "stop"}],
            "model": model,
        }).encode("utf-8")

    def __call__(self, url, headers, body, timeout):
        self.calls.append({"url": url, "headers": headers, "body": body, "timeout": timeout})
        if self.raise_exc is not None:
            raise self.raise_exc
        return self.status, self.body


def call(deadline_in=5.0, model=MODEL, max_tokens=64, prompt="hi"):
    return ModelCall(model_id=model, prompt=prompt, max_output_tokens=max_tokens,
                     deadline=time.monotonic() + deadline_in)


def make(transport):
    return GrokProvider(SecretStr(FAKE_KEY), transport=transport)


class CapabilityDeclarationTests(unittest.TestCase):
    def test_declares_only_text_generation(self):
        self.assertEqual(GrokProvider.capabilities, ProviderCapabilities(text_generation=True))
        self.assertEqual(GrokProvider.name, "grok")


class AuthenticationTests(unittest.TestCase):
    def test_key_read_from_environment_and_stripped(self):
        self.assertEqual(load_xai_api_key({"XAI_API_KEY": " abc "}).get_secret_value(), "abc")

    def test_missing_or_blank_key_names_setting_not_value(self):
        for env in ({}, {"XAI_API_KEY": "  "}):
            with self.subTest(env=env), self.assertRaises(ConfigError) as ctx:
                load_xai_api_key(env)
            self.assertIn("XAI_API_KEY", str(ctx.exception))

    def test_adapter_requires_secret_str_with_content(self):
        with self.assertRaises(ConfigError):
            GrokProvider("plain", transport=FakeTransport())
        with self.assertRaises(ConfigError):
            GrokProvider(SecretStr(" "), transport=FakeTransport())


class RequestShapeTests(unittest.TestCase):
    def test_pinned_url_and_bearer_header_key_not_in_url(self):
        t = FakeTransport()
        make(t).generate(call())
        sent = t.calls[0]
        self.assertEqual(sent["url"], PINNED_URL)
        self.assertNotIn(FAKE_KEY, sent["url"])
        self.assertEqual(sent["headers"]["authorization"], f"Bearer {FAKE_KEY}")
        self.assertNotIn("key=", sent["url"])

    def test_model_id_only_in_body_not_in_url(self):
        t = FakeTransport()
        make(t).generate(call())
        self.assertNotIn(MODEL, t.calls[0]["url"])
        self.assertEqual(json.loads(t.calls[0]["body"])["model"], MODEL)

    def test_body_carries_prompt_limit_and_no_streaming(self):
        t = FakeTransport()
        make(t).generate(call(max_tokens=64, prompt="ping"))
        self.assertEqual(json.loads(t.calls[0]["body"]), {
            "model": MODEL,
            "messages": [{"role": "user", "content": "ping"}],
            "max_tokens": 64,
            "stream": False,
        })

    def test_timeout_is_min_of_cap_and_remaining_budget(self):
        t = FakeTransport()
        make(t).generate(call(deadline_in=2.0))
        self.assertLessEqual(t.calls[0]["timeout"], 2.0)
        self.assertGreater(t.calls[0]["timeout"], 1.0)

    def test_missing_deadline_refused_before_io(self):
        t = FakeTransport()
        with self.assertRaises(ProviderError):
            make(t).generate(ModelCall(model_id=MODEL, prompt="p", max_output_tokens=8, deadline=None))
        self.assertEqual(t.calls, [])

    def test_expired_deadline_makes_no_call(self):
        t = FakeTransport()
        with self.assertRaises(ProviderError) as ctx:
            make(t).generate(ModelCall(model_id=MODEL, prompt="p", max_output_tokens=8,
                                       deadline=time.monotonic() - 1))
        self.assertTrue(ctx.exception.retryable)
        self.assertEqual(t.calls, [])

    def test_invalid_model_id_refused_before_io(self):
        for bad in ("../other", "a/b", "x?key=1", "", "m" * 129, "name with space", "-leading"):
            with self.subTest(bad=bad):
                t = FakeTransport()
                with self.assertRaises(ProviderError) as ctx:
                    make(t).generate(call(model=bad))
                self.assertFalse(ctx.exception.retryable)
                self.assertEqual(t.calls, [])


class ResponseParsingTests(unittest.TestCase):
    def test_content_and_model_echoed(self):
        self.assertEqual(make(FakeTransport()).generate(call()), ModelResult(text="hello", reported_model_id=MODEL))

    def test_malformed_bodies_yield_empty_result_for_gateway_to_reject(self):
        for body in (b"not json", b"[]", b'{"choices": []}',
                     b'{"choices": [{"message": 1, "finish_reason": "stop"}]}',
                     b'{"choices": [{"message": {"content": 5}, "finish_reason": "stop"}]}'):
            with self.subTest(body=body):
                self.assertEqual(make(FakeTransport(body=body)).generate(call()).text, "")

    def test_oversized_response_refused(self):
        with self.assertRaises(ProviderError):
            make(FakeTransport(body=b"x" * 2_000_001)).generate(call())


class ErrorMappingTests(unittest.TestCase):
    def test_status_codes_map_to_expected_retryability(self):
        cases = [(429, False), (401, False), (403, False), (404, False), (400, False),
                 (500, True), (503, True), (418, False)]
        for status, retryable in cases:
            with self.subTest(status=status):
                with self.assertRaises(ProviderError) as ctx:
                    make(FakeTransport(status=status, body=b"")).generate(call())
                self.assertEqual(ctx.exception.retryable, retryable)

    def test_unknown_429_is_not_transient(self):
        # Stage 10.28: no structural 429 code is confirmed for this provider, so it is unknown.
        with self.assertRaises(ProviderError) as ctx:
            make(FakeTransport(status=429, body=b"")).generate(call())
        self.assertIsNone(getattr(ctx.exception, "error_code", None))
        self.assertEqual(ctx.exception.failure_reason, "unknown")
        self.assertFalse(ctx.exception.retryable)

    def test_network_failure_retryable_and_hides_details(self):
        t = FakeTransport(raise_exc=urllib.error.URLError("dns failed for internal-host xai-LEAKME"))
        with self.assertRaises(ProviderError) as ctx:
            make(t).generate(call())
        self.assertTrue(ctx.exception.retryable)
        self.assertNotIn("LEAKME", str(ctx.exception))

    def test_error_body_and_key_never_reach_exception_text(self):
        t = FakeTransport(status=401, body=b'{"error": "bad xai-SECRETBODY"}')
        with self.assertRaises(ProviderError) as ctx:
            make(t).generate(call())
        text = str(ctx.exception) + repr(ctx.exception)
        self.assertNotIn("SECRETBODY", text)
        self.assertNotIn(FAKE_KEY, text)

    def test_redirects_are_refused(self):
        with self.assertRaises(urllib.error.HTTPError):
            _RefuseRedirects().redirect_request(urllib.request.Request(PINNED_URL), None, 302, "Found", {},
                                                "https://evil.example/")


class GatewayIntegrationTests(unittest.TestCase):
    PROFILE = ModelProfile(
        alias="grok_primary",
        provider="grok",
        model_id=MODEL,
        capabilities=ModelCapabilities(text_generation=True, max_context_tokens=8192, max_output_tokens=4096),
        runs_locally=False,
    )

    def _gateway(self, transport):
        return ModelGateway({"grok": make(transport)}, max_concurrent_calls=2)

    def test_success_through_gateway(self):
        self.assertEqual(self._gateway(FakeTransport()).generate(self.PROFILE, call(), time.monotonic() + 5, identity=_rid(self.PROFILE)).text,
                         "hello")

    def test_unknown_429_is_one_attempt_and_provider_failed(self):
        t = FakeTransport(status=429, body=b"")
        with self.assertRaises(SanourError) as ctx:
            self._gateway(t).generate(self.PROFILE, call(), time.monotonic() + 5, identity=_rid(self.PROFILE))
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_FAILED)
        self.assertFalse(ctx.exception.retryable)
        self.assertEqual(len(t.calls), 1)

    def test_wrong_model_version_rejected_by_gateway(self):
        t = FakeTransport(body=FakeTransport._ok_body(model="grok-other-9"))
        with self.assertRaises(SanourError) as ctx:
            self._gateway(t).generate(self.PROFILE, call(), time.monotonic() + 5, identity=_rid(self.PROFILE))
        self.assertEqual(ctx.exception.code, ErrorCode.PROVIDER_INVALID_RESPONSE)


if __name__ == "__main__":
    unittest.main()
